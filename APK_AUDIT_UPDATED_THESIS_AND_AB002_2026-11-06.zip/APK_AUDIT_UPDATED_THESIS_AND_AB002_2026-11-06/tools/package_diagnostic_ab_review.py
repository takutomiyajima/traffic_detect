#!/usr/bin/env python3
"""Package derived AB002 documents; exclude APKs, captures and raw logs."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATE = '2026-11-06'


def main():
    dist = ROOT / 'dist'
    dist.mkdir(exist_ok=True)
    stem = 'APK_AUDIT_UPDATED_THESIS_AND_AB002_' + DATE
    stage = dist / stem
    if stage.exists():
        raise SystemExit('Preserve the existing distribution; choose another name.')
    stage.mkdir()
    files = set()

    def closure(path):
        path = path.resolve()
        if path in files:
            return
        path.relative_to(ROOT)
        if not path.is_file():
            raise FileNotFoundError(path)
        files.add(path)
        if path.suffix == '.tex':
            for kind, name in re.findall(r'\\(input|include|includegraphics)(?:\[[^\]]*\])?\{([^}]+)\}', path.read_text()):
                dependency = ROOT / 'docs' / name
                if not dependency.suffix and kind != 'includegraphics':
                    dependency = dependency.with_suffix('.tex')
                closure(dependency)

    for name in ['docs/thesis.tex', 'docs/thesis.pdf',
                 'docs/diagnostic-ab-002-review-2026-11-06.tex',
                 'docs/diagnostic-ab-002-review-2026-11-06.pdf',
                 'docs/research/diagnostic-ab-002-review-2026-11-06.md',
                 'tools/build_thesis.sh', 'tools/build_beginner_guide.py',
                 'tools/build_diagnostic_ab_report.py',
                 'tools/review_diagnostic_study.py',
                 'tools/review_diagnostic_raw_controls.py',
                 'tools/package_diagnostic_ab_review.py']:
        closure(ROOT / name)
    for path in (ROOT / 'docs/research/diagnostic-ab002-verified-2026-11-06').iterdir():
        if path.suffix in {'.json', '.csv'}:
            closure(path)
    for path in sorted(files):
        assert path.suffix not in {'.apk', '.pcap', '.pcapng', '.jsonl'}
        target = stage / path.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)

    readme = '''# URI切替4試行の原本確認と論文更新（2026-11-06）

まず docs/diagnostic-ab-002-review-2026-11-06.pdf（5ページ）をご覧ください。
docs/thesis.pdf は結果を反映した42ページの卒業論文草稿です。
docs/research/diagnostic-ab002-verified-2026-11-06/trial-results.csv に4試行を記載しています。

同一APK・同一AVDのABBA4試行で、指定URIへの対象UID要求・200応答・184 Bの保持本文を確認しました。
既存25試行と追加4試行は別群で、合計29試行は29アプリや独立標本ではありません。
全試行の品質partialを維持します。3試行目にUID不明UDPが1フローあり、対象アプリには帰属させません。
1試行目は停止統計123パケットに対し保存PCAP124パケットで、末尾の対象外UDP1パケットの差を保存しました。
今回の成立確認から一般精度・因果・選択方式の優越・方法上の新規性を確定しません。

原本APK、PCAP、通信本文ログ、ユーザーのホームディレクトリ、提供された論文PDFは収録していません。
本ZIPは資料と集計・点検ソースの配布です。Mac側の解析プログラムを更新するパッチではありません。

TeX再生成: XeLaTeX、Noto Serif CJK JP、Noto Sans CJK JP、DejaVu Sans Mono、一般的なTeXパッケージを用意し、
このフォルダで bash tools/build_thesis.sh を実行します。短いレポートは完成TeXをdocs内でXeLaTeXで3回処理できます。
レポートのPythonビルダーと原本点検ツールは研究リポジトリ・非公開原本・信頼済み配布版を前提とします。
この資料ZIPだけでは原本検証やAndroid実験を再実行できません。

著者情報と大学の提出書式は未確定です。AIによる点検を第三者の独立評価とはしません。
'''
    (stage / 'README.md').write_text(readme)
    summary = json.loads((ROOT / 'docs/research/diagnostic-ab002-verified-2026-11-06/review-summary.json').read_text())
    entries = []
    for path in sorted(stage.rglob('*')):
        if path.is_file():
            entries.append({'path': path.relative_to(stage).as_posix(), 'bytes': path.stat().st_size,
                            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    manifest = {'date': DATE, 'kind': 'derived_documents_and_review_sources',
                'thesis_pages': 42, 'review_pages': 5,
                'input_archive_sha256': summary['archive_sha256'],
                'originals_unchanged': True, 'new_cloud_device_trials': 0,
                'quality': 'partial', 'independent_accuracy_established': False,
                'visual_review': 'All 47 pages inspected in contact sheets; result page inspected at larger scale.',
                'files': entries}
    (stage / 'MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    zip_path = dist / (stem + '.zip')
    if zip_path.exists():
        raise SystemExit('Archive already exists')
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(stage.rglob('*')):
            if path.is_file():
                archive.write(path, path.relative_to(dist))
    standalone = {
        'APK_AUDIT_DIAGNOSTIC_AB002_REVIEW_' + DATE + '.pdf': ROOT / 'docs/diagnostic-ab-002-review-2026-11-06.pdf',
        'APK_AUDIT_UPDATED_THESIS_' + DATE + '.pdf': ROOT / 'docs/thesis.pdf',
        'APK_AUDIT_DIAGNOSTIC_AB002_RESULTS_' + DATE + '.csv': ROOT / 'docs/research/diagnostic-ab002-verified-2026-11-06/trial-results.csv',
    }
    for name, source in standalone.items():
        shutil.copy2(source, dist / name)
    downloads = Path('/workspace/downloads')
    downloads.mkdir(exist_ok=True)
    for path in [zip_path] + [dist / name for name in standalone]:
        shutil.copy2(path, downloads / path.name)
        print(json.dumps({'name': path.name, 'bytes': path.stat().st_size,
                          'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()
