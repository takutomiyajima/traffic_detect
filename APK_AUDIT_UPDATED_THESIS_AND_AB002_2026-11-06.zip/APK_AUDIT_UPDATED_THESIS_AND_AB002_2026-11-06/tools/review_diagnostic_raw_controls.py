#!/usr/bin/env python3
"""Supplemental raw nonce checks on an already restored diagnostic study."""
from pathlib import Path
import argparse
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tools")]
from apk_audit.core import read_json, sha256, write_json
from apk_audit.research_diagnosis import verify_run
from review_automatic_archive import packet_headers


def inspect(study):
    study = Path(study)
    result = []
    for trial in read_json(study / "trials.json"):
        directory = study / trial["directory"]
        run = verify_run(directory)
        headers, _ = packet_headers(directory / "raw/automatic.pcap", read_json(directory / "automatic.metadata.json"))
        server = [__import__("json").loads(x) for x in (directory / "raw/automatic-controls.jsonl").read_text().splitlines() if x.strip()]
        probes = [r for r in read_json(directory / "raw/bridge-results.json") if r["action"] == "probe"]
        packets = []
        for probe in probes:
            hits = [h for h in headers if h["uid"] == run["bridge_uid"] and h["run_marker"] == probe["request_id"]
                    and h["method"] == "GET" and h["destination_port"] == run["control_port"]]
            received = [s for s in server if s.get("run_id") == probe["request_id"] and s.get("event") == "http_request_received"]
            assert len(hits) == len(received) == 1
            packets.append(hits[0]["packet"])
        assert len(packets) == 2
        result.append({"trial_id": trial["trial_id"], "raw_pre_control_packet": packets[0],
                       "raw_post_control_packet": packets[1], "UID_nonce_and_server_match": True})
    return {"kind": "raw_control_request_nonce_cross_check", "script_sha256": sha256(Path(__file__)),
            "trials": result, "new_device_trials": 0, "independent_capture_accuracy": False}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--study", type=Path, required=True);p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    if a.out.exists():raise ValueError("Choose a new audit output")
    write_json(a.out, inspect(a.study))
