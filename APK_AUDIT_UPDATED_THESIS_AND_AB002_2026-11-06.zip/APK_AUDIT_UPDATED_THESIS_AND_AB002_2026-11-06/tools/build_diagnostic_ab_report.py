#!/usr/bin/env python3
"""Build a five-page Japanese report from the verified AB002 review table."""
from pathlib import Path
import json
import os
import subprocess

import build_beginner_guide as base

ROOT = Path(__file__).resolve().parents[1]


def main():
    review = json.loads((ROOT / 'runs/diagnostic-ab-002-reviewed-2026-11-06/audit-v3/review.json').read_text())
    assert review['status'] == 'verified_selected_environment_input_association'
    rows = review['rows']
    table = '\n'.join(f"| {i}：{r['arm']} | {r['packets']}パケット・{r['flows']}フロー | 対象{r['target_flows']}・別UID{r['other_flows']}・不明{r['unknown_flows']} |" for i, r in enumerate(rows, 1))
    requests = '\n'.join(f"| {i}：{r['arm']} | {r['port']}番、要求パケット{r['request_packet']} | 200、本文{r['rss_body_bytes']} B |" for i, r in enumerate(rows, 1))
    source = '''# URI入力切替4試行の原本確認レポート

## 01｜結論：4試行の成立を原本から確認

**diagnostic-ab-002は、選定したMac・Androidエミュレータ環境で、A・B・B・Aの4試行が成立したことを原本から確認できました。**

対象はAntennaPod 3.12.3の同じAPKと、API35・arm64の同じAVDです。入力Aは59521番、入力Bは59522番の研究用サーバーへ向けました。各試行の要求パスには別のnonceを使っています。

:::diagram ab_review

PCAPの対象UID要求、サーバー受信記録の候補対応、前後対照、同一APK、実行シナリオ、時計補正、hashを点検しました。静的解析、通信フロー、規則判定、対応表、保存された診断の再計算も一致しました。

:::key 今回、更新できる主張
「新ランナーのAndroid実測は未確認」から、「このAPK・この環境・この入力操作での成立を原本確認した」へ更新できます。一般的な精度、因果の確定、操作選択方式の優越は別の評価です。
:::

ZIPと原本は保持し、解析は別フォルダで行いました。復元した136ファイルに変更はありません。クラウドで新しい端末試行は実行していません。

:::source 2026年11月6日受領の返却ZIP。原本コードは実行せず、既知配布版のhashと照合。

<!-- page -->
## 02｜実際に見つかった要求と通信記録

| 試行 | 制御した宛先と要求位置 | 応答 |
| --- | --- | --- |
''' + requests + '''

対象の4要求はUID10213で、各試行とも対象フローは1件です。保持した応答本文184 Bは、既知配布版のサーバー仕様から再構成したRSS本文に一致しました。アプリが全文を処理した証明にはしません。

| 試行 | PCAP全体の記録量 | フローの帰属 |
| --- | --- | --- |
''' + table + '''

各試行の静的候補は38宛先組で、対象要求に対応する候補はなく、動的のみ1行でした。3試行目だけ、これに帰属不明の判断不能1行が加わります。38組と1フローを引いて欠落数にはしません。

:::key 観測の単位を混ぜない
パケット、フロー、要求、宛先組、試行は別の単位です。前後対照は各2要求で、補助UIDの要求パケットと固有マーカー、サーバー記録も照合しました。4試行の成立を精度100%とは呼びません。
:::

:::source 全4 PCAPからのフロー再生成、UID合意、限定HTTP本文検査。元のCSV集計と同じ標本とはしない。

<!-- page -->
## 03｜残った不確実性も原本どおり保持

### 3試行目のUID不明UDP

UID不明のUDP/443フロー1件があり、パケットは2件です。これをAntennaPodの通信へ割り当てていません。ポート番号だけでQUIC成立や送信アプリ、通信目的を決めません。対象のHTTP要求が確認できたことと、取得全体の帰属が分かることは別です。

### 1試行目の停止統計との差

停止応答の統計は123パケット、保存PCAPは124パケットでした。停止応答のdump byte数は先頭123パケットのレコード量と一致し、末尾には別UID10134のUDPパケットが1件あります。差が生じた仕組みは未確定で、非同期処理のせいと断定していません。目的の要求はパケット43であり、この末尾パケットとは別です。

:::key partialを維持する
4試行とも品質はpartialです。本文や要求の正の証拠があっても、全通信の漏れや、収集器UIDの独立した正しさを保証しません。統計との不一致も消さずに記録します。
:::

時計補正は試行ごとに再計算できました。端末時刻をホスト時刻へ換算する補正差は約0.280〜0.309秒の範囲ですが、これは条件付きの補正です。サーバーとの対応はnonce・宛先・対象UID・時刻による候補対応で、NATの完全な接続同一性ではありません。

:::source 停止応答・raw PCAPの末尾・UID拡張・時計サンプル。対象外通信の相手は公開資料で省略。

<!-- page -->
## 04｜研究で言えることと、まだ言わないこと

| 論点 | 今回の判断 |
| --- | --- |
| 新ランナーの実行 | 指定環境の4試行で成立を原本確認 |
| 静的と動的の差 | 入力先に対応する対象要求が、抽出候補にない実測として現れた |
| 入力との関係 | 登録したURIへの要求と受信記録の候補対応を確認 |
| 因果・コード箇所 | 初期状態未統制。どのコードが原因かを確定していない |
| 一般的な精度 | 独立した正解・比較評価がなく未算出 |
| 手法の新規性 | この1事例だけでは確定しない |

開始状態は既存データを保持し、復元スナップショットは使っていません。入力はポートと試行固有のパスが変わります。追加操作なしの申告は取得後に保存されていますが、全タッチの客観的監視ではありません。

:::key 新規性に対する率直な評価
今回の出力順序は事前に決めたABBAです。このケースでは固定ABBAの計画と選択結果が一致するため、効率や正しさの優位性を測る比較になっていません。限定したA/B操作を自動実行できた成果と、選択アルゴリズムの新規性を区別します。
:::

既存25試行と追加4試行は別群として保存し、受領済み端末試行は合計29件になりました。同一アプリ・同一AVDでの反復を含み、29本の独立したアプリの評価ではありません。

:::source 元の25試行台帳と今回の4試行。失敗した001の起動報告は、この成立4試行へ加えない。

<!-- page -->
## 05｜今回を固定し、次は比較評価へ進む

今回の4試行は「新ランナーの成立確認」として固定します。同じ動作確認を目的なく増やす段階は区切ります。

次の中心課題は、**同じ観測予算で、どれだけ正しい差分説明に到達できるか**です。

1. 評価する説明の種類と、解析器の出力から作らない正解を先に固定する。
2. 文字列のみ、使用文脈の追加、固定の追加実行、選択方式の比較条件をそろえる。
3. 説明の正しさ、保留した範囲、誤断定、必要な追加実行数を併記する。
4. 開発用とは別の評価素材を使い、素材を作った側の偏りも記録する。

文字列結合を文脈解析で補える条件、実行時入力の条件、未操作の条件、取得不足などを事前に分けます。選択方式が有利になるケースだけを結果を見て選びません。精度が同じで実行数が減った場合は、効率改善として評価します。

:::key こちらで完了した作業
原本hashとコード版、同一APK、4試行のPCAP・UID・前後対照・本文・時計・再解析結果を点検し、試行別CSVと論文用の結果表へまとめました。現在、新たな操作や人手レビュー票の記入は求めていません。
:::

解析器・AI・資料に共通する誤りは残り得ます。今回の確認を、第三者による独立評価や一般的な取得精度へ置き換えません。原本の場所とhashは研究者用に保管し、公開配布にはAPK・PCAP・本文ログを含めません。

:::source review_diagnostic_study.py、補助nonce点検、再生成したCSV。新しい端末試行をクラウドで追加していない。
'''
    path = ROOT / 'docs/research/diagnostic-ab-002-review-2026-11-06.md'
    path.write_text(source)
    base.DIAGRAMS['ab_review'] = r'''
\begin{center}\begin{tikzpicture}[box/.style={rounded corners=2mm,fill=mint,draw=none,align=center,text width=31mm,minimum height=24mm,font=\small},a/.style={-{Stealth[length=2mm]},thick,draw=teal}]
\node[box] (a) {1：入力A\\59521番\\GET・200・184 B};
\node[box,right=7mm of a,fill=bluewash] (b) {2：入力B\\59522番\\GET・200・184 B};
\node[box,right=7mm of b,fill=bluewash] (c) {3：入力B\\59522番\\GET・200・184 B};
\node[box,right=7mm of c] (d) {4：入力A\\59521番\\GET・200・184 B};
\draw[a](a)--(b);\draw[a](b)--(c);\draw[a](c)--(d);
\end{tikzpicture}\end{center}'''
    tex = base.render(source, expected_pages=5)
    replacements = {
        'はじめて読む、この研究の全体像':'URI入力切替4試行の原本確認レポート',
        '研究の目的・仕組み・実験・結果・結論を初心者向けに説明する入門ガイド':'diagnostic-ab-002の原本確認と研究上の解釈',
        'APKと通信解析を理解する入門ガイド':'URI入力切替4試行：原本確認レポート',
        '2026年11月5日版':'2026年11月6日版',
        '研究の範囲：指定操作下の解析支援と事例評価':'指定環境の成立確認・一般的な精度と新規性は未評価',
        'RESEARCH GUIDE /':'VERIFIED CASE /',
    }
    for a, b in replacements.items():tex = tex.replace(a, b)
    output = ROOT / 'docs/diagnostic-ab-002-review-2026-11-06.tex';output.write_text(tex)
    env = {**os.environ, 'TEXMFVAR':str(ROOT/'.cache/texmf-var'), 'TEXMFCONFIG':str(ROOT/'.cache/texmf-config'), 'XDG_CACHE_HOME':str(ROOT/'.cache')}
    for _ in range(3):
        subprocess.run(['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error',output.name],cwd=output.parent,env=env,check=True)


if __name__ == '__main__':main()
