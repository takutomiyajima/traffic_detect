#!/usr/bin/env python3
"""Review a received URI contrast study without executing received code/Android.

Versioned archive integrity, source identity, re-import, rules, context and
bounded HTTP case checks. This is not independent ground truth or accuracy.
"""
import argparse
from collections import Counter
import copy
import csv
import hashlib
import ipaddress
import json
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tools")]
from apk_audit.core import read_json, read_jsonl, sha256, timestamp, write_json, write_jsonl
from apk_audit.research_bundle import restore
from apk_audit.research_diagnosis import assess, plan_from_evidence
from apk_audit.capture import import_capture
from apk_audit.compare import compare
from apk_audit.differential import build
from apk_audit.report import report
from review_rss_archive import trusted_release, clock_interval, uid_disagreements
from review_automatic_archive import packet_headers
from analyze_controlled_http_flows import inspect_exchange

APK_HASH = "6e79f28f69cef1a8b2e4f5f88c9c3cf3c3d7c51356f01394ac23b0dc5d56a00b"
PROGRAM_ZIP_HASH = "1730ea04d3c804f5e49cffdefe51c87abdb949712fdaf5c3b67556d7dcfce8f0"


def fingerprint(directory):
    return {str(p.relative_to(directory)): sha256(p) for p in sorted(directory.rglob("*")) if p.is_file()}


def static_facts(value):
    value = copy.deepcopy(value);value.pop("analysis_duration_s", None)
    return value


def inspect_target_http(directory, port):
    import dpkt
    run = read_json(directory / "run.json")
    meta = read_json(directory / "automatic.metadata.json")
    flows = [f for _, f in read_jsonl(directory / "flows.jsonl") if f["attribution"] == "target"]
    payloads = {}
    with (directory / "raw/automatic.pcap").open("rb") as stream:
        for n, (ts, raw) in enumerate(dpkt.pcap.Reader(stream), 1):
            ip = dpkt.ethernet.Ethernet(raw).data
            if isinstance(ip, dpkt.ip.IP) and isinstance(ip.data, dpkt.tcp.TCP) and ip.data.data:
                tcp = ip.data
                payloads[n] = {"packet": n, "seq": tcp.seq, "data": bytes(tcp.data), "epoch": float(ts) + meta["clock_offset_s"],
                               "src": str(ipaddress.ip_address(ip.src)), "dst": str(ipaddress.ip_address(ip.dst)),
                               "sport": tcp.sport, "dport": tcp.dport}
    # Expected bytes from the locally trusted, published v1 server specification.
    # These bytes were not a preregistered feed.xml file in this study.
    expected = (f'<?xml version="1.0"?><rss version="2.0"><channel><title>APK Contrast Research</title>'
                f'<link>http://10.0.2.2:{port}/</link><description>Controlled empty feed</description></channel></rss>').encode()
    rows = []
    for flow in flows:
        if flow["transport"] != "TCP" or flow["port"] != port:
            continue
        parts = [payloads[n] for n in flow["source_record"]["packet_numbers"] if n in payloads]
        incoming = [p for p in parts if p["src"] == flow["destination_ip"] and p["sport"] == port]
        outgoing = [p for p in parts if p not in incoming]
        for request in inspect_exchange(outgoing, incoming):
            response = request["response"]
            rows.append({"flow_id": flow["flow_id"], **request,
                         "expected_body_sha256_from_release_spec": hashlib.sha256(expected).hexdigest(),
                         "body_matches_release_spec": bool(response and response["body_sha256"] == hashlib.sha256(expected).hexdigest())})
    return rows


def review(archive, out, revision="v1"):
    archive, out = Path(archive), Path(out)
    original = out / "original"
    if not out.exists():
        out.mkdir(parents=True);restore(archive, original)
        write_json(out / "RECEIVED-FINGERPRINT.json", {"archive_sha256": sha256(archive), "files": fingerprint(original)})
    registration = read_json(out / "RECEIVED-FINGERPRINT.json")
    assert registration["archive_sha256"] == sha256(archive)
    before = fingerprint(original)
    assert before == registration["files"]
    audit = out / ("audit-" + revision)
    if audit.exists():
        raise ValueError("Audit exists; preserve this review and select a new output folder")
    audit.mkdir()
    published = ROOT / "dist/apk-audit-diagnostic-v1.zip"
    assert sha256(published) == PROGRAM_ZIP_HASH
    with zipfile.ZipFile(published) as archive_file:
        known_extension = {name: hashlib.sha256(archive_file.read("apk-audit-diagnostic-v1/payload/" + name)).hexdigest()
                           for name in ("research_context.py", "research_diagnosis.py", "research_contrast.py", "research_bundle.py")}
    recorded_extension = read_json(original / "RESEARCH-CODE-MANIFEST.json")
    known_base, _ = trusted_release()
    assert recorded_extension["files"] == known_extension
    assert recorded_extension["base_pipeline_sha256"] == known_base["pipeline.py"]
    plan = read_json(original / "study-plan.json")
    assert plan["apk_sha256"] == APK_HASH and plan["order"] == ["A", "B", "B", "A"]
    baseline = ROOT / "runs/antennapod-rss-preview-006-reviewed-2026-11-05/original"
    basis = plan["selection"]["evidence_basis"]["source_sha256"]
    assert all(sha256(baseline / name) == digest for name, digest in basis.items())
    context = read_json(original / "context.json")
    assert plan_from_evidence(baseline, context, pairs=2, budget=4) == plan["selection"]
    cloud_context = read_json(ROOT / "runs/research-context-smoke-2026-11-06/antennapod-context-final.json")
    assert {k: v for k, v in context.items() if k != "worker_resource_limits"} == {
        k: v for k, v in cloud_context.items() if k != "worker_resource_limits"}
    static_dir = out / "static-reparse"
    if not static_dir.exists():
        from apk_audit.cli import static_stage
        static_stage(original / "trial-001-A/raw/original.apk", static_dir)
    reference_static = read_json(static_dir / "static.json")
    assert reference_static["apk_sha256"] == APK_HASH
    replay = out / ("recomputed-" + revision)
    if replay.exists():
        raise ValueError("Recomputed outputs exist; select a new review folder")
    replay.mkdir()
    rows, detail = [], []
    for trial in read_json(original / "trials.json"):
        directory = original / trial["directory"]
        run = read_json(directory / "run.json")
        assert run["apk_sha256"] == sha256(directory / "raw/original.apk") == APK_HASH
        assert timestamp(plan["prepared_utc"]) <= timestamp(run["created_utc"])
        code = read_json(directory / "raw/analysis-code-manifest.json")
        assert sha256(directory / "raw/analysis-code-manifest.json") == run["analysis_code_manifest_sha256"]
        assert code["files"] == known_base
        assert static_facts(read_json(directory / "static.json")) == static_facts(reference_static)
        identity = read_json(directory / "raw/installation-identity.json")
        assert identity == {"package": run["package"], "uid": run["target_uid"], "bridge_uid": run["bridge_uid"], "apk_sha256": APK_HASH}
        meta = read_json(directory / "automatic.metadata.json")
        lower, upper = clock_interval(meta, read_json(directory / "raw/clock-samples.json"))
        assert sha256(directory / "raw/automatic.pcap") == sha256(directory / "raw/capture-1.pcap")
        headers, packets = packet_headers(directory / "raw/automatic.pcap", meta)
        saved_flows = [f for _, f in read_jsonl(directory / "flows.jsonl")]
        assert not uid_disagreements(saved_flows, packets, run["target_uid"])
        controls = read_json(directory / "raw/bridge-results.json")
        stop_results = [x["result"] for x in controls if x.get("action") == "stop"]
        assert len(stop_results) == 1
        stop = stop_results[0]
        reported_packets = stop["pkts_sent"] + stop["pkts_rcvd"]
        import dpkt
        with (directory / "raw/automatic.pcap").open("rb") as stream:
            frames = [raw for _, raw in dpkt.pcap.Reader(stream)]
        prefix_bytes = sum(16 + len(raw) for raw in frames[:reported_packets])
        terminal_uids = []
        if len(frames) > reported_packets:
            from apk_audit.pcapdroid import trailer_uid
            terminal_uids = [trailer_uid(raw) for raw in frames[reported_packets:]]
        counter_note = {"stop_reported_packets": reported_packets, "retained_packets": len(packets),
                        "packet_delta": len(packets) - reported_packets,
                        "stop_reported_dump_bytes": stop["bytes_dumped"],
                        "prefix_record_bytes": prefix_bytes,
                        "dump_counter_matches_record_prefix": prefix_bytes == stop["bytes_dumped"],
                        "extra_terminal_packet_UIDs": terminal_uids,
                        "interpretation": "Counter snapshot differs from retained file; do not assert the asynchronous cause." if terminal_uids else "Counters agree."}
        events = [r for _, r in read_jsonl(directory / "ui_events.jsonl")]
        assert len(events) == 2 and all(e["success"] for e in events)
        expected_scenario = next(p["scenario"] for p in plan["trials"] if p["trial_id"] == trial["trial_id"])
        assert run["analysis_scenario"] == expected_scenario
        assert all(timestamp(e["ended_utc"]) - timestamp(e["started_utc"]) >= s["observe_s"]
                   for e, s in zip(events, expected_scenario["steps"]))
        destination = replay / trial["directory"]
        shutil.copytree(directory, destination)
        replay_run = copy.deepcopy(run);replay_run.update(captures=[], analysis_mode="replay")
        write_json(destination / "run.json", replay_run);write_jsonl(destination / "flows.jsonl", [])
        import_capture(destination, directory / "raw/automatic.pcap", directory / "automatic.metadata.json", "pcapdroid-pcap")
        assert [f for _, f in read_jsonl(destination / "flows.jsonl")] == saved_flows
        findings = compare(destination, read_json(directory / "intent.json"))
        assert findings == read_json(directory / "findings.json")
        report(destination)
        correspondence = build(destination)
        saved_correspondence = read_json(directory / "correspondence.json")
        assert {k: v for k, v in correspondence.items() if k != "analysis_mode"} == {
            k: v for k, v in saved_correspondence.items() if k != "analysis_mode"}
        http_rows = inspect_target_http(directory, plan["endpoints"][trial["arm"]])
        assert len(http_rows) == 1
        request = http_rows[0]
        assert request["method"] == "GET" and request["path"] == trial["url"].split(str(plan["endpoints"][trial["arm"]]), 1)[1]
        assert request["response"]["status"] == 200 and request["response"]["body_bytes"] == 184 and request["body_matches_release_spec"]
        owners = Counter(f["attribution"] for f in saved_flows)
        unknown = [f for f in saved_flows if f["attribution"] == "unknown"]
        row = {"trial_id": trial["trial_id"], "arm": trial["arm"], "port": plan["endpoints"][trial["arm"]],
               "packets": len(packets), "flows": len(saved_flows), "target_flows": owners["target"],
               "other_flows": owners["other"], "unknown_flows": owners["unknown"],
               "request_packet": request["request_packets"][0], "http_status": 200, "rss_body_bytes": 184,
               "static_groups": correspondence["static_candidate_counts"]["endpoint_groups"],
               **{k: correspondence["counts"][k] for k in ("both", "static_only", "dynamic_only", "indeterminate")},
               "clock_lower_s": lower, "clock_upper_s": upper, "quality": run["dynamic_status"],
               "stop_reported_packets": reported_packets, "packet_counter_delta": len(packets) - reported_packets,
               "input_window_s": round(timestamp(events[1]["ended_utc"]) - timestamp(events[1]["started_utc"]), 6)}
        rows.append(row)
        detail.append({"trial_id": trial["trial_id"], "run_id": run["run_id"], "raw_uid_packet_counts": dict(Counter(str(p["uid"]) for p in packets)),
                       "http": http_rows, "counter_note": counter_note,
                       "unknown_flows": [{k: f.get(k) for k in ("flow_id", "uid", "transport", "port", "source_record")} for f in unknown],
                       "checks": {"APK_and_installation": True, "code_release": True, "clock_brackets": True,
                                  "stop_packet_count_matches": reported_packets == len(packets), "packet_UID_consensus": True, "raw_reimport": True,
                                  "static_reparse": True, "findings_reproduced": True, "correspondence_reproduced": True}})
    # Recompute the saved diagnostic on a copy; do not overwrite received files.
    diagnostic_copy = out / ("diagnosis-recheck-" + revision)
    diagnostic_copy.mkdir()
    # The existing replay tree was created by the initial restore check. It is
    # untouched by per-trial re-imports above and still validates as a study.
    study_replay = out / "replay"
    if not study_replay.exists():
        shutil.copytree(original, study_replay)
    saved_diagnosis = read_json(original / "diagnosis.json")
    recomputed_diagnosis = assess(study_replay)
    assert all(recomputed_diagnosis[k] == value for k, value in saved_diagnosis.items())
    write_json(diagnostic_copy / "recomputed.json", recomputed_diagnosis)
    assert timestamp(read_json(original / "operator-report.json")["recorded_utc"]) >= max(
        timestamp(read_json(original / t["directory"] / "run.json")["ended_utc"]) for t in read_json(original / "trials.json"))
    assert before == fingerprint(original)
    result = {"date_jst": "2026-11-06", "study_id": "diagnostic-ab-002", "status": "verified_selected_environment_input_association",
              "archive_sha256": sha256(archive), "archive_bytes": archive.stat().st_size,
              "review_script_sha256": sha256(Path(__file__)), "restored_files": len(before),
              "received_originals_unchanged": True, "device_trials": 4, "new_device_trials_in_cloud": 0,
              "all_selected_controls_and_requests_verified": True, "all_saved_diagnosis_fields_reproduced": True,
              "state_policy": plan["state_policy"], "quality": "partial", "general_accuracy": None,
              "method_novelty_established": False, "causal_root_proven": False,
              "scope": "Same APK, one public app and one AVD; registered input URI endpoint associations with candidate server correlation.",
              "context": {"counts": context["counts"], "reproduced_excluding_platform_resource_policy": True},
              "selection": {"recomputed_against_verified_baseline": True, "selected_probe": plan["selection"]["selected_probe"],
                            "fixed_ABBA_output_equivalent_for_this_case": True, "superiority_evaluated": False},
              "rows": rows, "detail": detail,
              "limitations": ["Integrity/code manifests are not independent attestation of the capture or experimenter timeline.",
                              "UIDs are collector assertions with installation-record consistency, not independent OS verification.",
                              "Server matches are nonce/time/destination candidates; NAT mapping and conditional clocks remain.",
                              "Body match is to reconstructed release specification, not a preregistered feed file or app consumption.",
                              "Preserved state and self-report do not prove matched initial conditions or absence of all manual input.",
                              "One UID-unknown UDP flow remains in trial 3; never assigned to the target.",
                              "Trial 1 has one additional terminal UID10134 UDP packet beyond the stop counter snapshot; retain partial quality and do not infer cause.",
                              "Four successes are not a precision, causality, or probe-selection superiority estimate."]}
    write_json(audit / "review.json", result)
    with (audit / "trial-results.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print(json.dumps({k: v for k, v in result.items() if k not in ("detail", "limitations")}, ensure_ascii=False, indent=2))
    return result


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--archive", type=Path, required=True);p.add_argument("--out", type=Path, required=True)
    p.add_argument("--revision", default="v1")
    args = p.parse_args();review(args.archive, args.out, args.revision)
