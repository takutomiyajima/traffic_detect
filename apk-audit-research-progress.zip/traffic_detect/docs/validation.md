# 実行した検証

初回検証日: 2026-10-27。追加作業日: 2026-10-28、2026-10-29（JST）。各試行のUTC時刻は原記録を優先する。Linux x86_64 / Python 3.12.14。

## 確認できたこと

- `bash tools/setup.sh`: ハッシュ付きロックから依存を確認・導入し、編集可能インストールと自動テストまで成功。
- 自動テスト: 初回53件、最初の追加後65件、時計測定と品質項目の追加後は総数 **76 passed**。実APKやAndroid実験の76件という意味ではない。
- `apk-audit demo`: 合成入力からJSON・CSV・ローカルHTMLを生成。実通信は行わない。
- `apk-audit share`: 原本・ホスト・自由文を含まない共有用要約を生成。
- 公開サンプルAPKを改変せず2回解析し、所要時間以外の `static.json` が一致。
- 元APKのSHA-256は解析後も一致。
- 公開APKの静的結果に架空のoffline意図を適用し、JSON・CSV・HTMLを生成。指摘から証拠のファイル・位置・ハッシュへ到達可能。
- `bash tools/build_thesis.sh`: 初版14ページ。追加検証・表・図・公式資料の比較をTeXへ反映し、PDFを再生成。最新状態は `research/executed-work.md` に記録。

## 公開サンプルの再現

```bash
.venv/bin/python tools/validate_public_apk.py --out runs/public-check
```

明示実行時のみGitHubからダウンロードし、固定ハッシュと一致してから解析します。サンプルAPK自体は配布物へ含めていません。機械可読な結果は [validation-results.json](validation-results.json) に保存しました。

| 項目 | 結果 |
|---|---|
| 取得元 | Androguard公式repo、commit `581f7a3251545a97f66ee92b674dd810ee380a00`、`tests/data/APK/hello-world.apk` |
| SHA-256 | `f427a0ebe0bca97b9acf6cd2a2a01c37a7d3762841810fc54a7191ec637330b2` |
| サイズ | 1,722,314 bytes |
| package | `de.rhab.helloworld` |
| minSdk / targetSdk | 21 / 25 |
| DEX | `classes.dex` |
| 権限宣言 | 0 |
| URL候補 | 202（所在の違う候補は別件） |
| 登録対象APIへの参照 | 41 |
| 登録SDK候補 | 0（登録対象4種の一致がなかった意味） |
| 最終版の1回目 | 5.61秒 / 最大RSS 158,968 KiB |
| 最終版の2回目 | 4.71秒 / 最大RSS 158,928 KiB |
| 反復一致 | 所要時間を除いて一致 |

原稿の3.68秒・157,316 KiBは初回の動作確認値です。上の最終版の2回とは別の実行であり、いずれも性能の上限や優位性を主張する値ではありません。

レポートの処理確認には、サンプルAPKの本来の意図とは関係のない `intent-offline.json` を使用しました。結果は平文**設定**の不一致候補1件、URL文字列の要確認202件、動的観測未実施の判定不能1件、合計204指摘です。実接続や漏えいの204件を検出したという意味ではありません。

## 自動テストの範囲

意図の矛盾、未指定、IP/IDN正規化、ドット境界、ポート/プロトコル不明、UID矛盾、別アプリ、CONNECT-only、未観測と取得失敗、取得ID不一致、重複取り込み、改変された証拠、ZIPパストラバーサル、破損APK、静的タイムアウト、NSC継承、target依存の平文既定、NSC解析不能、非有限JSON値、HTML/CSV出力、共有版の除去を検査しました。

合成PCAPはTCPハンドシェイク・HTTP Host・443だけでTLSと断定しない処理・断片があるときのpartialを確認しました。ADBの取得停止と停止失敗は**モック**で検査しており、実Emulatorで確認した結果ではありません。

## 未実施・未実装を区別した残課題

- 一部実施: 実験者のMac/EmulatorからHTTPの画面・logcat・CSV・前後対照・前後時計差を受領し、試行後に報告されたAPKハッシュを同定。21行をpartialとしてrunに取り込み、3条件×3方式の事後比較と44証拠索引を確認。クラウドの自動ADB経路は未実施で、doctorは引き続きADB・Emulator・KVMなしを検出する。
- 未実施: 既知正解素材によるA01–A18の一式、未知アプリでの適合率・再現率、動的観測率、アプリ帰属精度。
- 未実装: mitmproxy dumpの直接取り込みとHTTPS復号、TCP再構成、ネイティブ意味解析、logcatクラッシュ検出、異形式ログの同一接続自動突合。PCAPdroid CSVはEmulatorから受領した出力の取り込みを確認したが、独立した帰属精度・全取得条件の検証は未実施。
- 未検証: 新しいタスクでのスナップショット復元、環境設定の公開、他OS・API・ABI。

要件書のMVP受入条件に全面合格した状態ではありません。現状は「静的解析・ログ取り込み・意図照合・レポートを検証した研究用プロトタイプ」です。

## 追加の実測

10種類の自作APKをビルドしapksignerで署名を検証した後、ソースに基づく103項目の静的期待値が一致した。複数DEXのURL/API所在、NSCドメイン継承、原本ハッシュ、権限等を含む。データと解析器は同じ開発者が作成しており、未見データでの精度ではない。結果は `generated/static-controls-summary.json`、図表は `generated/static-control-results.tex` と `generated/static-control-cost.pdf`。

ホストのループバックでHTTP要求2件・HTTPS要求2件・UDPデータグラム1件を実際に送受信し、TCP接続は計2本だった。HTTPSの証明書検証を有効にし、試験用証明書だけをクライアントで明示的に信頼した。証明書検証の無効化は行っていない。これは参照サーバの動作確認でありAndroid観測系の試験ではない。結果は `generated/control-server-summary.json`。


## 2026-10-29のHTTP取り込みと品質保持

`http-004`の試行後APKハッシュはビルド原本と一致。21行を正式なimport経路で取り込み、前後対照passedでもcoverage unknown・clock conditionalをpartialとして保持した。新規品質6ケースと時計5ケースを含む全テスト76件が成功（2.17秒）。3種類の事後説明用ポリシーを各3証拠方式で実行し、原本へ到達する44索引のファイルとSHA-256を確認した。検出精度評価とは区別する。詳細は `research/http-004-results.md` と `generated/http-004-comparison-summary.json`。
