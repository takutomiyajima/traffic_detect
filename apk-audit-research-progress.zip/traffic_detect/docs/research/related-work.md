# 関連研究調査の実施記録

作業日: 2026-10-28（利用者側日付）。現段階で実読できたのは公式プロジェクトREADMEとPCAPdroidの関連ソースである。査読論文の本文を読んだという記録にはしない。取得元の固定コミットとSHA-256は `source-inventory.json` に保存した。

## 一次実装資料に基づく比較

| 対象 | 実際に確認した資料・内容 | 本システムとの関係 |
|---|---|---|
| FlowDroid | 公式README。Android/Javaの静的なsource-to-sinkデータフロー解析。source/sink定義、SDK JAR等の入力、タイムアウト設定 | 本システムはデータフロー追跡を実装しておらず、同等の漏えい解析とは呼ばない。通信メタデータと開発意図の照合を対象にする |
| LibScout | 公式README。元ライブラリからプロファイルを作り、難読化等に配慮してライブラリ・版を検出する方式 | 現行の4種接頭辞/Manifest特徴ルールより高度。模擬クラス一致を実SDKの検出精度として評価しない |
| PCAPdroid | 公式README、ConnectionsAdapter、ConnectionDescriptor、Utils、CSVヘッダ。UID・package付き接続ログ、CSV列と時刻書式 | 観測部品候補。CSVのInfoはホスト出典を保持せず、表示状態はNEW/CONNECTING/CONNECTED等を集約する。CSVだけからTLS成立・SNIを復元しない |

固定した資料:

- FlowDroid: `9bf10349ec6fdceebbcfda2d261a1f23b9e2e439`。
- LibScout: `8c0bd2c147e818841fc695eecb1246e38458435f`。
- PCAPdroid: `66f7b3514540c20add8655a74dfee93d00a9563b`。当該ソースのversionNameは2.0.2。

この比較は利用目的と方式の差を整理したもので、既存研究に対する新規性や性能優越を証明するものではない。3ツールの性能比較実験も行っていない。

## 査読文献の本文確認として残る作業

検索候補は以下。本文と書誌を取得し、方法・評価対象・限界を読んだ後に本論文の関連研究として確定する。

| 検索候補 | 確認する論点 | 現状 |
|---|---|---|
| FlowDroid: Precise Context, Flow, Field, Object-sensitive and Lifecycle-aware Taint Analysis for Android Apps | 静的データフロー、Androidライフサイクル、評価の単位 | 公式ツール資料のみ確認。論文本文・正式書誌の確認待ち |
| TaintDroid: An Information-Flow Tracking System for Realtime Privacy Monitoring on Smartphones | 動的追跡とメタデータ観測の違い | USENIX配布先への接続がproxy 403 |
| ReCon: Revealing and Controlling PII Leaks in Mobile Network Traffic | ネットワーク観測でどの情報を扱い、どう正解を作るか | 著者配布先への接続がproxy 403 |
| Reliable Third-Party Library Detection in Android and its Security Applications | SDK検出手法と接頭辞検出の限界 | LibScout公式READMEからCCS 2016の題名と著者配布リンクを確認。本文未取得 |

未読文献から精度・実験規模等を引用しない。書誌が未確認の候補は `references.bib` の確定済み引用には入れていない。

必要な通信先の追加を環境設定ドラフトへ保存したが、ドラフト保存は実行環境への適用・公開ではない。接続許可の反映後に本文取得を再開する。許可がなくても、本書のソース確認・実装・静的評価は実施できた。
