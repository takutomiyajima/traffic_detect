# ここからの役割分担と手作業の手順

作成日: 2026-10-29（JST）。対象は現在の研究用プロトタイプ。端末側の手順は今後実施するもので、このクラウドでAndroid動作確認済みという意味ではない。

## 役割分担

| 作業 | このチャットのGPTで進められる部分 | PC・端末側または人の判断が必要な部分 |
|---|---|---|
| 研究範囲 | 研究計画、比較条件、評価指標、説明資料の作成・修正 | 指導教員との相談、提出要件と主張の確定 |
| Android環境 | 設定手順の提示、コマンドの作成、出力からの問題診断 | PCでAndroid StudioとAVDを準備・起動する |
| 実験用APK | ソース修正、ビルド、静的解析、シナリオの準備 | 対象AVDで起動・画面操作・権限許可を行う |
| 通信観測 | CSV形式の確認、アダプタ修正、UID・時刻・状態の照合 | PCAPdroidの導入、VPN許可、取得開始・停止・書き出し |
| 正解表 | ソース・ログを基に候補表を作り、矛盾や不足を整理 | 実際に行った操作の記録、可能なら別の人による確認 |
| 比較・集計 | 3方式の比較実行、棄権を分けた指標計算、図表作成 | 実験条件に従ってデータを取得し、欠落・失敗も渡す |
| 文献 | 入手できた本文の読解支援、比較表、引用・BibTeXの整理 | 接続制限が続く場合の設定反映、または大学等の正規アクセスでPDFを取得 |
| AI生成等の事例 | 課題・プロンプト案、コード・結果の整理 | 使用したサービス/モデル/日時/修正履歴の実記録、端末操作 |
| 論文 | TeXの更新、実測値の反映、図表・参照の点検、PDF生成 | 主張・解釈・著者情報の最終確認、指導教員レビュー、提出 |

Androidを実行可能な環境がこのチャットへ接続されれば、ADB操作等の一部はGPT側でも実行できる。現状ではその環境がないため、下記は手元のPCで行う。

## 最初の到達目標

HTTP制御APKを1回操作し、次の3つが対応する記録を得る。

1. アプリ画面とアプリ側ログに操作・HTTP応答がある。
2. 参照サーバが `http-001` の要求を受信する。
3. PCAPdroidの接続ログに、対象インストールのUIDがある。

この段階ではHTTPだけでよい。HTTPS・UDP・Home後・遅延・実SDKの評価を一度に始めない。初回は手順と観測経路の確認用で、本評価の精度値には数えない。

## 1. 成果物とPCの準備

このチャットの `dist/apk-audit-research-progress.zip` をダウンロードし、展開した `traffic_detect` フォルダを使う。中に `src/` と `runs/control-apks-v2/http.apk` があることを確認する。

Python 3.12を用意する。以下の `python` は、Windowsでは `py`、macOS/Linuxでは `python3` など、そのPCでPython 3を起動できるコマンドに読み替える。コマンドはすべて展開した `traffic_detect` フォルダをカレントディレクトリにして実行する。

初回はPC側で解析ライブラリを一式導入する必要はない。下記の参照サーバは標準ライブラリで動作し、解析・集計は受け取ったログをこのチャットで処理できる。現在の静的解析ワーカはUnixのresourceモジュールを使うため、Windows上で全解析コマンドがそのまま動くとは扱わない。

## 2. Android Studioで専用AVDを作る

1. Android公式からAndroid Studioを導入する。
2. SDK ManagerでAndroid SDK Platform-ToolsとAndroid Emulatorを導入する。
3. Device Managerから専用の仮想端末を作る。初期候補はAPI 35のGoogle APIsイメージ。CPUに合わせてx86_64またはarm64-v8aを選ぶ。
4. 個人の端末データ・アカウントを入れず、起動してホーム画面まで進む。
5. PCのターミナルで次を実行する。

```text
adb devices
```

`emulator-5554 device` のような表示を確認する。以下のserialは例なので、実際の表示と違う場合は全コマンドで置き換える。adbが見つからなければ、SDK Managerに表示されるSDK保存先の `platform-tools` をPATHへ追加するか、その中のadbをフルパスで実行する。

完了の目安: AVDが起動し、adbの状態がdeviceである。offlineやunauthorizedの場合は、表示を記録して接続の診断から行う。

## 3. PCで参照サーバを起動する（ターミナルA）

```text
python -c "import sys; sys.path.insert(0, 'src'); from apk_audit.control_server import main; main()" --log handoff/http-001/server-events.jsonl
```

起動表示を確認して、ターミナルAは開いたままにする。デフォルトはHTTP 8765とUDP 8766で、HTTPSはこの段階では起動しない。

`10.0.2.2` はAndroid Emulatorから見た、AVDを起動したPCを指す。そのため、このサーバもAVDと同じPCで起動する。別PCやクラウドを指すアドレスではない。

サーバは保存先フォルダを自動作成する。同じ試行名で再実行すると追記されるため、やり直しは `http-002` 等の新しいフォルダ・実験IDに変える。

## 4. 制御APKを導入し、インストール情報を保存する（ターミナルB）

```text
adb -s emulator-5554 install runs/control-apks-v2/http.apk
adb -s emulator-5554 shell dumpsys package org.example.apkaudit.http > handoff/http-001/package-info.txt
adb -s emulator-5554 shell getprop ro.build.version.sdk > handoff/http-001/android-api.txt
adb -s emulator-5554 shell getprop ro.product.cpu.abilist > handoff/http-001/android-abi.txt
adb -s emulator-5554 shell getprop ro.build.fingerprint > handoff/http-001/android-image.txt
```

インストールのSuccessを確認する。既に同じAPKがある場合は新規AVDを使うか、研究用インストールに限って `install -r` で更新し、その操作も記録する。UIDは推測せず、今回のpackage-info.txtの `userId=` 等の記録で確認する。再インストールした試行は区別する。

## 5. PCAPdroidを導入する

1. 公式配布先 `https://github.com/emanuele-f/PCAPdroid/releases` または正規のアプリ配布経路から入手する。
2. AVDにAPKをドラッグしてインストールするか、adb installを使う。
3. PCAPdroidを起動し、取得方式とVPN接続の許可を確認する。
4. 今回はTLS復号・CA導入・System Proxy変更を行わず、接続メタデータを取得する。
5. 対象アプリ以外の対照も確認できるよう、最初は全アプリを対象に取得し、書き出しでも選択行や対象アプリだけへ絞らない。
6. 実際に入手した版を保存する。

```text
adb -s emulator-5554 shell dumpsys package com.emanuelef.remote_capture > handoff/http-001/capture-app-info.txt
```

現CSVアダプタは2.0.2の固定ソース契約に対応しているが、実エクスポートでの検証はまだない。別の正式配布版を入手した場合は、その版とCSVをそのまま渡す。取り込みを通すためにversionを2.0.2へ書き換えない。GPT側で実形式を確認して対応を判断する。

## 6. 取得開始・対照・本操作・取得停止を行う

最初に `examples/handoff/trial-notes.md` をコピーして `handoff/http-001/trial-notes.md` とし、実際の時刻と結果を記入する。PC時刻のUTC表示には次を使える。

```text
python -c "from datetime import datetime, timezone; print(datetime.now(timezone.utc).isoformat())"
```

実施順:

1. PCAPdroidで取得を開始し、開始時刻を記録する。
2. **取得前対照**としてAVDのブラウザで `http://10.0.2.2:8765/health` を開く。JSON応答が見え、サーバ記録とPCAPdroidにも接続があるか確認する。これはブラウザ側の通信であり、対象アプリの要求数に数えない。
3. 次で対象アプリを新しく起動する。`-S` により、以前のActivityに古い実験IDが残ることを避ける。

```text
adb -s emulator-5554 shell am start -S -n org.example.apkaudit.http/.MainActivity --es endpoint http://10.0.2.2:8765/collect --es run_id http-001
```

4. アプリ画面の **Run one control action** を1回押し、時刻を記録する。
5. `http_response=200` が表示されるか確認し、30秒間観測する。エラーの場合は表示をそのまま保存し、成功と記録しない。
6. **取得後対照**として再びAVDのブラウザで同じhealthのURLを開き、応答と取得を確認する。
7. PCAPdroidの取得を停止し、終了時刻を記録する。

ブラウザ対照の要求には対象アプリの `http-001` ヘッダがない。サーバでは、対象アプリによるPOSTのrun_idと、対照のGETを分けて確認する。ブラウザの接続再利用や再取得があるため、TCP接続数の合計を固定値と決めつけない。

対照が片方でも確認できない場合はfailed/unknownとして記録する。「ログが空だから通信なし」とは扱わない。今回、操作時刻が粗い場合は背景通信の時間判定を保留してよい。

## 7. CSVとアプリログを保存する

PCAPdroidの接続一覧からCSVを書き出す。画面名は版に依存するので、接続の保存・エクスポートに相当する操作を使う。Androidの保存画面でDownloadフォルダに `capture.csv` として保存できた場合、次でPCへコピーする。

```text
adb -s emulator-5554 pull /sdcard/Download/capture.csv handoff/http-001/capture.csv
adb -s emulator-5554 logcat -d -v epoch ApkAuditControl:I AndroidRuntime:E "*:S" > handoff/http-001/app-logcat.txt
adb -s emulator-5554 shell date -u > handoff/http-001/device-clock.txt
python -c "from datetime import datetime, timezone; print(datetime.now(timezone.utc).isoformat())" > handoff/http-001/host-clock.txt
```

保存先が違う場合は実際のパスへ置き換える。CSVはExcel等で開いて再保存せず、元ファイルのまま渡す。logcatは初回確認ではバッファから回収する。本評価では取得前から継続記録し、欠落や時計差の測定方法も固定する。

最後にターミナルAでCtrl+Cを押して、自分が起動したサーバを停止する。

完了の目安: 画面のHTTP 200、サーバのrun_id=http-001の受信、対象UIDの接続ログが対応している。ブラウザ対照やGoogle系通信は別UIDとして区別する。対応しないときも、失敗一式をそのまま残せば診断に使える。

## 8. GPTへ渡すファイル

`handoff/http-001` をZIP等にまとめ、次を渡す。

- capture.csv（元のCSV）
- server-events.jsonl
- package-info.txt、capture-app-info.txt
- android-api.txt、android-abi.txt、android-image.txt
- app-logcat.txt
- device-clock.txt、host-clock.txt
- 記入したtrial-notes.md
- APKを変更・再ビルドした場合は、そのAPKまたはハッシュとソース変更点

UID、時計差、取得前後の対照、実験IDを基に取り込み用metadataをGPT側で整える。単にホストとAVDが同じだからclock_offset_s=0と決めない。入力が不足している項目は不明のまま保存する。原本には研究用のダミーデータだけを使い、証明書の秘密鍵等は添付しない。

GPT側で引き継げる作業は、形式・版の確認、CSVの問題診断と必要なアダプタ修正、原本ハッシュの記録、UID・サーバ記録との照合、3方式の比較、受入試験表の更新、集計・図表・TeXへの反映である。

## 次に増やす端末実験

HTTPの観測経路が成立してから、各ケースを別の試行ID・保存先で行う。

| ケース | PC・端末で行うこと | GPTへ渡す追加記録 |
|---|---|---|
| offline | 同じ取得系でoffline.apkを操作。前後対照は別アプリで行う | 観測窓、対照の成立、offlineのUID |
| UDP | udp.apkを導入し、同じPCの8766へRunを押す | UDP送信ログ、サーバのデータグラム記録 |
| HTTPS | 証明書を正常に検証できる研究用HTTPS宛先を準備し、https.apkに入力 | 宛先、証明書条件、エラーを含む取得記録 |
| 別アプリ同時通信 | http.apkとudp.apk等、別package・別UIDから同時に送信 | 両UID、両操作時刻、両サーバ記録 |
| Home後・遅延 | after_home.apkでRun後Home、delayed.apkでRun後30秒以上待機 | Run/Home/終了の時刻、観測を終了した時刻 |
| 位置情報 | AVDへダミー位置を設定し権限を許可。location_readと送信の有無を分ける | 権限状態、ダミー位置設定、アプリ・サーバログ |
| クラッシュ | crash.apkを操作し、終了と取得継続/停止を確認 | AndroidRuntimeログ、取得状態、終了時刻 |

HTTPSでCAを追加したりdebug用信頼設定を使う場合は、元のプロファイルAとは別条件として保存する。証明書検証を無効化して成功に見せない。全ケースを最初から一括で行う必要はない。

## 文献と指導教員に関する手作業

文献は環境設定の通信許可を確認・反映するか、大学図書館・出版社・著者公開版等の正規経路からPDFを入手する。本文を渡せれば、GPTは主張・方法・評価・限界の整理と引用候補の照合を支援できる。著者、題名、会議/雑誌、年、DOI、入手URLも保存する。未読文献の数値を論文へ入れない。

指導教員には `protocol.md` を使い、(1)何を研究課題とするか、(2)比較方式と正解表が適切か、(3)必要なアプリ数・反復・AI生成事例の要否、(4)実験できない項目をどう扱うか、を確認する。回答を記録して渡せば、GPTが計画とTeXへ反映できる。最終の主張・解釈・提出は著者と指導教員が確認する。
