# UDP初回試行 udp-auto-001

2026-10-29 JST。実験者から受領したZIPの28索引、APK・取得前ポリシーのハッシュ、前後時計差の原サンプル再計算を確認した。

アプリlogcatはaction_startedとudp_sentを各1件記録。サーバーはrun_id=udp-auto-001のデータグラムを1件受信し、18 bytesの本文ハッシュがaudit:udp-auto-001に一致した。送信・受信の陽性証拠がある。

CSVは37行。対象UID 10210 / org.example.apkaudit.udpとしての行は0。CSV20行目に10.0.2.2:8766宛UDP行があるが、UID=-1、PackageName=unknownである。送信46 bytes・受信37 bytes、各1 packet。宛先・時刻・送受信量は制御通信との対応候補になるが、確定したUID帰属へ昇格させない。残るunknown 2行は別のTLS宛先であり、UDP行と区別する。

自動待機は約30.005秒。前対照は実験者の目視確認とサーバGET、後対照はUIとサーバ応答IDの一致で記録されている。ランナーのcollected_needs_review / expected_target_connection_row_missingは、実際のUID付き対象行の不足を正しく残した結果である。通信なし、UDP受信失敗と分類しない。

原因は未確定。現UDP素材は送信直後にDatagramSocketを閉じるため、VPN収集器のUID照会との競合が仮説の一つ。まず同じ条件で追加2試行を記録し、不明帰属の再現性を確認する。その後、同一package・記録した別APKハッシュでソケット保持時間を延ばした診断条件を比較できる。保持条件を原条件の成功として置き換えない。

原ZIP SHA-256と個別集計はruns/received-udp-auto-001/review.jsonに保存。今回の結果は送受信の成功とアプリ帰属の未確定を分けた予備実測であり、UDPの帰属精度や観測系全体の受入完了を主張しない。
