# 実施報告と次の実験への引き継ぎ

作業日: 2026-10-28（利用者側日付）。各runのUTC時刻はそのまま保持。今回の作業では、Android実行を必要としない部分を実施した。

## 実施できたこと

| 計画項目 | 今回の実施結果 | 成果物 |
|---|---|---|
| 1 研究目的・範囲 | RQ1～RQ3、比較方法、正解単位、棄権の扱いを具体化。指導教員確認は残る | protocol.md |
| 2 関連研究 | FlowDroid・LibScout・PCAPdroidの公式資料を固定コミットで取得・実読。査読文献本文は接続制限で未取得 | related-work.md、source-inventory.json、references.bib |
| 3 実験環境 | build-only SDK/ECJをチェックサム照合して用意。Emulator・ADB・KVMはなし | tools/prepare_android_tools.py、generated/environment-doctor.json |
| 4 P0観測実証 | Android部分は未実施。参照サーバのホスト内通信は実行済み | generated/control-server-summary.json |
| 5 正解素材 | 10種類の自作APKを作成、ビルド、公式apksignerで署名検証。静的期待値表を作成 | fixtures/android、expected-static.csv、generated/control-build-inventory.json |
| 6 必要な機能 | PCAPdroid 2.0.2のCSV取り込み、3方式の証拠選択、参照サーバ、棄権を分ける集計器を追加 | src/apk_audit、tools/evaluate_labels.py |
| 7 受入試験 | A01～A18の確認範囲と未実施を記録。10 APKの103項目一致。自動テスト65件成功 | acceptance.csv、generated/static-controls-summary.json |
| 8 比較実験 | 実行用の3方式を実装・テストしたが、Android正解付きの本比較は未実施 | compare --evidence-mode、protocol.md |
| 9 対象アプリ | 未実施。自作制御アプリをAI生成アプリの標本には数えない | protocol.md |
| 10 集計・図表 | 自作素材の静的実測から表・時間/RSS図を生成。独立ラベル集計ツールを実装 | generated/static-control-results.tex、static-control-cost.pdf |
| 11 論文 | 一次資料比較、制御APKの実測、参照サーバの実測、限界をTeXへ反映。提出用最終稿ではない | docs/thesis.tex、docs/thesis.pdf |

## 数値の意味

- **10 APK / 103一致項目**: 自作の開発用素材の静的期待値との一致。未知APKに対する検出率ではない。
- **65 passed**: Python自動テスト。元要件の受入試験65件やAndroid実験65回ではない。
- **HTTP 2要求、HTTPS 2要求、UDP 1データグラム**: ホストのループバックでの実通信。TCP接続総数は2で、HTTP要求総数4と区別した。HTTPSの証明書検証は有効。
- **SDK模擬クラス**: 接頭辞ルールの構造試験。本物のSentry SDKを含まない。実SDK検出精度の正例にしない。
- **集計器の合成ラベル**: 欠測・棄権を陰性へ変えない算術検査。研究の精度結果ではない。

## 再実行手順

既存出力を保護するため、`--out` には未使用のパスを指定する。

```bash
cd /workspace/traffic_detect
.venv/bin/python -m pytest -q
.venv/bin/python tools/prepare_android_tools.py
.venv/bin/python tools/build_control_apks.py --out runs/new-controls
.venv/bin/python tools/evaluate_static_controls.py \
  --apks runs/new-controls --out runs/new-static-check
.venv/bin/python tools/render_static_results.py \
  --summary runs/new-static-check/summary.json --out docs/generated
.venv/bin/python tools/check_control_servers.py --out runs/new-server-check
.venv/bin/python tools/evaluate_labels.py \
  --gold fixtures/evaluation/synthetic-gold.json \
  --predictions fixtures/evaluation/synthetic-predictions.json \
  --out runs/new-metric-selftest.json
bash tools/build_thesis.sh
```

## 外部環境が必要で残ったこと

1. **Android実行環境**: 固定AVDの起動、APKインストール、実UID取得、実通信の収集、同時通信の帰属、操作・クラッシュ・取得停止の実証。このクラウドのdoctorはADB/Emulator/KVMなしを再確認した。
2. **査読文献の本文アクセス**: USENIX等へのHTTPS接続はproxy 403で拒否された。公式READMEの確認を論文全文レビューと扱っていない。必要な配布先を環境設定のネットワーク許可ドラフトへ追加した。ドラフト保存は実行環境への適用・公開ではないため、環境設定で確認・保存し、必要なら公開後に取得を再試行する。
3. **人による研究確認**: 指導教員による目的・評価方針の確認、可能なら独立した正解表確認者。こちらから第三者へ連絡はしていない。

今回ドラフトへ追加した通信先は `www.usenix.org`、`publica.fraunhofer.de`、`recon.meddle.mobi`、`api.crossref.org`、`dl.acm.org`、`people.svv.lu`。既存のパッケージ配布先プリセットは維持した。再利用用の開始手順も更新した。設定を適用・公開済みとは主張しない。

論文PDFは追加後16ページ。最終ビルドで未定義参照・文字欠落・Overfullの警告がないことを確認し、追加した結果表とグラフを画像化して表示を確認した。

## 次に実行する最小の端末実験

fixtures/android/README.mdに従い、HTTP制御APKを専用AVDへインストールする。参照サーバを起動し、run IDとインストール時UIDを記録する。PCAPdroidを開始してRun操作を1回行い、アプリ付きログとサーバ受信を照合する。同じ操作で別アプリも通信させ、UIDで区別できるか確認する。HTTPが成立してからHTTPS・UDP・通信なしへ広げる。


## 2026-10-29: HTTP実測の同定と取り込み

実験者報告のインストールAPKハッシュがHTTP版1.1と一致した。同定したビルドAPKの静的解析とPCAPdroid 21行のimport、3事後条件×3証拠方式、JSON/CSV/HTML出力、44証拠索引を確認。時計差の条件付きモデルと連続性unknownをpartialのまま保存する品質項目を追加。全自動テストは総数76件成功。未知素材の精度、事前固定ポリシーへの違反評価、自動ADB動作の証明とはしない。論文に結果と制約を反映。
