# 通信ログの契約 1.0

## capture.metadata.json

次は例です。`run_id` と `apk_sha256` は取り込み先の `run.json` から転記してください。時刻はタイムゾーン付きISO-8601、単位は秒です。`started_utc` / `ended_utc` は**補正後のホスト基準**、ログ行の時刻は取得元基準です。`clock_offset_s` を行の時刻に加えます。正しいオフセットは同時イベント等で測定し、その方法を `clock_basis` に記載します。

```json
{
  "schema_version": "1.0",
  "run_id": "RUN_ID_FROM_RUN_JSON",
  "apk_sha256": "SHA256_FROM_RUN_JSON",
  "tool": "validated-collector-name",
  "tool_version": "actual-version",
  "started_utc": "2026-01-01T00:00:00Z",
  "ended_utc": "2026-01-01T00:05:00Z",
  "clock_offset_s": 0,
  "clock_basis": "describe measured clock alignment here",
  "controls_before": "unknown",
  "controls_after": "unknown",
  "missing_intervals": [],
  "target_identity": {
    "package": "org.example.travel",
    "uid": 10123,
    "source": "dumpsys package output captured for this installation; retain original record"
  },
  "client_ips": ["10.0.2.15"]
}
```

`target_identity` はオフラインでアプリ付きログを取り込む場合に利用できます。APKのpackageと一致させます。既存UIDとの矛盾は拒否します。再インストールした場合は別runにしてください。入力された同一UIDに複数packageが関係する場合は特定アプリを保証しないため、原記録とインストール条件を確認してください。

対照は実際の既知通信を取得の前後に観測できた場合に `passed` としてください。単にツールが起動している場合は `unknown` のままにします。取得欠落は `missing_intervals` に `{ "started_utc": "...", "ended_utc": "...", "reason": "..." }` と記録します。対照が正常かつ欠落なしの場合のみcompletedとし、その情報が自己申告であることも保存します。

## app-flow JSONL

1行1フロー。次のオブジェクト全体を1行にします。接続数とHTTP要求数を混同しないため、HTTP要求を別フローとして増やさず、取得ツールの接続レコード単位で変換します。

```json
{"started_utc":"2026-01-01T00:00:10Z","ended_utc":"2026-01-01T00:00:11Z","destination_ip":"192.0.2.1","destination_port":443,"transport":"TCP","observation":"transport_established","host":"telemetry.example.org","host_evidence":"sni","package":"org.example.travel","uid":10123,"application_protocol":null,"content_visibility":"metadata_only","bytes_sent":420,"bytes_received":100}
```

- `transport`: TCP / UDP。
- `observation`: connection_attempt / transport_established / tls_established / http_observed / capture_failed。UDPは往復が見えただけでTCP接続成立と同一視しません。
- `application_protocol`: http / https / tls / dns / quic / other / null。推測で443→httpsに変換しません。
- `host_evidence`: sni / http_host / collector_correlated_dns / explicit_ip。DNS対応付けでは `dns_correlation_unambiguous: true` の明示が必要です。それがなければhostを不明にします。
- `uid` / `package`: 取得元の記録。パッケージ名だけの一致は対象通信の確定に使いません。
- `bytes_sent` / `bytes_received`: 整数byteまたはnull。取得元のバイト計数層をメタデータに記載してください。異なる層の数値を比較・合算しません。
- `source_status`: 任意。CONNECT / tunnel_onlyの場合、上流へのTLS・HTTP成立や本文可視性を引き継ぎません。TLSエラーは原ログとsource_statusに残します。
- `related_to_target`: 別UIDの委譲候補を取得元が注記するときだけtrue。SDKへの帰属を示しません。

元のエクスポートは別途保管し、変換器の版・元レコードとの対応を残してください。現在の索引は**取り込んだJSONLの行**へ到達します。ネイティブ出力への変換前の追跡は変換器側の責任です。PCAPdroidの任意のCSV列を自動推測する処理はありません。

## PCAP

`--adapter pcap` はEthernet、raw IP、Linux cooked v1のPCAP/PCAPNGを扱います。IPv4/IPv6のTCP/UDPを `client_ips` 側から見た方向へ整理します。送受信byteはIPヘッダを含むIP層の値です。TCPの3ウェイハンドシェイクを確認できるときだけtransport_establishedにします。完全な単一TCPセグメントのClientHelloからSNI、HTTP要求からHostを抽出できます。

制約: TCP再構成、IP断片の再構成、ECH復号、DNS→IPによる確実なホスト帰属、TLS成立の完全検出、HTTP/2・HTTP/3本文解釈はありません。IP断片は解析対象外です。PCAPのフロー数は60秒アイドルまたは新規SYNで区切る**観測上のグループ**であり、真の接続イベント数とは限りません。観測系対照がpassedでも、この解析範囲が完全になるわけではありません。PCAPにpackage/UIDは含まれないため、attributionはunknownです。

複数の取得元は `source_id` を付けて保持します。同一ファイルの再取り込みを拒否しますが、別形式・別ファイルの同一通信を自動統合する機能はありません。そのため全取得元のフロー数・byte数を合算した統計は出しません。

## PCAPdroid CSV（固定ソース契約）

`--adapter pcapdroid-csv` を追加しました。メタデータのtoolは `PCAPdroid`、tool_versionは `2.0.2` に限定します。ソースコミット `66f7b3514540c20add8655a74dfee93d00a9563b` のConnectionsAdapter・strings.xml・Utils・ConnectionDescriptorを確認した実装です。実端末のエクスポートでの検証は未実施です。

ヘッダは `IPProto,SrcIP,SrcPort,DstIp,DstPort,UID,App,PackageName,Proto,Status,Info,BytesSent,BytesRcvd,PktsSent,PktsRcvd,FirstSeen,LastSeen`。末尾Malicious列も許容します。ヘッダは非翻訳ですが表示用Statusは翻訳され、複数内部状態を集約します。ACTIVE/CLOSEDだけで接続成立とみなさず、すべて接続記録としてconnection_attemptに留めます。UID/package/宛先/時刻/通信量は保存します。UIDが負ならunknownです。

Infoのホスト出典とProtoの推定根拠はCSVから確定できないため、hostとapplication_protocolはnullにし原CSVに残します。ホストallowlistの判定には別途確実なホスト証拠が必要です。network deny_allはUIDが一致すれば接続記録から照合できます。

当該上流実装は各フィールドをCSVエスケープせず連結するため、アプリ名等にカンマ・改行があると列が曖昧になります。本アダプタは列ずれを推測修正せず拒否します。証拠索引は変換前のCSVの行と、元メタデータファイルへ到達します。
