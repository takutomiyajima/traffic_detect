# 自作Android制御素材

`cases.json` は解析器の出力を見る前に作ったManifest等の期待値の元データ、`MainActivity.java.in` とビルドスクリプトがアプリのソースです。同じ開発者が素材と解析器を作った開発確認用データです。独立した本評価コーパスではありません。

```bash
.venv/bin/python tools/prepare_android_tools.py
.venv/bin/python tools/build_control_apks.py --out runs/control-apks-new
.venv/bin/python tools/evaluate_static_controls.py \
  --apks runs/control-apks-new --out runs/static-controls-new
.venv/bin/python tools/render_static_results.py \
  --summary runs/static-controls-new/summary.json --out docs/generated
```

Java 21でビルド確認。Android Platform 35、Build Tools 35.0.0、Eclipse ECJ 3.39.0を用います。SDK配布物に付属するライセンス・NOTICEを確認してください。ツールは `.cache/android-toolchain` に保存し、配布ZIPにはSDKを含めません。各APKは研究用debug鍵で署名し、apksignerで検証します。固定のdebug用パスワードは製品の認証情報ではなく、製品署名に使ってはいけません。秘密鍵は配布しません。

10ケース: offline、http、https、udp、location_only、location_https、delayed、after_home、crash、static_multidex。

APKは作成・署名・静的解析済みですが、Android上での実行は未実施です。各素材の動的な期待挙動はこれから確認します。HTTPSの宛先は入力必須。位置情報は専用AVDのダミー位置と権限を用意し、`location_read`を確認してください。delayedは操作後30秒、after_homeはRunで準備してActivityのonStop後に送信します。onStopはHome以外でも呼ばれるため、操作ログを併用しOSの厳密な背景実行とは同一視しません。

`static_multidex` のSentry名のクラスは、接頭辞ルールを試す自作の模擬クラスです。本物のSentry SDKやその通信を含みません。実SDK陽性の評価に数えず、検出限界の例としても使ってください。

端末で手動確認する例:

```bash
adb -s emulator-5554 install runs/control-apks-new/http.apk
adb -s emulator-5554 shell am start \
  -n org.example.apkaudit.http/.MainActivity \
  --es endpoint http://10.0.2.2:8765/collect --es run_id trial-001
```

画面のRunを押し、UI状態・logcatのApkAuditControl・サーバ受信を照合します。インストール後のUIDを毎回記録します。別APKを起動して同時通信し、アプリ帰属を確認してください。上のコマンドは手順例であり、このクラウドで端末実行した記録ではありません。
