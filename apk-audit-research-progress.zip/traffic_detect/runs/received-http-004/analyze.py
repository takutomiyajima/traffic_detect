"""Reproduce the received http-004 descriptive analysis without inventing APK identity."""
import csv
import hashlib
import importlib.util
import json
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from apk_audit.pcapdroid import HEADER, pcapdroid_flows

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
RAW = ROOT / 'raw'
spec = importlib.util.spec_from_file_location('clock_tool', PROJECT / 'tools/measure_android_clock.py')
clock = importlib.util.module_from_spec(spec)
spec.loader.exec_module(clock)


def load(name):
    return json.loads((RAW / name).read_text())


def ts(text):
    d = datetime.fromisoformat(text.strip().replace('Z', '+00:00'))
    assert d.tzinfo is not None
    return d.timestamp()


def utc(epoch):
    return datetime.fromtimestamp(epoch, timezone.utc).isoformat()


before, after = load('clock-before.json'), load('clock-after.json')
for batch in (before, after):
    assert batch['serial'] == 'emulator-5554'
    recomputed = clock.summarize(batch['samples'], batch['expected_samples'])
    assert recomputed == batch['summary']
    assert recomputed['status'] == 'measured_under_batch_assumptions'
low = max(batch['summary']['offset_lower_s'] for batch in (before, after))
high = min(batch['summary']['offset_upper_s'] for batch in (before, after))
assert low <= high
offset = (low + high) / 2
envelope = [min(batch['summary']['offset_lower_s'] for batch in (before, after)),
            max(batch['summary']['offset_upper_s'] for batch in (before, after))]
app = (RAW / 'app-package.txt').read_text()
uid = int(re.search(r'^\s+appId=(\d+)', app, re.M)[1])
assert re.search(r'^\s+User 0:.*installed=true', app, re.M)
assert re.search(r'^\s+versionName=1\.1$', app, re.M)
assert re.search(r'^\s+versionName=2\.0\.2$', (RAW / 'pcapdroid-package.txt').read_text(), re.M)
assert (RAW / 'http-proxy.txt').read_text().strip() == ':0'
with (RAW / 'capture.csv').open(newline='', encoding='utf-8-sig') as stream:
    reader = csv.DictReader(stream)
    assert reader.fieldnames == HEADER
    rows = [{'source_line': n, **row} for n, row in enumerate(reader, 2)]
    assert all(None not in row and all(v is not None for v in row.values()) for row in rows)
target = [r for r in rows if r['PackageName'] == 'org.example.apkaudit.http' and int(r['UID']) == uid]
assert len(target) == 1
target = target[0]
assert (target['DstIp'], target['DstPort'], target['IPProto']) == ('10.0.2.2', '8765', '6')
events = [{'source_line': n, **json.loads(line)} for n, line in
          enumerate((RAW / 'server-events.jsonl').read_text().splitlines(), 1) if line.strip()]
posts = [e for e in events if e.get('event') == 'http_request_received' and e.get('method') == 'POST']
assert len(posts) == 1 and posts[0]['run_id'] == 'http-004'
post = posts[0]
body = b'audit=http-004'
assert post['body_bytes'] == len(body) and post['body_sha256'] == hashlib.sha256(body).hexdigest()
app_events = []
for n, line in enumerate((RAW / 'app-logcat.txt').read_text().splitlines(), 1):
    m = re.search(r'^\s*(\d+\.\d+).*ApkAuditControl: run=http-004 case=http (.*)$', line)
    if m:
        app_events.append({'source_line': n, 'device_epoch_s': float(m[1]), 'message': m[2]})
actions = [e for e in app_events if e['message'] == 'action_started']
responses = [e for e in app_events if e['message'] == 'http_response=200']
assert len(actions) == len(responses) == 1
action, response = actions[0], responses[0]
get_events = [e for e in events if e.get('event') == 'http_request_received' and e.get('method') == 'GET']
pre = [e for e in get_events if ts(e['utc']) < ts(post['utc'])]
following = [e for e in get_events if ts(e['utc']) > ts(post['utc'])]
assert len(pre) == len(following) == 2
# Human visual review of the supplied screenshots is retained separately from automated parsing.
review = {
    'method': 'assistant visually inspected all three original screenshots',
    'app-result.png': {'visible_text': 'http_response=200'},
    'health-before.png': {'ok': True, 'event_id': 'f244b1fa23e2462bac7a213bcc0659c3'},
    'health-after.png': {'ok': True, 'event_id': '2a5c6e9e4bd74d41bfc56f3d3b610f46'},
}
assert review['health-before.png']['event_id'] == pre[0]['event_id']
assert review['health-after.png']['event_id'] == following[0]['event_id']
boundaries = {name: ts((RAW / (name + '.txt')).read_text()) for name in (
    'capture-start-earliest', 'capture-start-latest', 'capture-stop-earliest', 'capture-stop-latest')}
# Host date files were printed in whole seconds; include the truncation bin.
possible_start = [boundaries['capture-start-earliest'], boundaries['capture-start-latest'] + 1]
possible_stop = [boundaries['capture-stop-earliest'], boundaries['capture-stop-latest'] + 1]
core = [possible_start[1], possible_stop[0]]
assert core[0] < core[1]
assert all(core[0] <= ts(e['utc']) <= core[1] for e in (pre[0], post, following[0]))
assert core[0] <= ts(target['FirstSeen']) + offset <= ts(target['LastSeen']) + offset <= core[1]
meta = {'tool': 'PCAPdroid', 'tool_version': '2.0.2', 'clock_offset_s': offset,
        'started_utc': utc(possible_start[0]), 'ended_utc': utc(possible_stop[1])}
flows = list(pcapdroid_flows(RAW / 'capture.csv', {'package': 'org.example.apkaudit.http', 'target_uid': uid}, meta))
assert len(flows) == len(rows)
for flow in flows:
    flow['source_sha256'] = hashlib.sha256((RAW / 'capture.csv').read_bytes()).hexdigest()
    flow['alignment_model'] = 'conditional constant offset consistent with both endpoint batches; within-capture steps untested'
(ROOT / 'normalized-flows.jsonl').write_text(''.join(json.dumps(f, ensure_ascii=False) + '\n' for f in flows))
post_delay = ts(following[0]['utc']) - (action['device_epoch_s'] + offset)
new_flow_after_action = max(ts(r['FirstSeen']) for r in rows) - action['device_epoch_s']
result = {
    'trial_id': 'http-004', 'classification': 'successful_http_observation_with_operator_confirmed_control_timing',
    'target_uid': uid, 'app_version': '1.1', 'pcapdroid_version': '2.0.2',
    'csv_row_count': len(rows), 'csv_target_row_count': 1, 'target_row': target,
    'csv_other_row_count': len(rows) - 1,
    'csv_packages': dict(Counter(r['PackageName'] for r in rows)),
    'csv_local_server_tcp_rows': sum(r['DstIp'] == '10.0.2.2' and r['DstPort'] == '8765' and r['IPProto'] == '6' for r in rows),
    'server_tcp_accepted': sum(e.get('event') == 'tcp_connection_accepted' for e in events),
    'server_http_get_requests': len(get_events), 'server_http_post_requests': len(posts),
    'target_server_post': post, 'app_events': app_events, 'screenshot_review': review,
    'application_action_to_response_s': response['device_epoch_s'] - action['device_epoch_s'],
    'clock_before_recomputed': before['summary'], 'clock_after_recomputed': after['summary'],
    'endpoint_compatible_constant_offset_s': {'lower': low, 'upper': high, 'midpoint': offset},
    'endpoint_offset_envelope_s': envelope,
    'endpoint_midpoint_difference_s': after['summary']['offset_midpoint_s'] - before['summary']['offset_midpoint_s'],
    'capture_start_host_interval_utc': list(map(utc, possible_start)),
    'capture_stop_host_interval_utc': list(map(utc, possible_stop)),
    'capture_common_core_under_manual_boundary_assumption_utc': list(map(utc, core)),
    'browser_controls': {'before': 'observed', 'after': 'observed_operator_confirmed_timing',
                         'after_get_minus_action_s_under_constant_offset': post_delay},
    'latest_csv_new_flow_minus_action_s_on_device_clock': new_flow_after_action,
    'procedure_notes': ['Original guide proposed waiting 30 seconds before the after control; actual after control was at about 14.13 seconds and the operator confirmed this timing matches their action'],
    'operator_clarification': '14秒後なのはそのときに送ったので合っている',
    'http_observation_status': 'successful',
    'fixed_30_second_wait_protocol_claimed': False,
    'installed_apk_sha256': None, 'formal_run_import_performed': False, 'accuracy_metrics_computed': False,
    'limitations': [
        'No APK bytes or installed APK hash supplied; pm path is not a hash',
        'Source-only normalization exercises the actual adapter but is not a validated formal run import',
        'Endpoint offset consistency does not prove no clock step or drift during capture',
        'CSV and server have no shared connection ID; target correspondence remains an evidence-supported candidate',
        'Capture start/stop are manual whole-second brackets; no verified missing-interval inventory',
        'Latest flow after 36 seconds does not establish continuous capture with no gaps',
        'Google/Messages traffic is not an independently operated second-app attribution gold set',
        'App action-to-response interval includes application scheduling and is not network RTT',
        'Do not sum byte counters across sources or equate request count with connection count',
    ],
    'originals_manifest': json.loads((ROOT / 'originals-manifest.json').read_text()),
}
(ROOT / 'analysis.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: result[k] for k in (
    'csv_row_count', 'csv_target_row_count', 'csv_other_row_count', 'csv_packages',
    'server_tcp_accepted', 'server_http_get_requests', 'server_http_post_requests',
    'application_action_to_response_s', 'endpoint_compatible_constant_offset_s',
    'endpoint_midpoint_difference_s', 'browser_controls', 'latest_csv_new_flow_minus_action_s_on_device_clock')}, indent=2))
