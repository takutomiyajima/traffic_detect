"""Create an evidence-linked run and retrospective policy examples for http-004."""
import copy
import hashlib
import json
import re
import shutil
from pathlib import Path

from apk_audit.capture import import_capture
from apk_audit.cli import static_stage
from apk_audit.compare import compare
from apk_audit.core import add_evidence, read_json, sha256, write_json
from apk_audit.report import report

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
OUT = PROJECT / 'runs/http-004-integrated'
APK = PROJECT / 'runs/control-apks-v3-ui/http.apk'
analysis = read_json(ROOT / 'analysis.json')
identity = read_json(ROOT / 'installed-apk-hash-attestation.json')
assert sha256(APK) == identity['installed_apk_sha256_reported']
assert not OUT.exists(), 'Never overwrite an existing experiment; choose a new output directory'
run = static_stage(APK, OUT)
run.update(external_trial_id='http-004', run_kind='manual_emulator_observation_retrospective_policy_example',
           execution_method='operator_performed_manual_trial', execution_status='completed',
           comparison_policy_timing='after_capture',
           installed_apk_identity=identity)
run['limitations'] += [
    'Policies below are retrospective examples, not developer declarations fixed before capture',
    'Not a prospective intent-violation or accuracy experiment',
    'APK hash is a post-capture user report; unchanged installation at capture is not independently established',
    'Outer capture time brackets are validation envelopes, not exact start/stop times',
    'Clock alignment assumes a constant offset consistent with endpoint batches; capture-wide drift not bounded',
    'Continuous coverage and absence of missing intervals are not established',
    'No successful UI phase interval is retrospectively invented; logcat is retained as source evidence',
]
write_json(OUT / 'run.json', run)
sources = OUT / 'raw/handoff'
sources.mkdir()
for file in sorted((ROOT / 'raw').iterdir()):
    shutil.copyfile(file, sources / file.name)
    add_evidence(OUT, 'handoff-' + re.sub(r'[^a-zA-Z0-9_-]', '-', file.name), sources / file.name,
                 'Original operator-provided http-004 handoff file; see trial analysis for record locations')
for name in ('originals-manifest.json', 'installed-apk-hash-attestation.json', 'analysis.json'):
    target = sources / ('analysis-pre-import.json' if name == 'analysis.json' else name)
    shutil.copyfile(ROOT / name, target)
    add_evidence(OUT, 'handoff-' + name.removesuffix('.json'), target,
                 'Pre-import snapshot or post-receipt attestation; distinguished from original capture files')
meta = {
    'schema_version': '1.0', 'run_id': run['run_id'], 'apk_sha256': run['apk_sha256'],
    'tool': 'PCAPdroid', 'tool_version': '2.0.2',
    'started_utc': analysis['capture_start_host_interval_utc'][0],
    'ended_utc': analysis['capture_stop_host_interval_utc'][1],
    'clock_offset_s': analysis['endpoint_compatible_constant_offset_s']['midpoint'],
    'clock_alignment_status': 'conditional',
    'clock_basis': 'Constant-offset model consistent with both raw clock batches; no in-capture drift bound; see raw/handoff/clock-before.json and clock-after.json',
    'clock_offset_interval_s': analysis['endpoint_compatible_constant_offset_s'],
    'capture_time_basis': 'Outer manual start/stop brackets expanded for whole-second timestamp truncation',
    'controls_before': 'passed', 'controls_after': 'passed',
    'control_evidence': 'Chrome screenshots match server GET event IDs; corresponding Chrome rows appear in CSV',
    'coverage_status': 'unknown', 'missing_intervals': [],
    'missing_intervals_basis': 'No known gaps enumerated; no claim that the capture was continuous',
    'target_identity': {'package': run['package'], 'uid': analysis['target_uid'],
                        'source': 'raw/handoff/app-package.txt appId=10207 and installed User 0; raw/handoff/installed-apk-hash-attestation.json'},
    'byte_counter_basis': 'PCAPdroid CSV counters; not HTTP request-body bytes',
}
write_json(OUT / 'http-004.capture.metadata.json', meta)
assert import_capture(OUT, ROOT / 'raw/capture.csv', OUT / 'http-004.capture.metadata.json', 'pcapdroid-csv') == 21
assert read_json(OUT / 'run.json')['dynamic_status'] == 'partial'
primary = {
    'schema_version': '1.0',
    'app_purpose': 'Retrospective processing example for http-004, not a predeclared developer policy',
    'network': {'mode': 'allowlist', 'allowed_destinations': [
        {'host': '10.0.2.2', 'include_subdomains': False, 'ports': [8765], 'application_protocols': []}]},
    'sdk': {'mode': 'unspecified'},
    'permissions': {'mode': 'allowlist', 'allowed': ['android.permission.INTERNET']},
    'cleartext_policy': 'allow', 'background_network_policy': 'unspecified',
}
deny = copy.deepcopy(primary)
deny['network'] = {'mode': 'deny_all'}
deny['app_purpose'] = 'Retrospective counterfactual: communication forbidden; not the developer policy'
protocol = copy.deepcopy(primary)
protocol['network']['allowed_destinations'][0]['application_protocols'] = ['http']
protocol['app_purpose'] = 'Retrospective example: HTTP constrained but native CSV protocol provenance unavailable'
policies = {'ip_port_allowlist': primary, 'counterfactual_deny_all': deny, 'http_protocol_constraint': protocol}
results = []
for policy_id, policy in policies.items():
    for mode in ('static-only', 'dynamic-only', 'integrated'):
        result = compare(OUT, copy.deepcopy(policy), mode)
        result['policy_basis'] = 'retrospective example, not a prospective research label'
        destination = OUT / 'comparisons' / policy_id
        destination.mkdir(parents=True, exist_ok=True)
        write_json(destination / (mode + '.findings.json'), result)
        targets = [f for f in result['findings'] if f['subject'] == 'external_connection' and f['attribution'] == 'target']
        results.append({'policy_id': policy_id, 'evidence_mode': mode,
                        'target_connection_findings': [{k: f[k] for k in ('rule_id', 'verdict', 'message', 'evidence_ids')} for f in targets],
                        'permission_findings': sum(f['subject'] == 'permission_declaration' for f in result['findings']),
                        'all_finding_counts_not_connection_counts': result['counts']})
compare(OUT, copy.deepcopy(primary), 'integrated')
report(OUT)  # Resolves and hashes every cited source before writing HTML/CSV.
index = read_json(OUT / 'evidence/index.json')
for entry in index.values():
    assert sha256(OUT / entry['path']) == entry['sha256']
summary = {
    'external_trial_id': 'http-004', 'internal_run_id': run['run_id'],
    'installed_apk_sha256_reported': identity['installed_apk_sha256_reported'],
    'local_apk_sha256': sha256(APK), 'hash_match': True,
    'hash_measurement_phase': 'after_capture_user_report',
    'static_status': read_json(OUT / 'run.json')['static_status'],
    'dynamic_status': read_json(OUT / 'run.json')['dynamic_status'],
    'run_status': read_json(OUT / 'run.json')['run_status'],
    'imported_csv_rows': 21, 'target_rows': 1, 'other_rows': 20,
    'coverage_status': 'unknown', 'clock_alignment_status': 'conditional',
    'comparison_policy_timing': 'after_capture', 'accuracy_metrics_computed': False,
    'evidence_entries_verified': len(index), 'results': results,
    'limitations': read_json(OUT / 'run.json')['limitations'],
}
write_json(OUT / 'comparison-summary.json', summary)
write_json(PROJECT / 'docs/generated/http-004-comparison-summary.json', summary)
print(json.dumps(summary, ensure_ascii=False, indent=2))
