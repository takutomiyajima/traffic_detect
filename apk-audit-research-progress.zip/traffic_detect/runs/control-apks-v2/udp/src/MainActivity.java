package org.example.apkaudit.udp;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.util.Log;

/** Self-authored control fixture. Runtime behavior is NOT yet device-validated. */
public class MainActivity extends Activity {
    private TextView status;
    private EditText endpoint;
    private String experimentId;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        experimentId = getIntent().getStringExtra("run_id");
        if (experimentId == null) experimentId = "manual-unassigned";
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText("APK audit control: udp"); view.addView(title);
        endpoint = new EditText(this); endpoint.setId(R.id.endpoint);
        endpoint.setSingleLine(true); endpoint.setHint("Test server URL / UDP host:port");
        String configured = getIntent().getStringExtra("endpoint");
        endpoint.setText(configured == null ? "10.0.2.2:8766" : configured);
        view.addView(endpoint);
        Button run = new Button(this); run.setId(R.id.run_case); run.setText("Run one control action");
        view.addView(run);
        status = new TextView(this); status.setId(R.id.status); status.setText("waiting");
        view.addView(status); setContentView(view);
        run.setOnClickListener(v -> runCase());
    }
    private void record(String message) {
        Log.i("ApkAuditControl", "run=" + experimentId + " case=udp " + message);
        runOnUiThread(() -> status.setText(message));
    }
    private void runCase() {
        final String destination = endpoint.getText().toString();
        record("action_started");
        new Thread(() -> {try {
            String[] parts=destination.split(":");
            byte[] body=("audit:"+experimentId).getBytes("UTF-8");
            try(java.net.DatagramSocket socket=new java.net.DatagramSocket()) {
                socket.send(new java.net.DatagramPacket(body,body.length,java.net.InetAddress.getByName(parts[0]),Integer.parseInt(parts[1])));
            } record("udp_sent");
        }catch(Exception e){record("udp_error="+e.getClass().getSimpleName());}}).start();
    }
    
}
