package org.example.apkaudit.location_https;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.util.Log;

/** Self-authored control fixture. Runtime behavior is NOT yet device-validated. */
public class MainActivity extends Activity {
    private TextView status;
    private EditText endpoint;
    private String experimentId;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        experimentId = getIntent().getStringExtra("run_id");
        if (experimentId == null) experimentId = "manual-unassigned";
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText("APK audit control: location_https"); view.addView(title);
        endpoint = new EditText(this); endpoint.setId(R.id.endpoint);
        endpoint.setSingleLine(true); endpoint.setHint("Test server URL / UDP host:port");
        String configured = getIntent().getStringExtra("endpoint");
        endpoint.setText(configured == null ? "" : configured);
        view.addView(endpoint);
        Button run = new Button(this); run.setId(R.id.run_case); run.setText("Run one control action");
        view.addView(run);
        status = new TextView(this); status.setId(R.id.status); status.setText("waiting");
        view.addView(status); setContentView(view);
        run.setOnClickListener(v -> runCase());
    }
    private void record(String message) {
        Log.i("ApkAuditControl", "run=" + experimentId + " case=location_https " + message);
        runOnUiThread(() -> status.setText(message));
    }
    private void runCase() {
        final String destination = endpoint.getText().toString();
        record("action_started");
        if(!destination.startsWith("https://")){record("https_endpoint_required");return;}
        if(locationReady()) {android.location.Location loc=readLocation(); if(loc==null)return;
        final String body="dummy_location="+loc.getLatitude()+","+loc.getLongitude();
        new Thread(() -> sendHttp(destination,body)).start();}
    }
    
private boolean locationReady() {
    if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
        requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        record("grant_permission_then_press_run_again"); return false;
    }
    return true;
}
private android.location.Location readLocation() {
    android.location.LocationManager m = (android.location.LocationManager)getSystemService(LOCATION_SERVICE);
    android.location.Location loc = m.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER);
    record(loc == null ? "location_unavailable" : "location_read"); return loc;
}

private void sendHttp(String destination, String body) {
    try {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection)new java.net.URL(destination).openConnection();
        c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setInstanceFollowRedirects(false);
        c.setRequestProperty("X-Audit-Run", experimentId); c.setRequestProperty("Connection", "close");
        c.setRequestMethod("POST"); c.setDoOutput(true);
        try(java.io.OutputStream out = c.getOutputStream()) { out.write(body.getBytes("UTF-8")); }
        int code = c.getResponseCode(); c.disconnect(); record("http_response=" + code);
    } catch(Exception e) { record("http_error=" + e.getClass().getSimpleName()); }
}

}
