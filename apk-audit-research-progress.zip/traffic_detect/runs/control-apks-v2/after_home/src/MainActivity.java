package org.example.apkaudit.after_home;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.util.Log;

/** Self-authored control fixture. Runtime behavior is NOT yet device-validated. */
public class MainActivity extends Activity {
    private TextView status;
    private EditText endpoint;
    private String experimentId;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        experimentId = getIntent().getStringExtra("run_id");
        if (experimentId == null) experimentId = "manual-unassigned";
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText("APK audit control: after_home"); view.addView(title);
        endpoint = new EditText(this); endpoint.setId(R.id.endpoint);
        endpoint.setSingleLine(true); endpoint.setHint("Test server URL / UDP host:port");
        String configured = getIntent().getStringExtra("endpoint");
        endpoint.setText(configured == null ? "http://10.0.2.2:8765/collect" : configured);
        view.addView(endpoint);
        Button run = new Button(this); run.setId(R.id.run_case); run.setText("Run one control action");
        view.addView(run);
        status = new TextView(this); status.setId(R.id.status); status.setText("waiting");
        view.addView(status); setContentView(view);
        run.setOnClickListener(v -> runCase());
    }
    private void record(String message) {
        Log.i("ApkAuditControl", "run=" + experimentId + " case=after_home " + message);
        runOnUiThread(() -> status.setText(message));
    }
    private void runCase() {
        final String destination = endpoint.getText().toString();
        record("action_started");
        armed=true; armedDestination=destination; record("armed_press_Home");
    }
    
private void sendHttp(String destination, String body) {
    try {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection)new java.net.URL(destination).openConnection();
        c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setInstanceFollowRedirects(false);
        c.setRequestProperty("X-Audit-Run", experimentId); c.setRequestProperty("Connection", "close");
        c.setRequestMethod("POST"); c.setDoOutput(true);
        try(java.io.OutputStream out = c.getOutputStream()) { out.write(body.getBytes("UTF-8")); }
        int code = c.getResponseCode(); c.disconnect(); record("http_response=" + code);
    } catch(Exception e) { record("http_error=" + e.getClass().getSimpleName()); }
}

private boolean armed=false; private String armedDestination;
@Override protected void onStop() { super.onStop(); if(armed){armed=false;
    final String d=armedDestination; new Thread(() -> sendHttp(d,"audit="+experimentId)).start();}}

}
