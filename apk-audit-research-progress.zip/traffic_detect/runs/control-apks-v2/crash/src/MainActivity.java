package org.example.apkaudit.crash;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.util.Log;

/** Self-authored control fixture. Runtime behavior is NOT yet device-validated. */
public class MainActivity extends Activity {
    private TextView status;
    private EditText endpoint;
    private String experimentId;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        experimentId = getIntent().getStringExtra("run_id");
        if (experimentId == null) experimentId = "manual-unassigned";
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText("APK audit control: crash"); view.addView(title);
        endpoint = new EditText(this); endpoint.setId(R.id.endpoint);
        endpoint.setSingleLine(true); endpoint.setHint("Test server URL / UDP host:port");
        String configured = getIntent().getStringExtra("endpoint");
        endpoint.setText(configured == null ? "" : configured);
        view.addView(endpoint);
        Button run = new Button(this); run.setId(R.id.run_case); run.setText("Run one control action");
        view.addView(run);
        status = new TextView(this); status.setId(R.id.status); status.setText("waiting");
        view.addView(status); setContentView(view);
        run.setOnClickListener(v -> runCase());
    }
    private void record(String message) {
        Log.i("ApkAuditControl", "run=" + experimentId + " case=crash " + message);
        runOnUiThread(() -> status.setText(message));
    }
    private void runCase() {
        final String destination = endpoint.getText().toString();
        record("action_started");
        throw new IllegalStateException("deliberate control crash");
    }
    
}
