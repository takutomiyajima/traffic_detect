package org.example.apkaudit.after_home;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.util.Log;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;

/** Self-authored control fixture. Runtime behavior is NOT yet device-validated. */
public class MainActivity extends Activity {
    private TextView status;
    private EditText endpoint;
    private String experimentId;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        // targetSdk 35 is edge-to-edge. Keep interactive views outside system
        // bars and the display cutout, and do not overlay a framework ActionBar.
        if (getActionBar() != null) getActionBar().hide();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        getWindow().getDecorView().setSystemUiVisibility(
                android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                | android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        experimentId = getIntent().getStringExtra("run_id");
        if (experimentId == null) experimentId = "manual-unassigned";
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.WHITE);
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets edges = insets.getInsets(WindowInsets.Type.systemBars()
                        | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                v.setPadding(edges.left, edges.top, edges.right, edges.bottom);
            } else {
                v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);
        view.setPadding(dp(20), dp(20), dp(20), dp(24));
        view.setFocusableInTouchMode(true);
        TextView title = new TextView(this);
        title.setText("APK audit control: after_home");
        title.setTextSize(22); title.setTextColor(Color.BLACK);
        title.setTypeface(null, Typeface.BOLD);
        view.addView(title, rowParams(0));
        TextView instruction = new TextView(this);
        instruction.setText("Enter the test destination, then press Run test once.");
        instruction.setTextSize(16); instruction.setTextColor(Color.DKGRAY);
        view.addView(instruction, rowParams(12));
        endpoint = new EditText(this); endpoint.setId(R.id.endpoint);
        endpoint.setTextColor(Color.BLACK);
        endpoint.setSingleLine(true); endpoint.setHint("Test server URL / UDP host:port");
        String configured = getIntent().getStringExtra("endpoint");
        endpoint.setText(configured == null ? "http://10.0.2.2:8765/collect" : configured);
        view.addView(endpoint, rowParams(12));
        Button run = new Button(this); run.setId(R.id.run_case);
        run.setText("通信を実行 / Run test"); run.setAllCaps(false);
        run.setTextSize(18); run.setTextColor(Color.WHITE);
        run.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(24, 86, 150)));
        run.setMinHeight(dp(64));
        view.addView(run, rowParams(20));
        status = new TextView(this); status.setId(R.id.status);
        status.setText("waiting — press Run test");
        status.setTextSize(18); status.setTextColor(Color.BLACK);
        view.addView(status, rowParams(20));
        scroll.addView(view, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);
        scroll.requestApplyInsets();
        run.setOnClickListener(v -> runCase());
    }
    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
    private LinearLayout.LayoutParams rowParams(int topMargin) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(topMargin);
        return params;
    }
    private void record(String message) {
        Log.i("ApkAuditControl", "run=" + experimentId + " case=after_home " + message);
        runOnUiThread(() -> status.setText(message));
    }
    private void runCase() {
        final String destination = endpoint.getText().toString();
        record("action_started");
        armed=true; armedDestination=destination; record("armed_press_Home");
    }
    
private void sendHttp(String destination, String body) {
    try {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection)new java.net.URL(destination).openConnection();
        c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setInstanceFollowRedirects(false);
        c.setRequestProperty("X-Audit-Run", experimentId); c.setRequestProperty("Connection", "close");
        c.setRequestMethod("POST"); c.setDoOutput(true);
        try(java.io.OutputStream out = c.getOutputStream()) { out.write(body.getBytes("UTF-8")); }
        int code = c.getResponseCode(); c.disconnect(); record("http_response=" + code);
    } catch(Exception e) { record("http_error=" + e.getClass().getSimpleName()); }
}

private boolean armed=false; private String armedDestination;
@Override protected void onStop() { super.onStop(); if(armed){armed=false;
    final String d=armedDestination; new Thread(() -> sendHttp(d,"audit="+experimentId)).start();}}

}
