"""Create publication-style artifacts from measured control-APK results."""
import argparse
import json
import os
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
os.environ.setdefault("MPLCONFIGDIR",str(ROOT/".cache/matplotlib"))
os.environ.setdefault("XDG_CACHE_HOME",str(ROOT/".cache"))


def main():
    p=argparse.ArgumentParser();p.add_argument("--summary",required=True,type=Path);p.add_argument("--out",required=True,type=Path);a=p.parse_args()
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    data=json.loads(a.summary.read_text());a.out.mkdir(parents=True,exist_ok=True)
    (a.out/"static-controls-summary.json").write_text(json.dumps(data,indent=2)+"\n")
    rows=data["results"]
    fig,axes=plt.subplots(2,1,figsize=(8,5.2),sharex=True,layout="constrained")
    x=list(range(len(rows)));names=[r["case_id"] for r in rows]
    axes[0].bar(x,[r["duration_s"] for r in rows],color="#285e8e");axes[0].set_ylabel("Analysis time (s)")
    axes[1].bar(x,[r["max_rss_kib"]/1024 for r in rows],color="#397d63");axes[1].set_ylabel("Worker peak RSS (MiB)")
    axes[1].set_xticks(x,names,rotation=35,ha="right",fontsize=8)
    for ax in axes:ax.grid(axis="y",alpha=.2);ax.set_axisbelow(True)
    fig.suptitle("Self-authored development controls: one static run per APK",fontsize=10)
    fig.savefig(a.out/"static-control-cost.pdf");plt.close(fig)
    text=['\\begin{tabular}{lrrrr}\\toprule','Case & Checks & URLs & API refs & Time (s) \\\\ \\midrule']
    for r in rows:
        name=r["case_id"].replace("_","\\_")
        text.append(f'{name} & {sum(r["checks"].values())}/{len(r["checks"])} & {r["url_candidates"]} & {r["api_references"]} & {r["duration_s"]:.2f} \\\\')
    text+=['\\bottomrule\\end{tabular}']
    (a.out/"static-control-results.tex").write_text("\n".join(text)+"\n")
    print("Wrote measured table, figure and JSON to",a.out)


if __name__=="__main__":main()
