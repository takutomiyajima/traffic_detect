"""Install build-only Android tools locally, with pinned checksums. No emulator.

The Google archives include their license/NOTICE files; inspect those before
using or redistributing SDK components. This script never runs sdkmanager or
accepts a license on the user's behalf.
"""
import hashlib
import json
import zipfile
from pathlib import Path
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".cache/android-toolchain"
ARTIFACTS = [
    ("platform-35_r02.zip", "https://dl.google.com/android/repository/platform-35_r02.zip", "0988cacad01b38a18a47bac14a0695f246bc76c1b06c0eeb8eb0dc825ab0c8e0", "platform"),
    ("build-tools_r35_linux.zip", "https://dl.google.com/android/repository/build-tools_r35_linux.zip", "bd3a4966912eb8b30ed0d00b0cda6b6543b949d5ffe00bea54c04c81e1561d88", "build-tools"),
    ("ecj-3.39.0.jar", "https://repo.maven.apache.org/maven2/org/eclipse/jdt/ecj/3.39.0/ecj-3.39.0.jar", "01f5a92ac19bb2b3bf85e295a68f2c73c264369109158b566ce9b490af982948", None),
]


def main():
    BASE.mkdir(parents=True, exist_ok=True)
    inventory = []
    for name, url, expected, directory in ARTIFACTS:
        path = BASE / name
        if not path.exists():
            with urlopen(url, timeout=60) as response, path.open("wb") as f:
                while chunk := response.read(1024**2):
                    f.write(chunk)
        actual = hashlib.file_digest(path.open("rb"), "sha256").hexdigest()
        if actual != expected:
            raise SystemExit(f"Checksum mismatch: {name}; do not use the artifact")
        if directory:
            target = BASE / directory
            # Re-extract only verified archives so cached executables cannot be
            # substituted without checking the source artifact on refresh.
            with zipfile.ZipFile(path) as z:
                for member in z.infolist():
                    p = Path(member.filename)
                    if p.is_absolute() or ".." in p.parts:
                        raise SystemExit("Unsafe SDK member path")
                    z.extract(member, target)
                    if member.external_attr >> 16 & 0o111:
                        (target / p).chmod(0o755)
        inventory.append({"name": name, "url": url, "sha256": actual})
    (BASE / "inventory.json").write_text(json.dumps(inventory, indent=2) + "\n")
    print("Build tools prepared under", BASE)


if __name__ == "__main__":
    main()
