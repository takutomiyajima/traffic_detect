"""Evaluate self-authored static controls against source-derived expectations.

This is development/acceptance data, not a held-out accuracy benchmark.
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path

from apk_audit.core import sha256, write_json, utc_now
from apk_audit.cli import static_stage

ROOT = Path(__file__).resolve().parents[1]


def main():
    p=argparse.ArgumentParser();p.add_argument("--apks",required=True,type=Path);p.add_argument("--out",required=True,type=Path);a=p.parse_args()
    if a.out.exists():raise SystemExit("Use a new output directory")
    a.out.mkdir(parents=True)
    inventory=json.loads((a.apks/"inventory.json").read_text())
    results=[]
    for case in inventory["cases"]:
        apk=a.apks/case["apk"];out=a.out/case["case_id"]
        run=static_stage(apk,out)
        actual=json.loads((out/"static.json").read_text());spec=case["source_spec"]
        badging=subprocess.run([str(ROOT/".cache/android-toolchain/build-tools/android-15/aapt2"),"dump","badging",str(apk)],capture_output=True,text=True,check=True)
        (out/"evidence/aapt2-badging.txt").write_text(badging.stdout)
        checks={"original_hash_unchanged":sha256(apk)==case["sha256"]==actual["apk_sha256"],
                "package_matches_source":actual["package"]==case["package"],
                "package_matches_independent_aapt2":f"name='{case['package']}'" in badging.stdout,
                "permissions_match_source":sorted(p["name"] for p in actual["permissions"])==sorted(case["expected_permissions"]),
                "dex_files_match_source":sorted(actual["dex_files"])==sorted(case["expected_dex_files"]),
                "base_cleartext_matches_source":actual["network_config"]["base_cleartext_permitted"]==spec["cleartext"],
                "resource_url_found":any(u["host"]=="docs.example.org" for u in actual["urls"]),
                "signing_metadata_extracted":bool(actual["signing"]["certificate_sha256"]),
                "static_stage_completed":run["static_status"]=="completed"}
        if spec.get("multidex"):
            checks["secondary_dex_url_location"]=any(u["host"]=="secondary.example.org" and u["location"]["file"]=="classes2.dex" for u in actual["urls"])
            checks["secondary_dex_api_location"]=any(r["dex"]=="classes2.dex" and "Ljava/net/URL;" in r["reference"] for r in actual["api_references"])
        checks["sdk_signature_rule_conformance"]={s["id"] for s in actual["sdk_candidates"]}==({"sentry.android"} if spec.get("sdk_signature_stub") else set())
        if spec.get("nsc"):
            checks["domain_nsc_inheritance"]={d["host"]:d["cleartext_permitted"] for d in actual["network_config"]["domains"]}=={"example.org":True,"api.example.org":False}
        results.append({"case_id":case["case_id"],"apk_sha256":sha256(apk),"checks":checks,"passed":all(checks.values()),
                        "url_candidates":len(actual["urls"]),"api_references":len(actual["api_references"]),
                        "duration_s":run["static_duration_s"],"max_rss_kib":run["static_resources"]["max_rss_kib"]})
        print(case["case_id"],"PASS" if all(checks.values()) else "FAIL",flush=True)
    summary={"schema_version":"1.0","created_utc":utc_now(),"evaluation_kind":"self_authored_development_controls_static_only",
             "spec_sha256":sha256(ROOT/"fixtures/android/cases.json"),"build_inventory_sha256":sha256(a.apks/"inventory.json"),
             "case_count":len(results),"passed_cases":sum(r["passed"] for r in results),
             "passed_assertions":sum(sum(r["checks"].values()) for r in results),"total_assertions":sum(len(r["checks"]) for r in results),"results":results,
             "limitations":["Same implementer authored source expectations and analyzer","No Android runtime validation","SDK class is a structural stub, not the real SDK","Not held-out data and not a population accuracy estimate"]}
    write_json(a.out/"summary.json",summary)
    return 0 if all(r["passed"] for r in results) else 1


if __name__=="__main__":raise SystemExit(main())
