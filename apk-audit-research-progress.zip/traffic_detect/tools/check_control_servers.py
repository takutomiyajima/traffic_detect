"""Functional HTTP/HTTPS/UDP check on this host, with certificate verification."""
import argparse
import http.client
import ipaddress
import json
import socket
import ssl
from datetime import datetime,timedelta,timezone
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID
from apk_audit.control_server import ControlServers
from apk_audit.core import write_json


def main():
    p=argparse.ArgumentParser();p.add_argument("--out",type=Path,required=True);a=p.parse_args()
    if a.out.exists():raise SystemExit("Use a new output directory")
    a.out.mkdir(parents=True)
    key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    subject=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,"localhost")]);now=datetime.now(timezone.utc)
    cert=(x509.CertificateBuilder().subject_name(subject).issuer_name(subject).public_key(key.public_key()).serial_number(x509.random_serial_number())
          .not_valid_before(now-timedelta(minutes=1)).not_valid_after(now+timedelta(days=1))
          .add_extension(x509.SubjectAlternativeName([x509.DNSName("localhost"),x509.IPAddress(ipaddress.ip_address("127.0.0.1"))]),False).sign(key,hashes.SHA256()))
    certpath=a.out/"lab-cert.pem";keypath=a.out/"lab-key.pem"
    certpath.write_bytes(cert.public_bytes(serialization.Encoding.PEM));keypath.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()));keypath.chmod(0o600)
    try:
        with ControlServers(a.out/"server-events.jsonl",tls_cert=certpath,tls_key=keypath) as servers:
            for protocol in ("http","https"):
                address,port=servers.addresses[protocol]
                conn=(http.client.HTTPSConnection(address,port,context=ssl.create_default_context(cafile=str(certpath)),timeout=5) if protocol=="https" else http.client.HTTPConnection(address,port,timeout=5))
                ids=[]
                try:
                    for _ in range(2):
                        conn.request("POST","/collect",body=b"dummy",headers={"X-Audit-Run":"host-smoke"})
                        response=conn.getresponse();assert response.status==200;ids.append(json.loads(response.read())["connection_id"])
                    assert len(set(ids))==1
                finally:conn.close()
            with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sock:
                sock.settimeout(5);sock.sendto(b"audit:host-smoke",servers.addresses["udp"]);assert sock.recvfrom(100)[0]==b"audit-ack"
    finally:
        keypath.unlink(missing_ok=True)  # The temporary test key is not a deliverable.
    events=[json.loads(s) for s in (a.out/"server-events.jsonl").read_text().splitlines()]
    result={"scope":"actual host-loopback HTTP/HTTPS/UDP; NOT Android capture or UID attribution", "tls_verification":"enabled; ephemeral certificate explicitly trusted only by this client",
            "http_requests":sum(e["event"]=="http_request_received" and e["protocol"]=="http" for e in events),
            "https_requests":sum(e["event"]=="http_request_received" and e["protocol"]=="https" for e in events),
            "tcp_connections":sum(e["event"]=="tcp_connection_accepted" for e in events),"udp_datagrams":sum(e["event"]=="udp_datagram_received" for e in events)}
    assert (result["http_requests"],result["https_requests"],result["tcp_connections"],result["udp_datagrams"])==(2,2,2,1)
    write_json(a.out/"summary.json",result);print(json.dumps(result,indent=2))


if __name__=="__main__":main()
