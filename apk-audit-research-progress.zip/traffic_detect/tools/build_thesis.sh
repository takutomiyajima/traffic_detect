#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../docs"
export TEXMFVAR="$(pwd)/../.cache/texmf-var"
export TEXMFCONFIG="$(pwd)/../.cache/texmf-config"
export XDG_CACHE_HOME="$(pwd)/../.cache"
mkdir -p "$TEXMFVAR" "$TEXMFCONFIG"
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error thesis.tex
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error thesis.tex
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error thesis.tex
