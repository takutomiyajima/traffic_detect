"""Score independently annotated JSON labels; does not create ground truth."""
import argparse
from apk_audit.core import read_json,write_json
from apk_audit.evaluation import score_labels


def main():
    p=argparse.ArgumentParser();p.add_argument("--gold",required=True);p.add_argument("--predictions",required=True);p.add_argument("--out",required=True);a=p.parse_args()
    gold=read_json(a.gold);predictions=read_json(a.predictions)
    result=score_labels(gold["units"],predictions["predictions"])
    result["dataset_kind"]=gold.get("dataset_kind","unspecified")
    write_json(a.out,result)


if __name__=="__main__":main()
