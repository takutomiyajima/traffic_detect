"""Reproduce the public APK smoke test. Downloads only when explicitly invoked.

Run: .venv/bin/python tools/validate_public_apk.py --out runs/public-check
The test APK remains a local generated input; it is not redistributed here.
"""
import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from urllib.request import urlopen

COMMIT = "581f7a3251545a97f66ee92b674dd810ee380a00"
EXPECTED = "f427a0ebe0bca97b9acf6cd2a2a01c37a7d3762841810fc54a7191ec637330b2"
URL = f"https://raw.githubusercontent.com/androguard/androguard/{COMMIT}/tests/data/APK/hello-world.apk"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out", required=True, type=Path)
    args = p.parse_args()
    if args.out.exists():
        raise SystemExit("Use a new output directory")
    args.out.mkdir(parents=True)
    with urlopen(URL, timeout=30) as response:
        data = response.read(4 * 1024**2)
    digest = hashlib.sha256(data).hexdigest()
    if digest != EXPECTED:
        raise SystemExit("APK checksum mismatch: stop without analyzing")
    apk = args.out / "hello-world.apk"
    apk.write_bytes(data)
    summaries, canonical = [], []
    for repetition in (1, 2):
        out = args.out / f"repetition-{repetition}"
        subprocess.run([sys.executable, "-m", "apk_audit.cli", "static", "--apk", str(apk), "--out", str(out)], check=True)
        result = json.loads((out / "static.json").read_text())
        run = json.loads((out / "run.json").read_text())
        summaries.append({"repetition": repetition, "package": result["package"], "url_candidates": len(result["urls"]),
                          "api_references": len(result["api_references"]), "permission_count": len(result["permissions"]),
                          "sdk_candidates": len(result["sdk_candidates"]), "duration_s": run["static_duration_s"], "max_rss_kib": run["static_resources"]["max_rss_kib"]})
        result.pop("analysis_duration_s")
        canonical.append(json.dumps(result, ensure_ascii=False, sort_keys=True))
    if canonical[0] != canonical[1] or hashlib.sha256(apk.read_bytes()).hexdigest() != EXPECTED:
        raise SystemExit("Reproducibility or original APK integrity check failed")
    root = Path(__file__).resolve().parent.parent
    subprocess.run([sys.executable, "-m", "apk_audit.cli", "compare", "--run", str(out), "--intent", str(root / "examples/intent-offline.json")], check=True)
    subprocess.run([sys.executable, "-m", "apk_audit.cli", "report", "--run", str(out)], check=True)
    summary = {"input_url": URL, "sha256": digest, "size_bytes": len(data), "static_repeatability": "passed_excluding_duration",
               "original_apk_integrity": "unchanged", "measurements": summaries, "canonical_static_sha256": hashlib.sha256(canonical[0].encode()).hexdigest(),
               "scope": "public sample static smoke test only; no Android execution and no accuracy estimate"}
    (args.out / "validation.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
