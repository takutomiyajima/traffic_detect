"""Package only the stdlib guided runner, pinned controls, and instructions."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path

from run_guided_trial import CASES

ROOT = Path(__file__).resolve().parents[1]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', type=Path, default=ROOT / 'dist/guided-trial-runner.zip')
    p.add_argument('--folder-name', default='guided-trial-runner')
    p.add_argument('--readme', type=Path, default=ROOT / 'docs/research/guided-trials.md')
    args = p.parse_args()
    if not args.folder_name or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_' for c in args.folder_name):
        p.error('Invalid bundle folder name')
    files = {
        'run_guided_trial.py': (ROOT / 'tools/run_guided_trial.py').read_bytes(),
        'measure_android_clock.py': (ROOT / 'tools/measure_android_clock.py').read_bytes(),
        'README.md': args.readme.read_bytes(),
    }
    for name in ('__init__.py', 'core.py', 'control_server.py'):
        files['apk_audit/' + name] = (ROOT / 'src/apk_audit' / name).read_bytes()
    for case, spec in CASES.items():
        data = (ROOT / spec.get('apk_relative', 'runs/control-apks-v3-ui/' + case + '.apk')).read_bytes()
        assert hashlib.sha256(data).hexdigest() == spec['sha256'], case
        files['apks/' + case + '.apk'] = data
    inventory = {'files': [{'path': name, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
                            for name, data in sorted(files.items())],
                 'scope': 'stdlib runner; pinned self-authored API-35 controls; operator manages PCAPdroid'}
    files['BUNDLE-MANIFEST.json'] = (json.dumps(inventory, ensure_ascii=False, indent=2) + '\n').encode()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.out, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for name, data in sorted(files.items()):
            z.writestr(args.folder_name + '/' + name, data)
    with zipfile.ZipFile(args.out) as z:
        assert z.testzip() is None
        for entry in inventory['files']:
            assert hashlib.sha256(z.read(args.folder_name + '/' + entry['path'])).hexdigest() == entry['sha256']
    print(json.dumps({'out': str(args.out), 'files': len(files), 'bytes': args.out.stat().st_size,
                      'sha256': hashlib.sha256(args.out.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()
