"""Build signed, source-controlled Android controls without Gradle or an emulator."""
import argparse
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SDK = ROOT / ".cache/android-toolchain"
HTTP = '''
private void sendHttp(String destination, String body) {
    try {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection)new java.net.URL(destination).openConnection();
        c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setInstanceFollowRedirects(false);
        c.setRequestProperty("X-Audit-Run", experimentId); c.setRequestProperty("Connection", "close");
        c.setRequestMethod("POST"); c.setDoOutput(true);
        try(java.io.OutputStream out = c.getOutputStream()) { out.write(body.getBytes("UTF-8")); }
        int code = c.getResponseCode(); c.disconnect(); record("http_response=" + code);
    } catch(Exception e) { record("http_error=" + e.getClass().getSimpleName()); }
}
'''
LOCATION = '''
private boolean locationReady() {
    if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
        requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        record("grant_permission_then_press_run_again"); return false;
    }
    return true;
}
private android.location.Location readLocation() {
    android.location.LocationManager m = (android.location.LocationManager)getSystemService(LOCATION_SERVICE);
    android.location.Location loc = m.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER);
    record(loc == null ? "location_unavailable" : "location_read"); return loc;
}
'''


def run(argv):
    subprocess.run([str(s) for s in argv], check=True, timeout=120, capture_output=True)


def behavior(mode):
    if mode == "offline": return 'record("local_only_completed");', "", ""
    if mode == "crash": return 'throw new IllegalStateException("deliberate control crash");', "", ""
    if mode == "location": return 'if(locationReady()) readLocation();', LOCATION, ""
    if mode == "udp":
        return '''new Thread(() -> {try {
            String[] parts=destination.split(":");
            byte[] body=("audit:"+experimentId).getBytes("UTF-8");
            try(java.net.DatagramSocket socket=new java.net.DatagramSocket()) {
                socket.send(new java.net.DatagramPacket(body,body.length,java.net.InetAddress.getByName(parts[0]),Integer.parseInt(parts[1])));
            } record("udp_sent");
        }catch(Exception e){record("udp_error="+e.getClass().getSimpleName());}}).start();''', "", "10.0.2.2:8766"
    if mode == "location_https":
        return '''if(!destination.startsWith("https://")){record("https_endpoint_required");return;}
        if(locationReady()) {android.location.Location loc=readLocation(); if(loc==null)return;
        final String body="dummy_location="+loc.getLatitude()+","+loc.getLongitude();
        new Thread(() -> sendHttp(destination,body)).start();}''', LOCATION+HTTP, ""
    if mode == "after_home":
        # Set a flag on click, perform once after the Activity leaves foreground.
        return 'armed=true; armedDestination=destination; record("armed_press_Home");', HTTP+'''
private boolean armed=false; private String armedDestination;
@Override protected void onStop() { super.onStop(); if(armed){armed=false;
    final String d=armedDestination; new Thread(() -> sendHttp(d,"audit="+experimentId)).start();}}
''', "http://10.0.2.2:8765/collect"
    guard = 'if(!destination.startsWith("https://")){record("https_endpoint_required");return;}' if mode == "https" else 'if(!destination.startsWith("http://")){record("http_endpoint_required");return;}'
    sleep = 'try{Thread.sleep(30000);}catch(InterruptedException e){Thread.currentThread().interrupt();return;}' if mode == "delayed" else ""
    return guard+'new Thread(() -> {'+sleep+'sendHttp(destination,"audit="+experimentId);}).start();', HTTP, "" if mode == "https" else "http://10.0.2.2:8765/collect"


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--out",type=Path,required=True);args=parser.parse_args()
    out=args.out.resolve()
    if out.exists(): raise SystemExit("Use a new output directory")
    out.mkdir(parents=True)
    jar=SDK/"platform/android-35/android.jar";bt=SDK/"build-tools/android-15";ecj=SDK/"ecj-3.39.0.jar"
    if not all(p.exists() for p in (jar,bt/"aapt2",ecj)): raise SystemExit("Run tools/prepare_android_tools.py first")
    keystore=SDK/"research-debug.keystore"
    if not keystore.exists():
        run(["keytool","-genkeypair","-noprompt","-keystore",keystore,"-storepass","android","-keypass","android","-alias","androiddebugkey","-dname","CN=Research Control Only","-keyalg","RSA","-keysize","2048","-validity","3650"])
    inventory=[]
    template=(ROOT/"fixtures/android/MainActivity.java.in").read_text()
    cases=json.loads((ROOT/"fixtures/android/cases.json").read_text())["cases"]
    for spec in cases:
        case=spec["id"];package="org.example.apkaudit."+case;work=out/case;work.mkdir()
        src=work/"src";res=work/"res";classes=work/"classes";dex=work/"dex"
        for d in (src,res/"values",classes,dex,work/"gen"): d.mkdir(parents=True,exist_ok=True)
        (res/"values/ids.xml").write_text('<resources><item type="id" name="run_case"/><item type="id" name="status"/><item type="id" name="endpoint"/><string name="documentation">https://docs.example.org/reference</string></resources>')
        nsc=' android:networkSecurityConfig="@xml/network"' if spec.get("nsc") else ""
        if nsc:
            (res/"xml").mkdir()
            (res/"xml/network.xml").write_text('<network-security-config><base-config cleartextTrafficPermitted="false"/><domain-config cleartextTrafficPermitted="true"><domain includeSubdomains="true">example.org</domain><domain-config cleartextTrafficPermitted="false"><domain>api.example.org</domain></domain-config></domain-config></network-security-config>')
        permissions=''.join('<uses-permission android:name="'+p+'"/>' for p in spec["permissions"])
        manifest=work/"AndroidManifest.xml"
        manifest.write_text(f'<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="{package}" android:versionCode="2" android:versionName="1.1"><uses-sdk android:minSdkVersion="24" android:targetSdkVersion="35"/>{permissions}<application android:theme="@android:style/Theme.Material.Light.NoActionBar" android:label="Audit {case}" android:debuggable="true" android:usesCleartextTraffic="{str(spec["cleartext"]).lower()}"{nsc}><activity android:name=".MainActivity" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>')
        action,helpers,default=behavior(spec["mode"])
        java=template.replace("@PACKAGE@",package).replace("@CASE@",case).replace("@DEFAULT_ENDPOINT@",default).replace("@ACTION@",action).replace("@HELPERS@",helpers)
        (src/"MainActivity.java").write_text(java)
        if spec.get("sdk_signature_stub"):
            # Structural test only, NOT actual Sentry code or an SDK benchmark.
            (src/"AuditMarker.java").write_text('package io.sentry.android.core; public class AuditMarker { public static String marker(){return "signature-only-stub";} }')
        run([bt/"aapt2","compile","--dir",res,"-o",work/"resources.zip"])
        run([bt/"aapt2","link","-I",jar,"--manifest",manifest,"--java",work/"gen","-o",work/"resources.apk",work/"resources.zip"])
        java_files=list(src.rglob("*.java"))+list((work/"gen").rglob("*.java"))
        run(["java","-jar",ecj,"-8","-proc:none","-classpath",jar,"-d",classes,*java_files])
        run([bt/"d8","--min-api","24","--lib",jar,"--output",dex,*classes.rglob("*.class")])
        unsigned=work/"unsigned.apk"
        unsigned.write_bytes((work/"resources.apk").read_bytes())
        with zipfile.ZipFile(unsigned,"a") as z:z.write(dex/"classes.dex","classes.dex")
        if spec.get("multidex"):
            extra=work/"extra";extra.mkdir();(extra/"classes").mkdir();(extra/"dex").mkdir()
            (extra/"Secondary.java").write_text('package org.example.secondary; public class Secondary { public static String unused(){return "https://secondary.example.org/unused";} public static java.net.URL api() throws Exception {return new java.net.URL(unused());}}')
            run(["java","-jar",ecj,"-8","-proc:none","-classpath",jar,"-d",extra/"classes",extra/"Secondary.java"])
            run([bt/"d8","--min-api","24","--lib",jar,"--output",extra/"dex",*list((extra/"classes").rglob("*.class"))])
            with zipfile.ZipFile(unsigned,"a") as z:z.write(extra/"dex/classes.dex","classes2.dex")
        run([bt/"zipalign","-f","4",unsigned,work/"aligned.apk"])
        apk=out/(case+".apk")
        run([bt/"apksigner","sign","--ks",keystore,"--ks-pass","pass:android","--key-pass","pass:android","--out",apk,work/"aligned.apk"])
        run([bt/"apksigner","verify","--verbose",apk])
        inventory.append({"case_id":case,"package":package,"apk":apk.name,"sha256":hashlib.sha256(apk.read_bytes()).hexdigest(),"version_code":2,"version_name":"1.1","ui_revision":"no_action_bar_with_system_insets","runtime_status":"not_executed","signature_verified_by":"Android apksigner 35.0.0","expected_permissions":spec["permissions"],"expected_dex_files":["classes.dex","classes2.dex"] if spec.get("multidex") else ["classes.dex"],"source_spec":spec})
        print("Built and signature-verified",apk.name,flush=True)
    (out/"inventory.json").write_text(json.dumps({"schema_version":"1.0","signing":"research-only debug key; not a production identity","tools_inventory_sha256":hashlib.sha256((SDK/"inventory.json").read_bytes()).hexdigest(),"activity_template_sha256":hashlib.sha256((ROOT/"fixtures/android/MainActivity.java.in").read_bytes()).hexdigest(),"cases":inventory},indent=2)+"\n")


if __name__=="__main__":
    try: main()
    except subprocess.CalledProcessError as e:
        print(e.stdout.decode(errors="replace"));print(e.stderr.decode(errors="replace"));raise
