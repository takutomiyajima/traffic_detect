# APK通信と開発意図の照合支援システム

制御アプリの画面修正版1.1を追加しました。旧版の画面でボタンがタイトルバーに隠れる状態が報告されたため、NoActionBar・画面Insets・余白を明示しました。更新手順は [UI修正とAPK更新](docs/research/ui-fix.md) を参照してください。旧版の静的評価記録は維持し、修正版のAPK・検証を別runに保存しています。

Python製のローカルCLIです。APKのManifest・DEX・リソースから得た静的候補と、取得した通信メタデータを、開発者が明示した意図JSONに照合します。JSONを正本に、根拠へ移動できるHTMLとCSVを生成します。有料AI APIは使いません。

**実装段階は研究用プロトタイプです。** 静的解析・ログ取り込み・照合・出力はこのクラウドで検証しています。Android Emulatorでの実行連携も実装していますが、この環境にはADB・Emulator・KVMがなく、実機能としての検証は未実施です。要件書のMVP完成条件すべてに合格したとは主張しません。要件との対応は [docs/requirements.md](docs/requirements.md)、実測は [docs/validation.md](docs/validation.md) を参照してください。

## 最初に動かす

検証環境はLinux x86_64 / Python 3.12です。既存のチェックアウトを使い、新しいGit worktreeは不要です。

```bash
cd /workspace/traffic_detect
bash tools/setup.sh
source .venv/bin/activate
apk-audit demo --out runs/my-demo
```

`runs/my-demo/report.html` をファイルとして開いてください。デモは**合成の入力・通信・操作記録**です。Androidで通信を取得した結果ではありません。`--out` は新規または空のディレクトリを指定します。原本を誤って上書きしません。

初回インストールにはPyPI接続が必要です。`requirements.lock` は間接依存を含む版とハッシュを固定しています。通常の解析はローカルで完結します。Androguardの依存としてFrida等も導入されますが、本システムはFridaを使用せず、APKの再署名やピンニング回避も行いません。

## 自分のAPKを解析する

```bash
apk-audit static --apk /path/to/app.apk --out runs/app
apk-audit compare --run runs/app --intent examples/intent-offline.json
apk-audit report --run runs/app
```

静的解析だけでもレポートを作れますが、動的観測は `not_run` と明示されます。APKに埋め込まれたURLを実通信として扱いません。対象は権限のある単一APKです。split APK・AAB、ネイティブコードの意味解析、難読化解除は対象外です。

`intent-offline.json` は旅行記録アプリの**例**なので、対象アプリの本来の意図に合わせて事前に編集してください。`app_purpose` の自然文から禁止事項を自動生成しません。

- `allowlist`: 空ではない許可リスト。リスト外を比較対象にする。
- `deny_all`: 当該カテゴリをすべて禁止。許可リストは空または省略。
- `unspecified`: 条件未指定。禁止とは扱わず `needs_review`。
- 通信先には `host`、`include_subdomains`、`ports`、`application_protocols` を指定。空のprotocolリストはプロトコル制約なし。
- `cleartext_policy` / `background_network_policy`: `allow` / `forbid` / `unspecified`。省略時は未指定。

IDNとIPを正規化し、サブドメインはドット境界で照合します。443番という理由だけでHTTPSやQUICとは判定しません。IPだけの記録で許可ドメインへの対応が不明なら、指定外通信と断定しません。HTTPS本文・URLパス・送信データの意味は判定しません。

## 外部で取得したログを取り込む

```bash
apk-audit import --run runs/app --adapter app-flow \
  --capture /path/to/flows.jsonl --metadata /path/to/capture.metadata.json
apk-audit compare --run runs/app --intent examples/intent-offline.json
apk-audit report --run runs/app
```

形式の詳細とコピー用の例は [docs/capture-format.md](docs/capture-format.md) にあります。`run_id`・APKハッシュ・取得ツール版・時刻補正・取得前後の対照を確認します。対象UIDは毎回のインストールから取得し、`target_identity` またはADB実行記録を通して結び付けます。記録の自己申告が正しいことをプログラムだけで保証はできません。

PCAP/PCAPNGは `--adapter pcap` で取り込めます。メタデータに `client_ips` が必要です。PCAPだけの通信元アプリは `unknown` のままです。アプリ情報付きログと自動的に同一視しません。取得元ごとに分け、バイト数・通信数を単純合算しません。同じログの再取り込みは拒否します。修正した条件での再解析は新しいrunを作ってください。

PCAPdroid 2.0.2の固定ソースに基づくCSVアダプタを追加しました。`--adapter pcapdroid-csv` を指定し、メタデータの `tool` を `PCAPdroid`、`tool_version` を `2.0.2` にします。列ずれ・未確認の版を拒否し、原CSVの行へ追跡できます。CSV表示状態からTLS成立を推定せず、Info列はホスト出典が不明なので確定ホストにしません。ソース契約に沿った入力で試験済みですが、実端末のエクスポート検証はP0として残ります。mitmproxy dumpの直接取り込みとHTTPS復号は未実装です。

静的のみ・動的のみ・統合を比較する場合は、`apk-audit compare --run runs/app --intent intent.json --evidence-mode static-only` のように指定します。`dynamic-only`、`integrated` も選べます。元の証拠は維持しますがfindingsは更新するため、各方式の結果を別ファイルへ保存してから次を実行してください。

## Android側の実行（別途検証が必要）

専用AVDのあるホストにこのリポジトリとPython環境、Android SDK Platform Tools / Emulatorを用意します。このクラウドでAndroid動作確認はしていません。既存の個人用端末やアカウントを使わず、研究用のAVD・ダミーデータを使ってください。

```bash
apk-audit doctor --profile metadata --serial emulator-5554
# examples/scenario.json の resource-id を対象アプリの実際のIDに変更する
apk-audit run --apk /path/to/app.apk --intent examples/intent-offline.json \
  --scenario examples/scenario.json --profile metadata \
  --serial emulator-5554 --control-ip 10.0.2.2 --out runs/device
```

`--control-ip` はAVDからICMP疎通できる研究用ホストを指定してください。10.0.2.2はAndroid Emulatorから見たホストです。疎通確認で使用する通信は対象アプリの通信とは扱いません。実行は次を行います。

1. 選択したローカルEmulator、API・ABI・容量情報、owner user 0を確認。
2. 元APKを `adb install -r` でインストールし、その時点のUIDを記録。`fresh_app_data` 指定時は**対象アプリのデータを消去**。
3. Emulator consoleのnetwork captureを開始。前後のping要求・応答がPCAPにあることを検査。
4. launch、resource-id指定tap、Home、wait、手動チェックポイントを記録。launch/tapには到達確認用 `expect_resource_id` が必須。
5. finallyで取得を停止し、操作記録・取得条件・失敗理由を保存。停止失敗時は次の反復を実行しない。

手動操作は端末で `done` と入力するまで成功扱いにしません。自動操作の意味的な成功（本当に記録が保存されたか等）はUI要素だけでは保証できないため、手動確認とサーバ側正解を併用してください。反復ごとに独立したrunを保存します。PCAPはUIDを含まないので、アプリ帰属を検証するにはアプリ情報付きログの追加取り込みが必要です。CA・proxy・VPNは自動変更しません。

## 出力と共有

`run.json`、`static.json`、`ui_events.jsonl`、`flows.jsonl`、`findings.json`、`findings.csv`、`report.html`、`raw/`、`evidence/index.json` を保存します。証拠のファイル・レコード位置・ハッシュを索引に記録し、report生成時に存在と改変の有無を確認します。

HTMLは外部リソースやスクリプトを必要としません。文字列をエスケープし、CSVの先頭式記号も無害化します。ただし研究者用の原本はURLのトークン等を含む可能性があるため、そのまま共有しないでください。

```bash
apk-audit share --run runs/app --out runs/shared-summary
```

共有版は判定・規則・状態のみを許可リスト方式で書き出し、ホスト・パス・目的文・UID・原本・証拠リンクを含めません。匿名化した完全レポートではなく、原本への追跡性を省いた要約です。

終了コード: `0` 処理完了（不一致候補があっても0）、`2` 入力不正、`3` 環境不備、`4` 部分失敗、`5` 内部失敗。`doctor` はAndroid接続を確認できなければ3を返しますが、静的解析の利用は可能です。

## 卒論向け資料

- [docs/thesis.tex](docs/thesis.tex): 日本語A4の技術資料。理論・設計・実装・検証結果・評価計画・限界・参考文献。
- [docs/thesis.pdf](docs/thesis.pdf): ビルド済みPDF。
- [docs/validation.md](docs/validation.md): 実行済みの検証と未実施項目。

```bash
bash tools/build_thesis.sh
```

XeLaTeXとNoto Serif/Sans CJK JPが必要です。この環境にあるfontspecを使い、日本語フォントと改行を明示的に設定しています。大学・研究室の様式、関連研究レビュー、著者情報を合わせて編集してください。実験未実施の箇所を結果として記載しない構成です。

## 開発と検証

```bash
.venv/bin/python -m pytest -q
apk-audit schemas --out docs/schemas
```

単体・統合テストでは、ルール分岐、破損入力、証拠改変、JSON/HTML/CSV整合、合成PCAPのTCP/HTTP、共有版の除去を確認します。Android環境での受入試験や未知アプリでの検出精度の代わりにはなりません。依存更新時は `uv pip compile pyproject.toml --extra dev --generate-hashes -o requirements.lock` でロックを更新し、テストを実行してください。

公開APKによる動作確認を再現する場合は `.venv/bin/python tools/validate_public_apk.py --out runs/public-check` を実行します。固定コミットとハッシュを検査し、2回の静的解析の一致と原本未変更を確認します。APKの通信実験や精度評価は行いません。

## 卒論の実験準備と追加検証

[研究プロトコル](docs/research/protocol.md)、[調査記録](docs/research/related-work.md)、[受入試験表](docs/research/acceptance.csv)、[今回の実施報告](docs/research/executed-work.md)を追加しました。指導教員の確認と本評価は未実施です。

[自作制御APK](fixtures/android/README.md)は10種類をビルド・署名検証し、静的期待値103項目が一致しました。開発用の既知素材であり、未知アプリの精度ではありません。SDK名の模擬クラスは本物のSDKではないため、SDK検出精度の正例に数えません。

研究用サーバを手動で起動する場合:

```bash
.venv/bin/python -m apk_audit.control_server --log runs/server/events.jsonl
# HTTPSも必要な場合は、有効な試験用サーバ証明書と鍵を指定する
# --tls-cert /path/server.pem --tls-key /path/server-key.pem
```

接続IDとHTTP要求ID、UDPデータグラムを別イベントで記録し、本文・認証ヘッダは保存しません。ホスト内の通信試験は `.venv/bin/python tools/check_control_servers.py --out runs/new-server-check` で再現できます。この試験はAndroidでの取得やUID帰属の確認ではありません。

独立した正解ラベルを得た後、`.venv/bin/python tools/evaluate_labels.py --gold gold.json --predictions predictions.json --out scores.json` で方式別・項目別に集計できます。棄権を陰性に変換せず、条件付き再現率と評価可能率・全陽性に対する検出割合を併記します。入力例は研究プロトコルにあります。
