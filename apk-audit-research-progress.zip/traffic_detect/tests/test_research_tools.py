import json
import socket
import ssl
import http.client
import ipaddress
from datetime import datetime, timedelta, timezone

import pytest
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

from apk_audit.control_server import ControlServers
from apk_audit.core import AuditError, read_json, write_json
from apk_audit.capture import import_capture
from apk_audit.demo import demo
from apk_audit.pcapdroid import HEADER
from apk_audit.compare import compare
from apk_audit.evaluation import score_labels


@pytest.fixture
def csv_run(tmp_path):
    out=tmp_path/"run";demo(out)
    meta=read_json(out/"demo.metadata.json");meta.update(tool="PCAPdroid",tool_version="2.0.2")
    write_json(out/"pcapdroid-meta.json",meta)
    return out


def write_csv(out, **replace):
    row=dict(zip(HEADER,["6","10.0.2.15","12345","192.0.2.1","443","10123","Demo App","org.example.travel","TLS","Closed","telemetry.example.org","420","100","4","3","2026-01-01T00:00:10Z","2026-01-01T00:00:11Z"]))
    row.update(replace)
    path=out/"pcapdroid.csv";path.write_text(",".join(HEADER)+"\n"+",".join(row[k] for k in HEADER)+"\n")
    return path


def test_pcapdroid_original_csv_and_unknowns(csv_run):
    path=write_csv(csv_run)
    assert import_capture(csv_run,path,csv_run/"pcapdroid-meta.json","pcapdroid-csv")==1
    flows=[json.loads(s) for s in (csv_run/"flows.jsonl").read_text().splitlines()]
    flow=flows[-1]
    assert flow["attribution"]=="target"
    assert flow["observation"]=="connection_attempt"
    assert flow["host"] is None and flow["application_protocol"] is None
    index=read_json(csv_run/"evidence/index.json")
    assert index[flow["evidence_ids"][0]]["locator"]=={"line":2}
    assert index[flow["evidence_ids"][0]]["path"].endswith(".csv")


@pytest.mark.parametrize("replace",[{"App":"comma,name"},{"IPProto":"1"},{"UID":"not-a-uid"},{"FirstSeen":"no-timezone"}])
def test_pcapdroid_ambiguous_or_invalid_rejected(csv_run,replace):
    path=write_csv(csv_run,**replace)
    before=(csv_run/"flows.jsonl").read_bytes()
    with pytest.raises(AuditError):import_capture(csv_run,path,csv_run/"pcapdroid-meta.json","pcapdroid-csv")
    assert (csv_run/"flows.jsonl").read_bytes()==before


def test_pcapdroid_unsupported_version_rejected(csv_run):
    path=write_csv(csv_run);meta=read_json(csv_run/"pcapdroid-meta.json");meta["tool_version"]="unknown"
    write_json(csv_run/"pcapdroid-meta.json",meta)
    with pytest.raises(AuditError,match="tool_version"):import_capture(csv_run,path,csv_run/"pcapdroid-meta.json","pcapdroid-csv")


@pytest.mark.parametrize("field,value", [
    ("coverage_status", "unknown"), ("coverage_status", "incomplete"),
    ("clock_alignment_status", "conditional"), ("clock_alignment_status", "unknown"),
])
def test_positive_controls_do_not_override_explicit_capture_uncertainty(csv_run, field, value):
    path = write_csv(csv_run)
    meta = read_json(csv_run / "pcapdroid-meta.json")
    meta.update(controls_before="passed", controls_after="passed", missing_intervals=[],
                coverage_status="operator_attested", clock_alignment_status="measured")
    meta[field] = value
    write_json(csv_run / "pcapdroid-meta.json", meta)
    assert import_capture(csv_run, path, csv_run / "pcapdroid-meta.json", "pcapdroid-csv") == 1
    run = read_json(csv_run / "run.json")
    assert run["captures"][-1]["quality"] == "partial"
    assert run["dynamic_status"] == "partial" and run["run_status"] == "partial"


@pytest.mark.parametrize("field", ["coverage_status", "clock_alignment_status"])
def test_invalid_capture_quality_labels_rejected_before_mutation(csv_run, field):
    path = write_csv(csv_run)
    meta = read_json(csv_run / "pcapdroid-meta.json")
    meta[field] = "complete"
    write_json(csv_run / "pcapdroid-meta.json", meta)
    before = (csv_run / "flows.jsonl").read_bytes()
    with pytest.raises(AuditError, match=field):
        import_capture(csv_run, path, csv_run / "pcapdroid-meta.json", "pcapdroid-csv")
    assert (csv_run / "flows.jsonl").read_bytes() == before


def make_certificate(tmp_path):
    key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,"localhost")])
    now=datetime.now(timezone.utc)
    cert=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number())
          .not_valid_before(now-timedelta(minutes=1)).not_valid_after(now+timedelta(days=1))
          .add_extension(x509.SubjectAlternativeName([x509.DNSName("localhost"),x509.IPAddress(ipaddress.ip_address("127.0.0.1"))]),False)
          .sign(key,hashes.SHA256()))
    certpath=tmp_path/"lab-cert.pem";keypath=tmp_path/"lab-key.pem"
    certpath.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    keypath.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
    return certpath,keypath


def test_actual_loopback_http_https_udp_and_request_units(tmp_path):
    cert,key=make_certificate(tmp_path);log=tmp_path/"events.jsonl"
    with ControlServers(log,tls_cert=cert,tls_key=key) as servers:
        for protocol in ("http","https"):
            address,port=servers.addresses[protocol]
            conn=(http.client.HTTPSConnection(address,port,context=ssl.create_default_context(cafile=str(cert)),timeout=5)
                  if protocol=="https" else http.client.HTTPConnection(address,port,timeout=5))
            connection_ids=[]
            for _ in range(2):
                conn.request("POST","/collect?token=DO_NOT_LOG",body=b"dummy",headers={"X-Audit-Run":"unit-test","Authorization":"DO_NOT_LOG"})
                response=conn.getresponse();assert response.status==200
                connection_ids.append(json.loads(response.read())["connection_id"])
            assert connection_ids[0]==connection_ids[1]  # two requests, ONE connection
            conn.close()
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sock:
            sock.settimeout(5);sock.sendto(b"audit:unit-test",servers.addresses["udp"])
            assert sock.recvfrom(100)[0]==b"audit-ack"
    text=log.read_text();events=[json.loads(s) for s in text.splitlines()]
    assert sum(e["event"]=="tcp_connection_accepted" for e in events)==2
    assert sum(e["event"]=="http_request_received" for e in events)==4
    assert sum(e["event"]=="udp_datagram_received" for e in events)==1
    assert "DO_NOT_LOG" not in text and "dummy" not in text


def test_control_server_rejects_mismatched_tls_settings(tmp_path):
    with pytest.raises(ValueError,match="Both TLS"):ControlServers(tmp_path/"log",tls_cert="one-file-only")


def test_three_modes_preserve_evidence_and_exclude_other_scope(tmp_path):
    out=tmp_path/"demo";demo(out)
    intent=read_json(out/"intent.json")
    original=(out/"flows.jsonl").read_bytes()
    static=compare(out,intent,"static-only")
    assert any(f["subject"]=="permission_declaration" for f in static["findings"])
    assert not any(f["subject"]=="external_connection" for f in static["findings"])
    assert all(f["observation"]!="not_observed" for f in static["findings"])
    dynamic=compare(out,intent,"dynamic-only")
    assert any(f["subject"]=="external_connection" for f in dynamic["findings"])
    assert not any(f["subject"]=="permission_declaration" for f in dynamic["findings"])
    integrated=compare(out,intent)
    assert any(f["subject"]=="permission_declaration" for f in integrated["findings"])
    assert any(f["subject"]=="external_connection" for f in integrated["findings"])
    assert (out/"flows.jsonl").read_bytes()==original


def test_metrics_do_not_convert_unknown_to_negative():
    gold=[{"unit_id":"p1","stratum":"connection","positive":True},{"unit_id":"p2","stratum":"connection","positive":True},{"unit_id":"n1","stratum":"connection","positive":False}]
    predictions=[{"unit_id":"p1","mode":"integrated","verdict":"mismatch_candidate"},{"unit_id":"p2","mode":"integrated","verdict":"not_evaluable"},{"unit_id":"n1","mode":"integrated","verdict":"consistent_with_observed_evidence"}]
    row=next(r for r in score_labels(gold,predictions)["results"] if r["mode"]=="integrated")
    assert row["tp"]==1 and row["fn_on_evaluable"]==0 and row["abstained_positives"]==1
    assert row["recall_on_evaluable"]==1 and row["overall_positive_detection_yield"]==0.5
    assert row["evaluable_coverage"]==pytest.approx(2/3)
    empty=next(r for r in score_labels(gold,predictions)["results"] if r["mode"]=="static-only")
    assert empty["precision_on_evaluable"] is None and empty["missing_predictions"]==3


def test_metrics_reject_duplicate_labels():
    row={"unit_id":"same","stratum":"permissions","positive":True}
    with pytest.raises(AuditError):score_labels([row,row],[])


def test_metrics_count_false_positives_and_negatives():
    gold=[{"unit_id":"a","stratum":"sdk","positive":False},{"unit_id":"b","stratum":"sdk","positive":True}]
    predictions=[{"unit_id":"a","mode":"integrated","verdict":"mismatch_candidate"},{"unit_id":"b","mode":"integrated","verdict":"consistent_with_observed_evidence"}]
    row=next(r for r in score_labels(gold,predictions)["results"] if r["mode"]=="integrated")
    assert row["fp"]==1 and row["fn_on_evaluable"]==1 and row["overall_positive_detection_yield"]==0
