"""Host-side simulator tests; these do not establish Android UI compatibility."""
import csv
import hashlib
import http.client
import importlib.util
import json
import socket
import sys
import time
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

import pytest

TOOLS = Path(__file__).parents[1] / 'tools'
sys.path.insert(0, str(TOOLS))
spec = importlib.util.spec_from_file_location('guided', TOOLS / 'run_guided_trial.py')
guided = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guided)


class FakeProcess:
    def __init__(self):
        self.terminated = False

    def poll(self):
        return 0 if self.terminated else None

    def terminate(self):
        self.terminated = True

    def wait(self, timeout):
        return 0


class SimulatedTrial(guided.GuidedTrial):
    def start_logcat(self):
        self.logcat = FakeProcess()
        (self.out / 'app-logcat.txt').write_text('')
        (self.out / 'app-logcat-stderr.txt').write_text('')

    def measure_clock(self, phase):
        value = {'summary': {'status': 'measured_under_batch_assumptions',
                             'offset_lower_s': -0.01, 'offset_upper_s': 0.01},
                 'test_fixture': 'simulated clocks, no device measurement'}
        (self.out / f'clock-{phase}.json').write_text(json.dumps(value))
        return value


class FakeAdb:
    serial = 'emulator-5554'

    def __init__(self, case, out, checksum, omit_target=False, tap_failure=False, stale_csv=False):
        self.case, self.out, self.checksum = case, out, checksum
        self.package = 'org.example.apkaudit.' + case
        self.omit_target, self.tap_failure = omit_target, tap_failure
        self.stale_csv = stale_csv
        self.mode = 'app'
        self.status = 'waiting — press Run test'
        self.rows = []
        self.taps = self.installs = 0

    def row(self, uid, package, port, proto):
        now = datetime.now(timezone.utc).isoformat()
        return dict(zip(guided.HEADER, [str(proto), '10.215.173.1', '12345', '10.0.2.2', str(port),
                    str(uid), 'Test fixture', package, 'HTTP' if proto == 6 else 'UDP', 'Closed', '',
                    '100', '100', '1', '1', now, now]))

    def request(self, url, post=False):
        parts = urlsplit(url)
        c = http.client.HTTPConnection('127.0.0.1', parts.port, timeout=2)
        c.request('POST' if post else 'GET', parts.path + ('?' + parts.query if parts.query else ''),
                  body=('audit=' + self.trial_id).encode() if post else None,
                  headers={'Connection': 'close', **({'X-Audit-Run': self.trial_id} if post else {})})
        r = c.getresponse()
        result = json.loads(r.read())
        assert r.status == 200
        c.close()
        return result

    def run(self, *args, **kwargs):
        if args[0] == 'get-state':
            return 'device\n'
        if args[0] == 'version':
            return 'Android Debug Bridge version 1.0.41 (test fixture)\n'
        if args[:3] == ('emu', 'avd', 'name'):
            return 'Pixel_8_Edited_API_35\nOK\n'
        if args[0] == 'install':
            self.installs += 1
            return 'Success\n'
        if args[0] == 'pull':
            with Path(args[2]).open('w', newline='') as stream:
                writer = csv.DictWriter(stream, fieldnames=guided.HEADER)
                writer.writeheader()
                rows = [dict(r) for r in self.rows]
                if self.stale_csv:
                    for r in rows:
                        r.update(FirstSeen='2000-01-01T00:00:00Z', LastSeen='2000-01-01T00:00:01Z')
                writer.writerows(rows)
            return '1 file pulled\n'
        raise AssertionError(args)

    def shell(self, *args, **kwargs):
        if args == ('am', 'get-current-user'):
            return '0\n'
        if args[0] == 'getprop':
            return {'ro.build.version.sdk': '35', 'ro.product.cpu.abilist': 'arm64-v8a',
                    'ro.build.fingerprint': 'test-fingerprint'}[args[1]]
        if args[:2] == ('settings', 'get'):
            return ':0\n'
        if args[:2] == ('dumpsys', 'package'):
            version = '2.0.2' if args[2] == guided.PCAP_PACKAGE else '1.1'
            uid = 10150 if args[2] == guided.CHROME else 10207
            return f'    appId={uid}\n    versionName={version}\n    User 0: installed=true\n'
        if args[:2] == ('pm', 'path'):
            return 'package:/data/app/test/base.apk\n'
        if args[:2] == ('toybox', 'sha256sum'):
            return self.checksum + '  /data/app/test/base.apk\n'
        if args[:2] == ('toybox', 'stat'):
            return '1000\n'
        if args[:2] == ('am', 'start'):
            if args[-1] == guided.CHROME:
                self.mode = 'browser'
                url = args[args.index('-d') + 1]
                self.browser = self.request(url)
                self.rows.append(self.row(10150, guided.CHROME, urlsplit(url).port, 6))
            else:
                self.mode = 'app'
                self.trial_id = args[args.index('run_id') + 1]
                self.endpoint = args[args.index('endpoint') + 1] if 'endpoint' in args else ''
            return 'Activity started\n'
        if args[:2] == ('input', 'tap'):
            self.taps += 1
            if self.tap_failure:
                raise guided.TrialError('simulated uncertain tap transport failure')
            with (self.out / 'app-logcat.txt').open('a') as stream:
                stream.write(f'{time.time():.3f} I ApkAuditControl: run={self.trial_id} case={self.case} action_started\n')
                if self.case == 'http':
                    self.request(self.endpoint, post=True)
                elif self.case == 'udp':
                    host, port = self.endpoint.split(':')
                    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                        sock.settimeout(2)
                        sock.sendto(('audit:' + self.trial_id).encode(), ('127.0.0.1', int(port)))
                        assert sock.recvfrom(100)[0] == b'audit-ack'
                self.status = guided.CASES[self.case]['expected']
                stream.write(f'{time.time():.3f} I ApkAuditControl: run={self.trial_id} case={self.case} {self.status}\n')
            if self.case != 'offline' and not self.omit_target:
                port = urlsplit(self.endpoint).port if self.case == 'http' else int(self.endpoint.split(':')[1])
                self.rows.append(self.row(10207, self.package, port, 6 if self.case == 'http' else 17))
            return ''
        raise AssertionError(args)

    def ui(self):
        root = ET.Element('hierarchy')
        if self.mode == 'browser':
            ET.SubElement(root, 'node', {'text': json.dumps(self.browser)})
        else:
            ET.SubElement(root, 'node', {'resource-id': self.package + ':id/status', 'text': self.status})
            ET.SubElement(root, 'node', {'resource-id': self.package + ':id/run_case', 'text': 'Run test',
                                       'enabled': 'true', 'clickable': 'true', 'bounds': '[0,0][100,80]'})
        return root

    def screenshot(self, path):
        Path(path).write_bytes(b'\x89PNG\r\n\x1a\nSIMULATED_SCREENSHOT')


def make_trial(tmp_path, monkeypatch, case='http', **fake_options):
    apk = tmp_path / 'source.apk'
    apk.write_bytes(b'TEST_FIXTURE_NOT_AN_ANDROID_APK')
    checksum = hashlib.sha256(apk.read_bytes()).hexdigest()
    monkeypatch.setitem(guided.CASES[case], 'sha256', checksum)
    out = tmp_path / 'out' / 'test-trial'
    adb = FakeAdb(case, out, checksum, **fake_options)
    answers = iter(['start', 'stop', 'none', '/sdcard/Download/capture.csv'])
    def free_port(kind):
        with socket.socket(socket.AF_INET, kind) as sock:
            sock.bind(('127.0.0.1', 0))
            return sock.getsockname()[1]
    runner = SimulatedTrial(case, 'test-trial', out, apk, adb=adb,
                            input_func=lambda _: next(answers), observe_s=0.01,
                            http_port=free_port(socket.SOCK_STREAM), udp_port=free_port(socket.SOCK_DGRAM))
    return runner, adb


@pytest.mark.parametrize('case', ['http', 'offline', 'udp'])
def test_guided_lifecycle_real_reference_server_fake_device(tmp_path, monkeypatch, case):
    runner, adb = make_trial(tmp_path, monkeypatch, case)
    assert runner.execute() == 0
    assert adb.taps == adb.installs == 1 and runner.logcat.terminated
    state = json.loads((runner.out / 'trial.json').read_text())
    assert state['status'] == 'collected' and state['quality'] == 'partial'
    assert state['clock_alignment_status'] == 'conditional'
    assert state['policy_timing'] == 'before_capture'
    policy = json.loads((runner.out / 'intent-before-capture.json').read_text())
    if case != 'offline':
        assert policy['network']['allowed_destinations'][0]['ports'] == [runner.http_port if case == 'http' else runner.udp_port]
    assert state['capture_summary']['target_rows'] == (0 if case == 'offline' else 1)
    assert all(c['verification'] == 'ui_and_server_event_id' for c in runner.controls.values())
    archive = Path(str(runner.out) + '.zip')
    with zipfile.ZipFile(archive) as z:
        m = json.loads(z.read('test-trial/manifest.json'))
        for entry in m['files']:
            assert hashlib.sha256(z.read('test-trial/' + entry['path'])).hexdigest() == entry['sha256']


def test_server_success_does_not_hide_missing_target_csv_row(tmp_path, monkeypatch):
    runner, adb = make_trial(tmp_path, monkeypatch, omit_target=True)
    assert runner.execute() == 4
    assert runner.state['status'] == 'collected_needs_review'
    assert 'expected_target_connection_row_missing' in runner.state['capture_summary']['problems']
    assert adb.taps == 1


def test_old_csv_from_same_app_is_not_accepted_as_current_capture(tmp_path, monkeypatch):
    runner, adb = make_trial(tmp_path, monkeypatch, stale_csv=True)
    assert runner.execute() == 4
    assert runner.state['status'] == 'collected_needs_review'
    assert 'csv_rows_outside_capture_time_brackets' in runner.state['capture_summary']['problems']
    assert runner.state['capture_summary']['target_rows'] == 1 and adb.taps == 1


def test_uncertain_tap_is_not_retried_and_manual_capture_cleanup_is_reported(tmp_path, monkeypatch):
    runner, adb = make_trial(tmp_path, monkeypatch, tap_failure=True)
    assert runner.execute() == 4
    assert adb.taps == 1 and runner.logcat.terminated
    assert runner.state['status'] == 'failed' and runner.state['manual_capture_stop_required']
    assert Path(str(runner.out) + '.zip').is_file()


def test_cancellation_at_start_prompt_does_not_assume_capture_is_stopped(tmp_path, monkeypatch):
    runner, adb = make_trial(tmp_path, monkeypatch)
    runner.input = lambda _: 'q'
    assert runner.execute() == 130
    assert runner.state['status'] == 'cancelled'
    assert runner.state['manual_capture_stop_required']
    assert runner.logcat.terminated and adb.taps == 0


def test_existing_trial_is_preserved_without_install_or_tap(tmp_path, monkeypatch):
    runner, adb = make_trial(tmp_path, monkeypatch)
    runner.out.mkdir(parents=True)
    (runner.out / 'old.txt').write_text('original evidence')
    with pytest.raises(guided.TrialError, match='既にあります'):
        runner.execute()
    assert (runner.out / 'old.txt').read_text() == 'original evidence'
    assert adb.taps == adb.installs == 0


def test_wrong_apk_is_not_installed(tmp_path, monkeypatch):
    runner, adb = make_trial(tmp_path, monkeypatch)
    runner.apk.write_bytes(b'changed')
    assert runner.execute() == 4
    assert adb.installs == adb.taps == 0


def test_user_zero_appid_supported_but_conflicting_ids_rejected():
    assert guided.installation_uid('    appId=10207\n    User 0: installed=true\n') == 10207
    with pytest.raises(guided.TrialError):
        guided.installation_uid('    appId=10207\n    userId=10100\n    User 0: installed=true\n')


def test_remote_file_paths_are_shell_quoted_without_command_substitution():
    adb = guided.Adb('emulator-5554')
    calls = []
    adb.run = lambda *args, **kwargs: calls.append(args) or ''
    path = '/sdcard/Download/a $(private-command); name.csv'
    adb.shell('toybox', 'stat', '-c', '%s', path)
    assert calls[0] == ('shell', "toybox stat -c %s '/sdcard/Download/a $(private-command); name.csv'")
