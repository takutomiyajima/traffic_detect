import importlib.util
from pathlib import Path

spec = importlib.util.spec_from_file_location('android_clock', Path(__file__).parents[1] / 'tools/measure_android_clock.py')
clock = importlib.util.module_from_spec(spec)
spec.loader.exec_module(clock)


def row(before, after, device, elapsed=None, quantum=1):
    return {'host_before_epoch_ns': before, 'host_after_epoch_ns': after,
            'device_epoch_ns': device, 'printed_quantum_ns': quantum,
            'host_elapsed_monotonic_ns': after - before if elapsed is None else elapsed}


def test_known_offset_remains_in_bounds_despite_asymmetric_query_delays():
    # A 1-second host-minus-device difference, with unequal before/after latency.
    r = clock.summarize([row(2_000_000_000, 2_100_000_000, 1_090_000_000),
                         row(3_000_000_000, 3_100_000_000, 2_005_000_000)], 2)
    assert r['offset_lower_s'] <= 1 <= r['offset_upper_s']
    assert r['offset_upper_s'] - r['offset_lower_s'] < 0.02


def test_fractional_truncation_expands_lower_bound():
    r = clock.summarize([row(2_000_000_000, 2_000_000_100, 1_000_000_000, quantum=1_000_000)], 1)
    assert r['offset_lower_s'] == 0.999
    assert r['offset_upper_s'] == 1.0000001


def test_device_clock_step_is_not_averaged_into_a_fake_offset():
    r = clock.summarize([row(2_000_000_000, 2_010_000_000, 1_000_000_000),
                         row(3_000_000_000, 3_010_000_000, 3_000_000_000)], 2)
    assert r['status'] == 'unknown'
    assert r['offset_midpoint_s'] is None
    assert 'no_constant_offset_fits_measurement_batch' in r['reasons']


def test_host_clock_step_rejected_using_monotonic_elapsed():
    r = clock.summarize([row(2_000_000_000, 3_000_000_000, 1_000_000_000, elapsed=10_000_000)], 1)
    assert r['status'] == 'unknown'
    assert 'host_wall_clock_discontinuity' in r['reasons']


def test_failed_or_missing_queries_never_become_zero_offset():
    for samples in ([], [{'error': 'TimeoutExpired'}]):
        r = clock.summarize(samples, 5)
        assert r['status'] == 'unknown'
        assert r['offset_midpoint_s'] is None
