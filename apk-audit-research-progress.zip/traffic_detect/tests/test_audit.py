import copy
import csv
import io
import json
import socket
import subprocess
import sys
import zipfile
from pathlib import Path

import dpkt
import pytest

from apk_audit.capture import app_flows, attribution, import_capture, pcap_flows
from apk_audit.cli import static_stage
from apk_audit.compare import destination_verdict, compare
from apk_audit.contracts import validate_intent, validate_scenario
from apk_audit.core import AuditError, host_matches, new_run, normalize_host, read_json, sha256, write_json, write_jsonl
from apk_audit.demo import demo
from apk_audit.report import report
from apk_audit.share import export_summary
from apk_audit.static import check_apk, network_config


def intent(mode="deny_all"):
    network = {"mode": mode}
    if mode == "allowlist":
        network["allowed_destinations"] = [{"host": "example.com", "include_subdomains": False, "ports": [443], "application_protocols": ["https"]}]
    return {"schema_version": "1.0", "app_purpose": "offline", "network": network, "sdk": {"mode": "deny_all"}, "permissions": {"mode": "unspecified"}}


@pytest.mark.parametrize("value,expected", [("EXAMPLE.com.", "example.com"), ("[2001:0db8::1]", "2001:db8::1"), ("例え.テスト", "xn--r8jz45g.xn--zckzah"), ("192.0.2.1", "192.0.2.1")])
def test_host_normalization(value, expected):
    assert normalize_host(value) == expected


@pytest.mark.parametrize("value", ["https://example.com", "*.example.com", "bad..com", "-bad.com", "a@b.com", "a/b", "2001:xxx::1"])
def test_invalid_hosts(value):
    with pytest.raises(AuditError):
        normalize_host(value)


def test_domain_boundaries():
    assert host_matches("api.example.com", "example.com", True)
    assert not host_matches("badexample.com", "example.com", True)
    assert not host_matches("example.com.evil.org", "example.com", True)
    assert not host_matches("api.example.com", "example.com", False)


@pytest.mark.parametrize("mutate", [lambda x: x["network"].update(mode="allowlist", allowed_destinations=[]), lambda x: x["sdk"].update(allowed_ids=["x"]), lambda x: x.update(extra="typo"), lambda x: x["network"].update(mode="deny_all", allowed_destinations=[{}])])
def test_contradictory_intent_rejected(mutate):
    value = intent()
    mutate(value)
    with pytest.raises(AuditError):
        validate_intent(value)


def test_missing_policy_unspecified():
    assert validate_intent(intent())["cleartext_policy"] == "unspecified"


@pytest.mark.parametrize("host,protocol,expected", [("badexample.com", "https", "mismatch_candidate"), (None, None, "not_evaluable"), ("example.com", None, "not_evaluable"), ("example.com", "tls", "not_evaluable"), ("example.com", "https", "consistent_with_observed_evidence")])
def test_destination_states(host, protocol, expected):
    verdict, _ = destination_verdict(intent("allowlist")["network"], {"host": host, "destination_ip": "192.0.2.1", "port": 443, "application_protocol": protocol})
    assert verdict == expected


def test_unknown_ip_does_not_disprove_domain():
    p = intent("allowlist")["network"]
    assert destination_verdict(p, {"host": "192.0.2.1", "destination_ip": "192.0.2.1", "port": 443})[0] == "not_evaluable"


def test_unknown_attribution_and_conflicting_uid():
    run = {"package": "org.example.app", "target_uid": 10123}
    assert attribution({"package": "org.example.app"}, run)[0] == "unknown"
    assert attribution({"package": "org.other", "uid": 10123}, run)[0] == "unknown"
    assert attribution({"package": "org.example.app", "uid": 10123}, run)[0] == "target"
    assert attribution({"package": "org.other", "uid": 10124}, run)[0] == "other"
    assert attribution({"uid": 10124, "related_to_target": True}, run)[0] == "related_candidate"


@pytest.fixture
def demo_run(tmp_path):
    out = tmp_path / "demo"
    demo(out)
    return out


def test_demo_end_to_end_and_evidence(demo_run):
    data = read_json(demo_run / "findings.json")
    assert data["counts"]["mismatch_candidate"] == 3
    assert read_json(demo_run / "run.json")["run_kind"] == "synthetic_demonstration"
    assert report(demo_run) == len(data["findings"])
    assert "telemetry.example.org" in (demo_run / "flows.jsonl").read_text()
    with (demo_run / "findings.csv").open(encoding="utf-8-sig") as f:
        assert len(list(csv.DictReader(f))) == len(data["findings"])


def test_evidence_tamper_fails(demo_run):
    (demo_run / "raw/capture-1.jsonl").write_text("tampered")
    with pytest.raises(AuditError, match="Missing/modified"):
        report(demo_run)


def test_duplicate_import_rejected_without_new_flows(demo_run):
    before = (demo_run / "flows.jsonl").read_bytes()
    with pytest.raises(AuditError, match="already imported"):
        import_capture(demo_run, demo_run / "raw/demo-flow-input.jsonl", demo_run / "demo.metadata.json", "app-flow")
    assert (demo_run / "flows.jsonl").read_bytes() == before


def test_wrong_run_rejected(demo_run):
    meta = read_json(demo_run / "demo.metadata.json")
    meta["run_id"] = "wrong"
    write_json(demo_run / "wrong.metadata.json", meta)
    with pytest.raises(AuditError, match="mismatch"):
        import_capture(demo_run, demo_run / "raw/demo-flow-input.jsonl", demo_run / "wrong.metadata.json", "app-flow")


def test_connect_only_not_https(demo_run):
    row = json.loads((demo_run / "raw/demo-flow-input.jsonl").read_text())
    row.update(source_status="CONNECT", observation="http_observed", application_protocol="https")
    path = demo_run / "connect.jsonl"
    write_jsonl(path, [row])
    flow = list(app_flows(path, read_json(demo_run / "run.json"), read_json(demo_run / "demo.metadata.json")))[0]
    assert flow["observation"] == "connection_attempt"
    assert flow["application_protocol"] is None


def test_html_csv_injection_and_share(demo_run, tmp_path):
    result = read_json(demo_run / "findings.json")
    result["findings"][0]["message"] = '=HYPERLINK("https://evil.org")<script>alert(1)</script>'
    write_json(demo_run / "findings.json", result)
    report(demo_run)
    text = (demo_run / "report.html").read_text()
    assert "<script>alert" not in text
    assert "&lt;script&gt;" in text
    with (demo_run / "findings.csv").open(encoding="utf-8-sig") as f:
        assert next(csv.DictReader(f))["message"].startswith("'=")
    export_summary(demo_run, tmp_path / "shared")
    shared = (tmp_path / "shared/summary.json").read_text()
    assert "HYPERLINK" not in shared
    assert "telemetry.example.org" not in shared
    assert not (tmp_path / "shared/raw").exists()


@pytest.mark.parametrize("name", ["../outside.txt", "/tmp/outside.txt", "res/../../evil", "res\\evil", "C:evil"])
def test_zip_traversal_rejected(tmp_path, name):
    apk = tmp_path / "bad.apk"
    with zipfile.ZipFile(apk, "w") as z:
        z.writestr("AndroidManifest.xml", "x")
        z.writestr("classes.dex", "x")
        z.writestr(name, "x")
    with pytest.raises(AuditError):
        check_apk(apk)


def test_bad_apk_preserves_failure(tmp_path):
    apk = tmp_path / "bad.apk"
    apk.write_bytes(b"not a zip")
    out = tmp_path / "run"
    with pytest.raises(AuditError):
        static_stage(apk, out)
    run = read_json(out / "run.json")
    assert run["static_status"] == "failed"
    assert run["errors"]


def test_empty_capture_requires_controls(demo_run):
    run = read_json(demo_run / "run.json")
    run["captures"][0]["quality"] = "partial"
    run["dynamic_status"] = "partial"
    write_json(demo_run / "run.json", run)
    write_jsonl(demo_run / "flows.jsonl", [])
    result = compare(demo_run, intent())
    observation = [x for x in result["findings"] if x["subject"] == "observation_coverage"][0]
    assert observation["observation"] == "capture_failed"
    run["dynamic_status"] = "completed"
    write_json(demo_run / "run.json", run)
    assert [x for x in compare(demo_run, intent())["findings"] if x["subject"] == "observation_coverage"][0]["observation"] == "not_observed"


def test_partial_parse_never_safe(demo_run):
    run = read_json(demo_run / "run.json")
    run["static_status"] = "failed"
    write_json(demo_run / "run.json", run)
    assert any(f["subject"] == "static_coverage" and f["verdict"] == "not_evaluable" for f in compare(demo_run, intent())["findings"])


def test_invalid_ui_contract():
    scenario = {"schema_version": "1.0", "scenario_id": "x", "execution": "automatic", "repetitions": 1,
                "steps": [{"id": "launch", "action": "launch", "observe_s": 1}]}
    with pytest.raises(AuditError, match="expect_resource_id"):
        validate_scenario(scenario)


def packet(src, dst, sport, dport, flags, seq, ack=0, payload=b""):
    tcp = dpkt.tcp.TCP(sport=sport, dport=dport, flags=flags, seq=seq, ack=ack, data=payload)
    ip = dpkt.ip.IP(src=socket.inet_aton(src), dst=socket.inet_aton(dst), p=6, ttl=64, data=tcp)
    ip.len = len(ip)
    return bytes(dpkt.ethernet.Ethernet(src=b"\x00"*6, dst=b"\x01"*6, type=0x800, data=ip))


def test_pcap_handshake_http_and_unknown_owner(tmp_path):
    p = tmp_path / "test.pcap"
    a, b = "10.0.2.15", "192.0.2.1"
    with p.open("wb") as f:
        w = dpkt.pcap.Writer(f)
        w.writepkt(packet(a,b,12345,80,2,100), ts=1767225601)
        w.writepkt(packet(b,a,80,12345,18,200,101), ts=1767225602)
        w.writepkt(packet(a,b,12345,80,16,101,201), ts=1767225603)
        w.writepkt(packet(a,b,12345,80,24,101,201,b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n"), ts=1767225604)
    meta = {"client_ips": [a], "clock_offset_s": 0, "started_utc": "2026-01-01T00:00:00Z", "ended_utc": "2026-01-01T00:01:00Z"}
    flows = list(pcap_flows(p, {}, meta))
    assert len(flows) == 1
    assert flows[0]["host"] == "example.com"
    assert flows[0]["observation"] == "http_observed"
    assert flows[0]["attribution"] == "unknown"
    assert flows[0]["bytes_sent"] > 0 and flows[0]["bytes_received"] > 0


def test_port_443_does_not_prove_tls(tmp_path):
    p = tmp_path / "test.pcap"
    with p.open("wb") as f:
        w = dpkt.pcap.Writer(f)
        w.writepkt(packet("10.0.2.15","192.0.2.1",12345,443,2,100), ts=1767225601)
    flow = list(pcap_flows(p, {}, {"client_ips": ["10.0.2.15"], "clock_offset_s": 0, "started_utc": "2026-01-01T00:00:00Z", "ended_utc": "2026-01-01T00:01:00Z"}))[0]
    assert flow["application_protocol"] is None
    assert flow["observation"] == "connection_attempt"


@pytest.mark.parametrize("target,expected", [(23, True), (25, True), (28, False), (35, False)])
def test_cleartext_target_defaults(tmp_path, target, expected):
    from lxml import etree
    class FakeAPK:
        def get_target_sdk_version(self): return str(target)
        def get_min_sdk_version(self): return "21"
    manifest = etree.fromstring(b'<manifest><application/></manifest>')
    nsc = network_config(FakeAPK(), manifest, tmp_path)
    assert nsc["base_cleartext_permitted"] is expected


def test_nsc_inheritance_and_manifest_ignored(tmp_path):
    from lxml import etree
    source = tmp_path / "input.apk"
    source.write_bytes(b"fixture")
    out = tmp_path / "out"
    new_run(out, source)
    class FakeAPK:
        def get_target_sdk_version(self): return "35"
        def get_min_sdk_version(self): return "24"
        def get_file(self, name):
            assert name == "res/xml/network.xml"
            return b'<network-security-config><base-config cleartextTrafficPermitted="false"/><domain-config cleartextTrafficPermitted="true"><domain includeSubdomains="true">example.org</domain><domain-config cleartextTrafficPermitted="false"><domain>api.example.org</domain></domain-config></domain-config><debug-overrides><trust-anchors><certificates src="user"/></trust-anchors></debug-overrides></network-security-config>'
    manifest = etree.fromstring(b'<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application android:usesCleartextTraffic="true" android:networkSecurityConfig="@xml/network"/></manifest>')
    nsc = network_config(FakeAPK(), manifest, out)
    assert nsc["base_cleartext_permitted"] is False
    assert [d["cleartext_permitted"] for d in nsc["domains"]] == [True, False]
    assert nsc["trust_anchor_declarations"] == [{"src": "user"}]
    assert nsc["debug_overrides_present"]


def test_unresolved_nsc_is_unknown(tmp_path):
    from lxml import etree
    class FakeAPK:
        def get_target_sdk_version(self): return "35"
        def get_file(self, name): raise ValueError("fixture unsupported")
    manifest = etree.fromstring(b'<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application android:networkSecurityConfig="@xml/missing"/></manifest>')
    nsc = network_config(FakeAPK(), manifest, tmp_path)
    assert nsc["base_cleartext_permitted"] is None
    assert "unresolved" in nsc["warnings"][0]


def test_static_timeout_preserves_run(tmp_path, monkeypatch):
    source = tmp_path / "timeout.apk"
    with zipfile.ZipFile(source, "w") as z:
        z.writestr("AndroidManifest.xml", "x")
        z.writestr("classes.dex", "x")
    def timeout(*args, **kwargs):
        raise subprocess.TimeoutExpired("worker", 0.01)
    monkeypatch.setattr(subprocess, "run", timeout)
    with pytest.raises(AuditError):
        static_stage(source, tmp_path / "out", timeout=0.01)
    run = read_json(tmp_path / "out/run.json")
    assert run["static_status"] == "failed"
    assert run["errors"][0]["type"] == "TimeoutExpired"


def test_bad_capture_import_is_atomic(demo_run):
    before = (demo_run / "flows.jsonl").read_bytes()
    bad = demo_run / "bad.jsonl"
    bad.write_text('{"started_utc":"not-a-date"}\n')
    with pytest.raises(AuditError):
        import_capture(demo_run, bad, demo_run / "demo.metadata.json", "app-flow")
    assert (demo_run / "flows.jsonl").read_bytes() == before
    assert len(read_json(demo_run / "run.json")["captures"]) == 1


def test_nonfinite_json_rejected(tmp_path):
    p = tmp_path / "bad.json"
    p.write_text('{"observe_s": NaN}')
    with pytest.raises(AuditError):
        read_json(p)


@pytest.mark.parametrize("cleanup_fails", [False, True])
def test_android_capture_cleanup_on_ui_failure(tmp_path, monkeypatch, cleanup_fails):
    from apk_audit import android
    source = tmp_path / "original.apk"
    source.write_bytes(b"not executed: mocked adb fixture")
    out = tmp_path / "run"
    run = new_run(out, source)
    run.update(static_status="completed", package="org.example.app")
    write_json(out / "run.json", run)
    write_json(out / "static.json", {"abis": [], "min_sdk": "21"})
    calls = []
    class FakeAdb:
        def __init__(self, *args): pass
        def call(self, *args, **kwargs):
            calls.append(args)
            if args == ("shell", "am", "get-current-user"): return "0"
            if args[0] == "install": return "Success"
            if args[:3] == ("shell", "dumpsys", "package"): return "userId=10123"
            if args[:2] == ("shell", "ip"): return "inet 10.0.2.15/24"
            if args[:2] == ("shell", "ping"): return "1 packets transmitted, 1 received"
            if args[:2] == ("shell", "monkey"): raise AuditError("Simulated launch failure", 4)
            if args == ("emu", "network", "capture", "stop") and cleanup_fails:
                raise AuditError("Simulated capture stop failure", 3)
            return "OK"
    monkeypatch.setattr(android, "Adb", FakeAdb)
    monkeypatch.setattr(android, "doctor", lambda serial: {"api": "35", "abi": "x86_64", "avd": "mock-only"})
    scenario = {"execution": "automatic", "scenario_id": "fixture", "steps": [{"id": "launch", "action": "launch", "observe_s": 0}]}
    with pytest.raises(AuditError, match="Android trial failed"):
        android.execute(source, out, scenario, "emulator-5554", "10.0.2.2")
    result = read_json(out / "run.json")
    assert ("emu", "network", "capture", "stop") in calls
    assert result["execution_status"] == "failed"
    assert result["dynamic_status"] == "failed"
    assert result.get("cleanup_failed", False) is cleanup_fails
    assert sha256(source) == result["apk_sha256"]


def test_fragmented_capture_is_partial(demo_run):
    path = demo_run / "fragment.pcap"
    ip = dpkt.ip.IP(src=socket.inet_aton("10.0.2.15"), dst=socket.inet_aton("192.0.2.1"), p=6, data=b"fragment")
    ip.mf = 1
    ip.len = len(ip)
    with path.open("wb") as f:
        w = dpkt.pcap.Writer(f)
        w.writepkt(bytes(dpkt.ethernet.Ethernet(src=b"\x00"*6, dst=b"\x01"*6, type=0x800, data=ip)), ts=1767225601)
    meta = read_json(demo_run / "demo.metadata.json")
    meta["client_ips"] = ["10.0.2.15"]
    write_json(demo_run / "fragment.metadata.json", meta)
    import_capture(demo_run, path, demo_run / "fragment.metadata.json", "pcap")
    run = read_json(demo_run / "run.json")
    assert run["dynamic_status"] == "partial"
    assert run["captures"][-1]["metadata"]["adapter_coverage"]["ip_fragments_skipped"] == 1
