"""Local HTTP/HTTPS/UDP reference servers, recording connections separately.

No payloads, query strings, cookies or authorization headers are logged.
Use only dummy data. This is a lab server, not a production deployment.
"""
import argparse
import hashlib
import json
import re
import socketserver
import ssl
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from .core import utc_now


class EventLog:
    def __init__(self,path):
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
        self.lock=threading.Lock()
        # Append, never silently truncate previous experiments.
        self.file=self.path.open("a",encoding="utf-8")
    def write(self,**fields):
        record={"schema_version":"1.0","utc":utc_now(),"monotonic_s":time.monotonic(),**fields}
        with self.lock:
            self.file.write(json.dumps(record,sort_keys=True)+"\n");self.file.flush()
    def close(self):self.file.close()


def safe_run_id(value):
    return value if isinstance(value,str) and re.fullmatch(r"[A-Za-z0-9_.-]{1,80}",value) else None


class Handler(BaseHTTPRequestHandler):
    protocol_version="HTTP/1.1"
    def log_message(self,*args):pass
    def setup(self):
        super().setup();self.connection_id=uuid.uuid4().hex
        self.server.events.write(event="tcp_connection_accepted",connection_id=self.connection_id,protocol=self.server.observed_protocol)
    def finish(self):
        try:super().finish()
        finally:self.server.events.write(event="tcp_connection_closed",connection_id=self.connection_id,protocol=self.server.observed_protocol)
    def do_GET(self):self.respond()
    def do_POST(self):self.respond()
    def respond(self):
        try:
            length=int(self.headers.get("Content-Length","0"))
            if not 0<=length<=65536 or self.headers.get("Transfer-Encoding"):
                raise ValueError("unsupported body framing")
        except ValueError:
            self.send_error(400);self.close_connection=True;return
        self.connection.settimeout(5)
        body=self.rfile.read(length)
        if len(body)!=length:self.close_connection=True;return
        event_id=uuid.uuid4().hex
        self.server.events.write(event="http_request_received",event_id=event_id,connection_id=self.connection_id,
                                 protocol=self.server.observed_protocol,method=self.command,
                                 run_id=safe_run_id(self.headers.get("X-Audit-Run")),body_bytes=length,
                                 body_sha256=hashlib.sha256(body).hexdigest())
        response=json.dumps({"ok":True,"event_id":event_id,"connection_id":self.connection_id}).encode()
        self.send_response(200);self.send_header("Content-Type","application/json");self.send_header("Content-Length",str(len(response)));self.end_headers();self.wfile.write(response)


class UDPHandler(socketserver.BaseRequestHandler):
    def handle(self):
        body,socket=self.request
        run_id=None
        if body.startswith(b"audit:"):
            run_id=safe_run_id(body[6:].decode("ascii",errors="replace"))
        self.server.events.write(event="udp_datagram_received",datagram_id=uuid.uuid4().hex,protocol="udp",run_id=run_id,
                                 body_bytes=len(body),body_sha256=hashlib.sha256(body).hexdigest())
        socket.sendto(b"audit-ack",self.client_address)


class UDPServer(socketserver.ThreadingUDPServer):
    daemon_threads=True


class ControlServers:
    def __init__(self,log,bind="127.0.0.1",http_port=0,udp_port=0,https_port=0,tls_cert=None,tls_key=None):
        if bool(tls_cert)!=bool(tls_key):raise ValueError("Both TLS certificate and key required")
        self.events=EventLog(log);self.servers=[];self.threads=[];self.addresses={}
        try:
            for kind,port in (("http",http_port),("udp",udp_port),("https",https_port)):
                if kind=="https" and not tls_cert:continue
                server=UDPServer((bind,port),UDPHandler) if kind=="udp" else ThreadingHTTPServer((bind,port),Handler)
                server.daemon_threads=True;server.events=self.events;server.observed_protocol=kind
                self.servers.append(server)
                if kind=="https":
                    context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);context.minimum_version=ssl.TLSVersion.TLSv1_2
                    context.load_cert_chain(tls_cert,tls_key);server.socket=context.wrap_socket(server.socket,server_side=True)
                self.addresses[kind]=server.server_address
        except Exception:
            for server in self.servers:server.server_close()
            self.events.close();raise
    def __enter__(self):
        for server in self.servers:
            thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();self.threads.append(thread)
        self.events.write(event="control_server_started",protocols=list(self.addresses))
        return self
    def __exit__(self,*exc):
        for server in self.servers:server.shutdown();server.server_close()
        for thread in self.threads:thread.join(timeout=2)
        self.events.write(event="control_server_stopped");self.events.close()


def main():
    p=argparse.ArgumentParser(description="Dummy-data lab reference server; records requests and connections separately")
    p.add_argument("--log",type=Path,required=True);p.add_argument("--bind",default="127.0.0.1")
    p.add_argument("--http-port",type=int,default=8765);p.add_argument("--udp-port",type=int,default=8766);p.add_argument("--https-port",type=int,default=8767)
    p.add_argument("--tls-cert");p.add_argument("--tls-key");a=p.parse_args()
    with ControlServers(a.log,a.bind,a.http_port,a.udp_port,a.https_port,a.tls_cert,a.tls_key) as servers:
        print(json.dumps({"listening":servers.addresses,"body_logging":False}),flush=True)
        try:
            while True:time.sleep(1)
        except KeyboardInterrupt:pass


if __name__=="__main__":main()
