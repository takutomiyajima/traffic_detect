from __future__ import annotations

import hashlib
import ipaddress
import json
import os
import platform
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

SCHEMA_VERSION = "1.0"
MAX_JSON = 16 * 1024 * 1024


def _reject_constant(value):
    raise ValueError(f"Non-finite JSON constant: {value}")


class AuditError(Exception):
    def __init__(self, message: str, code: int = 2):
        super().__init__(message)
        self.code = code


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def timestamp(value):
    if not isinstance(value, str):
        raise AuditError("timestamp must be an ISO-8601 string with timezone")
    try:
        d = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if d.tzinfo is None:
            raise ValueError("timezone missing")
        return d.timestamp()
    except ValueError as e:
        raise AuditError(f"Invalid timestamp: {value}") from e


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path):
    p = Path(path)
    if p.stat().st_size > MAX_JSON:
        raise AuditError(f"JSON exceeds {MAX_JSON} bytes")
    try:
        return json.loads(p.read_text(encoding="utf-8"), parse_constant=_reject_constant)
    except (ValueError, UnicodeError) as e:
        raise AuditError(f"Invalid JSON: {p.name}: {e}") from e


def write_json(path, value):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=p.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(value, f, ensure_ascii=False, indent=2, sort_keys=True)
            f.write("\n")
        os.replace(tmp, p)
    finally:
        Path(tmp).unlink(missing_ok=True)


def read_jsonl(path):
    with Path(path).open(encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            if not line.strip():
                continue
            if len(line) > MAX_JSON:
                raise AuditError(f"JSONL line {i} too large")
            try:
                yield i, json.loads(line, parse_constant=_reject_constant)
            except ValueError as e:
                raise AuditError(f"Invalid JSONL at line {i}") from e


def write_jsonl(path, records):
    Path(path).write_text("".join(json.dumps(r, ensure_ascii=False, sort_keys=True) + "\n" for r in records), encoding="utf-8")


def normalize_host(host):
    if not isinstance(host, str) or not host.strip():
        raise AuditError("host must be a nonempty hostname or IP")
    host = host.strip().rstrip(".").lower()
    if host.startswith("[") and host.endswith("]"):
        host = host[1:-1]
    try:
        return ipaddress.ip_address(host).compressed
    except ValueError:
        pass
    if any(c in host for c in "/:@*?#\\ \t\r\n"):
        raise AuditError(f"Invalid host: {host}")
    try:
        host = host.encode("idna").decode("ascii")
    except UnicodeError as e:
        raise AuditError("Invalid IDN") from e
    labels = host.split(".")
    if len(host) > 253 or any(not x or len(x) > 63 or x.startswith("-") or x.endswith("-") or not all(c.isalnum() or c == "-" for c in x) for x in labels):
        raise AuditError(f"Invalid hostname: {host}")
    return host


def is_ip(host):
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


def host_matches(actual, allowed, subdomains=False):
    actual, allowed = normalize_host(actual), normalize_host(allowed)
    return actual == allowed or (subdomains and not is_ip(allowed) and actual.endswith("." + allowed))


def url_candidate(value):
    try:
        parsed = urlsplit(value)
        if parsed.scheme.lower() not in ("http", "https", "ws", "wss") or not parsed.hostname:
            return None
        host = normalize_host(parsed.hostname)
        return {"raw": value, "host": host, "port": parsed.port or (443 if parsed.scheme in ("https", "wss") else 80), "scheme": parsed.scheme.lower()}
    except (ValueError, AuditError):
        return None


def new_run(out, apk):
    out = Path(out)
    if out.exists() and any(out.iterdir()):
        raise AuditError("Output directory must be empty; previous evidence is never overwritten")
    out.mkdir(parents=True, exist_ok=True)
    (out / "raw").mkdir()
    (out / "evidence").mkdir()
    run = {"schema_version": SCHEMA_VERSION, "run_id": "R-" + uuid.uuid4().hex,
           "created_utc": utc_now(), "timezone": "UTC", "tool_version": "0.1.0",
           "apk_sha256": sha256(apk), "apk_name": Path(apk).name,
           "host": {"os": platform.platform(), "cpu": platform.machine(), "python": platform.python_version()},
           "run_status": "partial", "static_status": "pending", "dynamic_status": "not_run",
           "profile": "metadata", "original_apk": True, "errors": [], "captures": [],
           "limitations": ["No claim of absence, necessity, data leakage or safety."]}
    write_json(out / "run.json", run)
    write_json(out / "evidence/index.json", {})
    write_jsonl(out / "flows.jsonl", [])
    write_jsonl(out / "ui_events.jsonl", [])
    return run


def add_evidence(out, evidence_id, path, locator, **extra):
    out = Path(out)
    index = read_json(out / "evidence/index.json")
    index[evidence_id] = {"path": str(Path(path).relative_to(out)), "sha256": sha256(path), "locator": locator, **extra}
    write_json(out / "evidence/index.json", index)


def validate_schema(obj, schema):
    from jsonschema import Draft202012Validator
    errors = sorted(Draft202012Validator(schema).iter_errors(obj), key=lambda e: str(list(e.path)))
    if errors:
        raise AuditError("; ".join(f"{'.'.join(map(str,e.path)) or '$'}: {e.message}" for e in errors[:8]))
