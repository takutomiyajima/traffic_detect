from pathlib import Path

from .contracts import validate_intent
from .core import host_matches, is_ip, read_json, read_jsonl, write_json

RULE_VERSION = "2026-10-27.1"
MATCH = "mismatch_candidate"
OK = "consistent_with_observed_evidence"
REVIEW = "needs_review"
UNKNOWN = "not_evaluable"


def list_verdict(policy, value, key):
    if policy["mode"] == "unspecified":
        return REVIEW
    if policy["mode"] == "deny_all":
        return MATCH
    return OK if value in policy[key] else MATCH


def destination_verdict(policy, flow):
    if policy["mode"] == "unspecified":
        return REVIEW, "Network condition unspecified"
    if policy["mode"] == "deny_all":
        return MATCH, "Target connection attempt conflicts with deny_all"
    host = flow.get("host")
    if not host:
        # Literal IP allow rules may be evaluated directly; domain->IP is not assumed.
        ip_rules = [d for d in policy["allowed_destinations"] if is_ip(d["host"])]
        if any(d["host"] == flow.get("destination_ip") for d in ip_rules):
            host = flow["destination_ip"]
        else:
            return UNKNOWN, "No unambiguous host; IP cannot establish a domain mismatch"
    candidates = [d for d in policy["allowed_destinations"] if host_matches(host, d["host"], d["include_subdomains"])]
    if not candidates:
        # Explicit IP evidence does not prove that no permitted domain uses that IP.
        if is_ip(host) and any(not is_ip(d["host"]) for d in policy["allowed_destinations"]):
            return UNKNOWN, "Literal IP cannot disprove domain allowlist membership"
        return MATCH, "Observed host is outside allowlist"
    ports = [d for d in candidates if flow["port"] in d["ports"]]
    if not ports:
        return MATCH, "Observed port is outside host allowlist"
    if any(not d["application_protocols"] for d in ports):
        return OK, "Host and port permitted; application protocol unconstrained"
    if flow.get("application_protocol") is None:
        return UNKNOWN, "Protocol constrained but not observed; port does not prove protocol"
    if any(flow["application_protocol"] in d["application_protocols"] for d in ports):
        return OK, "Observed host, port and application protocol permitted"
    # TLS evidence alone is compatible with HTTPS, so cannot call it a mismatch.
    if flow["application_protocol"] == "tls" and any("https" in d["application_protocols"] for d in ports):
        return UNKNOWN, "TLS seen, HTTPS application semantics unknown"
    return MATCH, "Observed application protocol is outside allowlist"


def compare(out, intent, evidence_mode="integrated"):
    if evidence_mode not in ("static-only", "dynamic-only", "integrated"):
        from .core import AuditError
        raise AuditError("Unknown evidence mode")
    out = Path(out)
    intent = validate_intent(intent)
    run = read_json(out / "run.json")
    static = read_json(out / "static.json") if (out / "static.json").exists() else {}
    flows = [f for _, f in read_jsonl(out / "flows.jsonl")]
    if evidence_mode == "dynamic-only":
        static = {}
    if evidence_mode == "static-only":
        flows = []
    findings = []
    def add(rule, subject, verdict, message, evidence, flow=None, **extra):
        flow = flow or {}
        findings.append({"schema_version": "1.0", "finding_id": f"F{len(findings)+1:05}", "run_id": run["run_id"],
                         "rule_id": rule, "rule_version": RULE_VERSION, "subject": subject, "verdict": verdict, "message": message,
                         "observation": flow.get("observation", "static_only"), "attribution": flow.get("attribution", "unknown"),
                         "content_visibility": flow.get("content_visibility", "none"), "evidence_ids": evidence,
                         "related_ui_event_ids": flow.get("related_ui_event_ids", []),
                         "limitations": flow.get("limitations", []) + ["No safety or data-leakage conclusion"],
                         **{k: flow.get(k) for k in ("host", "port", "transport", "application_protocol", "source_id")}, **extra})
    for permission in static.get("permissions", []):
        name = permission["name"]
        add("C04", "permission_declaration", list_verdict(intent["permissions"], name, "allowed"), name, permission["evidence_ids"], value=name)
    for sdk in static.get("sdk_candidates", []):
        add("C03", "sdk_candidate", list_verdict(intent["sdk"], sdk["id"], "allowed_ids"), sdk["id"], sdk["evidence_ids"], value=sdk["id"], evidence_strength=sdk["strength"])
    for url in static.get("urls", []):
        # Static strings are NEVER treated as observed communication.
        add("C07", "static_url_candidate", REVIEW, "String candidate; execution and connection unproven", url["evidence_ids"], value=url["raw"], location=url["location"])
    nsc = static.get("network_config", {})
    flag = nsc.get("base_cleartext_permitted")
    if nsc:
        policy = intent["cleartext_policy"]
        declared_allow = flag is True or any(d["cleartext_permitted"] is True for d in nsc.get("domains", []))
        verdict = REVIEW if policy == "unspecified" else UNKNOWN if flag is None else MATCH if policy == "forbid" and declared_allow else OK
        add("C05", "cleartext_configuration", verdict, "Configuration only, assuming Android API >=24; not proof of actual cleartext traffic", ["manifest"] + (["nsc"] if (out / "evidence/network_security_config.xml").exists() else []), value=nsc)
    for flow in flows:
        evidence = flow["evidence_ids"]
        if flow["observation"] == "capture_failed":
            add("C07", "capture_failure", UNKNOWN, "Collector failure is not a connection or absence", evidence, flow)
            continue
        if flow["attribution"] != "target":
            add("C07", "connection_attribution", UNKNOWN, "Cannot compare non-target/unknown traffic as a target violation", evidence, flow)
            continue
        verdict, message = destination_verdict(intent["network"], flow)
        add("C01" if intent["network"]["mode"] == "deny_all" else "C02", "external_connection", verdict, message, evidence, flow)
        clear = intent["cleartext_policy"]
        plaintext = flow.get("application_protocol") in ("http", "dns")
        secure = flow.get("observation") == "tls_established" or (flow.get("observation") == "http_observed" and flow.get("application_protocol") == "https")
        cv = REVIEW if clear == "unspecified" else MATCH if clear == "forbid" and plaintext else OK if clear == "allow" or secure else UNKNOWN
        add("C05", "observed_cleartext", cv, "Observed protocol only; unclassified traffic remains unknown", evidence, flow)
        bg = intent["background_network_policy"]
        bv = REVIEW if bg == "unspecified" else UNKNOWN if not flow.get("ui_phase_known") else MATCH if bg == "forbid" and flow.get("after_home") else OK
        add("C06", "after_home_connection", bv, "Operational UI interval only; temporal association does not prove causality", evidence, flow)
    if evidence_mode == "static-only":
        add("C07", "excluded_dynamic_scope", UNKNOWN, "Dynamic evidence deliberately excluded by static-only mode", [], observation="static_only")
    elif not flows:
        verified_empty = bool(run["captures"]) and run["dynamic_status"] == "completed" and run.get("execution_status", "completed") == "completed"
        add("C07", "observation_coverage", UNKNOWN, "No target connection in submitted window; not a claim of absence" if verified_empty else "No verified complete dynamic observation", ["apk"] if (out / "raw/original.apk").exists() else [],
            observation="not_observed" if verified_empty else "capture_failed")
    if evidence_mode == "dynamic-only":
        add("C07", "excluded_static_scope", UNKNOWN, "Static evidence deliberately excluded by dynamic-only mode", [])
    elif run["static_status"] != "completed":
        add("C07", "static_coverage", UNKNOWN, "Static stage failed or is partial; missing findings do not prove absence", ["apk"] if (out / "raw/original.apk").exists() else [])
    result = {"schema_version": "1.0", "run_id": run["run_id"], "rule_version": RULE_VERSION, "intent": intent, "evidence_mode": evidence_mode,
              "findings": findings, "counts": {v: sum(f["verdict"] == v for f in findings) for v in (MATCH, OK, REVIEW, UNKNOWN)},
              "limitations": ["Counts are findings, NOT packets, connections or HTTP requests", "Multiple sources are kept separate; no sum of traffic volumes", "Consistent does not mean safe"]}
    write_json(out / "intent.json", intent)
    write_json(out / "findings.json", result)
    return result
