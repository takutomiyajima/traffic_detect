"""Strict app-flow JSONL and conservative PCAP adapters.

Native PCAPdroid formats vary by version: they must be explicitly converted to
the documented app-flow contract; no guessed column mapping is performed.
"""
from __future__ import annotations

import ipaddress
import math
import shutil
import socket
import struct
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from .core import (AuditError, normalize_host, read_json, read_jsonl, sha256,
                   timestamp, write_json, write_jsonl)

STATES = {"connection_attempt", "transport_established", "tls_established", "http_observed", "capture_failed"}
PROTOCOLS = {None, "http", "https", "tls", "dns", "quic", "other"}


def iso(epoch):
    return datetime.fromtimestamp(epoch, timezone.utc).isoformat()


def validate_meta(meta, run):
    required = ["schema_version", "run_id", "apk_sha256", "tool", "tool_version", "started_utc", "ended_utc", "clock_offset_s", "controls_before", "controls_after", "missing_intervals"]
    if not isinstance(meta, dict) or any(k not in meta for k in required):
        raise AuditError("Capture metadata missing required fields")
    if meta["schema_version"] != "1.0" or meta["run_id"] != run["run_id"] or meta["apk_sha256"] != run["apk_sha256"]:
        raise AuditError("Capture metadata version/run_id/APK hash mismatch")
    if not all(isinstance(meta[k], str) and meta[k] for k in ("tool", "tool_version")):
        raise AuditError("Capture tool and version required")
    offset = meta["clock_offset_s"]
    if isinstance(offset, bool) or not isinstance(offset, (int, float)) or not math.isfinite(offset):
        raise AuditError("clock_offset_s must be finite seconds added to source timestamps")
    if timestamp(meta["ended_utc"]) < timestamp(meta["started_utc"]):
        raise AuditError("Capture end precedes start")
    if any(meta[k] not in ("passed", "failed", "unknown") for k in ("controls_before", "controls_after")):
        raise AuditError("Control status must be passed/failed/unknown")
    for field, allowed in (
        ("coverage_status", ("operator_attested", "unknown", "incomplete")),
        ("clock_alignment_status", ("measured", "conditional", "unknown")),
    ):
        if field in meta and meta[field] not in allowed:
            raise AuditError(f"Invalid {field}")
    if not isinstance(meta["missing_intervals"], list):
        raise AuditError("missing_intervals must be a list")
    for gap in meta["missing_intervals"]:
        if not isinstance(gap, dict) or not all(k in gap for k in ("started_utc", "ended_utc", "reason")) or timestamp(gap["ended_utc"]) < timestamp(gap["started_utc"]):
            raise AuditError("Malformed missing interval")
    return meta


def attribution(row, run):
    package, uid = row.get("package"), row.get("uid")
    expected_package, expected_uid = run.get("package"), run.get("target_uid")
    # UID is specific to this installation. Conflicting or incomplete identity stays unknown.
    if not isinstance(expected_uid, int) or not isinstance(uid, int):
        return "unknown", "installation UID or record UID missing"
    if uid == expected_uid:
        if package and package != expected_package:
            return "unknown", "shared/conflicting UID: package differs"
        return "target", "UID matched this run; shared UID attribution remains a limitation"
    if package == expected_package:
        return "unknown", "package matched but installation UID differs"
    if row.get("related_to_target") is True:
        return "related_candidate", "collector annotated possible delegation; not proven"
    return "other", "record UID differs from target installation UID; delegation not excluded"


def app_flows(path, run, meta):
    yield from normalize_app_rows(read_jsonl(path), run, meta)


def normalize_app_rows(rows, run, meta):
    offset = meta["clock_offset_s"]
    for line, row in rows:
        if not isinstance(row, dict):
            raise AuditError(f"app-flow line {line}: expected object")
        for field in ("started_utc", "ended_utc", "destination_ip", "destination_port", "transport", "observation"):
            if field not in row:
                raise AuditError(f"app-flow line {line}: missing {field}")
        start, end = timestamp(row["started_utc"]) + offset, timestamp(row["ended_utc"]) + offset
        if end < start or start < timestamp(meta["started_utc"]) or end > timestamp(meta["ended_utc"]):
            raise AuditError(f"app-flow line {line}: invalid/out-of-capture time")
        try:
            dest_ip = str(ipaddress.ip_address(row["destination_ip"]))
        except ValueError as e:
            raise AuditError(f"app-flow line {line}: invalid IP") from e
        port = row["destination_port"]
        if type(port) is not int or not 1 <= port <= 65535 or row["transport"] not in ("TCP", "UDP"):
            raise AuditError(f"app-flow line {line}: invalid port/transport")
        state = row["observation"]
        if state not in STATES or row.get("application_protocol") not in PROTOCOLS:
            raise AuditError(f"app-flow line {line}: invalid observation/protocol")
        if row.get("uid") is not None and (type(row["uid"]) is not int or row["uid"] < 0):
            raise AuditError(f"app-flow line {line}: invalid UID")
        for field in ("bytes_sent", "bytes_received"):
            if row.get(field) is not None and (type(row[field]) is not int or row[field] < 0):
                raise AuditError(f"app-flow line {line}: invalid byte count")
        host = normalize_host(row["host"]) if row.get("host") else None
        host_evidence = row.get("host_evidence")
        if host and host_evidence not in ("sni", "http_host", "collector_correlated_dns", "explicit_ip"):
            raise AuditError(f"app-flow line {line}: hostname requires evidence type")
        if host and host_evidence == "explicit_ip" and host != dest_ip:
            raise AuditError(f"app-flow line {line}: explicit_ip must equal destination_ip")
        if host_evidence == "collector_correlated_dns" and not row.get("dns_correlation_unambiguous", False):
            host = None
        owner, reason = attribution(row, run)
        # CONNECT only is not evidence of completed TLS or an HTTP request to the upstream.
        if row.get("source_status") in ("CONNECT", "tunnel_only"):
            state = "connection_attempt"
        visibility = row.get("content_visibility", "metadata_only")
        if visibility not in ("none", "metadata_only", "plaintext_available"):
            raise AuditError(f"app-flow line {line}: invalid visibility")
        if row.get("source_status") in ("CONNECT", "tunnel_only"):
            visibility = "metadata_only"
        yield {"started_utc": iso(start), "ended_utc": iso(end), "destination_ip": dest_ip, "port": port,
               "transport": row["transport"], "host": host, "host_evidence": host_evidence if host else None,
               "host_unknown_reason": None if host else "no unambiguous hostname evidence",
               "package": row.get("package"), "uid": row.get("uid"), "attribution": owner, "attribution_reason": reason,
               "observation": state, "application_protocol": None if row.get("source_status") in ("CONNECT", "tunnel_only") else row.get("application_protocol"),
               "content_visibility": visibility, "bytes_sent": row.get("bytes_sent"), "bytes_received": row.get("bytes_received"),
               "source_status": row.get("source_status"), "source_record": {"line": line},
               "limitations": ["payload_semantics_unknown", "sdk_owner_unknown", "collector_assertions_not_independently_verified"]}


def _sni(payload):
    """Parse a complete TLS ClientHello in a single TCP segment, without reassembly."""
    import dpkt
    try:
        records, _ = dpkt.ssl.tls_multi_factory(payload)
        for record in records:
            if record.type != 22:
                continue
            hello = dpkt.ssl.TLSHandshake(record.data).data
            if not isinstance(hello, dpkt.ssl.TLSClientHello):
                continue
            for kind, data in getattr(hello, "extensions", []):
                if kind == 0:
                    n = struct.unpack("!H", data[:2])[0]
                    pos = 2
                    while pos + 3 <= min(2 + n, len(data)):
                        name_type = data[pos]
                        length = struct.unpack("!H", data[pos+1:pos+3])[0]
                        name = data[pos+3:pos+3+length]
                        pos += 3 + length
                        if name_type == 0:
                            return normalize_host(name.decode("ascii"))
    except (ValueError, IndexError, struct.error, UnicodeError, dpkt.UnpackError, dpkt.ssl.SSL3Exception, AuditError):
        pass
    return None


def pcap_flows(path, run, meta):
    import dpkt
    coverage = meta["adapter_coverage"] = {"frames_seen": 0, "ip_fragments_skipped": 0, "tcp_udp_packets": 0}
    clients = {str(ipaddress.ip_address(i)) for i in meta.get("client_ips", [])}
    if not clients:
        raise AuditError("PCAP metadata requires client_ips (emulator interfaces, NOT app identity)")
    sessions = {}
    generations = defaultdict(int)
    with Path(path).open("rb") as f:
        try:
            reader = dpkt.pcap.Reader(f)
        except ValueError:
            f.seek(0)
            reader = dpkt.pcapng.Reader(f)
        link = reader.datalink()
        if link not in (dpkt.pcap.DLT_EN10MB, dpkt.pcap.DLT_RAW, dpkt.pcap.DLT_LINUX_SLL, 101, 228, 229):
            raise AuditError(f"Unsupported PCAP link type {link}")
        for packet_no, (ts, buf) in enumerate(reader, 1):
            coverage["frames_seen"] += 1
            ts = float(ts) + meta["clock_offset_s"]
            if not timestamp(meta["started_utc"]) <= ts <= timestamp(meta["ended_utc"]):
                raise AuditError("PCAP packet outside capture metadata window")
            try:
                if link == dpkt.pcap.DLT_EN10MB:
                    ip = dpkt.ethernet.Ethernet(buf).data
                elif link == dpkt.pcap.DLT_LINUX_SLL:
                    ip = dpkt.sll.SLL(buf).data
                else:
                    ip = dpkt.ip.IP(buf) if buf[0] >> 4 == 4 else dpkt.ip6.IP6(buf)
                if not isinstance(ip, (dpkt.ip.IP, dpkt.ip6.IP6)):
                    continue
                if isinstance(ip, dpkt.ip.IP) and (ip.offset or ip.mf):
                    coverage["ip_fragments_skipped"] += 1
                    continue  # Fragment reassembly is outside this adapter.
                segment = ip.data
                if not isinstance(segment, (dpkt.tcp.TCP, dpkt.udp.UDP)):
                    continue
                coverage["tcp_udp_packets"] += 1
                src, dst = str(ipaddress.ip_address(ip.src)), str(ipaddress.ip_address(ip.dst))
                outgoing = src in clients and dst not in clients
                incoming = dst in clients and src not in clients
                if not (outgoing or incoming):
                    continue
                local = (src, segment.sport) if outgoing else (dst, segment.dport)
                remote = (dst, segment.dport) if outgoing else (src, segment.sport)
                transport = "TCP" if isinstance(segment, dpkt.tcp.TCP) else "UDP"
                key = (*local, *remote, transport)
                syn = transport == "TCP" and outgoing and segment.flags & dpkt.tcp.TH_SYN and not segment.flags & dpkt.tcp.TH_ACK
                session = sessions.get(key)
                if session is None or ts - session["last"] > 60 or (syn and session.get("syn_seq") not in (None, segment.seq)):
                    if session:
                        yield _finish_pcap(session)
                    generations[key] += 1
                    session = sessions[key] = {"first": ts, "last": ts, "destination_ip": remote[0], "port": remote[1], "transport": transport,
                                               "bytes_sent": 0, "bytes_received": 0, "packet_numbers": [], "host": None, "host_evidence": None,
                                               "application_protocol": None, "syn_seq": None, "synack": False, "established": False}
                session["last"] = ts
                session["packet_numbers"].append(packet_no)
                session["bytes_sent" if outgoing else "bytes_received"] += len(ip)
                if transport == "TCP":
                    if syn:
                        session["syn_seq"] = segment.seq
                    if incoming and segment.flags & dpkt.tcp.TH_SYN and segment.flags & dpkt.tcp.TH_ACK and session["syn_seq"] is not None and segment.ack == (session["syn_seq"] + 1) % 2**32:
                        session["synack"] = True
                        session["server_seq"] = segment.seq
                    if outgoing and session["synack"] and segment.flags & dpkt.tcp.TH_ACK and segment.ack == (session["server_seq"] + 1) % 2**32:
                        session["established"] = True
                    if outgoing and segment.data:
                        host = _sni(segment.data)
                        if host:
                            session.update(host=host, host_evidence="sni", application_protocol="tls")
                        try:
                            request = dpkt.http.Request(segment.data)
                            if request.method != "CONNECT" and request.headers.get("host"):
                                from urllib.parse import urlsplit
                                hostname = urlsplit("//" + request.headers["host"]).hostname
                                session.update(host=normalize_host(hostname), host_evidence="http_host", application_protocol="http")
                        except (dpkt.UnpackError, ValueError, AuditError):
                            pass
            except (dpkt.UnpackError, ValueError, IndexError):
                raise AuditError(f"Malformed/unsupported IP packet {packet_no}; capture cannot establish absence", 4)
    for session in sessions.values():
        yield _finish_pcap(session)


def _finish_pcap(s):
    return {"started_utc": iso(s["first"]), "ended_utc": iso(s["last"]),
            **{k: s[k] for k in ("destination_ip", "port", "transport", "host", "host_evidence", "application_protocol", "bytes_sent", "bytes_received")},
            "host_unknown_reason": None if s["host"] else "no visible HTTP Host or complete single-segment SNI; DNS IP mapping not assumed",
            "observation": "http_observed" if s["application_protocol"] == "http" else "transport_established" if s["established"] else "connection_attempt",
            "attribution": "unknown", "attribution_reason": "PCAP has no app UID", "content_visibility": "metadata_only",
            "source_record": {"packet_numbers": s["packet_numbers"]}, "limitations": ["no_app_identity", "no_tcp_stream_reassembly", "no_ip_fragment_reassembly", "flow_grouping_idle_timeout_60s", "bytes_are_ip_layer_including_headers", "sdk_owner_unknown"]}


def import_capture(out, path, meta_path, adapter):
    out, path = Path(out), Path(path)
    run = read_json(out / "run.json")
    meta = validate_meta(read_json(meta_path), run)
    identity = meta.get("target_identity")
    if identity is not None:
        if not isinstance(identity, dict) or identity.get("package") != run.get("package") or type(identity.get("uid")) is not int or identity["uid"] < 0 or not isinstance(identity.get("source"), str) or not identity["source"].strip():
            raise AuditError("target_identity requires matching package, installation UID and evidence source")
        if run.get("target_uid") is not None and run["target_uid"] != identity["uid"]:
            raise AuditError("Capture installation identity conflicts with this run")
        run["target_uid"] = identity["uid"]
        run["identity_source"] = identity["source"]
        run["limitations"].append("Imported installation identity is an operator assertion; retain the original ADB/collector record")
    digest = sha256(path)
    meta_digest = sha256(meta_path)
    existing = run.get("captures", [])
    if any(c["sha256"] == digest and c["adapter"] == adapter for c in existing):
        raise AuditError("Capture already imported; duplicate counting prevented")
    if path.stat().st_size > 512 * 1024**2:
        raise AuditError("Capture exceeds 512 MiB limit")
    source_id = "capture-" + str(len(existing) + 1)
    if adapter == "pcapdroid-csv":
        from .pcapdroid import pcapdroid_flows
        parser = pcapdroid_flows
    elif adapter == "app-flow":
        parser = app_flows
    elif adapter == "pcap":
        parser = pcap_flows
    else:
        raise AuditError("Unsupported capture adapter")
    flows = list(parser(path, run, meta))  # Validate before replacing normalized evidence.
    suffix = {"app-flow": ".jsonl", "pcap": ".pcap", "pcapdroid-csv": ".csv"}[adapter]
    raw = out / "raw" / (source_id + suffix)
    shutil.copyfile(path, raw)
    raw_meta = out / "raw" / (source_id + ".metadata.input.json")
    shutil.copyfile(meta_path, raw_meta)
    write_json(out / "raw" / (source_id + ".metadata.json"), meta)
    events = [v for _, v in read_jsonl(out / "ui_events.jsonl")]
    index = read_json(out / "evidence/index.json")
    metadata_id = source_id + "-metadata"
    index[metadata_id] = {"path": str(raw_meta.relative_to(out)), "sha256": meta_digest,
                          "locator": "run identity, clock alignment, collector version and control attestations"}
    for i, flow in enumerate(flows, 1):
        evidence_id = f"{source_id}-flow-{i}"
        flow.update(schema_version="1.0", run_id=run["run_id"], flow_id=evidence_id, source_id=source_id, adapter=adapter, evidence_ids=[evidence_id, metadata_id])
        flow["related_ui_event_ids"] = [e["event_id"] for e in events if e.get("success") and timestamp(e["started_utc"]) <= timestamp(flow["started_utc"]) <= timestamp(e["ended_utc"])]
        flow["after_home"] = any(e.get("success") and e.get("phase") == "after_home" and timestamp(e["started_utc"]) <= timestamp(flow["started_utc"]) <= timestamp(e["ended_utc"]) for e in events)
        flow["ui_phase_known"] = bool(flow["related_ui_event_ids"])
        index[evidence_id] = {"path": str(raw.relative_to(out)), "sha256": digest, "locator": flow["source_record"]}
    previous = [f for _, f in read_jsonl(out / "flows.jsonl")]
    write_jsonl(out / "flows.jsonl", previous + flows)
    write_json(out / "evidence/index.json", index)
    complete = (meta["controls_before"] == meta["controls_after"] == "passed" and not meta["missing_intervals"]
                and meta.get("coverage_status", "operator_attested") == "operator_attested"
                and meta.get("clock_alignment_status", "measured") == "measured"
                and not meta.get("adapter_coverage", {}).get("ip_fragments_skipped", 0)
                and not any(f["observation"] == "capture_failed" for f in flows))
    quality = "completed" if complete else "partial"
    run["captures"].append({"id": source_id, "adapter": adapter, "sha256": digest, "metadata_input_sha256": meta_digest,
                            "flow_count": len(flows), "quality": quality, "metadata": meta})
    run["dynamic_status"] = quality if all(c["quality"] == "completed" for c in run["captures"]) else "partial"
    run["run_status"] = "completed" if run["dynamic_status"] == "completed" and run["static_status"] == "completed" and run.get("execution_status", "completed") == "completed" else "partial"
    run["limitations"].append("Capture control statuses are operator/collector attestations; sources are not summed or assumed independent")
    write_json(out / "run.json", run)
    return len(flows)
