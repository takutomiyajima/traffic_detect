"""Sharing uses a strict field allowlist; raw evidence must never be copied."""
import html
import json
from pathlib import Path

from .core import AuditError, read_json, write_json


def export_summary(source, destination):
    source, destination = Path(source).resolve(), Path(destination).resolve()
    if destination == source or destination.is_relative_to(source):
        raise AuditError("Shared export must be outside the original run directory")
    if destination.exists() and any(destination.iterdir()):
        raise AuditError("Shared output directory must be empty")
    result = read_json(source / "findings.json")
    # IDs, enum statuses and rule IDs only; no URLs, app purpose, timestamps,
    # descriptions, payloads, APKs, paths, package names, UID or source files.
    safe_fields = ("finding_id", "rule_id", "verdict", "observation", "attribution", "content_visibility")
    exported = {"schema_version": "1.0", "export_kind": "redacted_summary_without_evidence",
                "notice": "Endpoints, source evidence and free text removed. This summary cannot replace the original audit.",
                "findings": [{k: f[k] for k in safe_fields} for f in result["findings"]]}
    write_json(destination / "summary.json", exported)
    (destination / "summary.html").write_text('<!doctype html><html lang="ja"><meta charset="utf-8"><title>共有用要約</title><h1>共有用要約（証拠原本を含まない）</h1><pre>' + html.escape(json.dumps(exported, ensure_ascii=False, indent=2)) + "</pre></html>", encoding="utf-8")
