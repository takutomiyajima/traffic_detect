"""APK inspection without installing, re-signing or modifying the input."""
from __future__ import annotations

import re
import hashlib
import shutil
import time
import zipfile
from importlib.resources import files
from pathlib import Path, PurePosixPath

from .core import AuditError, add_evidence, read_json, sha256, url_candidate, write_json

ANDROID = "{http://schemas.android.com/apk/res/android}"
URL = re.compile(r"(?:https?|wss?)://[^\s\x00<>\"'{}\\]{1,2048}", re.I)
API_PREFIXES = ("Ljava/net/", "Ljavax/net/", "Lokhttp3/", "Landroid/location/", "Lcom/google/android/gms/location/", "Landroid/webkit/WebView;")


def check_apk(path, max_mib=200, expanded_mib=1024):
    path = Path(path)
    if path.stat().st_size > max_mib * 1024**2:
        raise AuditError(f"APK exceeds {max_mib} MiB")
    try:
        with zipfile.ZipFile(path) as z:
            names = set()
            total = 0
            for member in z.infolist():
                p = PurePosixPath(member.filename)
                if p.is_absolute() or ".." in p.parts or "\\" in member.filename or ":" in member.filename or member.filename in names:
                    raise AuditError("Unsafe/duplicate APK member name")
                if member.flag_bits & 1:
                    raise AuditError("Encrypted APK entries are unsupported")
                names.add(member.filename)
                total += member.file_size
                if total > expanded_mib * 1024**2 or len(names) > 100000:
                    raise AuditError("APK expanded size/member count limit exceeded")
            if "AndroidManifest.xml" not in names:
                raise AuditError("Not an APK: AndroidManifest.xml missing")
            if not any(re.fullmatch(r"classes\d*\.dex", n) for n in names):
                raise AuditError("Single APK must contain classes.dex; resource/split APK unsupported")
    except zipfile.BadZipFile as e:
        raise AuditError("Broken ZIP/APK") from e


def attributes(element):
    return {k.replace(ANDROID, "android:"): v for k, v in element.attrib.items()}


def network_config(apk, manifest, out):
    """Resolve target defaults and inherited NSC declarations, preserving unknowns."""
    app = manifest.find("application")
    target = apk.get_target_sdk_version() or apk.get_min_sdk_version() or "1"
    try:
        target = int(target)
    except ValueError:
        target = None
    raw_flag = app.get(ANDROID + "usesCleartextTraffic") if app is not None else None
    reference = app.get(ANDROID + "networkSecurityConfig") if app is not None else None
    default = target < 28 if target is not None else None
    result = {"target_sdk": target, "manifest_cleartext": raw_flag, "reference": reference,
              "debuggable": app.get(ANDROID + "debuggable", "false") if app is not None else None,
              "base_cleartext_permitted": (raw_flag == "true") if raw_flag in ("true", "false") else default,
              "platform_condition": "Android API >=24; older OS behavior differs",
              "default_trust_anchors": ["system", "user"] if target is not None and target <= 23 else ["system"],
              "domains": [], "trust_anchor_declarations": [], "warnings": []}
    if not reference:
        return result
    try:
        from androguard.core.axml import AXMLPrinter
        from defusedxml.ElementTree import fromstring
        if reference.startswith("@7") or reference.startswith("@0x"):
            res_id = int(reference[1:].removeprefix("0x"), 16)
            configs = apk.get_android_resources().get_resolved_res_configs(res_id)
            paths = sorted(set(value for _, value in configs if isinstance(value, str)))
        else:
            paths = ["res/xml/" + reference.split("/")[-1] + ".xml"]
        if len(paths) != 1:
            raise ValueError("Multiple/no resource variants; effective configuration unresolved")
        raw = apk.get_file(paths[0])
        xml = raw if raw.lstrip().startswith(b"<") else AXMLPrinter(raw).get_xml()
        tree = fromstring(xml)
        (Path(out) / "evidence/network_security_config.xml").write_bytes(xml)
        add_evidence(out, "nsc", Path(out) / "evidence/network_security_config.xml", paths[0])
        base = tree.find("base-config")
        # With NSC, manifest flag is ignored on API >=24. Base defaults depend on target.
        result["base_cleartext_permitted"] = default
        if base is not None and base.get("cleartextTrafficPermitted") in ("true", "false"):
            result["base_cleartext_permitted"] = base.get("cleartextTrafficPermitted") == "true"
        def visit(node, inherited):
            raw_bool = node.get("cleartextTrafficPermitted")
            effective = raw_bool == "true" if raw_bool in ("true", "false") else inherited
            for domain in node.findall("domain"):
                result["domains"].append({"host": domain.text, "include_subdomains": domain.get("includeSubdomains") == "true", "cleartext_permitted": effective})
            for child in node.findall("domain-config"):
                visit(child, effective)
        for child in tree.findall("domain-config"):
            visit(child, result["base_cleartext_permitted"])
        for cert in tree.iter("certificates"):
            result["trust_anchor_declarations"].append(dict(cert.attrib))
        result["debug_overrides_present"] = tree.find("debug-overrides") is not None
        result["warnings"].append("Trust declarations are not proof of runtime trust; domain/API/library behavior matters")
    except Exception as e:
        result["base_cleartext_permitted"] = None
        result["warnings"].append(f"NSC unresolved: {type(e).__name__}: {e}")
    return result


def analyze(apk_path, out, max_mib=200):
    from loguru import logger
    logger.disable("androguard")
    from androguard.core.apk import APK
    from androguard.core.dex import DEX
    from lxml import etree

    started = time.monotonic()
    out = Path(out)
    check_apk(apk_path, max_mib)
    raw_path = out / "raw/original.apk"
    shutil.copyfile(apk_path, raw_path)
    add_evidence(out, "apk", raw_path, "complete original APK")
    apk = APK(str(raw_path))
    if not apk.is_valid_APK():
        raise AuditError("Androguard could not parse a valid APK", 4)
    manifest = apk.get_android_manifest_xml()
    if manifest is None:
        raise AuditError("Manifest could not be decoded", 4)
    manifest_path = out / "evidence/AndroidManifest.xml"
    manifest_path.write_bytes(etree.tostring(manifest, encoding="utf-8", pretty_print=True))
    add_evidence(out, "manifest", manifest_path, "decoded AndroidManifest.xml")
    rules = read_json(files("apk_audit").joinpath("data/sdk_rules.json"))
    result = {"schema_version": "1.0", "apk_sha256": sha256(raw_path), "package": apk.get_package(),
              "version_name": apk.get_androidversion_name(), "version_code": apk.get_androidversion_code(),
              "min_sdk": apk.get_min_sdk_version(), "target_sdk": apk.get_target_sdk_version(),
              "abis": sorted({p.split("/")[1] for p in apk.get_files() if p.startswith("lib/") and p.count("/") >= 2}),
              "permissions": [], "components": [], "application": {}, "network_config": {},
              "dex_files": [], "urls": [], "sdk_candidates": [], "api_references": [],
              "rule_version": rules["version"], "coverage": {"processed": ["AndroidManifest.xml"], "unprocessed": [], "warnings": []},
              "limitations": ["Static declarations and strings do not prove execution or transmission", "Native code, dynamic loading and obfuscation may hide evidence"]}
    for tag in ("uses-permission", "uses-permission-sdk-23"):
        for el in manifest.findall(tag):
            result["permissions"].append({"name": el.get(ANDROID + "name"), "attributes": attributes(el), "evidence_ids": ["manifest"]})
    app = manifest.find("application")
    if app is not None:
        result["application"] = attributes(app)
        for child in app:
            result["components"].append({"tag": child.tag, "attributes": attributes(child), "children": [{"tag": c.tag, "attributes": attributes(c)} for c in child]})
    try:
        result["signing"] = {"v1_present": apk.is_signed_v1(), "v2_present": apk.is_signed_v2(), "v3_present": apk.is_signed_v3(),
                             "certificate_sha256": sorted({hashlib.sha256(c.dump()).hexdigest() for c in apk.get_certificates()}),
                             "cryptographic_signature_verification": "not_performed"}
    except Exception as e:
        result["signing"] = {"cryptographic_signature_verification": "not_performed", "error": str(e)}
        result["coverage"]["warnings"].append("Signing metadata extraction partial: " + str(e))
    result["network_config"] = network_config(apk, manifest, out)
    result["coverage"]["warnings"].extend(result["network_config"]["warnings"])
    all_classes = []
    string_evidence = []
    with zipfile.ZipFile(raw_path) as z:
        for name in sorted(z.namelist()):
            if not re.fullmatch(r"classes\d*\.dex", name):
                continue
            result["dex_files"].append(name)
            try:
                dex = DEX(z.read(name))
                for idx, value in enumerate(dex.get_strings()):
                    string_evidence.append((value, {"file": name, "string_index": idx}))
                for cls in dex.get_classes():
                    all_classes.append((cls.get_name(), name))
                    for method in cls.get_methods():
                        offset = 0
                        for instruction in method.get_instructions():
                            if instruction.get_name().startswith("invoke-"):
                                target = instruction.get_output()
                                if any(prefix in target for prefix in API_PREFIXES):
                                    result["api_references"].append({"dex": name, "class": cls.get_name(), "method": method.get_name(), "offset_bytes": offset, "reference": target, "evidence_ids": ["apk"]})
                            offset += instruction.get_length()
                result["coverage"]["processed"].append(name)
            except Exception as e:
                result["coverage"]["unprocessed"].append({"file": name, "reason": f"{type(e).__name__}: {e}"})
        for name in sorted(z.namelist()):
            if name == "resources.arsc" or name.startswith(("res/", "assets/")):
                member = z.getinfo(name)
                if member.file_size > 8 * 1024**2:
                    result["coverage"]["unprocessed"].append({"file": name, "reason": "resource >8 MiB scan limit"})
                    continue
                raw = z.read(name)
                for encoding in ("utf-8", "utf-16le"):
                    for match in URL.finditer(raw.decode(encoding, errors="ignore")):
                        string_evidence.append((match.group(), {"file": name, "decoded_encoding": encoding, "character_offset": match.start()}))
                result["coverage"]["processed"].append(name)
            elif name not in result["coverage"]["processed"] and not re.fullmatch(r"classes\d*\.dex", name):
                result["coverage"]["unprocessed"].append({"file": name, "reason": "not a DEX or selected resource; not semantically analyzed"})
    # Resolve compiled resource strings too; byte scanning alone misses string pools.
    try:
        arsc = apk.get_android_resources()
        if arsc:
            from defusedxml.ElementTree import fromstring
            for package in arsc.get_packages_names():
                for locale in arsc.get_locales(package):
                    xml = arsc.get_string_resources(package, locale)
                    for item in fromstring(xml).iter("string"):
                        string_evidence.append((item.text or "", {"file": "resources.arsc", "resource": item.get("name"), "locale": repr(locale)}))
    except Exception as e:
        result["coverage"]["warnings"].append(f"Resource string resolution partial: {e}")
    seen = set()
    for value, location in string_evidence:
        for match in URL.finditer(value):
            candidate = url_candidate(match.group())
            key = (match.group(), str(location))
            if candidate and key not in seen:
                seen.add(key)
                result["urls"].append({**candidate, "location": location, "kind": "string_candidate", "evidence_ids": ["apk"]})
    manifest_text = manifest_path.read_text()
    for rule in rules["rules"]:
        matches = [{"kind": "class_prefix", "class": c, "dex": n, "prefix": p} for c, n in all_classes for p in rule["prefixes"] if c.startswith(p)]
        matches += [{"kind": "manifest_string", "value": v} for v in rule["manifest_strings"] if v in manifest_text]
        if matches:
            kinds = {m["kind"] for m in matches}
            result["sdk_candidates"].append({"id": rule["id"], "category": rule["category"], "matches": matches,
                                              "strength": "multiple_feature_types" if len(kinds) > 1 else "single_feature_type",
                                              "source": rule["source"], "evidence_ids": ["apk", "manifest"]})
    result["analysis_duration_s"] = time.monotonic() - started
    write_json(out / "static.json", result)
    add_evidence(out, "static", out / "static.json", "static analysis output")
    return result
