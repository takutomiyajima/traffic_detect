"""ADB/emulator integration. Requires validation on the user's selected AVD."""
from __future__ import annotations

import ipaddress
import re
import shutil
import subprocess
import time
from pathlib import Path

from defusedxml.ElementTree import fromstring

from .core import AuditError, read_json, sha256, utc_now, write_json, write_jsonl


class Adb:
    def __init__(self, serial, deadline=None):
        if not re.fullmatch(r"emulator-\d+", serial):
            raise AuditError("Only an explicitly selected local Android Emulator is supported")
        if not shutil.which("adb"):
            raise AuditError("adb not installed; run Android workflow on a host with Android SDK", 3)
        self.serial = serial
        self.deadline = deadline

    def call(self, *args, timeout=20):
        if self.deadline is not None:
            timeout = min(timeout, self.deadline - time.monotonic())
        if timeout <= 0:
            raise AuditError("Dynamic trial timeout", 4)
        result = subprocess.run(["adb", "-s", self.serial, *map(str, args)], capture_output=True, text=True, timeout=timeout, check=False)
        if result.returncode or any(x in result.stdout for x in ("KO:", "Error:", "Failure [")):
            raise AuditError(f"adb {args[0]} failed: {(result.stderr or result.stdout)[-2000:]}", 3)
        return result.stdout

    def ui(self):
        xml = self.call("exec-out", "uiautomator", "dump", "/dev/tty")
        begin = xml.find("<?xml")
        end = xml.rfind("</hierarchy>")
        if begin < 0 or end < begin:
            raise AuditError("UI hierarchy unavailable; operation success cannot be confirmed", 4)
        return fromstring(xml[begin:end+len("</hierarchy>")])

    def element(self, resource_id):
        for element in self.ui().iter("node"):
            if element.get("resource-id") == resource_id:
                return element
        return None


def doctor(serial=None):
    checks = {"adb_installed": bool(shutil.which("adb")), "emulator_installed": bool(shutil.which("emulator")),
              "kvm_present": Path("/dev/kvm").exists(), "android_validation": "not_yet_validated",
              "local_static_and_import_available": True}
    if serial:
        adb = Adb(serial)
        checks.update(serial=serial, state=adb.call("get-state").strip(),
                      api=adb.call("shell", "getprop", "ro.build.version.sdk").strip(),
                      abi=adb.call("shell", "getprop", "ro.product.cpu.abilist").strip(),
                      disk=adb.call("shell", "df", "/data").strip(), avd=adb.call("emu", "avd", "name").strip())
    return checks


def _verify_ping_controls(path, address, windows):
    """Require request AND reply inside each pre/post control interval."""
    import dpkt
    import socket
    from .core import timestamp
    seen = [set() for _ in windows]
    with Path(path).open("rb") as f:
        reader = dpkt.pcap.Reader(f)
        for ts, buf in reader:
            link = reader.datalink()
            if link == dpkt.pcap.DLT_EN10MB:
                ip = dpkt.ethernet.Ethernet(buf).data
            elif link in (dpkt.pcap.DLT_RAW, 101):
                ip = dpkt.ip.IP(buf)
            else:
                raise AuditError("Control verification requires Ethernet/raw IPv4 capture", 4)
            if not isinstance(ip, dpkt.ip.IP) or not isinstance(ip.data, dpkt.icmp.ICMP):
                continue
            icmp = ip.data
            for i, (start, end) in enumerate(windows):
                if timestamp(start) - 1 <= float(ts) <= timestamp(end) + 1:
                    if socket.inet_ntoa(ip.dst) == address and icmp.type == 8:
                        seen[i].add("request")
                    if socket.inet_ntoa(ip.src) == address and icmp.type == 0:
                        seen[i].add("reply")
    return all(s == {"request", "reply"} for s in seen)


def execute(apk_path, out, scenario, serial, control_ip, max_seconds=600):
    out = Path(out).resolve()
    run = read_json(out / "run.json")
    if run["static_status"] != "completed":
        raise AuditError("Dynamic execution requires successful static APK inspection", 4)
    if not ipaddress.ip_address(control_ip).version == 4:
        raise AuditError("Control destination must be a reachable IPv4 test host")
    package = run["package"]
    if not re.fullmatch(r"[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+", package):
        raise AuditError("Unsupported/unsafe Android package name")
    if scenario["execution"] == "manual" and not __import__("sys").stdin.isatty():
        raise AuditError("Manual scenarios require an interactive terminal; no automatic acknowledgement", 3)
    deadline = time.monotonic() + max_seconds
    adb = Adb(serial, deadline)
    events = []
    capture_path = out / "raw/emulator.pcap"
    capturing = False
    start = utc_now()
    windows = []
    errors = []
    run.update(dynamic_status="pending", execution_status="pending", scenario_id=scenario["scenario_id"],
               scenario=scenario, serial=serial, capture_backend="Android Emulator console network capture (host PCAP, no UID)",
               capture_settings={"profile": "A", "apk_modified": False, "ca_changes": False, "proxy_changes": False, "vpn_changes": False})
    write_json(out / "run.json", run)
    try:
        run["android"] = doctor(serial)
        if adb.call("shell", "am", "get-current-user").strip() != "0":
            raise AuditError("Only Android owner user 0 supported; UID mapping otherwise ambiguous", 3)
        abi_list = run["android"]["abi"].split(",")
        static = read_json(out / "static.json")
        if static["abis"] and not set(abi_list).intersection(static["abis"]):
            raise AuditError("APK native ABI is incompatible with selected emulator", 3)
        if static["min_sdk"] and int(static["min_sdk"]) > int(run["android"]["api"]):
            raise AuditError("APK minSdk exceeds emulator API", 3)
        # Installation is a separate stage; no signing, repackaging or CA changes.
        install = adb.call("install", "-r", str(Path(apk_path).resolve()), timeout=90)
        if "Success" not in install:
            raise AuditError("Install success was not confirmed", 3)
        dump = adb.call("shell", "dumpsys", "package", package)
        uid_match = re.search(r"\buserId=(\d+)", dump)
        if not uid_match:
            raise AuditError("Cannot establish installed UID", 3)
        run["target_uid"] = int(uid_match.group(1))
        run["initial_app_data"] = "preserved"
        if "fresh_app_data" in scenario.get("preconditions", []):
            if "Success" not in adb.call("shell", "pm", "clear", package):
                raise AuditError("Failed to clear app data", 3)
            run["initial_app_data"] = "cleared via pm clear"
        elif scenario.get("preconditions"):
            run["limitations"].append("Additional preconditions require operator confirmation: " + repr(scenario["preconditions"]))
        ip_output = adb.call("shell", "ip", "-o", "-4", "addr", "show", "scope", "global")
        client_ips = sorted(set(re.findall(r"\binet (\d+\.\d+\.\d+\.\d+)/", ip_output)))
        if not client_ips:
            raise AuditError("Cannot identify emulator network interface", 3)
        adb.call("shell", "am", "force-stop", package)
        start = utc_now()
        adb.call("emu", "network", "capture", "start", str(capture_path))
        capturing = True
        def probe():
            a = utc_now()
            response = adb.call("shell", "ping", "-c", "1", "-W", "3", control_ip)
            b = utc_now()
            if not re.search(r"1 (?:packets )?received|1 received", response):
                raise AuditError("Control host not reachable from emulator", 3)
            windows.append((a, b))
        probe()
        phase = "foreground"
        for step in scenario["steps"]:
            event = {"event_id": step["id"], "action": step["action"], "started_utc": utc_now(),
                     "monotonic_start_s": time.monotonic(), "success": False, "phase": phase}
            events.append(event)
            try:
                action = step["action"]
                if action == "launch":
                    adb.call("shell", "monkey", "-p", package, "-c", "android.intent.category.LAUNCHER", "1")
                    phase = "foreground"
                elif action == "home":
                    adb.call("shell", "input", "keyevent", "KEYCODE_HOME")
                    if package in adb.call("shell", "dumpsys", "activity", "activities").split("mResumedActivity:")[-1].split("\n")[0]:
                        raise AuditError("Home transition not confirmed", 4)
                    phase = "after_home"
                elif action == "tap":
                    element = adb.element(step["resource_id"])
                    bounds = re.fullmatch(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", element.get("bounds", "")) if element is not None else None
                    if not bounds:
                        raise AuditError("Tap resource not present/has no bounds", 4)
                    x1, y1, x2, y2 = map(int, bounds.groups())
                    adb.call("shell", "input", "tap", (x1+x2)//2, (y1+y2)//2)
                elif action == "manual_checkpoint":
                    # A blocked input still respects the trial deadline on POSIX.
                    import select
                    import sys
                    print(f"{step['id']}: {step.get('description', '')} — type done then Enter", flush=True)
                    ready, _, _ = select.select([sys.stdin], [], [], max(0, deadline-time.monotonic()))
                    if not ready or sys.stdin.readline().strip() != "done":
                        raise AuditError("Manual checkpoint not completed", 4)
                if step.get("expect_resource_id"):
                    until = min(deadline, time.monotonic()+10)
                    while adb.element(step["expect_resource_id"]) is None:
                        if time.monotonic() >= until:
                            raise AuditError("Expected UI element not reached", 4)
                        time.sleep(0.3)
                event["phase"] = phase
                remaining = deadline - time.monotonic()
                if step["observe_s"] > remaining:
                    raise AuditError("Trial timeout before observation interval completed", 4)
                time.sleep(step["observe_s"])
                event["success"] = True
            finally:
                event["ended_utc"] = utc_now()
                event["monotonic_end_s"] = time.monotonic()
                write_jsonl(out / "ui_events.jsonl", events)
        probe()
        run["execution_status"] = "completed"
    except (Exception, KeyboardInterrupt) as e:
        errors.append({"stage": "android", "type": type(e).__name__, "message": str(e)})
        run["execution_status"] = "failed"
    finally:
        # Cleanup has its own budget even when the trial's deadline expired.
        adb.deadline = time.monotonic() + 30
        if capturing:
            try:
                adb.call("emu", "network", "capture", "stop")
            except (AuditError, subprocess.TimeoutExpired) as e:
                errors.append({"stage": "cleanup", "message": str(e)})
                run["cleanup_failed"] = True
        run["ended_utc"] = utc_now()
        run["errors"].extend(errors)
        run["run_status"] = "partial" if errors else "completed"
        run["dynamic_status"] = "failed" if errors else "pending_import"
        write_json(out / "run.json", run)
    if errors:
        raise AuditError("Android trial failed; see run.json and successful evidence", 4)
    if sha256(apk_path) != run["apk_sha256"]:
        raise AuditError("Input APK changed during execution", 4)
    controls_ok = capture_path.exists() and _verify_ping_controls(capture_path, control_ip, windows)
    meta = {"schema_version": "1.0", "run_id": run["run_id"], "apk_sha256": run["apk_sha256"],
            "tool": "Android Emulator console capture", "tool_version": run["android"]["avd"],
            "started_utc": start, "ended_utc": run["ended_utc"], "clock_offset_s": 0,
            "clock_basis": "host capture and host UI clock; no device timestamp merge",
            "controls_before": "passed" if controls_ok else "failed", "controls_after": "passed" if controls_ok else "failed",
            "missing_intervals": [], "client_ips": client_ips, "control_windows": windows, "control_ip": control_ip}
    write_json(out / "capture.metadata.json", meta)
    from .capture import import_capture
    import_capture(out, capture_path, out / "capture.metadata.json", "pcap")
    if not controls_ok:
        raise AuditError("Pre/post ICMP controls not found in capture; trial partial", 4)
