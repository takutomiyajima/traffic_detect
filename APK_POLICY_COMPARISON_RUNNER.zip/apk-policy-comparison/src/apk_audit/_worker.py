"""Disposable static-analysis worker; parent enforces wall-clock timeout."""
import argparse
import resource

from .core import AuditError, write_json
from .static import analyze


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("apk")
    parser.add_argument("out")
    parser.add_argument("--max-mib", type=int, default=200)
    args = parser.parse_args()
    try:
        # Bound pathological DEX/XML memory consumption, without disabling validation.
        resource.setrlimit(resource.RLIMIT_AS, (3 * 1024**3, 3 * 1024**3))
        result = analyze(args.apk, args.out, args.max_mib)
        write_json(args.out + "/static-worker.json", {"ok": True, "max_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
        return 0
    except Exception as e:
        write_json(args.out + "/static-worker.json", {"ok": False, "error": type(e).__name__ + ": " + str(e)})
        return e.code if isinstance(e, AuditError) else 4


if __name__ == "__main__":
    raise SystemExit(main())
