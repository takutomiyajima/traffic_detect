"""Metrics with explicit abstention and coverage; no unknown->negative coercion."""
from collections import defaultdict

from .core import AuditError

VERDICTS={"mismatch_candidate","consistent_with_observed_evidence","needs_review","not_evaluable"}
MODES={"static-only","dynamic-only","integrated"}


def ratio(a,b):return a/b if b else None


def score_labels(gold,predictions):
    """Gold units: unit_id, stratum, positive(bool). Predictions: unit_id, mode, verdict.

    Unit IDs and strata must be defined before inspecting analyzer output.
    Missing predictions abstain. Unknown positives are reported separately and
    remain in the denominator of overall detection yield.
    """
    truth={}
    for row in gold:
        key=row.get("unit_id")
        if not isinstance(key,str) or not key or key in truth or type(row.get("positive")) is not bool or not isinstance(row.get("stratum"),str) or not row["stratum"]:
            raise AuditError("Gold requires unique nonempty unit_id, stratum and boolean positive")
        truth[key]=row
    if not truth:raise AuditError("Empty gold set cannot validate a workflow")
    indexed={}
    for row in predictions:
        key=(row.get("mode"),row.get("unit_id"))
        if key[0] not in MODES or key[1] not in truth or row.get("verdict") not in VERDICTS or key in indexed:
            raise AuditError("Invalid, duplicate or unmatched prediction")
        indexed[key]=row["verdict"]
    results=[]
    for mode in sorted(MODES):
        groups=defaultdict(list)
        for key,row in truth.items():groups[row["stratum"]].append((key,row))
        for stratum,units in sorted(groups.items()):
            tp=fp=tn=fn=abstain=abstain_positive=missing=0
            for key,row in units:
                verdict=indexed.get((mode,key))
                if verdict is None:missing+=1
                if verdict in (None,"needs_review","not_evaluable"):
                    abstain+=1;abstain_positive+=row["positive"];continue
                predicted_positive=verdict=="mismatch_candidate"
                if predicted_positive and row["positive"]:tp+=1
                elif predicted_positive:fp+=1
                elif row["positive"]:fn+=1
                else:tn+=1
            positives=sum(row["positive"] for _,row in units)
            results.append({"mode":mode,"stratum":stratum,"unit_count":len(units),"gold_positives":positives,
                            "tp":tp,"fp":fp,"tn":tn,"fn_on_evaluable":fn,"abstentions":abstain,"abstained_positives":abstain_positive,"missing_predictions":missing,
                            "precision_on_evaluable":ratio(tp,tp+fp),"recall_on_evaluable":ratio(tp,tp+fn),
                            "overall_positive_detection_yield":ratio(tp,positives),"evaluable_coverage":ratio(tp+fp+tn+fn,len(units)),"abstention_rate":ratio(abstain,len(units))})
    return {"schema_version":"1.0","results":results,"interpretation":"Conditional recall excludes abstentions; always report coverage and overall positive detection yield too. Null denotes zero denominator. Repeated runs are not independent apps."}
