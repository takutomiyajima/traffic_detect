"""Synthetic demonstration. Never a measurement of a real APK or emulator."""
from pathlib import Path

from .capture import import_capture
from .compare import compare
from .core import add_evidence, new_run, write_json, write_jsonl
from .report import report


def demo(out):
    out = Path(out)
    if out.exists() and any(out.iterdir()):
        from .core import AuditError
        raise AuditError("Demo output must be empty")
    out.mkdir(parents=True, exist_ok=True)
    source = out.parent / (out.name + "-synthetic-input.json")
    if source.exists():
        from .core import AuditError
        raise AuditError("Synthetic input filename already exists")
    write_json(source, {"synthetic": True, "description": "Illustrative fixture, not an APK or captured traffic"})
    try:
        run = new_run(out, source)
        write_json(out / "raw/demo-source.json", {"synthetic": True})
    finally:
        source.unlink(missing_ok=True)
    run.update(original_apk=False, run_kind="synthetic_demonstration", package="org.example.travel", target_uid=10123,
               static_status="completed", execution_status="completed")
    run["limitations"].append("ALL demo inputs and events are synthetic; no Android evaluation was conducted")
    write_json(out / "run.json", run)
    add_evidence(out, "demo", out / "raw/demo-source.json", "synthetic fixture")
    write_json(out / "static.json", {"schema_version": "1.0", "permissions": [
        {"name": "android.permission.CAMERA", "evidence_ids": ["demo"]},
        {"name": "android.permission.INTERNET", "evidence_ids": ["demo"]}], "urls": [], "sdk_candidates": []})
    intent = {"schema_version": "1.0", "app_purpose": "端末内だけで旅行記録を保存（合成デモ）", "network": {"mode": "deny_all"},
              "sdk": {"mode": "unspecified"}, "permissions": {"mode": "allowlist", "allowed": ["android.permission.CAMERA"]},
              "cleartext_policy": "forbid", "background_network_policy": "forbid"}
    write_jsonl(out / "ui_events.jsonl", [{"event_id": "home", "started_utc": "2026-01-01T00:00:00Z", "ended_utc": "2026-01-01T00:01:00Z", "action": "home", "phase": "after_home", "success": True}])
    write_jsonl(out / "raw/demo-flow-input.jsonl", [{"started_utc": "2026-01-01T00:00:10Z", "ended_utc": "2026-01-01T00:00:11Z", "destination_ip": "192.0.2.1", "destination_port": 443,
        "transport": "TCP", "observation": "transport_established", "host": "telemetry.example.org", "host_evidence": "sni", "uid": 10123, "package": "org.example.travel", "bytes_sent": 420, "bytes_received": 100}])
    write_json(out / "demo.metadata.json", {"schema_version": "1.0", "run_id": run["run_id"], "apk_sha256": run["apk_sha256"], "tool": "synthetic fixture", "tool_version": "1.0", "started_utc": "2026-01-01T00:00:00Z", "ended_utc": "2026-01-01T00:01:00Z", "clock_offset_s": 0, "controls_before": "passed", "controls_after": "passed", "missing_intervals": []})
    import_capture(out, out / "raw/demo-flow-input.jsonl", out / "demo.metadata.json", "app-flow")
    compare(out, intent)
    report(out)
    return out
