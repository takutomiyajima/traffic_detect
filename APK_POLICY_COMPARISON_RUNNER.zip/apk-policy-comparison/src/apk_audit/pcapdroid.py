"""CSV contract read from upstream PCAPdroid 2.0.2 source.

Selected operator-provided Emulator exports were parsed and imported; this is
not a general validation of collector accuracy or other versions.

Source commit: 66f7b3514540c20add8655a74dfee93d00a9563b
ConnectionsAdapter.dumpConnectionsCsv(), values/strings.xml, Utils.java.
The export loses exact connection state and hostname provenance. Preserve
unknowns rather than infer TLS success or SNI from translated display fields.
"""
from pathlib import Path

from .core import AuditError
from .capture import normalize_app_rows

SOURCE_COMMIT = "66f7b3514540c20add8655a74dfee93d00a9563b"
HEADER = "IPProto,SrcIP,SrcPort,DstIp,DstPort,UID,App,PackageName,Proto,Status,Info,BytesSent,BytesRcvd,PktsSent,PktsRcvd,FirstSeen,LastSeen".split(",")


def pcapdroid_flows(path, run, meta):
    if meta.get("tool") != "PCAPdroid" or meta.get("tool_version") != "2.0.2":
        raise AuditError("pcapdroid-csv requires PCAPdroid tool_version 2.0.2; other formats unverified")
    def rows():
        with Path(path).open(encoding="utf-8-sig") as f:
            header = f.readline().rstrip("\r\n").split(",")
            if header not in (HEADER, HEADER + ["Malicious"]):
                raise AuditError("PCAPdroid CSV header differs from the inspected upstream contract")
            for line, text in enumerate(f, 2):
                if not text.strip(): continue
                # Upstream concatenates fields without RFC4180 quoting. Reject
                # commas/newlines in names rather than silently shift UID/IP columns.
                values = text.rstrip("\r\n").split(",")
                if len(values) != len(header):
                    raise AuditError(f"PCAPdroid CSV line {line}: ambiguous columns; retain original and export JSON with explicit mapping")
                row = dict(zip(header, values))
                try:
                    ipproto = int(row["IPProto"])
                    if ipproto not in (6, 17):
                        raise AuditError(f"PCAPdroid CSV line {line}: only TCP/UDP supported")
                    uid = int(row["UID"])
                    yield line, {"started_utc": row["FirstSeen"], "ended_utc": row["LastSeen"],
                                 "destination_ip": row["DstIp"], "destination_port": int(row["DstPort"]),
                                 "transport": "TCP" if ipproto == 6 else "UDP", "uid": uid if uid >= 0 else None,
                                 "package": row["PackageName"] or None, "bytes_sent": int(row["BytesSent"]), "bytes_received": int(row["BytesRcvd"]),
                                 "host": None, "application_protocol": None, "observation": "connection_attempt",
                                 "content_visibility": "metadata_only", "source_status": "PCAPdroid display: " + row["Status"]}
                except ValueError as e:
                    raise AuditError(f"PCAPdroid CSV line {line}: invalid numeric field") from e
    for flow in normalize_app_rows(rows(), run, meta):
        flow["host_unknown_reason"] = "CSV Info field has no SNI/DNS/HTTP provenance; retained in original CSV"
        flow["limitations"] += ["pcapdroid_csv_source_contract_only", "display_status_cannot_prove_transport_or_tls_success", "protocol_label_not_promoted_to_http_evidence"]
        flow["adapter_source_commit"] = SOURCE_COMMIT
        yield flow
