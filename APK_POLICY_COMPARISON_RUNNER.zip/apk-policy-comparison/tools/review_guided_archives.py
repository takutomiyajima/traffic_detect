#!/usr/bin/env python3
"""Recheck saved guided-trial ZIPs without extraction; deduplicate exact reuploads.

Example: python tools/review_guided_archives.py --out docs/generated/review.json \
  --primary http-test-001 --primary udp-short-001 handoff/*.zip
Only derived values are exported. Raw CSV, package dumps and images stay private.
"""
import argparse
import csv
import hashlib
import io
import json
import re
import zipfile
from collections import Counter
from datetime import datetime
from decimal import Decimal
from pathlib import Path, PurePosixPath

import measure_android_clock as clock


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def epoch(value):
    parsed = datetime.fromisoformat(value.strip())
    require(parsed.tzinfo is not None, 'Timestamp without timezone')
    return parsed.timestamp()


def review(path):
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        require(len(names) == len(set(names)), 'Duplicate ZIP member')
        require(all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts for n in names), 'Unsafe ZIP path')
        trials = [n for n in names if n.endswith('/trial.json')]
        require(len(trials) == 1, 'Expected exactly one trial.json')
        prefix = trials[0][:-len('trial.json')]
        read = lambda rel: z.read(prefix + rel)
        obj = lambda rel: json.loads(read(rel))
        t = obj('trial.json')
        tid, case = t['trial_id'], t['case']
        require(prefix == tid + '/', 'Trial ID and ZIP prefix differ')
        manifest = obj('manifest.json')['files']
        require(len({e['path'] for e in manifest}) == len(manifest), 'Duplicate manifest path')
        require({prefix + e['path'] for e in manifest} | {prefix + 'manifest.json'} == set(names), 'Manifest inventory differs')
        for e in manifest:
            data = read(e['path'])
            require(len(data) == e['bytes'] and sha(data) == e['sha256'], f'{tid}: manifest mismatch {e["path"]}')
        apk = sha(read('original.apk'))
        require(apk == t['apk_sha256'], 'APK hash mismatch')
        require(read('installed-apk-sha256.txt').decode().startswith(apk + ' '), 'Installed APK differs')
        policy = sha(read('intent-before-capture.json'))
        require(policy == t['intent_sha256'], 'Policy hash differs')
        require(epoch(t['policy_saved_utc']) < epoch(read('capture-start-earliest.txt').decode()), 'Policy not saved before capture')
        require(epoch(t['installed_hash_verified_before_capture_utc']) < epoch(read('capture-start-earliest.txt').decode()), 'Installed hash not checked before capture')
        dump = read('app-package.txt').decode()
        uids = re.findall(r'^\s+(?:appId|userId)=(\d+)\b', dump, re.M)
        require(uids and len(set(uids)) == 1 and int(uids[0]) == t['target_uid'], 'Package UID mismatch')
        require(re.search(r'^\s+User 0:.*installed=true', dump, re.M), 'User 0 installation missing')
        version = re.search(r'^\s+versionName=(\S+)', dump, re.M)[1]
        pcap_version = re.search(r'^\s+versionName=(\S+)', read('pcapdroid-package.txt').decode(), re.M)[1]
        require(pcap_version == '2.0.2', 'Unexpected PCAPdroid version')
        summaries = {}
        for phase in ('before', 'after'):
            c = obj(f'clock-{phase}.json')
            summaries[phase] = clock.summarize(c['samples'], 5)
            require(summaries[phase] == c['summary'], 'Clock summary differs')
        lower = max(s['offset_lower_s'] for s in summaries.values())
        upper = min(s['offset_upper_s'] for s in summaries.values())
        require(lower <= upper, 'Clock endpoint batches incompatible')
        require(t['endpoint_compatible_offset_s'] == {'lower': lower, 'upper': upper}, 'Clock intersection differs')
        reader = csv.DictReader(io.StringIO(read('capture.csv').decode('utf-8-sig')))
        flows = list(reader)
        require(all(None not in r and all(v is not None for v in r.values()) for r in flows), 'Ragged CSV')
        uid, package = t['target_uid'], t['package']
        conflicts = [n for n, r in enumerate(flows, 2) if (int(r['UID']) == uid) != (r['PackageName'] == package)]
        require(not conflicts, 'CSV UID/package contradiction')
        start = epoch(read('capture-start-earliest.txt').decode())
        stop = epoch(read('capture-stop-latest.txt').decode())
        outside = [n for n, r in enumerate(flows, 2) if epoch(r['LastSeen']) + upper < start or epoch(r['FirstSeen']) + lower > stop]
        require(not outside, 'CSV outside capture brackets')
        port, proto = ('8765', '6') if case == 'http' else ('8766', '17')
        local = [(n, r) for n, r in enumerate(flows, 2) if r['DstIp'] == '10.0.2.2' and r['DstPort'] == port and r['IPProto'] == proto]
        target_all = [(n, r) for n, r in enumerate(flows, 2) if int(r['UID']) == uid and r['PackageName'] == package]
        target = [(n, r) for n, r in local if int(r['UID']) == uid and r['PackageName'] == package]
        events = [json.loads(line) for line in read('server-events.jsonl').decode().splitlines()]
        target_events = [e for e in events if e.get('run_id') == tid]
        if case != 'offline':
            require(len(target_events) == 1, 'Target receive event not exactly once')
            e = target_events[0]
            expected_event = 'http_request_received' if case == 'http' else 'udp_datagram_received'
            require(e['event'] == expected_event, 'Wrong target event type')
            require(case != 'http' or e['method'] == 'POST', 'Target HTTP method differs')
            body = (('audit=' if case == 'http' else 'audit:') + tid).encode()
            require(e['body_bytes'] == len(body) and e['body_sha256'] == sha(body), 'Target body hash or length mismatch')
        else:
            require(not target_all and not target_events, 'Offline has target evidence')
        log = read('app-logcat.txt').decode()
        log_case = 'udp' if case == 'udp_hold' else case
        lines = [line for line in log.splitlines() if f'run={tid} case={log_case} ' in line]
        expected = {'http': 'http_response=200', 'offline': 'local_only_completed', 'udp': 'udp_sent', 'udp_hold': 'udp_sent'}[case]
        require(sum(line.endswith(' action_started') for line in lines) == 1, 'App action not exactly once')
        require(sum(line.endswith(' ' + expected) for line in lines) == 1, 'Expected app result not exactly once')
        require(t['app_result'] == expected and t['tap_count'] == 1, 'Trial app result or tap count differs')
        require(expected in read('app-result-ui.xml').decode(), 'Result UI differs')
        hold = None
        if case == 'udp_hold':
            a = re.search(r'^\s*(\d+\.\d+).*socket_hold_started_ms=2000', log, re.M)[1]
            b = re.search(r'^\s*(\d+\.\d+).*socket_hold_finished', log, re.M)[1]
            hold = float(Decimal(b) - Decimal(a))
        controls = obj('browser-controls.json')
        for phase, c in controls.items():
            gets = [e for e in events if e.get('event') == 'http_request_received' and e.get('method') == 'GET' and epoch(c['started_utc']) <= epoch(e['utc']) <= epoch(c['ended_utc'])]
            require(gets, 'Health control GET absent')
            if c['verified_event_id']:
                require(any(e['event_id'] == c['verified_event_id'] for e in gets), 'Health event ID mismatch')
            chrome = [n for n, r in enumerate(flows, 2) if int(r['UID']) == t['environment']['chrome_uid'] and r['PackageName'] == 'com.android.chrome' and r['DstIp'] == '10.0.2.2' and r['DstPort'] == '8765' and epoch(r['FirstSeen']) + lower <= epoch(c['ended_utc']) and epoch(r['LastSeen']) + upper >= epoch(c['started_utc'])]
            require(chrome, 'Health control CSV correspondence absent')
        summary = t['capture_summary']
        require(summary['csv_rows'] == len(flows) and summary['target_rows'] == len(target_all), 'Recorded row count differs')
        require(t['observation_elapsed_monotonic_s'] >= 30, 'Wait below 30 seconds')
        require(t['quality'] == 'partial' and t['clock_alignment_status'] == 'conditional', 'Unexpected quality classification')
        candidates = [{'line': n, 'uid': int(r['UID']), 'package': r['PackageName'], 'bytes_sent': int(r['BytesSent']), 'bytes_received': int(r['BytesRcvd']), 'packets_sent': int(r['PktsSent']), 'packets_received': int(r['PktsRcvd'])} for n, r in local]
        return {
            'trial_id': tid, 'case': case, 'created_utc': t['created_utc'], 'app_version': version,
            'apk_sha256': apk, 'policy_sha256': policy, 'archive_sha256': sha(path.read_bytes()),
            'uid': uid, 'csv_rows': len(flows), 'candidate_rows': candidates,
            'identified_target_rows': len(target), 'server_events': len(target_events),
            'server_body_bytes': [e['body_bytes'] for e in target_events], 'app_result': expected,
            'hold_observed_s': hold, 'wait_s': t['observation_elapsed_monotonic_s'],
            'quality': t['quality'], 'coverage_status': t['coverage_status'], 'checks': summary['checks'],
            'status': t['status'], 'recorded_problems': summary['problems'],
            'control_verification': {phase: c['verification'] for phase, c in controls.items()},
            'manifest_entries': len(manifest), 'clock_summaries_recomputed': summaries,
            'verification': 'manifest_apk_uid_policy_clock_server_log_ui_csv_controls_rechecked',
        }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--primary', action='append', default=[])
    parser.add_argument('archives', nargs='+', type=Path)
    args = parser.parse_args()
    rows, duplicate = {}, []
    for path in args.archives:
        row = review(path)
        tid = row['trial_id']
        if tid in rows:
            require(row['archive_sha256'] == rows[tid]['archive_sha256'], 'Same trial ID with different contents')
            duplicate.append({'trial_id': tid, 'archive_sha256': row['archive_sha256']})
        else:
            rows[tid] = row
    require(len(args.primary) == len(set(args.primary)) and set(args.primary) <= rows.keys(), 'Primary trial inventory ambiguous')
    counts = Counter(row['case'] for row in rows.values())
    result = {
        'schema_version': '1.1', 'review_date_jst': '2026-10-31',
        'dataset_scope': 'Received guided trials, deduplicated by trial ID and identical archive hash; primary uploaded nine distinguished from earlier pilots',
        'primary_trial_ids': sorted(args.primary), 'trials': [rows[k] for k in sorted(rows)],
        'duplicate_reuploads': duplicate,
        'counts': {'guided_trials': len(rows), 'manifest_references_verified': sum(row['manifest_entries'] for row in rows.values()), 'http': counts['http'], 'offline': counts['offline'], 'short_udp': counts['udp'], 'held_udp': counts['udp_hold'], 'primary_trials': len(args.primary)},
        'limitations': ['Single AVD and self-authored controls; repeated trials are not independent apps', 'Unknown CSV UDP rows are correspondence candidates, not measured target UIDs', 'Short and held UDP APK versions, order, logs and body lengths differ', 'Endpoint clock models are conditional; acquisition continuity is operator-attested', 'Earlier http-004 and ui-check-001 are separate pilots, excluded from guided trial count', 'Additional offline repetitions remain an experimenter statement without received raw archives'],
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    fields = ['trial_id', 'case', 'app_version', 'uid', 'app_result', 'server_events', 'identified_target_rows', 'hold_observed_s', 'wait_s', 'quality', 'status', 'archive_sha256']
    with args.out.with_suffix('.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(result['trials'])
    print(json.dumps(result['counts']))
    for row in result['trials']:
        print(row['trial_id'], row['server_events'], row['identified_target_rows'], row['server_body_bytes'], row['hold_observed_s'])


if __name__ == '__main__':
    main()
