# 研究進捗資料と卒業論文草稿（2026-10-29）

- docs/progress.pdf: 研究進捗・残作業・実施順（4ページ）。
- docs/thesis.pdf: 現時点の論文草稿（22ページ）。
- docs/thesis.tex / generated/: 本文と必要な表・図。
- docs/research/progress-and-next-steps-2026-10-29.md: 進捗資料の編集元。
- docs/generated/current-experiments.json: 受領済み半自動8試行の集計。

論文は確認済みの実測と回帰確認を反映した草稿です。著者情報・大学様式・査読関連研究・独立正解による本評価・指導教員レビューは今後反映します。既存の事後ポリシー例は事前固定実験と区別しています。ユーザーの原本ログや画面の全文は本ZIPに含めていません。

## PDFの再生成

PDFを読むだけなら追加環境は不要です。再生成にはXeLaTeX、Noto Serif CJK JP、Noto Sans CJK JP、DejaVu Sans Monoと通常のLaTeXパッケージが必要です。進捗Markdownの変換にはPython 3.11以上の標準ライブラリを使います。

このREADMEがあるフォルダで:

```bash
bash tools/build_thesis.sh
python tools/build_progress_report.py
```

論文を直接修正する場合はdocs/thesis.texと必要なgenerated内のTeXを編集します。進捗はMarkdownを編集してbuild_progress_report.pyで再生成します。実測値を変える場合は元記録との対応を再確認してください。

本ZIPは文書の再ビルド用です。端末実験のランナー一式とは別の成果物です。
