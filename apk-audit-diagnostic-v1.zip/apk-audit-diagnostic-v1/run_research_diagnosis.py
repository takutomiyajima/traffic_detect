#!/usr/bin/env python3
"""Additive research CLI. Does not overwrite established analyzer modules."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if (ROOT / "src").is_dir():
    sys.path.insert(0, str(ROOT / "src"))


def main(argv=None):
    from apk_audit.core import AuditError, write_json
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    context = sub.add_parser("context", help="APKのURL引数の使用文脈だけを解析。端末操作なし")
    context.add_argument("--apk", type=Path, required=True)
    context.add_argument("--out", type=Path, required=True)
    plan = sub.add_parser("plan", help="宣言した候補操作を予算内で順位付け。端末操作なし")
    plan.add_argument("--pairs", type=int, default=2)
    plan.add_argument("--budget", type=int, default=4)
    plan.add_argument("--out", type=Path, required=True)
    plan.add_argument("--baseline-run", type=Path)
    plan.add_argument("--context", type=Path)
    live = sub.add_parser("contrast", help="既存エミュレータで研究用RSS入力A/Bを実行")
    live.add_argument("--apk", type=Path, required=True)
    live.add_argument("--out", type=Path, required=True)
    live.add_argument("--baseline-run", type=Path, required=True, help="同じAPKの動的のみがある既存試行")
    live.add_argument("--serial", default="emulator-5554")
    live.add_argument("--package", default="de.danoeh.antennapod")
    live.add_argument("--activity", default="de.danoeh.antennapod/.ui.screen.onlinefeedview.OnlineFeedViewActivity")
    live.add_argument("--pairs", type=int, default=2)
    live.add_argument("--budget", type=int, default=4)
    live.add_argument("--observe-s", type=int, default=30)
    live.add_argument("--snapshot", help="任意：保存済み研究用AVD状態を各試行前に復元。省略時は既存データを保持")
    live.add_argument("--non-interactive", action="store_true", help="終了後申告を尋ねず不明として保存")
    review = sub.add_parser("assess", help="取得済み対照実行を原本から点検。端末操作なし")
    review.add_argument("--study", type=Path, required=True)
    restore = sub.add_parser("restore", help="返却ZIPを新規フォルダへ復元。コードは実行しません")
    restore.add_argument("--archive", type=Path, required=True)
    restore.add_argument("--out", type=Path, required=True)
    a = p.parse_args(argv)
    try:
        if a.command == "context":
            from apk_audit.research_context import scan_bounded
            result = scan_bounded(a.apk, a.out)
            print(json.dumps({"out": str(a.out), "status": result["analysis_status"], "counts": result["counts"]}, ensure_ascii=False, indent=2))
        elif a.command == "plan":
            from apk_audit.research_diagnosis import default_plan, plan_from_evidence, write_plan_report
            if a.out.exists() or (a.context and a.out.with_suffix('.html').exists()):
                raise AuditError("Plan output exists; choose a new file")
            if bool(a.baseline_run) != bool(a.context):
                raise AuditError("Evidence-based plan requires both --baseline-run and --context")
            from apk_audit.core import read_json
            result = plan_from_evidence(a.baseline_run, read_json(a.context), a.pairs, a.budget) if a.baseline_run else default_plan(a.pairs, a.budget)
            write_json(a.out, result)
            if a.context:
                write_plan_report(a.out.with_suffix('.html'), result, read_json(a.context))
            print(json.dumps(result, ensure_ascii=False, indent=2))
        elif a.command == "contrast":
            from apk_audit.research_contrast import run_live
            result, code = run_live(a)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            print(result.get("report", str(Path(a.out).resolve() / "diagnosis.html")))
            return code
        elif a.command == "assess":
            from apk_audit.research_diagnosis import assess
            print(json.dumps(assess(a.study), ensure_ascii=False, indent=2))
        else:
            from apk_audit.research_bundle import restore
            print(restore(a.archive, a.out))
        return 0
    except (AuditError, ValueError, OSError) as exc:
        print(json.dumps({"error": str(exc), "type": type(exc).__name__}, ensure_ascii=False, indent=2), file=sys.stderr)
        return 4


if __name__ == "__main__":
    raise SystemExit(main())
