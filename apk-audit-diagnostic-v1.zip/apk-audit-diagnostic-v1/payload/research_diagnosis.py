"""Budgeted probe planning and bounded, evidence-gated contrast assessment."""
from __future__ import annotations

import html
from itertools import combinations
from pathlib import Path
import ipaddress
import re

from .core import AuditError, is_ip, read_json, read_jsonl, sha256, timestamp, write_json

PROFILE = "contrast-diagnosis-v1"


def select_probe(hypotheses, probes, budget):
    """Maximize separated model pairs / execution cost under valid observation.

    This is a declared heuristic over user-specified outcome models, not learned
    information gain, an optimal adaptive policy, or a novelty/accuracy result.
    """
    if type(budget) is not int or budget < 0 or len(hypotheses) != len(set(hypotheses)):
        raise AuditError("Invalid hypothesis list or execution budget")
    ranked = []
    ids = [p.get("probe_id") for p in probes]
    if len(ids) != len(set(ids)) or any(not isinstance(v, str) for v in ids):
        raise AuditError("Probe IDs must be unique strings")
    for probe in probes:
        cost = probe["cost_units"]
        if type(cost) is not int or cost <= 0:
            raise AuditError("Probe cost must be a positive execution count")
        outcomes = probe["valid_outcome_model"]
        if set(outcomes) != set(hypotheses) or not all(isinstance(v, list) and v and all(isinstance(x, str) for x in v) for v in outcomes.values()):
            raise AuditError("Outcome model must cover every hypothesis")
        separated = sum(set(outcomes[a]).isdisjoint(outcomes[b]) for a, b in combinations(hypotheses, 2))
        eligible = probe.get("available") is True and cost <= budget
        ranked.append({**probe, "separated_model_pairs": separated, "score": separated / cost,
                       "eligible": eligible})
    ranked.sort(key=lambda p: (-p["score"], p["cost_units"], p["probe_id"]))
    selected = next((p for p in ranked if p["eligible"] and p["separated_model_pairs"] > 0), None)
    return {"profile": PROFILE, "budget_units": budget, "cost_unit": "device_trial",
            "hypotheses": hypotheses, "ranked_probes": ranked,
            "selected_probe": selected["probe_id"] if selected else None,
            "reason": "declared_conditional_pair_separation_per_cost" if selected else "no_available_discriminating_probe_within_budget",
            "failure_policy": "Invalid/inconclusive observations retain all hypotheses; no forced cause.",
            "novelty_or_accuracy_established": False}


def default_plan(pairs=2, budget=4, activity_available=True):
    if type(pairs) is not int or not 1 <= pairs <= 5:
        raise AuditError("pairs must be 1..5")
    hypotheses = ["input_endpoint_dependency", "input_independent_behavior"]
    probes = [{"probe_id": "input_switch", "cost_units": 2 * pairs, "available": activity_available,
               "valid_outcome_model": {hypotheses[0]: ["tracks_input"], hypotheses[1]: ["unchanged_positive_endpoint"]}},
              {"probe_id": "repeat_same_input", "cost_units": 2 * pairs, "available": activity_available,
               "valid_outcome_model": {h: ["repeat_same"] for h in hypotheses}}]
    result = select_probe(hypotheses, probes, budget)
    result["scope"] = "Two declared probes for supplied URI action; not arbitrary GUI exploration or a general causal planner."
    return result


def plan_from_evidence(baseline, context, pairs=2, budget=4):
    """Only offer the implemented URI probe for a real dynamic-only baseline.

    Other gaps stay unresolved. The context counts describe support/limits;
    they never establish that a constructor was executed or a URL was sent.
    """
    baseline = Path(baseline)
    run = verify_run(baseline)
    if context.get("apk_sha256") != run.get("apk_sha256"):
        raise AuditError("Static context and baseline APK differ")
    correspondence = read_json(baseline / "correspondence.json")
    flows = {f["flow_id"]: f for _, f in read_jsonl(baseline / "flows.jsonl") if "flow_id" in f}
    dynamic_ids = {fid for row in correspondence.get("records", []) if row.get("status") == "dynamic_only" for fid in row.get("flows", [])}
    contextual_matches = []
    for number, site in enumerate(context.get("records", []), 1):
        endpoint = site.get("endpoint")
        if site.get("status") != "constant_url_argument" or not endpoint:
            continue
        for fid in dynamic_ids:
            flow = flows.get(fid, {})
            destination = flow.get("destination_ip") if is_ip(endpoint["host"]) else flow.get("host")
            if (flow.get("attribution") == "target" and flow.get("transport") == "TCP"
                    and flow.get("port") == endpoint["port"] and endpoint["host"] == destination):
                contextual_matches.append({"context_site": number, "flow_id": fid, "host": endpoint["host"],
                                           "port": endpoint["port"], "code_to_runtime_link_proven": False})
    scenario = run.get("analysis_scenario", {})
    uri_actions = [s for s in scenario.get("steps", []) if s.get("action") == "open_uri"]
    available = bool(correspondence["counts"].get("dynamic_only") and uri_actions
                     and run.get("dynamic_status") in ("completed", "partial"))
    if dynamic_ids and {x["flow_id"] for x in contextual_matches} == dynamic_ids:
        available = False
    result = default_plan(pairs, budget, available)
    result["evidence_basis"] = {
        "apk_sha256": run["apk_sha256"], "package": run.get("package"),
        "baseline_run_id": run["run_id"], "correspondence_counts": correspondence["counts"],
        "context_status_counts": context.get("counts", {}),
        "contextual_endpoint_matches": contextual_matches,
        "supplied_uri_action_exists": bool(uri_actions),
        "source_sha256": {name: sha256(baseline / name) for name in ("run.json", "correspondence.json", "flows.jsonl", "evidence/index.json")}}
    if not available:
        result["reason"] = "implemented_probe_requires_dynamic_only_record_and_registered_URI_action"
    if dynamic_ids and {x["flow_id"] for x in contextual_matches} == dynamic_ids:
        result["reason"] = "dynamic_only_endpoints_have_local_constant_argument_candidates"
    result["protected_unknowns"] = ["Capture completeness, unsupported APIs and root causes remain unproven."]
    return result


def write_plan_report(path, selection, context):
    esc = lambda x: html.escape(str(x), quote=True)
    sites = "".join('<tr><td>' + esc(r['class'] + ' / ' + r['method']) + '</td><td>' + esc(r['usage_kind'])
                    + '</td><td>' + esc(r['status']) + '</td><td>' + esc(r.get('value')) + '</td></tr>' for r in context.get('records', []))
    Path(path).write_text('<!doctype html><meta charset="utf-8"><title>静的文脈と追加観測の計画</title>'
        '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'">'
        '<style>body{font:16px/1.8 sans-serif;max-width:1100px;margin:2rem auto;padding:1rem}td,th{border:1px solid #bcc;padding:.5rem;overflow-wrap:anywhere}table{border-collapse:collapse;width:100%}</style>'
        '<h1>静的文脈から追加観測を選ぶ</h1><p>選択：' + esc(selection['selected_probe']) + '</p><p>理由：' + esc(selection['reason'])
        + '</p><p>URLの生成・設定APIに渡る値を基本ブロック内で追います。実行到達や送信の証明ではありません。</p>'
        '<p>不明な値を除外せず表示します。現在の対応関係：' + esc(selection.get('evidence_basis', {})) + '</p>'
        '<table><tr><th>所在</th><th>APIの役割</th><th>引数の状態</th><th>確認した値</th></tr>' + sites + '</table>'
        '<p>追加観測の順位付けは宣言した仮説モデルと予算による規則です。既存研究に対する新規性や精度改善は未実証です。</p>', encoding='utf-8')


def verify_run(out):
    out = Path(out).resolve()
    index = read_json(out / "evidence/index.json")
    for eid, item in index.items():
        path = (out / item["path"]).resolve()
        if not path.is_relative_to(out) or not path.is_file() or sha256(path) != item["sha256"]:
            raise AuditError(f"Run evidence missing or modified: {eid}", 4)
    return read_json(out / "run.json")


def capture_gate(out):
    """Recompute positive controls from trace/flow/server records, not a flag."""
    out = Path(out)
    run = verify_run(out)
    trace = read_json(out / "raw/bridge-results.json")
    servers = [r for _, r in read_jsonl(out / "raw/automatic-controls.jsonl")]
    flows = [r for _, r in read_jsonl(out / "flows.jsonl")]
    identity = read_json(out / "raw/installation-identity.json")
    statuses = [r.get("result", {}).get("running") for r in trace if r.get("action") == "get_status"]
    probes = [r for r in trace if r.get("action") == "probe" and r.get("result", {}).get("http_status") == 200]
    matched = [p for p in probes if any(s.get("run_id") == p.get("request_id") and s.get("event") == "http_request_received"
                                        and s.get("method") == "GET" for s in servers)]
    controls = [f for f in flows if f.get("uid") == run.get("bridge_uid") and f.get("port") == run.get("control_port")
                and f.get("destination_ip") == "10.0.2.2" and f.get("application_protocol") == "http"]
    checks = {"live": run.get("analysis_mode") == "live", "static_completed": run.get("static_status") == "completed",
              "installation_identity": type(run.get("target_uid")) is int and run["target_uid"] >= 0
                  and run.get("bridge_uid") != run["target_uid"] and identity.get("uid") == run["target_uid"]
                  and identity.get("package") == run.get("package") and identity.get("apk_sha256") == run.get("apk_sha256"),
              "execution_completed": run.get("execution_status") == "completed" and not run.get("errors"),
              "capture_retained": run.get("dynamic_status") in ("partial", "completed"),
              "start_stop_confirmed": statuses == [False, True, False],
              "callbacks": all(any(r.get("action") == action and r.get("result", {}).get("result_code") == -1 for r in trace) for action in ("start", "stop")),
              "two_device_server_controls": len(matched) == 2,
              "two_uid_control_flows": len(controls) >= 2,
              "cleanup": not run.get("cleanup_failed") and not run.get("manual_cleanup_required")}
    return {"checks": checks, "passed": all(checks.values()),
            "limitation": "Positive controls do not establish full coverage or independent UID truth."}


def request_witness(out, url, server_events):
    """Complete one-packet HTTP headers only; never reconstruct guessed bytes.

    The destination + target UID + per-trial nonce path provide a server match
    candidate. NAT ports and full TCP stream identity remain unproven.
    """
    from urllib.parse import urlsplit
    from .pcapdroid import trailer_uid
    import dpkt
    out = Path(out)
    run = verify_run(out)
    if type(run.get("target_uid")) is not int or run["target_uid"] < 0:
        raise AuditError("A nonnegative recorded target UID is required")
    uri = urlsplit(url)
    if uri.scheme != "http" or uri.hostname != "10.0.2.2" or not uri.port or uri.query or uri.fragment:
        raise AuditError("This witness accepts the controlled local HTTP endpoint only")
    path = uri.path
    if not re.fullmatch(r"/feed/[a-f0-9]{32}\.xml", path):
        raise AuditError("Expected a per-trial nonce feed path")
    metadata = read_json(out / "automatic.metadata.json")
    offset = metadata.get("clock_offset_s")
    witnesses = []
    with (out / "raw/automatic.pcap").open("rb") as stream:
        for number, (ts, frame) in enumerate(dpkt.pcap.Reader(stream), 1):
            try:
                ip = dpkt.ethernet.Ethernet(frame).data
                if not isinstance(ip, dpkt.ip.IP) or not isinstance(ip.data, dpkt.tcp.TCP):
                    continue
                tcp = ip.data
                if (trailer_uid(frame) != run.get("target_uid") or str(ipaddress.ip_address(ip.dst)) != uri.hostname
                        or tcp.dport != uri.port or b"\r\n\r\n" not in tcp.data):
                    continue
                first = tcp.data.split(b"\r\n", 1)[0]
                if first not in (("GET " + path + " HTTP/1.1").encode(), ("GET " + path + " HTTP/1.0").encode()):
                    continue
                matched = [i + 1 for i, row in enumerate(server_events)
                           if row.get("path") == path and row.get("method") == "GET" and row.get("status") == 200
                           and row.get("write_completed") is True and isinstance(offset, (int, float))
                           and abs(timestamp(row["started_utc"]) - (float(ts) + offset)) <= 1]
                if len(matched) == 1:
                    witnesses.append({"request_packet": number, "target_uid": run["target_uid"],
                                      "server_record": matched[0], "path": path, "destination_port": uri.port,
                                      "correlation": "candidate_by_unique_nonce_target_UID_destination_and_conditional_clock"})
            except (ValueError, dpkt.UnpackError, AttributeError):
                continue
    return witnesses


def assess(study):
    study = Path(study).resolve()
    manifest = read_json(study / "STUDY-MANIFEST.json")
    for name, digest in manifest["files"].items():
        path = (study / name).resolve()
        if not path.is_relative_to(study) or not path.is_file() or sha256(path) != digest:
            raise AuditError(f"Study evidence missing or modified: {name}", 4)
    plan = read_json(study / "study-plan.json")
    trials = read_json(study / "trials.json")
    prepared = read_json(study / "PREPARED-MANIFEST.json")["files"]
    if any(sha256(study / name) != digest for name, digest in prepared.items() if name in ("study-plan.json", "context.json")):
        raise AuditError("Prepared study plan differs")
    if len({x["url"] for x in plan["trials"]}) != len(plan["trials"]):
        raise AuditError("Every condition needs a distinct nonce URL")
    if len(plan["endpoints"]) != 2 or len(set(plan["endpoints"].values())) != 2:
        raise AuditError("The A/B task requires two different controlled endpoint ports")
    def registered_file(name):
        path = (study / name).resolve()
        if not path.is_relative_to(study) or name not in manifest["files"]:
            raise AuditError("Unregistered study file reference")
        return path
    rows = []
    seen_paths, seen_runs = set(), set()
    for trial in trials:
        directory = (study / trial["directory"]).resolve()
        if not directory.is_relative_to(study) or directory in seen_paths:
            raise AuditError("Distinct trial directories must stay inside the study")
        seen_paths.add(directory)
        run = verify_run(directory)
        if run["run_id"] in seen_runs:
            raise AuditError("Reused capture/run ID is not an independent contrast condition")
        seen_runs.add(run["run_id"])
        if run["apk_sha256"] != plan["apk_sha256"] or run.get("package") != plan["package"]:
            raise AuditError("Contrast must use the same unchanged APK and package")
        expected = next((x for x in plan["trials"] if x["trial_id"] == trial["trial_id"]), None)
        if not expected or any(trial.get(k) != expected.get(k) for k in ("arm", "url", "directory")):
            raise AuditError("Recorded condition differs from the frozen plan")
        from urllib.parse import urlsplit
        if urlsplit(trial["url"]).port != plan["endpoints"].get(trial["arm"]):
            raise AuditError("Input arm and endpoint differ")
        events = read_json(registered_file(trial["server_events"]))
        stored_gate = read_json(registered_file(trial["capture_gate"]))
        gate = capture_gate(directory)
        if gate != stored_gate:
            raise AuditError("Stored capture gate differs from recomputed controls")
        witnesses = request_witness(directory, trial["url"], events)
        dispatch = [e for _, e in read_jsonl(directory / "ui_events.jsonl")
                    if e.get("action") == "open_uri" and e.get("uri") == trial["url"] and e.get("success")]
        same_scenario = run.get("analysis_scenario") == expected["scenario"]
        timed_dispatch = any(timestamp(e["ended_utc"]) - timestamp(e["started_utc"]) >= expected["scenario"]["steps"][1]["observe_s"] for e in dispatch)
        positive = bool(witnesses and timed_dispatch and same_scenario and gate.get("passed") and run.get("analysis_mode") == "live")
        rows.append({"trial_id": trial["trial_id"], "arm": trial["arm"], "positive": positive,
                     "witnesses": witnesses, "capture_controls_passed": gate.get("passed", False),
                     "state_condition": trial.get("state_condition", "preserved_uncontrolled"),
                     "quality": run.get("dynamic_status")})
    planned = plan["order"]
    complete = len(rows) == len(planned) and [r["arm"] for r in rows] == planned
    both = complete and all(r["positive"] for r in rows) and set(planned) == {"A", "B"}
    if both:
        label = "input_endpoint_association_observed"
        text = "入力を切り替えた各条件で、指定した研究用宛先への対象UID要求と受信記録の候補対応を確認しました。"
    else:
        label = "inconclusive"
        text = "入力条件間の対応を説明する証拠がそろっていません。未観測を入力非依存・無通信へ変換しません。"
    result = {"schema_version": "1.0", "profile": PROFILE, "diagnosis": label, "explanation": text,
              "planned_trials": len(planned), "recorded_trials": len(rows), "complete_order": complete,
              "rows": rows, "causal_root_proven": False, "general_accuracy_established": False,
              "state_policy": plan["state_policy"],
              "operator_report": read_json(study / "operator-report.json") if (study / "operator-report.json").exists() else {"additional_actions": "unknown"},
              "supported_hypotheses": ["input_endpoint_dependency"] if both else [],
              "remaining_hypotheses": plan["selection"]["hypotheses"],
              "limitations": ["要求と受信記録は、NATと時計補正の仮定が残る候補対応です。",
                              "既存データの保持は開始状態の一致を意味しません。指定した場合だけスナップショット復元応答を記録します。",
                              "対応の観測は、実行されたコード箇所や一般的な因果関係の確定ではありません。",
                              "要求が見えないことを、入力非依存や無通信へ変換しません。",
                              "操作選択は宣言した仮説とコストによる規則で、他方式への優越は未実証です。"]}
    write_json(study / "diagnosis.json", result)
    esc = lambda value: html.escape(str(value), quote=True)
    rows_html = "".join(f'<tr><td>{esc(r["trial_id"])}</td><td>{esc(r["arm"])}</td><td>{esc(r["positive"])}</td>'
                        f'<td>{esc(r["state_condition"])}</td><td>{esc(r["witnesses"])}</td></tr>' for r in rows)
    (study / "diagnosis.html").write_text('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width">'
        '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'">'
        '<title>対照実行による差分診断</title><style>body{font:16px/1.8 sans-serif;max-width:1100px;margin:2rem auto;padding:1rem}'
        'td,th{border:1px solid #bcc;padding:.5rem;overflow-wrap:anywhere}table{border-collapse:collapse;width:100%}</style>'
        '<h1>対照実行による差分診断</h1><p>' + esc(text) + '</p><p>診断状態：' + esc(label) + '</p>'
        '<p>追加操作の終了後申告：' + esc(result['operator_report']) + '。全入力の客観的監視ではありません。</p>'
        '<p>追加操作の選択規則：有効観測を仮定した原因候補ペアの分離数÷実行数。実行時入力の一般的な原因確定や最適探索ではありません。</p>'
        '<table><tr><th>試行</th><th>入力条件</th><th>正の証拠</th><th>開始状態</th><th>要求と受信記録の候補</th></tr>' + rows_html + '</table>'
        '<h2>解釈の限界</h2><ul>' + ''.join('<li>' + esc(x) + '</li>' for x in result['limitations'])
        + '</ul><p><a href="diagnosis.json">診断JSON</a> / <a href="study-plan.json">取得前の実行計画</a>'
        ' / <a href="context.json">静的な引数使用文脈</a> / <a href="plan.html">選択に使った静的文脈と計画</a></p>', encoding="utf-8")
    return result
