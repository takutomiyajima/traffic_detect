# 差分診断プログラム v1 の使い方

2026年11月6日。既存システムを利用する追加プログラムです。元のプログラムの置換・再セットアップは不要です。

## 配置

`apk-audit-diagnostic-v1.zip` を展開し、`apk-audit-diagnostic-v1` フォルダをDocumentsに置きます。
既存プロジェクトは `Documents/apk-audit-unified-v1`、APKはDownloads、対象は既存のAPI35 arm64エミュレータを想定します。
Pythonは既存の仮想環境を絶対パスで指定するので、ターミナルの現在位置やactivateの有無に依存しません。

## 1. 静的な使用文脈だけ確認する

端末操作・サーバー起動はありません。

```sh
"$HOME/Documents/apk-audit-unified-v1/.venv/bin/python" \
  "$HOME/Documents/apk-audit-diagnostic-v1/run_research.py" context \
  --apk "$HOME/Downloads/de.danoeh.antennapod_3120395.apk" \
  --out "$HOME/Documents/apk-audit-unified-v1/runs/diagnostic-context-001.json"
```

基本ブロック内の文字列定義・コピー・限定した結合から、URL生成・設定APIの実際の引数へ届く値を追います。
メソッドが実行されたことや通信したことは断定しません。出力が既にある場合は末尾番号を変えます。

## 2. 保存済み試行から追加実行を計画する

端末操作はありません。既存の `antennapod-rss-preview-006` が同じAPKの試行であることを確認します。

```sh
"$HOME/Documents/apk-audit-unified-v1/.venv/bin/python" \
  "$HOME/Documents/apk-audit-diagnostic-v1/run_research.py" plan \
  --baseline-run "$HOME/Documents/apk-audit-unified-v1/runs/antennapod-rss-preview-006" \
  --context "$HOME/Documents/apk-audit-unified-v1/runs/diagnostic-context-001.json" \
  --out "$HOME/Documents/apk-audit-unified-v1/runs/diagnostic-plan-001.json"
open "$HOME/Documents/apk-audit-unified-v1/runs/diagnostic-plan-001.html"
```

静的文脈で対応候補を補えた場合は、その候補を示します。差が残り、登録済みURI操作を実行できる場合は、
予算内で入力A/Bの切替を選びます。対応しない差分に対して任意の画面探索を始める機能ではありません。

## 3. 既存エミュレータで入力A/Bを観測する

ここから新しいAndroid試行です。エミュレータ `emulator-5554` を起動した状態で実行します。
AntennaPodを手動で開く必要はありません。既存のPCAPdroid 2.0.2・制御補助アプリ・解析環境を使用します。

```sh
"$HOME/Documents/apk-audit-unified-v1/.venv/bin/python" \
  "$HOME/Documents/apk-audit-diagnostic-v1/run_research.py" contrast \
  --apk "$HOME/Downloads/de.danoeh.antennapod_3120395.apk" \
  --baseline-run "$HOME/Documents/apk-audit-unified-v1/runs/antennapod-rss-preview-006" \
  --out "$HOME/Documents/apk-audit-unified-v1/runs/diagnostic-ab-001"
```

既定はA・B・B・Aの4試行です。各試行では起動5秒とURI入力後30秒を予定し、前後対照・停止・回収も行います。
同じAPKへ、異なるローカルポートの研究用RSS URLを入力します。URLパスは試行ごとに固有です。
観測中は購読・再生・画面移動を追加せず、制御・VPNの許可画面だけ確認してください。
正常終了時に追加操作の有無を尋ねます。申告できない場合は不明のまま記録します。

必要なら `--pairs 1 --budget 2` でA・Bの2試行にできます。これは成立確認の規模で、統計的に十分な標本数を意味しません。
取得や後始末が失敗した場合は残りの試行を停止します。出力フォルダを保持し、新しい番号でやり直します。

### 開始状態の扱い

既定では既存アプリデータを保持します。キャッシュや購読状態を統制した因果実験とはしません。
保存済みの研究用AVD状態を用いる場合に限り、`--snapshot research_base` 等を明示指定できます。
この指定はAVDの状態を保存時点へ戻す操作です。研究用の保存状態にのみ使ってください。
プログラムはデータ消去や新しいスナップショット作成を自動では行いません。

### 結果を開く

```sh
open "$HOME/Documents/apk-audit-unified-v1/runs/diagnostic-ab-001/diagnosis.html"
```

正の証拠がそろえば `input_endpoint_association_observed`、不足すれば `inconclusive` です。
前者も、一般的な原因・コード箇所・アプリ全文処理を確定したという意味ではありません。
静的文脈だけで宛先候補を補え、追加実行を省いた場合は `plan.html` を開きます。この場合は新しい端末試行も返却ZIPも作りません。

## 4. 返却するファイル

対照実行後は、次の返却用ZIPを自動作成します。

`Documents/apk-audit-unified-v1/runs/diagnostic-ab-001.return.zip`

同じAPKの重複コピーを一度だけ保存し、原本・静的文脈・計画・受信記録をまとめます。
ZIPには元APKや通信原本を含むため、研究者用として扱います。GitHubへ自動送信しません。
結果をこちらへ返す場合は、このZIPを添付してください。

## 5. 返却ZIPを別の作業先で点検する場合

通常の解凍では重複APKの元配置が再現されません。専用の復元を行ってから点検します。

```sh
"$HOME/Documents/apk-audit-unified-v1/.venv/bin/python" \
  "$HOME/Documents/apk-audit-diagnostic-v1/run_research.py" restore \
  --archive "$HOME/Documents/apk-audit-unified-v1/runs/diagnostic-ab-001.return.zip" \
  --out "$HOME/Documents/apk-audit-unified-v1/runs/diagnostic-ab-restored-001"
"$HOME/Documents/apk-audit-unified-v1/.venv/bin/python" \
  "$HOME/Documents/apk-audit-diagnostic-v1/run_research.py" assess \
  --study "$HOME/Documents/apk-audit-unified-v1/runs/diagnostic-ab-restored-001"
```

復元は新しいフォルダに限定し、ファイル名とhashを検査します。受領したコードを自動実行しません。

## 実装と検証の範囲

新しい4モジュールとCLI、図入りの実装説明PDF、ソース、検査記録を同梱しています。
既存のstatic・pipeline・automatic・differentialは書き換えません。
クラウドで282件の自動テスト、開発用6ケースの実DEX検査、AntennaPodのオフライン解析を行いました。
新しいランナーによるMac・Android実測、一般的な精度改善、方法上の新規性は未検証です。

別の場所のプロジェクトを利用する場合は、起動コマンドに `--project /既存プロジェクトの絶対パス` を追加できます。
