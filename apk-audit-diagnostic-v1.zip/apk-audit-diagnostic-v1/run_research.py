#!/usr/bin/env python3
"""Distribution entry point, installed as run_research.py beside payload/."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys


def main():
    # Bytecode caches are not release artifacts or evidence. Keep the bundle
    # immutable across first and subsequent starts, including worker processes.
    sys.dont_write_bytecode = True
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--project", type=Path, default=Path.home() / "Documents/apk-audit-unified-v1")
    args, remaining = parser.parse_known_args()
    project, bundle = args.project.expanduser().resolve(), Path(__file__).resolve().parent
    if not (project / "src/apk_audit/core.py").is_file():
        print("既存プロジェクトが見つかりません。--project で場所を指定してください。", file=sys.stderr)
        return 4
    manifest = json.loads((bundle / "BUNDLE-MANIFEST.json").read_text())
    for name, digest in manifest["files"].items():
        path = (bundle / name).resolve()
        if not path.is_relative_to(bundle) or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            print("配布ファイルが見つからないか変更されています: " + name, file=sys.stderr)
            return 4
    sys.path.insert(0, str(project / "src"))
    import apk_audit
    apk_audit.__path__.insert(0, str(bundle / "payload"))
    sys.path.insert(0, str(bundle))
    from run_research_diagnosis import main as run
    return run(remaining)


if __name__ == "__main__":
    raise SystemExit(main())
