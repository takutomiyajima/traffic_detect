# AntennaPod 3.12.3 起動・60秒観測の予備実験

Macの既存apk-audit-unified-v1（Macワーカー修正適用済み）を使います。
本ツールはプログラム本体を書き換えず、新しいhandoff・runsだけを作成します。
APKや利用者の通信原本はこの配布ZIPに含めていません。

## 1. 準備

このZIPをDocumentsに展開してください。フォルダ名はantennapod-pilot-v1です。
API35のEmulator（emulator-5554）を起動し、PCAPdroid 2.0.2は停止状態にします。
今回、手動の8765サーバーは不要です。前後対照は既存ランナーの内部サーバーを使います。

## 2. 実行

保存したAPKがDownloadsにある場合は次を実行します。別の場所なら--apkのパスを変更してください。

```bash
cd "$HOME/Documents/apk-audit-unified-v1"
source .venv/bin/activate
python "$HOME/Documents/antennapod-pilot-v1/run_pilot.py" --apk "$HOME/Downloads/de.danoeh.antennapod_3120395.apk"
```

初期状態でAntennaPodを起動して60秒待機します。今回は追加のアプリ操作をしないでください。
PCAPdroid制御・VPNの許可画面が出た場合は内容を確認して許可してください。
アプリ側の初回案内や権限確認が進行を止めた場合、その結果を保存して次の操作を決めます。
この予備実験はRSS取得や全機能の評価ではありません。

## 3. 結果を返す

条件保存、既存analyzeの実行、公開アプリ用の合否確認、取得後の画面補足、ZIP作成までを行います。
runs/antennapod-launch-001.zipをチャットへ添付してください。
レポートはruns/antennapod-launch-001/summary.htmlです。

target_flow_countが0でも、予備取得の確認が通る場合があります。無通信と結論しません。
passed_exploratory_captureは起動・取得経路の確認であり、RSS成功や安全性を意味しません。
取得品質partialはそのまま保持します。

HTTP制御アプリ専用のcheck_automatic_trial.pyは使いません。
途中でCtrl+Cした場合は、取得停止を待ち、PCAPdroidの稼働状態も確認してください。

## 4. 再実行が必要な場合

失敗記録も残し、同じ名前を再利用しません。次のように--out-nameを追加します。

```bash
python "$HOME/Documents/antennapod-pilot-v1/run_pilot.py" --apk "$HOME/Downloads/de.danoeh.antennapod_3120395.apk" --out-name antennapod-launch-002
```

正式評価の前の予備観測です。APK hashと今回の条件は取得前に保存しますが、第三者事前登録や独立した正解ラベルではありません。
既存アプリのデータは消去しません。結果ZIPにはAPK・PCAP・端末情報・画面等を含み得るため、研究者用として共有してください。
