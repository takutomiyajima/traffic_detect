#!/usr/bin/env python3
"""Compile and signature-check four new reference APKs, without Android execution."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from apk_audit.core import sha256


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    if out.exists():
        raise ValueError('Preserve existing fixtures; use a new output folder')
    sdk = ROOT / '.cache/android-toolchain'
    jar, bt, ecj = sdk/'platform/android-35/android.jar', sdk/'build-tools/android-15', sdk/'ecj-3.39.0.jar'
    key = sdk/'research-debug.keystore'
    if not all(p.is_file() for p in (jar, bt/'aapt2', bt/'d8', ecj, key)):
        raise ValueError('Cached, established Android research toolchain is required')
    source = ROOT/'fixtures/comparison'
    template = (source/'MainActivity.java.in').read_text()
    cases = json.loads((source/'cases.json').read_text())
    out.mkdir(parents=True)
    shutil.copy2(source/'cases.json', out/'cases.json')
    endpoints = {
        'concat': 'private URL endpoint(String input) throws Exception { return new URL("http://".concat("10.0.").concat("2.2:18761/fixed.xml")); }',
        'input': 'private URL endpoint(String input) throws Exception { return new URL(input); }',
        'fixed': 'private String savedEndpoint() { return "http://".concat("10.0.").concat("2.2:18761/fixed.xml"); }\n'
                 'private URL endpoint(String input) throws Exception { return new URL(savedEndpoint()); }',
        'delayed': 'private URL endpoint(String input) throws Exception { return new URL(input); }',
    }
    def run(args):
        p = subprocess.run(list(map(str,args)), capture_output=True, text=True, timeout=120)
        if p.returncode:
            raise RuntimeError(p.stdout+'\n'+p.stderr)
        return p.stdout
    inventory = []
    for spec in cases['cases']:
        case = spec['case_id'];work = out/case
        for folder in ('src','classes','dex'):(work/folder).mkdir(parents=True)
        java = template.replace('@PACKAGE@',spec['package']).replace('@CASE@',case)
        java = java.replace('@ENDPOINT_METHOD@',endpoints[case]).replace('@DELAY@','Thread.sleep(75000);' if case=='delayed' else '')
        (work/'src/MainActivity.java').write_text(java)
        manifest = work/'AndroidManifest.xml'
        manifest.write_text('<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="'+spec['package']+'" android:versionCode="1" android:versionName="1.0">'
            '<uses-sdk android:minSdkVersion="24" android:targetSdkVersion="35"/><uses-permission android:name="android.permission.INTERNET"/>'
            '<application android:theme="@android:style/Theme.Material.Light.NoActionBar" android:label="Comparison '+case+'" android:usesCleartextTraffic="true">'
            '<activity android:name=".MainActivity" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/>'
            '<category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>')
        run([bt/'aapt2','link','-I',jar,'--manifest',manifest,'-o',work/'resources.apk'])
        run(['java','-jar',ecj,'-8','-proc:none','-classpath',jar,'-d',work/'classes',work/'src/MainActivity.java'])
        run([bt/'d8','--min-api','24','--lib',jar,'--output',work/'dex',*sorted((work/'classes').rglob('*.class'))])
        shutil.copy2(work/'resources.apk',work/'unsigned.apk')
        with zipfile.ZipFile(work/'unsigned.apk','a') as z:z.write(work/'dex/classes.dex','classes.dex')
        run([bt/'zipalign','-f','4',work/'unsigned.apk',work/'aligned.apk'])
        apk = out/(case+'.apk')
        run([bt/'apksigner','sign','--ks',key,'--ks-pass','pass:android','--key-pass','pass:android','--out',apk,work/'aligned.apk'])
        verified = run([bt/'apksigner','verify','--verbose',apk])
        inventory.append({'case_id':case,'package':spec['package'],'apk':apk.name,'apk_sha256':sha256(apk),
            'source_sha256':sha256(work/'src/MainActivity.java'),'manifest_sha256':sha256(manifest),
            'signature_checked':True,'device_executed':False})
        (work/'signature-verification.txt').write_text(verified)
        print(case,'compiled and signature-checked',flush=True)
    (out/'inventory.json').write_text(json.dumps({'profile':cases['profile'],'cases':inventory,
        'template_sha256':sha256(source/'MainActivity.java.in'),'case_spec_sha256':sha256(source/'cases.json'),
        'builder_sha256':sha256(__file__),'new_Android_trials':0,'same_author_reference_materials':True},indent=2)+'\n')


if __name__=='__main__':main()
