#!/usr/bin/env python3
"""Six-page Japanese purpose, implementation, evaluation and Mac-operation note."""
from pathlib import Path
import os
import subprocess
import build_beginner_guide as base

ROOT=Path(__file__).resolve().parents[1]


def main():
    source='''# 開発意図に立ち返った研究方針と次の操作

## 01｜目的は「自分の意図との照合」

**自分が作成したアプリに、意図していない通信先・権限・SDK候補がないかを、根拠付きで確認できるようにします。**

主入力は開発者が解析前に定めた意図JSON、APK、操作シナリオです。主出力は意図との不一致候補、証拠の範囲の整合、要確認、判定不能です。静的・動的の差分説明は、その判断の根拠を読む仕組みに戻します。

:::diagram intent_focus

| 確認すること | 使う証拠 |
| --- | --- |
| 宣言した宛先・方式か | 対象UID、ホスト・IP、ポート、観測プロトコル |
| 操作条件と合うか | 起動・URI入力・Home等の記録と時刻幅 |
| 想定外の権限・SDK候補か | Manifest宣言、登録ルールへの特徴一致 |
| なぜその判断なのか | 静的・動的の対応、原本参照、証拠ID |

プライバシーへの活用は、意図外の候補に気づく段階です。同じ許可先へ何を送ったか、HTTPS本文、権限の実使用、SDKによる送信、通信の必要性は別に確かめます。

:::key 元の動機と研究の関係
AI支援で作ったアプリも、手作業で作ったアプリも、同じ事前意図で自己確認します。「AIアプリは危険」と仮定する研究にはしません。
:::

:::source 意図照合版の設計。旧29試行と差分説明の実装は、根拠と観測系の成立確認として保持。

<!-- page -->
## 02｜意図をどう書き、どう判断するか

JSON 1.1の例を3つ用意しました。端末内だけのメモ用、固定API用、記録された入力先を許すフィード用を用意しました。自分のアプリには別コピーを作り、目的に合わせて編集します。

| カテゴリ | 宣言する内容 |
| --- | --- |
| 通信 | 禁止、固定許可先、未指定、固定先と記録入力先の許可 |
| 権限・SDK | 許可集合、禁止、未指定 |
| 平文・Home後 | 許可、禁止、未指定 |

**未指定は「まだ決めていない」です。禁止とは別に扱います。** 意図JSONは照合条件であり、通信を遮断する設定ではありません。 明示した許可集合にない項目は候補として指摘し、対象帰属や必要情報が不足すれば判断を保留します。

| 出力 | 読み方 |
| --- | --- |
| 不一致候補 | 宣言と比較できる証拠に、条件外の接続・宣言がある |
| 証拠の範囲で整合 | 今回比較できた条件は満たす。内容や安全性の保証ではない |
| 要確認 | 意図が未指定、または実行未確認の静的候補等 |
| 判定不能 | UID、取得、ホスト、方式、操作・時計等の根拠が不足 |

権限宣言の不一致は、その権限を使ったという判定にはしません。SDKも4種の登録ルールの候補検出であり、存在・初期化・送信をまとめて確定しません。

:::source examples/intent-recorded-input-v1.1.json、intent-offline-v1.1.json。自然言語の目的は表示用で、JSON条件を勝手に推定しない。

<!-- page -->
## 03｜利用者入力先は、証拠がある場合に許可

RSS URLのように実行時に決まる宛先は、APKの文字列一覧に出ない場合があります。それを意図外と決めず、開発者が入力先の許可を先に宣言できるようにしました。

許可の例外は、次の根拠を確認して適用します。

1. 今回の対象UIDに帰属する対応範囲の通信である。
2. 保存シナリオと成功したopen_uri操作のURL・Activityが一致する。
3. シナリオと操作記録が証拠索引のhashと一致する。
4. 観測先が登録先のホスト・ポートと一致し、必要な方式を確認できる。
5. 時計幅を含む通信区間が、その操作区間に収まる。

動的のみの宛先であることだけでは許可しません。許可先へリダイレクトされた別の宛先、任意画面での手入力、TLSしか分からないHTTPSの意味は、自動で確認済みへ変えません。固定許可先を別に宣言することはできます。

:::key 入力に追随しても、禁止を上書きしない
通信禁止の意図なら、入力に追随する要求も不一致候補です。URI切替は対応を説明する証拠であり、開発者の許可の代わりにはしません。
:::

意図の読み込みを静的解析前に記録し、保存済み通信への事後適用は別の時点として表示します。hashと時刻は追跡用のローカル記録で、第三者による事前登録証明ではありません。

:::source intent_extensions.py、contracts.py、compare.py、pipeline.py。1.0の旧意図との互換性を維持した追加形式。

<!-- page -->
## 04｜実施済みと、次に評価すること

新しい意図照合をレポートの先頭に表示するようにしました。配布入口からの静的解析と、自動検査を行っています。

| 今回確認したこと | 位置付け |
| --- | --- |
| 位置権限だけを宣言した参照APK | 許可外の権限宣言を提示。取得・送信の判定ではない |
| 既存URI4試行へ入力許可を事後適用 | 対象要求4件が整合。事前固定の精度評価に数えない |
| 欠落・改変・UID違い・時刻境界・方式不明 | ソフトウェア検査で、安易な許可や無通信化を防ぐ |

主評価用には、同じ意図で次の3条件を各3回実行する準備をしました。

| 条件 | 確かめること |
| --- | --- |
| 入力先への要求 | 意図どおりの要求を誤指摘しないか |
| 宣言外の固定先への要求 | 仕込んだ意図外宛先を指摘できるか |
| 観測時間外の要求予定 | 未観測を無通信へ変換せず保留できるか |

この9試行の新しいAndroid実測は未実施です。素材と期待値は同じ開発者側のソース仕様によるもので、独立した一般精度標本ではありません。結果は条件ごとのn件中k件、誤指摘、保留、根拠参照として報告します。

:::source 旧29試行を保持。参照素材のビルド・署名検査と静的確認を実施。新しい端末試行をクラウドで加えていない。

<!-- page -->
## 05｜次に必要なMacでの操作

`apk-audit-intent-v1.zip` をDocumentsへ展開し、Android Studioで既存の `Pixel_8_Edited_API_35` を起動します。端末番号は `emulator-5554` を使います。

```
"$HOME/Documents/apk-audit-unified-v1/.venv/bin/python" \\
  "$HOME/Documents/apk-audit-intent-v1/run_intent.py" \\
  --suite \\
  --out "$HOME/Documents/apk-audit-unified-v1/runs/intent-seeds-001"
```

目安10〜20分です。研究用参照APK3本をインストールし、各条件の操作・通信取得・意図照合・ZIP保存を行います。アプリは追加操作せず、PCAPdroid制御・VPNの同意画面だけ確認してください。最後の追加操作の質問には実際の状況を答えます。

終了時に表示される `intent-seeds-001.return.zip` をこのチャットへ返します。同名の出力がある場合は削除せず、新しい名前にします。失敗した場合は表示とZIPを保持し、こちらで確認します。

既存プロジェクトのソースとAntennaPodのデータは保持します。停止するのは今回の参照パッケージです。参照サーバーは18761・18762・18763番を自動使用します。他のプログラムがそのポートを使用中なら、試行を開始せず通知します。

:::key 手作業とAIの分担
Macでの起動・同意確認とZIP返却が手作業です。意図・条件・素材・記録の保存、照合、集計、原本点検、論文への反映はこちらで進めます。人手の評価CSVは求めません。
:::

:::source 配布READMEとFROZEN-PROTOCOL.json。ZIPには取得原本が入るため、返却用をGitHubへ公開しない。

<!-- page -->
## 06｜研究の着地点と、その後の拡張

最終的には、**開発者が事前に宣言した通信条件に対して、意図外の候補・整合・確認不足を根拠付きで提示できた範囲**を結論にします。元の目的である自己確認と、システムの入力・出力を合わせます。

| 順序 | 作業 |
| --- | --- |
| 今回 | 意図JSON拡張、入力先許可、主結果表示、参照素材・取得手順を準備 |
| 次 | 9試行の原本を受領し、判定・帰属・操作・サーバー記録を点検 |
| その後 | 静的のみ・動的のみ・併用で確認できる項目の差を同じ記録で比較 |
| 拡張 | 実SDK、Home後・遅延条件、AI生成アプリの事例を必要な主張に合わせて追加 |

AI生成アプリへの適用では、生成前の意図、プロンプト、モデル・日付、修正回数を記録します。何も指摘されない結果も残し、AI一般の危険性や安全性へ拡大しません。3〜5本の新アプリや実SDKを、最初の意図照合成立確認の必須条件にはしません。

構造化された意図、静的・動的解析、不明の保持、入力変更による観測には先行例があります。研究の位置付けは開発者向け自己確認支援の設計と、ソースで条件を定めた評価です。この設計だけで新規性や一般精度が確立したとはしません。

:::key 論文の扱い
意図照合を主題に草稿を再構成しました。旧29試行は補助結果、新しい仕込み実験は主評価前として区分しています。研究目的と題名・RQは今回の指示に合わせ、実測後に主結果と結論を更新します。
:::

:::source 目的・方法・評価範囲の改訂。SDK候補や権限宣言を漏えいの証明にせず、AI利用も実装・解析・執筆の範囲で開示。
'''
    folder=ROOT/'docs/research/intent-first-2026-11-06';folder.mkdir(exist_ok=True,parents=True)
    (folder/'research-direction.md').write_text(source)
    base.DIAGRAMS['intent_focus']=r'''
\begin{center}\begin{tikzpicture}[box/.style={rounded corners=2mm,draw=none,fill=mint,text width=43mm,minimum height=24mm,align=center,font=\small},a/.style={-{Stealth[length=2mm]},thick,draw=teal}]
\node[box](i){事前の開発意図\\許可・禁止・未指定};
\node[box,right=7mm of i,fill=bluewash](e){静的候補・実測\\条件と証拠を保存};
\node[box,right=7mm of e,fill=sand](r){意図と照合\\根拠と不足を表示};
\draw[a](i)--(e);\draw[a](e)--(r);
\end{tikzpicture}\end{center}'''
    code_start=source.index('```\n')
    code_end=source.index('```',code_start+4)+3
    command=source[code_start+4:code_end-3].strip()
    base.DIAGRAMS['intent_command']='\\begin{Verbatim}[fontsize=\\footnotesize,frame=single]\n'+command+'\n\\end{Verbatim}'
    tex=base.render(source[:code_start]+':::diagram intent_command'+source[code_end:],expected_pages=6)
    tex=tex.replace('\\usepackage{fontspec}', '\\usepackage{fancyvrb}\n\\usepackage{fontspec}')
    for a,b in {'はじめて読む、この研究の全体像':'開発意図に立ち返った研究方針と次の操作',
        '研究の目的・仕組み・実験・結果・結論を初心者向けに説明する入門ガイド':'構造化意図と静的・動的解析による自己確認支援',
        'APKと通信解析を理解する入門ガイド':'開発意図の照合・実装と次の実験',
        '2026年11月5日版':'2026年11月6日版','RESEARCH GUIDE /':'INTENT AUDIT /',
        '研究の範囲：指定操作下の解析支援と事例評価':'意図外の候補を根拠付きで確認する・新主評価は未実施'}.items():tex=tex.replace(a,b)
    path=ROOT/'docs/intent-first-direction-2026-11-06.tex';path.write_text(tex)
    env={**os.environ,'TEXMFVAR':str(ROOT/'.cache/texmf-var'),'TEXMFCONFIG':str(ROOT/'.cache/texmf-config'),'XDG_CACHE_HOME':str(ROOT/'.cache')}
    for _ in range(3):subprocess.run(['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error',path.name],cwd=path.parent,env=env,check=True)


if __name__=='__main__':main()
