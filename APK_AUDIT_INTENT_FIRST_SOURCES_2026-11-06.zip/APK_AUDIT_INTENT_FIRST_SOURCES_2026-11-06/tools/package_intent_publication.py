#!/usr/bin/env python3
"""Package policy-first drafts, source and aggregate examples without user raw data."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[1]


def main():
    stage=ROOT/'dist/APK_AUDIT_INTENT_FIRST_SOURCES_2026-11-06'
    if stage.exists():raise ValueError('Preserve existing publication; use another name')
    stage.mkdir(parents=True);files=set()
    def add(path):
        path=path.resolve();path.relative_to(ROOT)
        if path in files:return
        if not path.is_file():raise FileNotFoundError(path)
        files.add(path)
        if path.suffix=='.tex':
            for kind,name in re.findall(r'\\(input|include|includegraphics)(?:\[[^\]]*\])?\{([^}]+)\}',path.read_text()):
                q=ROOT/'docs'/name
                if not q.suffix and kind!='includegraphics':q=q.with_suffix('.tex')
                add(q)
    for n in ['docs/thesis.tex','docs/thesis.pdf','docs/intent-first-direction-2026-11-06.tex','docs/intent-first-direction-2026-11-06.pdf',
              'tools/build_thesis.sh','tools/build_beginner_guide.py','tools/build_intent_direction.py','tools/build_intent_bundle.py',
              'tools/build_permission_seed.py','tools/build_comparison_fixtures.py','tools/run_intent_audit.py','tools/package_intent_publication.py',
              'fixtures/comparison/MainActivity.java.in','fixtures/comparison/cases.json',
              'tests/test_intent_extensions.py','tests/test_intent_seeds.py','tests/test_research_switch.py',
              'dist/apk-audit-intent-v1.zip']:
        add(ROOT/n)
    for d in ['docs/research/intent-first-2026-11-06','examples']:
        for q in (ROOT/d).iterdir():
            if (d.startswith('docs/') and q.suffix in ('.json','.csv','.md')) or (q.name.startswith('intent-') and q.name.endswith('-v1.1.json')):add(q)
    for q in (ROOT/'src/apk_audit').glob('intent_*.py'):add(q)
    for n in ['compare.py','contracts.py','pipeline.py','differential.py']:add(ROOT/'src/apk_audit'/n)
    for q in files:
        dest=stage/q.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,dest)
    (stage/'README.md').write_text('''# 開発意図を主入力にした研究・実装草稿（2026-11-06）

docs/intent-first-direction-2026-11-06.pdf: 目的・方法・現在の結果・次のMac操作（6ページ）。
docs/thesis.pdf: 意図照合を主題に再構成した卒論草稿（27ページ、主評価前）。
dist/apk-audit-intent-v1.zip: Documentsへ展開する追加ツール。既存プロジェクトと仮想環境を使用します。
examples/: オフライン、固定API、記録入力先許可の意図JSON例。
docs/research/intent-first-2026-11-06/: 状態記録、事後の入力先照合例、JSON Schemaと方針。

新実装のAndroid実測は未実施です。9試行の意図・素材・条件を準備しました。
333自動テストの成功と静的確認・事後処理例を、一般精度・新規性や独立した正解へ置き換えません。
意図JSONは通信の遮断設定ではありません。観測範囲の整合は送信内容や安全性を保証しません。

ツールZIPには自作参照APKと自作の取得補助APK、そのソース／hashを含みます。
ユーザーの原本APK・PCAP・通信本文ログ・提供された論文PDFを収録していません。
実験結果の返却ZIPは別の研究者用資料であり、GitHubへ公開しません。

TeXはXeLaTeXとNoto CJK等のフォントを用い、bash tools/build_thesis.shで生成できます。
配布ビルダーには既存研究リポジトリ・SDKキャッシュと素材ビルド結果が必要です。
原本検証には非公開の取得記録が必要です。この資料ZIPだけで全試行が再実行できるとはしません。
''')
    entries=[{'path':str(q.relative_to(stage)),'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()}
             for q in sorted(stage.rglob('*')) if q.is_file()]
    (stage/'MANIFEST.json').write_text(json.dumps({'kind':'developer_intent_first_prototype_and_draft','thesis_pages':27,
        'direction_pages':6,'visual_review_pages':33,'tests_passed':333,'new_Android_trials':0,'next_seed_trials_planned':9,
        'user_raw_APK_or_capture_included':False,'own_reference_APKs_in_nested_tool_bundle':True,
        'independent_accuracy_established':False,'novelty_established':False,'files':entries},ensure_ascii=False,indent=2)+'\n')
    archive=stage.with_suffix('.zip')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for q in sorted(stage.rglob('*')):
            if q.is_file():z.write(q,q.relative_to(stage.parent))
    copies={'APK_AUDIT_INTENT_FIRST_DRAFT_2026-11-06.pdf':ROOT/'docs/thesis.pdf',
            'APK_AUDIT_INTENT_FIRST_DIRECTION_2026-11-06.pdf':ROOT/'docs/intent-first-direction-2026-11-06.pdf'}
    for n,q in copies.items():shutil.copy2(q,ROOT/'dist'/n)
    for q in [archive,ROOT/'dist/apk-audit-intent-v1.zip',*[ROOT/'dist'/n for n in copies]]:
        shutil.copy2(q,Path('/workspace/downloads')/q.name)
        print(json.dumps({'name':q.name,'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()}))


if __name__=='__main__':main()
