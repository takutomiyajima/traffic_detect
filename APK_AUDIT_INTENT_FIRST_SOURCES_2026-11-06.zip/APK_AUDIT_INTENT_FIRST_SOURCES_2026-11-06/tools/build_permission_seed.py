#!/usr/bin/env python3
"""Build one benign, permission-declaration-only reference APK."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from apk_audit.core import sha256


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();out=a.out.resolve()
    if out.exists():raise ValueError('Choose a new material folder')
    sdk=ROOT/'.cache/android-toolchain';bt=sdk/'build-tools/android-15';jar=sdk/'platform/android-35/android.jar'
    out.mkdir(parents=True)
    for n in ('classes','dex'):(out/n).mkdir()
    package='org.example.apkaudit.compare.permissiononly'
    source=out/'MainActivity.java';source.write_text('package '+package+'; public class MainActivity extends android.app.Activity {'
        ' @Override public void onCreate(android.os.Bundle b){super.onCreate(b);android.widget.TextView t=new android.widget.TextView(this);'
        't.setText("Permission declaration reference. No location API or networking.");setContentView(t);}}')
    manifest=out/'AndroidManifest.xml';manifest.write_text('<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="'+package+'" android:versionCode="1" android:versionName="1.0">'
        '<uses-sdk android:minSdkVersion="24" android:targetSdkVersion="35"/><uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>'
        '<application android:label="Permission reference" android:usesCleartextTraffic="false"><activity android:name=".MainActivity" android:exported="true">'
        '<intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>')
    def run(args):
        r=subprocess.run(list(map(str,args)),capture_output=True,text=True,timeout=120)
        if r.returncode:raise RuntimeError(r.stdout+'\n'+r.stderr)
        return r.stdout
    run([bt/'aapt2','link','-I',jar,'--manifest',manifest,'-o',out/'resources.apk'])
    run(['java','-jar',sdk/'ecj-3.39.0.jar','-8','-proc:none','-classpath',jar,'-d',out/'classes',source])
    run([bt/'d8','--min-api','24','--lib',jar,'--output',out/'dex',*sorted((out/'classes').rglob('*.class'))])
    shutil.copy2(out/'resources.apk',out/'unsigned.apk')
    with zipfile.ZipFile(out/'unsigned.apk','a') as z:z.write(out/'dex/classes.dex','classes.dex')
    run([bt/'zipalign','-f','4',out/'unsigned.apk',out/'aligned.apk'])
    apk=out/'permission-only.apk';run([bt/'apksigner','sign','--ks',sdk/'research-debug.keystore','--ks-pass','pass:android','--key-pass','pass:android','--out',apk,out/'aligned.apk'])
    (out/'signature-verification.txt').write_text(run([bt/'apksigner','verify','--verbose',apk]))
    write={'case_id':'permissiononly','package':package,'apk':apk.name,'apk_sha256':sha256(apk),'source_sha256':sha256(source),
        'manifest_sha256':sha256(manifest),'oracle':'Source declares fine-location permission without calling location APIs; tool evaluates the declaration only.',
        'signature_checked':True,'device_executed':False,'new_Android_trials':0}
    (out/'inventory.json').write_text(json.dumps(write,indent=2)+'\n');print(json.dumps(write))


if __name__=='__main__':main()
