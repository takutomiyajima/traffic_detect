"""Host HTTP + synthetic PCAP assertions; these tests do not execute Android."""
from datetime import datetime,timedelta,timezone
from pathlib import Path
import struct
import socket
import urllib.request

import dpkt
import pytest

from apk_audit.core import AuditError,add_evidence,new_run,read_json,sha256,write_json,write_jsonl
from apk_audit.research_contrast import build_scenario
from apk_audit.research_switch import classify,request_observations
from apk_audit.research_comparison import ReferenceServer,run_live,assess_comparison


@pytest.fixture
def servers(monkeypatch):
    import apk_audit.research_switch as switch
    import apk_audit.research_comparison as comparison
    ss=[ReferenceServer(0) for _ in range(3)]
    ports=dict(zip(('fixed','A','B'),[s.server.server_address[1] for s in ss]))
    monkeypatch.setattr(switch,'PORTS',ports);monkeypatch.setattr(comparison,'PORTS',ports)
    for s in ss:s.start()
    yield ss,ports
    for s in ss:s.close()


def synthetic_trial(apk,out,spec,ports,case='input',uid=10213,broken=None):
    out=Path(out);run=new_run(out,apk)
    package='org.example.apkaudit.compare.'+case
    run.update(package=package,target_uid=10213,bridge_uid=10212,control_port=8765,
               static_status='completed',dynamic_status='partial',analysis_mode='live',execution_status='completed',
               analysis_scenario=spec['scenario'],run_kind='synthetic_unit_test_not_device_evidence')
    write_json(out/'run.json',run)
    write_json(out/'raw/installation-identity.json',{'package':package,'uid':10213,'apk_sha256':run['apk_sha256']})
    trace=[{'action':'get_status','result':{'running':False}},{'action':'start','result':{'result_code':-1}},
           {'action':'get_status','result':{'running':True}},
           *[{'action':'probe','request_id':r,'result':{'http_status':200}} for r in ('pre','post')],
           {'action':'stop','result':{'result_code':-1}},{'action':'get_status','result':{'running':False}}]
    write_json(out/'raw/bridge-results.json',trace)
    write_jsonl(out/'raw/automatic-controls.jsonl',[{'event':'http_request_received','run_id':r,'method':'GET'} for r in ('pre','post')])
    controls=[{'uid':10212,'port':8765,'destination_ip':'10.0.2.2','application_protocol':'http'} for _ in range(2)]
    port=ports['fixed'] if case in ('concat','fixed') else ports[spec['arm']]
    flows=[] if case=='delayed' else [{'flow_id':'target1','uid':10213,'port':port,'destination_ip':'10.0.2.2',
        'host':'10.0.2.2','application_protocol':'http','transport':'TCP','attribution':'target'}]
    write_jsonl(out/'flows.jsonl',controls+flows)
    write_json(out/'correspondence.json',{'counts':{'both':0,'dynamic_only':int(bool(flows))},
        'records':[{'status':'dynamic_only','flows':['target1']}] if flows else []})
    started=datetime.now(timezone.utc)
    write_jsonl(out/'ui_events.jsonl',[{'action':'open_uri','uri':spec['url'],'success':True,
        'started_utc':started.isoformat(),'ended_utc':(started+timedelta(seconds=30)).isoformat()}])
    write_json(out/'automatic.metadata.json',{'clock_offset_s':0})
    token=spec['url'].split('/')[-1][:-4]
    path='/fixed.xml' if case in ('concat','fixed') else '/feed/'+token+'.xml'
    if case!='delayed':
        # Read an HTTP/1.0 connection through EOF: the server's handler has
        # then finished its event log. Content-Length-only reads can race the
        # asynchronous log append and produce intermittent missing witnesses.
        with socket.create_connection(('127.0.0.1',port),timeout=2) as connection:
            connection.sendall((f'GET {path} HTTP/1.0\r\nHost: 10.0.2.2:{port}\r\nX-Apk-Audit-Token: {token}\r\n\r\n').encode())
            response=b''
            while True:
                chunk=connection.recv(4096)
                if not chunk:break
                response+=chunk
            assert response.startswith(b'HTTP/1.0 200')
    with (out/'raw/automatic.pcap').open('wb') as stream:
        writer=dpkt.pcap.Writer(stream)
        if case!='delayed':
            raw_token='f'*32 if broken=='token' else token
            extra='X-Apk-Audit-Token: '+token+'\r\n' if broken=='duplicate_header' else ''
            data=(f'GET {path} HTTP/1.1\r\nHost: 10.0.2.2:{port}\r\nX-Apk-Audit-Token: {raw_token}\r\n'+extra+'\r\n').encode()
            if broken=='truncated':data=data[:-3]
            tcp=dpkt.tcp.TCP(sport=45000,dport=port,seq=100,data=data)
            ip=dpkt.ip.IP(src=b'\x0a\xd7\xad\x01',dst=b'\x0a\x00\x02\x02',p=6,data=tcp);ip.len=len(ip)
            frame=b'\0'*12+b'\x08\x00'+bytes(ip)
            frame+=b'\0'*(-len(frame)%4)+struct.pack('!Ii20sI',0x01072021,uid,b'test',0)
            ts=started.timestamp()-(100 if broken=='old_time' else 0)
            writer.writepkt(frame,ts=ts)
            if broken=='retransmit':writer.writepkt(frame,ts=ts+.001)
    add_evidence(out,'test-pcap',out/'raw/automatic.pcap','synthetic unit-test packet')
    return {'error':None},0


def make_spec(tmp_path,ports,arm='A',n=1):
    token=f'{n:032x}';url=f'http://10.0.2.2:{ports[arm]}/feed/{token}.xml'
    package='org.example.apkaudit.compare.input'
    return {'trial_id':f'trial-{n}','arm':arm,'url':url,
            'scenario':build_scenario(package,package+'/.MainActivity',url,30)}


@pytest.mark.parametrize('case,expected',[('input','input_endpoint_association_observed'),
    ('fixed','fixed_positive_endpoint_observed_under_switch'),('delayed','inconclusive')])
def test_positive_fixed_counterexample_and_missing_requests(tmp_path,servers,case,expected):
    ss,ports=servers;apk=tmp_path/'input.bin';apk.write_bytes(b'synthetic test only');rows=[]
    for n,arm in enumerate(('A','B','B','A'),1):
        spec=make_spec(tmp_path,ports,arm,n)
        # Every trace has its own nonce and run ID, same original bytes.
        spec['scenario']['steps'][1]['activity']='org.example.apkaudit.compare.'+case+'/.MainActivity'
        synthetic_trial(apk,tmp_path/str(n),spec,ports,case=case)
        rows.append(request_observations(tmp_path/str(n),spec,[e for s in ss for e in s.snapshot()]))
    result=classify(rows)
    assert result['diagnosis']==expected
    assert not result['causal_root_proven'] and result['remaining_hypotheses']
    if case=='fixed':assert result['fixed_endpoint']['port']==ports['fixed']


@pytest.mark.parametrize('broken',[None,'token','duplicate_header','truncated','old_time','retransmit'])
def test_nonce_time_complete_headers_and_retransmission(tmp_path,servers,broken):
    ss,ports=servers;apk=tmp_path/'input.bin';apk.write_bytes(b'test')
    spec=make_spec(tmp_path,ports);synthetic_trial(apk,tmp_path/'trial',spec,ports,broken=broken)
    row=request_observations(tmp_path/'trial',spec,[e for s in ss for e in s.snapshot()])
    assert len(row['witnesses'])==(1 if broken in (None,'retransmit') else 0)


@pytest.mark.parametrize('uid',[-1,55555])
def test_unknown_or_other_uid_does_not_support_target(tmp_path,servers,uid):
    ss,ports=servers;apk=tmp_path/'input.bin';apk.write_bytes(b'test');spec=make_spec(tmp_path,ports)
    synthetic_trial(apk,tmp_path/'trial',spec,ports,uid=uid)
    row=request_observations(tmp_path/'trial',spec,[e for s in ss for e in s.snapshot()])
    assert not row['witnesses']
    assert row['unknown_UID_packets_with_token']==int(uid==-1)


def test_duplicate_server_records_and_failed_controls_are_withheld(tmp_path,servers):
    ss,ports=servers;apk=tmp_path/'input.bin';apk.write_bytes(b'test');spec=make_spec(tmp_path,ports)
    synthetic_trial(apk,tmp_path/'trial',spec,ports)
    events=[e for s in ss for e in s.snapshot()]
    row=request_observations(tmp_path/'trial',spec,events+events)
    assert not row['witnesses'] and row['unmatched_target_requests']==1
    (tmp_path/'trial/raw/bridge-results.json').unlink()
    row=request_observations(tmp_path/'trial',spec,events)
    assert not row['controls_passed'] and not row['witnesses']


@pytest.mark.parametrize('change',['order','missing','controls','mixed','unmatched'])
def test_pattern_requires_all_valid_unambiguous_conditions(change):
    rows=[{'arm':a,'input_port':p,'controls_passed':True,'scenario_confirmed':True,
           'witnesses':[{'host':'10.0.2.2','port':p}],'unmatched_target_requests':0}
          for a,p in [('A',100),('B',101),('B',101),('A',100)]]
    if change=='order':rows.reverse();rows[0]['arm']='B'
    if change=='missing':rows.pop()
    if change=='controls':rows[2]['controls_passed']=False
    if change=='mixed':rows[1]['witnesses'].append({'host':'10.0.2.2','port':102})
    if change=='unmatched':rows[1]['unmatched_target_requests']=1
    assert classify(rows)['diagnosis']=='inconclusive'


def test_whole_reference_workflow_and_policy_replay_without_android(tmp_path,monkeypatch):
    import apk_audit.research_comparison as comparison
    import apk_audit.pipeline as pipeline
    import apk_audit.android as android
    from apk_audit.research_bundle import restore
    root=Path(__file__).parents[1];fixtures=tmp_path/'fixtures';fixtures.mkdir()
    source=read_json(root/'fixtures/comparison/cases.json');write_json(fixtures/'cases.json',source)
    inventory=[]
    for c in source['cases']:
        apk=fixtures/(c['case_id']+'.apk');apk.write_bytes(('synthetic '+c['case_id']).encode())
        inventory.append({'case_id':c['case_id'],'package':c['package'],'apk':apk.name,'apk_sha256':sha256(apk)})
    write_json(fixtures/'inventory.json',{'case_spec_sha256':sha256(fixtures/'cases.json'),'cases':inventory})
    monkeypatch.setattr(comparison,'device_preflight',lambda serial:{'test':'synthetic'})
    class FakeAdb:
        def __init__(self,serial):pass
        def call(self,*args):return ''
    monkeypatch.setattr(android,'Adb',FakeAdb)
    def context(apk,out):
        records=[{'status':'constant_url_argument','endpoint':{'host':'10.0.2.2','port':comparison.PORTS['fixed']}}] if apk.stem=='concat' else []
        result={'apk_sha256':sha256(apk),'records':records,'counts':{}}
        write_json(out,result);return result
    monkeypatch.setattr(comparison,'scan_bounded',context)
    def pipeline_fake(a):
        scenario=read_json(a.scenario);step=scenario['steps'][1]
        arm='A' if str(comparison.PORTS['A']) in step['uri'].split('/')[2] else 'B'
        return synthetic_trial(a.apk,a.out,{'scenario':scenario,'arm':arm,'url':step['uri']},comparison.PORTS,case=a.apk.stem)
    monkeypatch.setattr(pipeline,'analyze',pipeline_fake)
    result,code=run_live(fixtures,tmp_path/'study',non_interactive=True)
    assert code==0 and result['recorded_trials']==20
    data=read_json(tmp_path/'study/assessment/results.json')
    assert all(not r['unsupported_specific_labels'] for r in data['scores'])
    assert [c['switch']['diagnosis'] for c in data['cases']]==[
        'fixed_positive_endpoint_observed_under_switch','input_endpoint_association_observed',
        'fixed_positive_endpoint_observed_under_switch','inconclusive']
    m3=[r for r in data['scores'] if r['method']=='M3']
    assert [r['additional_trial_allocation'] for r in m3]==[0,4,4,0]
    assert m3[-1]['supported_primary'] is None and m3[-1]['withheld']
    restored=restore(tmp_path/'study.return.zip',tmp_path/'restored')
    assert assess_comparison(restored,tmp_path/'reassess')==data
    (restored/'fixed/switch-001-A/raw/automatic.pcap').write_bytes(b'modified')
    with pytest.raises(AuditError,match='modified'):
        assess_comparison(restored,tmp_path/'must-not-exist')
