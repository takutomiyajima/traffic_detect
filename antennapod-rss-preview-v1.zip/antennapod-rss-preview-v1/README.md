# AntennaPod 3.12.3 ローカルRSSプレビュー予備実験 v1

既存のapk-audit-unified-v1とMacワーカー修正を前提とします。
APK・利用者の通信原本は同梱しません。依存の追加インストールは不要です。
Android上のRSS動作は初回確認待ちです。失敗した結果も残してください。

## 変更内容

4ファイルを更新します。capture.pyは、60秒超の空白や新規SYNでフローを分割した場合にもパケットUIDを保持する修正です。
他3ファイルは、対象アプリの明示ActivityへHTTP(S) URIを渡すopen_uri操作と解析版の記録を追加します。
対象外アプリ、URLの認証情報、制御文字等は拒否します。旧コンソールrunにはopen_uriを追加しません。
全対象ファイルの元hashとpayload hashを確認してから更新し、元ファイルは.before-rss-preparation-v1として保存します。
既存のruns・handoff・Macワーカー・依存関係・元BUNDLE-MANIFESTは変更しません。
部分適用からも同じコマンドを再実行できます。独自に変更したファイルは上書きせず停止します。

## 1. 配置とパッチ適用

ZIPをDocumentsに展開します。フォルダ名はantennapod-rss-preview-v1です。

```bash
cd "$HOME/Documents/apk-audit-unified-v1"
source .venv/bin/activate
python "$HOME/Documents/antennapod-rss-preview-v1/apply_patch.py" --project "$PWD"
```

appliedまたはalready_appliedを確認します。エラーなら実験に進まず表示内容を保存してください。

## 2. 1回だけ実行

API35・arm64のemulator-5554を起動し、PCAPdroid 2.0.2の取得を停止しておきます。
APKがDownloadsにある場合の例です。別の場所なら--apkを変更します。

```bash
python "$HOME/Documents/antennapod-rss-preview-v1/run_rss.py" --apk "$HOME/Downloads/de.danoeh.antennapod_3120395.apk"
```

手動サーバーは不要です。Macの127.0.0.1に研究用RSSを自動配信し、エミュレータから10.0.2.2でアクセスします。
通常起動5秒の後、アプリの公開Activityへ研究用RSSのURLを渡し、プレビューを60秒観測します。
各試行で新しいランダムなURLにし、条件・RSS本文・研究用ポリシー・期待する観測を取得前に保存します。
追加タップ、購読、再生はしないでください。制御・VPNの同意画面が出た場合だけ内容を確認してください。
アプリのデータ消去・アンインストール・再署名・証明書追加・プロキシ変更はしません。
プレビューでもアプリ内部のキャッシュ等は更新され得ます。

## 3. 結果

runs/antennapod-rss-preview-001.zipをチャットに添付してください。
終了時の画面に「APK Audit Research Feed ...」が表示されたかも確認してください。
結果ZIPには端末情報・画面・APK・通信原本が含まれ得るため研究者用として共有します。
途中で止まった場合も結果を消さず、中断時はPCAPdroidの取得状態を確認します。

passed_controlled_rss_fetchは、取得対照、対象UIDのHTTP GET/200ヘッダ、nonce付きURLと時刻によるサーバー候補対応の確認です。
VPN/NATでポートが変わり得るため、端末の元5-tupleとMac側peerポートを同一と仮定しません。
本文のアプリ内処理成功、完全なTCP再構成、全機能、プライバシー適合、安全性を保証しません。
取得品質partialはそのまま保持します。

今回の許可条件は研究者が設定したローカルRSS用の試験条件で、AntennaPod開発者の意図ではありません。
入力したRSSの宛先がdynamic_onlyになっても、文字列候補の抽出ミスや不正通信とは限りません。
この操作確認が通るまで正式な反復評価には進みません。

## 名前を変えて再実行

既存結果は上書きしません。必要なら--out-name antennapod-rss-preview-002を追加します。
準備保存だけなら--prepare-onlyを追加します。その名前は消費され、Androidを操作しません。
起動のみの既存結果antennapod-launch-001は保存したままにしてください。
