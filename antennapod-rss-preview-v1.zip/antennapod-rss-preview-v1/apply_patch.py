#!/usr/bin/env python3
"""Apply a hash-checked, reversible four-module update; preserve trial outputs."""
import argparse
import hashlib
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path


def digest(data):return hashlib.sha256(data).hexdigest()


def apply(project,assets):
    project,assets=Path(project).resolve(),Path(assets).resolve()
    manifest=json.loads((assets/'PATCH-MANIFEST.json').read_text())
    if not (project/'pyproject.toml').is_file():raise ValueError('Specify the existing apk-audit-unified-v1 project')
    updates=[]
    for name,record in manifest['modules'].items():
        if name not in ('capture.py','contracts.py','automatic.py','pipeline.py'):raise ValueError('Unsupported module')
        target=project/'src/apk_audit'/name;source=assets/'payload'/name
        if target.is_symlink() or not target.is_file():raise ValueError('Module missing or symlink: '+name)
        old,new=target.read_bytes(),source.read_bytes()
        if digest(new)!=record['fixed_sha256']:raise ValueError('Payload hash mismatch: '+name)
        compile(new,str(target),'exec')
        if digest(old)==record['fixed_sha256']:continue
        if digest(old)!=record['original_sha256']:raise ValueError('Local module differs; no modules changed: '+name)
        backup=target.with_name(name+'.before-rss-preparation-v1')
        if backup.exists() and backup.read_bytes()!=old:raise ValueError('Different backup exists: '+name)
        updates.append((target,backup,old,new))
    if not updates:return {'status':'already_applied','patch_id':manifest['patch_id']}
    # Validate every payload and old module before writing anything.
    for target,backup,old,new in updates:
        if not backup.exists():
            with backup.open('xb') as f:f.write(old)
    for target,backup,old,new in updates:
        fd,path=tempfile.mkstemp(dir=target.parent,prefix='.rss-preparation-')
        try:
            with os.fdopen(fd,'wb') as f:f.write(new);f.flush();os.fsync(f.fileno())
            os.chmod(path,target.stat().st_mode&0o777);os.replace(path,target)
        finally:Path(path).unlink(missing_ok=True)
    result={'status':'applied','patch_id':manifest['patch_id'],'applied_utc':datetime.now(timezone.utc).isoformat(),
            'modules':manifest['modules'],'old_trial_files_modified':False,'dependencies_changed':False,
            'modules_changed':[p.name for p,_,_,_ in updates]}
    (project/'RSS-PREPARATION-V1.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);a=p.parse_args()
    print(json.dumps(apply(a.project,Path(__file__).resolve().parent),ensure_ascii=False,indent=2))


if __name__=='__main__':main()
