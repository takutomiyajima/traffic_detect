"""Render the maintained progress Markdown to Japanese TeX/PDF (not a general converter)."""
import argparse
import os
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / 'docs'
SOURCE = DOCS / 'research/progress-and-next-steps-2026-10-29.md'


def escape(value):
    chars = {'\\': r'\textbackslash{}', '&': r'\&', '%': r'\%', '$': r'\$', '#': r'\#',
             '_': r'\_', '{': r'\{', '}': r'\}', '~': r'\textasciitilde{}', '^': r'\textasciicircum{}'}
    return ''.join(chars.get(c, c) for c in value)


def inline(value):
    parts = re.split(r'(`[^`]+`)', value)
    return ''.join(r'{\small\nolinkurl{' + p[1:-1] + '}}' if p.startswith('`') else escape(p) for p in parts)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=SOURCE)
    parser.add_argument('--output-stem', default='progress')
    parser.add_argument('--title', default='研究進捗と今後の実施計画')
    parser.add_argument('--date', default='2026年10月29日現在')
    args = parser.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9_-]+', args.output_stem):
        parser.error('output-stem must contain only ASCII letters, digits, underscores or hyphens')
    lines = args.source.read_text().splitlines()
    body = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith('# '):
            i += 1
            continue
        if line.startswith('## '):
            body.append(r'\Needspace{8\baselineskip}\section*{' + inline(line[3:]) + '}')
        elif line.startswith('### '):
            body.append(r'\subsection*{' + inline(line[4:]) + '}')
        elif line.startswith('|'):
            table = []
            while i < len(lines) and lines[i].startswith('|'):
                cells = [c.strip() for c in lines[i].strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?', c) for c in cells):
                    table.append(cells)
                i += 1
            n = len(table[0])
            assert all(len(row) == n for row in table)
            width = (158 - 4.22 * n) / n
            body.append(r'{\small\begin{longtable}{' + ''.join(f'p{{{width:.2f}mm}}' for _ in range(n)) + r'}\toprule')
            for row_i, row in enumerate(table):
                body.append(' & '.join(inline(c) for c in row) + r' \\')
                if row_i == 0:
                    body.append(r'\midrule')
            body.append(r'\bottomrule\end{longtable}}')
            continue
        else:
            body.append(inline(line))
        body.append('')
        i += 1
    preamble = r'''\documentclass[a4paper,11pt]{article}
\usepackage[margin=25mm]{geometry}
\usepackage{fontspec}
\setmainfont{Noto Serif CJK JP}
\setsansfont{Noto Sans CJK JP}
\setmonofont{DejaVu Sans Mono}[Scale=0.85]
\XeTeXlinebreaklocale "ja"
\XeTeXlinebreakskip=0pt plus 1pt
\usepackage{booktabs,longtable,array,needspace}
\usepackage[unicode,hidelinks]{hyperref}
\setlength{\parindent}{0pt}
\setlength{\parskip}{0.4em}
\setlength{\emergencystretch}{3em}
\title{REPORTTITLE}
\author{Androidアプリの通信ポリシー照合支援}
\date{REPORTDATE}
\begin{document}
\maketitle
'''
    preamble = preamble.replace('REPORTTITLE', escape(args.title)).replace('REPORTDATE', escape(args.date))
    tex_name = args.output_stem + '.tex'
    (DOCS / tex_name).write_text(preamble + '\n'.join(body) + '\n\\end{document}\n')
    env = os.environ.copy()
    for key, rel in [('TEXMFVAR', '.cache/texmf-var'), ('TEXMFCONFIG', '.cache/texmf-config'), ('XDG_CACHE_HOME', '.cache')]:
        env[key] = str(ROOT / rel)
    for _ in range(2):
        subprocess.run(['xelatex', '-no-shell-escape', '-interaction=nonstopmode', '-halt-on-error', tex_name], cwd=DOCS, env=env, check=True)


if __name__ == '__main__':
    main()
