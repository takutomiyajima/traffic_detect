# 実験結果・卒業論文草稿（2026年10月31日・9件の原本照合後）

- docs/experiment-results.pdf：各条件3試行の結果と考察（4ページ）
- docs/thesis.pdf：結果反映済み卒業論文草稿（23ページ）
- docs/generated/experiment-results-2026-10-31.csv：今回の9試行
- docs/generated/current-experiments.json / .csv：重複除外した履歴全13試行
- docs/generated/current-experiments-2026-10-29.json：以前の8試行台帳の保存版

今回の9件には、同一hashで再提出された保持UDP3件と短時間UDP001を含みます。これらを新規試行として二重計数していません。通信なしの追加反復は原本未受領のため、実験者報告と区別しています。原本ZIP・CSV・画面・端末package全文は本共有物に含めていません。

PDF閲覧にTeXは不要です。再ビルドにはXeLaTeX、Noto Serif CJK JP、Noto Sans CJK JP、DejaVu Sans Monoと必要なTeXパッケージ（geometry/fontspec/amsmath/amssymb/booktabs/longtable/array/needspace/hyperref/fancyvrb/graphicx）が必要です。

このフォルダから：

```bash
bash tools/build_thesis.sh
python tools/build_progress_report.py --source docs/research/experiment-results-2026-10-31.md --output-stem experiment-results --title '実験結果のまとめと考察' --date '2026年10月31日・各条件3試行の原本照合版'
```

原本ZIPを保有する実験者は標準ライブラリのみで再照合できます。例：

```bash
python tools/review_guided_archives.py --out local-review.json --primary http-test-001 --primary http-test-002 --primary http-test-003 --primary udp-short-001 --primary udp-short-002 --primary udp-short-003 --primary udp-hold-001 --primary udp-hold-002 --primary udp-hold-003 handoff/*.zip
```

handoff/*.zipは対応する半自動ランナーの原本ZIPを想定します。同じ試行IDで内容が異なるZIPは自動合算せずエラーになります。今回の9件だけを指定した場合、履歴の別4試行は含まれません。再生成した台帳は指定した入力集合の範囲になります。

本稿は予備実験を反映した草稿です。査読文献比較、新規性の確定、事前条件による比較評価、著者情報等は引き続き必要です。
