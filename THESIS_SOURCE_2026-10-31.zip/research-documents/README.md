# 研究のまとめ・今後の展望と卒論草稿（2026年10月31日）

- docs/summary-outlook.pdf：研究のまとめ・今後の展望（4ページ）
- docs/thesis.pdf：論文草稿改訂版（23ページ）
- docs/progress.pdf：10月29日時点の以前の進捗資料（履歴として同梱）

追加反復は実験者の実施報告として記載し、原本照合済み8試行の件数は変更していません。原本ログや画面は含みません。

PDFの閲覧にTeX環境は不要です。再コンパイルにはXeLaTeX、Noto Serif CJK JP、Noto Sans CJK JP、DejaVu Sans Mono、およびTeX Liveのfontspec/geometry/amsmath/amssymb/booktabs/longtable/array/needspace/hyperref/fancyvrb/graphicxが必要です。

このフォルダ内で実行：

```bash
bash tools/build_thesis.sh
python tools/build_progress_report.py --source docs/research/summary-and-outlook-2026-10-31.md --output-stem summary-outlook --title '研究のまとめと今後の展望' --date '2026年10月31日更新'
```

またはdocsへ移動し、xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error thesis.texを3回、summary-outlook.texを2回コンパイルしてください。

著者情報、査読論文に基づく関連研究、事前条件による本評価は引き続き必要です。生の追加記録を確認していない件数や未実施実験を結果に補っていません。
