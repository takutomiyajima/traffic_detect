# HTTP・UDP追加試行の照合

2026-10-29 JST。HTTP自動取得とUDP短時間・保持の追加3 ZIPを確認。各28参照（計84）のhash、APK・取得前ポリシー、UID、前後時計サンプル、サーバー本文hash/試行IDを照合した。

|試行|アプリ結果|サーバー受信|CSV識別|本文サイズ|
|---|---|---:|---|---:|
|http-auto-001|http_response=200|POST 1件|10207 / org.example.apkaudit.http|19 bytes|
|udp-short-001|udp_sent|UDP 1件|UID -1 / unknown|19 bytes|
|udp-long-001|udp_sent|UDP 1件|10210 / org.example.apkaudit.udp|18 bytes|

各ケースの待機は30秒以上。短時間UDPのcollected_needs_reviewは、送信失敗ではなく期待された対象UID行が得られないことを保存した判定。Unknownを通信なしや対象違反確定へ変えない。UDP対応候補の行自体は記録され、サーバー受信に整合する。

既受領のudp-auto-001と合わせ、短時間版のUID不明は2試行で観測した。保持版はudp-hold-001/002/003と今回udp-long-001の計4試行でUID取得を確認した。同じAPK・AVDの反復であり、これを母集団の帰属精度や因果の確定として報告しない。HTTPの旧http-004は別の予備試行として残す。

短時間版と保持版は同じpackage・UID・署名だが、版と実行順が異なる。今回のID udp-short-001とudp-long-001は文字数が違い、制御本文も19/18 bytes、CSV送信計数も47/46 bytesだった。この差を隠さず記録する。厳密な次段階では同一APKで保持パラメータのみ切替え、本文長・観測窓起点・実行順も統制する。別条件の結果を削除・成功へ置換しない。

保持条件の単純反復は既に4回あるため一区切り。残りのHTTP・短時間UDPが実施済みなら原本をまとめて受領し、追加重複実行は要求しない。通信なしは利用者の希望どおり他ケース後に回す。HTTPS・接続失敗の自動シナリオは現時点で未配布であり、既存コマンドが対応していると偽らない。

データはdocs/generated/http-udp-batch-review.jsonおよびruns/received-<trial-id>/batch-review.jsonに保存した。取得品質は条件付きの時計モデル等を残すpartialであり、個別の送受信成功と混同しない。
