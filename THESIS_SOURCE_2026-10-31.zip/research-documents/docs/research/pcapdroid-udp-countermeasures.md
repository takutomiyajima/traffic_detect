# PCAPdroidの公式資料に基づくUDP対処

確認日2026-10-29 JST。公式Webサイト自体はproxy 403のため、公式リポジトリgh-pagesのFAQ・quick_start・advanced_featuresを読んだ。ガイドcommitはfe15479b1372214edd354a7095092c4dbee88077、利用版2.0.2の実装commitは66f7b3514540c20add8655a74dfee93d00a9563b。現行ガイドと版固定コードは区別する。ソースhashはdocs/generated/pcapdroid-udp-source-review.json。

## 確認できた仕様

1. 公式FAQは、Unknownをアプリに対応付けられなかった通信の集合と説明し、短命な通信でAndroid APIがUIDを対応付けられない制約を挙げる。今回の原因を一意に証明したものではない。
2. 2.0.2のUID resolverはAPI 29以降でCaptureService.getUidQ経由のConnectivityManager.getConnectionOwnerUidを使用する。失敗時はUID_UNKNOWNへ落とす。VPNの新規接続処理時にUID解決するコードを確認した。
3. 開始前StatusのApp FilterはVpnService.Builder.addAllowedApplicationを使う取得対象の選択。開始後の検索・Edit Filter・Apps選択は表示対象の絞り込み。両者を混同しない。取得対象限定は補助的な実験条件として記録できるが、CSVのUID=-1を実測UIDへ書き換えない。
4. ConnectionOverviewのDurationは(last_seen-first_seen)/1000。ソケット保持時間ではない。保持版でも単発パケットなら<1sになり得る。
5. root captureの公式説明にも短命通信のUnknownとフィルター漏れが記される。root化による解消は保証できない。
6. CSVは接続メタデータで本文そのものではない。必要な本文照合にはPCAPを別途保存できるが、Unknown UIDをPCAP/PCAPngの選択だけで復元はできない。VPN方式のL3/L4ヘッダ・量には合成・変換があり、IPやbytesを元ネットワークの完全な複製として扱わない。
7. 公式app_api.mdにはCaptureCtrlのstart/stop/get_statusとPCAPファイル保存がある。制御許可、初回VPN許可が関わる。API利用は自動化の追加候補であり、UID不明そのものの解決策ではない。

## 推奨手順

現在のランナーでは全アプリ取得、VPN方式、TLS復号なし、SOCKS5なし、他VPNなしで新規セッションを開始する。開始前にアプリを操作せず、開始後に新たに起動・単発送信する。表示側でUnknownを隠したり対象UIDのみで絞った状態を診断の原本にしない。app限定取得の別条件ではChrome前後対照が取得されなくなるため、既存ランナーの全アプリ手順と混在させない。

既に配布した保持版は、同じUDP package・署名・宛先・本文・未接続方式で送信後のソケット保持を2秒追加した別条件。--case udp_hold、trial-id udp-hold-001で1回実行する。APKは版1.2・versionCode3。アプリlogcatのsocket_hold_started_ms=2000 / socket_hold_finishedを確認する。画面Durationを保持実行の判定に使わない。

実行後に次も別ファイルとして保存し、生成ZIPと一緒に渡す。

```bash
adb -s emulator-5554 logcat -d -v epoch CaptureService:D pcapdroid-native:W ApkAuditControl:I AndroidRuntime:E "*:S" > pcapdroid-uid-log.txt
```

タグは2.0.2ソースで確認した。native側のUID not foundとそのtuple、利用可能ならJava側Get uid情報を調べる。ログが空でも成功と解釈せず、release側のログ抑制やバッファの条件を残す。

保持版でUIDが取得できた場合は短命ソケットの影響を支持する。改善しなければ、同じ保持時間でDatagramSocket.connectの有無だけを変える診断を次に準備する。これは公式が保証する解決法ではなく、照会tupleとの適合性を調べる追加仮説である。並行してアプリのローカルアドレス・ポートを記録し、PCAPdroidのUID照会のログと比較する。

改善しない結果はUDPの帰属不能例として保存する。全UIDを確定できるという主張を避け、必要に応じ別AVD/APIまたはrootを別プロファイルで比較する。端末の初期化・root化・CA追加・有料機能購入を先に要求しない。送受信の成功は独立サーバとアプリログ、観測器のUID精度は独立した評価軸として残す。

## 一次資料

- [公式FAQ](https://github.com/emanuele-f/PCAPdroid/blob/fe15479b1372214edd354a7095092c4dbee88077/faq.md): Unknown、仮想IP。
- [公式Quick Start](https://github.com/emanuele-f/PCAPdroid/blob/fe15479b1372214edd354a7095092c4dbee88077/quick_start.md): 開始、フィルター、VPNのパケット変換。
- [公式Advanced Features](https://github.com/emanuele-f/PCAPdroid/blob/fe15479b1372214edd354a7095092c4dbee88077/advanced_features.md): rootにも残るUnknown。
- [2.0.2 CaptureService](https://github.com/emanuele-f/PCAPdroid/blob/66f7b3514540c20add8655a74dfee93d00a9563b/app/src/main/java/com/emanuelef/remote_capture/CaptureService.java): addAllowedApplication、getUidQ。
- [2.0.2 UID resolver](https://github.com/emanuele-f/PCAPdroid/blob/66f7b3514540c20add8655a74dfee93d00a9563b/app/src/main/jni/common/uid_resolver.c): API別の照会。
- [2.0.2 ConnectionOverview](https://github.com/emanuele-f/PCAPdroid/blob/66f7b3514540c20add8655a74dfee93d00a9563b/app/src/main/java/com/emanuelef/remote_capture/fragments/ConnectionOverview.java): Duration。
- [2.0.2制御API](https://github.com/emanuele-f/PCAPdroid/blob/66f7b3514540c20add8655a74dfee93d00a9563b/docs/app_api.md): 同意、CaptureCtrl、PCAP保存。
