# はじめて読む、この研究の全体像

2026年11月5日時点の資料です。初心者向けの20ページの解説です。

最初は `APK_AUDIT_BEGINNER_GUIDE_2026-11-05.pdf` を開いてください。
プログラムの実行や、追加実験・人手評価票の記入は必要ありません。

## 読み方

- 1〜4ページ：何を目指し、何を研究しているか。
- 5〜10ページ：機器と用語、解析の仕組み、各実験を行った理由。
- 11〜14ページ：25試行とAntennaPodで得た結果。
- 15〜18ページ：比較、AI点検、先行研究、結論と限界。
- 19〜20ページ：結果ファイルと用語、自分で説明する練習。

PDFのしおりから各ページへ移動できます。

## 含まれるもの

- PDF：図8点、結果表、用語説明、理解確認の質問と答え。
- `docs/research/beginner-research-guide-2026-11-05.md`：編集しやすい日本語本文。
- `docs/beginner-research-guide-2026-11-05.tex`：TeX本文と図。
- `tools/build_beginner_guide.py`：MarkdownからTeXとPDFを生成するスクリプト。
- `data/trials-25.csv`：25試行の集計。独立した25アプリではありません。
- `SOURCE-STATUS.json`：本文の主要な数値とその出典ファイルのハッシュ。
- `QUALITY-CHECK.json`：20ページと見出し、文字欠け・はみ出しの確認。
- `MANIFEST.json`：同梱ファイルのSHA-256。

## 研究の位置付け

APK内の静的候補と指定操作下の実測を比較し、根拠と不足を説明する
解析支援システムの実装・事後的な事例評価です。
19/25を精度とせず、全試行の取得品質partialを維持しています。
独立した人手正解はなく、AIによる点検と説明しています。

## 詳しい資料

- 論文PDF：
  https://github.com/takutomiyajima/traffic_detect/raw/4a7f1ead6e97c53d23be2f9d0f6008c5bb6a5f4a/APK_AUDIT_THESIS_2026-11-05_AI_CHECKED.pdf
- 論文・集計データ一式：
  https://github.com/takutomiyajima/traffic_detect/raw/4a7f1ead6e97c53d23be2f9d0f6008c5bb6a5f4a/APK_AUDIT_PAPER_AND_DATA_2026-11-05.zip
- 研究発表用・進捗報告用のPPTXとPDF：
  https://github.com/takutomiyajima/traffic_detect/raw/5411ecc16b5defe150b868a1381edab7e1ec9507/APK_AUDIT_TWO_PRESENTATIONS_2026-11-05.zip

関連文献：
- PoliCheck: https://www.usenix.org/conference/usenixsecurity20/presentation/andow
- PoliGraph: https://www.usenix.org/conference/usenixsecurity23/presentation/cui
- PurPliance: https://doi.org/10.1145/3460120.3484536

提供論文の原本、APK、PCAP、受信本文の原本は同梱していません。

## PDFを再生成する場合だけ

Python 3、XeLaTeX、Noto Sans CJK JP、DejaVu Sans Mono、TikZ、tcolorbox等が
インストールされた環境で、展開フォルダから次を実行します。

```sh
python tools/build_beginner_guide.py
```

`docs/beginner-research-guide-2026-11-05.pdf` が生成されます。
TeXのみを編集する場合は `docs` で `xelatex` を3回実行できます。
図はベクター形式で、文字は検索・コピーできます。
