#!/usr/bin/env python3
"""Render the maintained, page-oriented beginner guide with native vector figures."""
import argparse
import os
from pathlib import Path
import re
import subprocess

ROOT=Path(__file__).resolve().parents[1]


def esc(text):
    mapping={'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#',
             '_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}
    return ''.join(mapping.get(c,c) for c in text)


def inline(text):
    parts=re.split(r'(\*\*[^*]+\*\*|`[^`]+`)',text)
    return ''.join(r'\textbf{'+esc(p[2:-2])+'}' if p.startswith('**') else
                   r'{\small\nolinkurl{'+p[1:-1]+'}}' if p.startswith('`') else esc(p) for p in parts)


DIAGRAMS={
'overview':r'''
\begin{center}\begin{tikzpicture}[node distance=5mm,box/.style={rounded corners=2mm,draw=none,fill=mint,align=center,font=\small,text width=42mm,minimum height=22mm},a/.style={-{Stealth[length=2mm]},thick,draw=teal}]
\node[box] (a) {APKを調べる\\何が入っている？};
\node[box,right=9mm of a,fill=bluewash] (b) {動かして記録する\\何を観測した？};
\node[box,right=9mm of b,fill=sand] (c) {比べて説明する\\根拠と不足は？};
\draw[a] (a)--(b);\draw[a] (b)--(c);
\end{tikzpicture}\end{center}''',
'pipeline':r'''
\begin{center}\begin{tikzpicture}[box/.style={rounded corners=2mm,draw=none,fill=mint,align=center,font=\small,text width=63mm,minimum height=16mm},a/.style={-{Stealth[length=2mm]},thick,draw=teal}]
\node[box,text width=140mm] (input) {入力：APK・指定する操作・選定環境\\任意の追加条件：明示ポリシー};
\node[box,anchor=north west] (static) at ([yshift=-9mm]input.south west) {静的解析\\宣言・設定・文字列候補};
\node[box,anchor=north east,fill=bluewash] (dynamic) at ([yshift=-9mm]input.south east) {動的観測\\操作中の通信と取得条件};
\node[box,text width=140mm,below=40mm of input,fill=sand] (result) {正規化・比較・任意条件への照合\\対応・差分・判断不能を根拠付きで出力};
\draw[a] (input.south -| static.north)--(static.north);
\draw[a] (input.south -| dynamic.north)--(dynamic.north);
\draw[a] (static.south)--(static.south |- result.north);
\draw[a] (dynamic.south)--(dynamic.south |- result.north);
\end{tikzpicture}\end{center}''',
'environment':r'''
\begin{center}\begin{tikzpicture}[box/.style={rounded corners=2mm,draw=none,fill=mint,align=center,font=\small,text width=65mm,minimum height=34mm},a/.style={-{Stealth[length=2mm]},thick,draw=teal}]
\node[box] (mac) {Mac\\Python解析システム\\ADB・研究用参照サーバー};
\node[box,right=15mm of mac,fill=bluewash] (avd) {仮想Android端末\\対象アプリ\\PCAPdroidによる通信記録};
\draw[a] ([yshift=5mm]mac.east)--node[above,font=\footnotesize]{操作・取得}([yshift=5mm]avd.west);
\draw[a] ([yshift=-6mm]avd.west)--node[below,font=\footnotesize]{通信・記録}([yshift=-6mm]mac.east);
\end{tikzpicture}\end{center}''',
'correspondence':r'''
\begin{center}\begin{tikzpicture}[box/.style={rounded corners=2mm,draw=none,fill=mint,align=center,font=\small,text width=64mm,minimum height=23mm},a/.style={-{Stealth[length=2mm]},thick,draw=teal}]
\node[box] (s) {静的な2候補\\10.0.2.2:8765\\docs.example.org:443};
\node[box,right=15mm of s,fill=bluewash] (d) {対象の実測\\10.0.2.2:8765\\HTTP通信1フロー};
\draw[a] (s.east)--node[above,font=\footnotesize]{対応} (d.west);
\node[below=3mm of s,font=\footnotesize,text width=66mm,align=center] {別候補は、この窓では対応未観測};
\end{tikzpicture}\end{center}''',
'trial':r'''
\begin{center}\begin{tikzpicture}[box/.style={rounded corners=1mm,draw=none,fill=mint,align=center,font=\footnotesize,text width=22mm,minimum height=15mm},a/.style={-{Stealth[length=1.5mm]},thick,draw=teal}]
\node[box] (a) {条件を\\保存};\node[box,right=4mm of a] (b) {取得前の\\確認};\node[box,right=4mm of b,fill=bluewash] (c) {操作して\\観測};\node[box,right=4mm of c] (d) {取得後の\\確認};\node[box,right=4mm of d,fill=sand] (e) {保存して\\比較};
\draw[a](a)--(b);\draw[a](b)--(c);\draw[a](c)--(d);\draw[a](d)--(e);
\end{tikzpicture}\end{center}''',
'http':r'''
\begin{center}\begin{tikzpicture}[a/.style={-{Stealth[length=2mm]},thick,draw=teal},b/.style={-{Stealth[length=2mm]},thick,draw=navy},font=\small]
\node[fill=mint,rounded corners=1mm,minimum width=32mm,minimum height=9mm] at (0,0) {アプリ};
\node[fill=bluewash,rounded corners=1mm,minimum width=38mm,minimum height=9mm] at (11,0) {研究用サーバー};
\draw[gray!45] (0,-.55)--(0,-4.85);\draw[gray!45] (11,-.55)--(11,-4.85);
\draw[a] (0,-1.1)--node[above]{RSSのGET：一覧の本文がほしい}(11,-1.1);
\draw[b] (11,-2.1)--node[above]{200応答 ＋ RSS本文679 B}(0,-2.1);
\draw[a] (0,-3.3)--node[above]{音声のHEAD：内容の情報を知りたい}(11,-3.3);
\draw[b] (11,-4.3)--node[above]{200応答、Content-Length 16,044、本文0 B}(0,-4.3);
\end{tikzpicture}\end{center}''',
'uid_correction':r'''
\begin{center}\begin{tikzpicture}[box/.style={rounded corners=2mm,draw=none,fill=sand,align=center,font=\small,text width=41mm,minimum height=19mm},a/.style={-{Stealth[length=2mm]},thick,draw=teal}]
\node[box] (old) {古い解析結果\\UID不明};\node[box,right=10mm of old,fill=bluewash] (raw) {原本を点検\\14パケットはUID10133};\node[box,right=10mm of raw,fill=mint] (new) {訂正版\\別UIDとして保持};
\draw[a](old)--(raw);\draw[a](raw)--(new);
\end{tikzpicture}\end{center}''',
'reproduction':r'''
\begin{center}\begin{tikzpicture}[box/.style={rounded corners=2mm,draw=none,fill=mint,align=center,font=\small,text width=42mm,minimum height=20mm},a/.style={-{Stealth[length=2mm]},thick,draw=teal}]
\node[box] (input) {保存された入力};\node[box,right=10mm of input,fill=bluewash] (again) {同じ処理を実行};\node[box,right=10mm of again,fill=sand] (output) {保存結果と一致};
\draw[a](input)--(again);\draw[a](again)--(output);
\node[below=5mm of again,font=\small,text width=145mm,align=center] {入力の誤りも再現できるので、原本との意味の照合は別途必要。};
\end{tikzpicture}\end{center}'''
}

PREAMBLE=r'''\documentclass[a4paper,11pt]{article}
\usepackage[top=19mm,bottom=19mm,left=20mm,right=20mm,headheight=15pt,headsep=6mm]{geometry}
\usepackage{fontspec}
\setmainfont{Noto Sans CJK JP}
\setsansfont{Noto Sans CJK JP}
\setmonofont{DejaVu Sans Mono}[Scale=0.83]
\XeTeXlinebreaklocale "ja"
\XeTeXlinebreakskip=0pt plus 1pt
\usepackage{xcolor,tikz,tcolorbox,booktabs,array,enumitem,fancyhdr,lastpage}
\usetikzlibrary{arrows.meta,positioning,calc}
\usepackage[unicode,hidelinks]{hyperref}
\usepackage{xurl}
\definecolor{navy}{HTML}{132A3A}
\definecolor{teal}{HTML}{147D88}
\definecolor{mint}{HTML}{E6F3F1}
\definecolor{bluewash}{HTML}{EAF0F8}
\definecolor{sand}{HTML}{FCF0DE}
\definecolor{muted}{HTML}{5A6E7F}
\definecolor{rulegray}{HTML}{D7E1E7}
\hypersetup{pdftitle={はじめて読む、この研究の全体像},pdfauthor={APK Audit Research},pdfsubject={研究の目的・仕組み・実験・結果・結論を初心者向けに説明する入門ガイド}}
\setlength{\parindent}{0pt}
\setlength{\parskip}{0.55em}
\setlength{\emergencystretch}{3em}
\linespread{1.12}
\setlist[itemize]{leftmargin=1.45em,itemsep=0.2em,topsep=0.2em}
\setlist[enumerate]{leftmargin=1.8em,itemsep=0.2em,topsep=0.2em}
\pagestyle{fancy}\fancyhf{}
\fancyhead[L]{\footnotesize\color{muted}APKと通信解析を理解する入門ガイド}
\fancyhead[R]{\footnotesize\color{muted}2026年11月5日版}
\fancyfoot[L]{\footnotesize\color{muted}研究の範囲：指定操作下の解析支援と事例評価}
\fancyfoot[R]{\footnotesize\color{muted}\thepage\ /\ \pageref{LastPage}}
\renewcommand{\headrulewidth}{0.3pt}\renewcommand{\footrulewidth}{0pt}
\newcommand{\chaptertitle}[2]{\pdfbookmark[1]{#1｜#2}{chapter#1}\noindent{\color{teal}\small\textbf{RESEARCH GUIDE / #1}}\par\vspace{2mm}{\color{navy}\fontsize{22}{29}\selectfont\bfseries #2\par}\vspace{3mm}}
\newenvironment{keybox}[1]{\begin{tcolorbox}[colback=mint,colframe=mint,boxrule=0pt,arc=2mm,left=3mm,right=3mm,top=2mm,bottom=2mm,title={#1},coltitle=teal,colbacktitle=mint,fonttitle=\bfseries]}{\end{tcolorbox}}
\begin{document}
'''


def render(source):
    parts=source.split('<!-- page -->');assert len(parts)==20
    output=[PREAMBLE]
    for page,part in enumerate(parts,1):
        if page>1:output.append(r'\clearpage')
        lines=part.strip().splitlines();i=0
        while i<len(lines):
            line=lines[i].strip()
            if not line or line.startswith('# '):i+=1;continue
            if line.startswith('## '):
                m=re.fullmatch(r'## (\d{2})｜(.+)',line);assert m and int(m[1])==page
                output.append(r'\chaptertitle{'+m[1]+'}{'+esc(m[2])+'}');i+=1;continue
            if line.startswith('### '):
                output.append(r'\par\smallskip{\color{teal}\large\bfseries '+inline(line[4:])+r'}\par');i+=1;continue
            if line.startswith(':::diagram '):
                output.append(DIAGRAMS[line.split()[1]]);i+=1;continue
            if line.startswith(':::source '):
                output.append(r'\vfill\par{\footnotesize\color{muted}出典・確認範囲：'+inline(line[len(':::source '):])+r'\par}');i+=1;continue
            if line.startswith(':::key '):
                output.append(r'\begin{keybox}{'+esc(line[7:])+r'}');i+=1
                while i<len(lines) and lines[i].strip()!=':::':
                    output.append(inline(lines[i])+r'\par');i+=1
                assert i<len(lines);output.append(r'\end{keybox}');i+=1;continue
            if line.startswith('|'):
                rows=[]
                while i<len(lines) and lines[i].strip().startswith('|'):
                    cells=[s.strip() for s in lines[i].strip().strip('|').split('|')]
                    if not all(re.fullmatch(r':?-+:?',c) for c in cells):rows.append(cells)
                    i+=1
                n=len(rows[0]);assert n in (2,3) and all(len(r)==n for r in rows)
                proportions=[.36,.64] if n==2 else [.23,.34,.43]
                available=170-5*(n-1)
                columns='@{}'+' '.join(r'>{\raggedright\arraybackslash}p{'+f'{available*v:.2f}mm'+'}' for v in proportions)+'@{}'
                output.append(r'\par\smallskip{\fontsize{10}{13}\selectfont\renewcommand{\arraystretch}{1.2}\setlength{\tabcolsep}{2.5mm}\begin{tabular}{'+columns+r'}\toprule')
                for j,row in enumerate(rows):
                    output.append(' & '.join((r'\textbf{'+inline(c)+'}') if j==0 else inline(c) for c in row)+r' \\')
                    if j==0:output.append(r'\midrule')
                output.append(r'\bottomrule\end{tabular}}\par\smallskip');continue
            if line.startswith('- ') or re.match(r'\d+\. ',line):
                ordered=not line.startswith('- ');environment='enumerate' if ordered else 'itemize';output.append('\\begin{'+environment+'}')
                while i<len(lines):
                    current=lines[i].strip();m=re.match(r'\d+\. (.*)',current) if ordered else re.match(r'- (.*)',current)
                    if not m:break
                    output.append(r'\item '+inline(m[1]));i+=1
                output.append('\\end{'+environment+'}');continue
            paragraph=[]
            while i<len(lines) and lines[i].strip() and not lines[i].strip().startswith(('#',':::','|','- ')) and not re.match(r'\d+\. ',lines[i].strip()):
                paragraph.append(lines[i].strip());i+=1
            assert paragraph,(page,line)
            output.append(inline(''.join(paragraph))+r'\par')
    output.append(r'\end{document}')
    return '\n'.join(output)+'\n'


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',type=Path,default=ROOT/'docs/research/beginner-research-guide-2026-11-05.md')
    p.add_argument('--out-dir',type=Path,default=ROOT/'docs')
    args=p.parse_args();args.out_dir.mkdir(parents=True,exist_ok=True)
    tex=args.out_dir/'beginner-research-guide-2026-11-05.tex';tex.write_text(render(args.source.read_text()),encoding='utf-8')
    env={**os.environ,'TEXMFVAR':str(ROOT/'.cache/texmf-var'),'TEXMFCONFIG':str(ROOT/'.cache/texmf-config'),'XDG_CACHE_HOME':str(ROOT/'.cache')}
    for _ in range(3):subprocess.run(['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error',tex.name],cwd=args.out_dir,env=env,check=True)


if __name__=='__main__':main()
