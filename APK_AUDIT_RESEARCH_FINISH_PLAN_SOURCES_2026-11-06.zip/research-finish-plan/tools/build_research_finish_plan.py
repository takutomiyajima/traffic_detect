#!/usr/bin/env python3
"""Freeze a bounded dissertation scope from already reviewed evidence."""
from pathlib import Path
from collections import Counter
import csv
import hashlib
import json
import os
import subprocess
import build_beginner_guide as base

ROOT=Path(__file__).resolve().parents[1]


def main():
    folder=ROOT/'docs/research/finish-plan-2026-11-06';folder.mkdir(parents=True,exist_ok=True)
    review=ROOT/'docs/research/intent-seeds-001-2026-11-06/review.json'
    result=json.loads(review.read_text());rows=result['rows']
    assert len(rows)==9 and all(r['capture_controls_passed'] and r['evidence_references_verified'] for r in rows)
    counts=Counter((r['condition'],r['verdict']) for r in rows)
    assert counts==Counter({('input','consistent_with_observed_evidence'):3,('fixed','mismatch_candidate'):3,('delayed','not_evaluable'):3})
    assert all(r['observation']=='not_observed' for r in rows if r['condition']=='delayed')
    assert sum(r['mismatch_findings'] for r in rows if r['condition']=='input')==0
    assert result['independent_accuracy_established'] is False
    assert result['raw_control_requests_verified']==18 and result['raw_target_requests_with_candidate_server_match']==6
    component=json.loads((review.parent/'component-analysis.json').read_text())
    assert len(component['rows'])==27
    fields=['external_consistent','external_mismatch','permission_mismatch','target_unobserved']
    for t in {r['trial_id'] for r in component['rows']}:
        bymode={r['evidence_mode']:r for r in component['rows'] if r['trial_id']==t}
        assert all(bymode['dynamic-only'][f]==bymode['integrated'][f] for f in fields)
    claims=[
        ('C1','目的・対象','解析前の構造化意図とAPK・指定操作を照合する確認支援','docs/thesis.tex; examples/intent-recorded-input-v1.1.json','自由記述の目的自動理解・任意アプリ全機能の自動探索を主張しない'),
        ('C2','意図外宛先','別ポートの固定先要求を3/3試行で不一致候補として提示','docs/research/intent-seeds-001-2026-11-06/trial-results.csv','同じ開発側の自作APKと同一AVDに限定'),
        ('C3','許可入力先','登録した入力先への3要求は整合、通信の不一致指摘0/3試行','docs/research/intent-seeds-001-2026-11-06/trial-results.csv','すべての正常通信に対する誤検出率ではない'),
        ('C4','未観測','対象未観測3試行を判定不能として保持','docs/research/intent-seeds-001-2026-11-06/review.json','遅延送信の検出・無通信・安全を結論しない'),
        ('C5','根拠追跡','9試行の照合結果と対応表を再現し根拠参照を検査','docs/research/intent-seeds-001-2026-11-06/review.json','利用者理解度・時間削減や独立した正解の評価ではない'),
        ('C6','方式の役割','27出力の事後比較で動的のみと併用の主要通信判定は一致','docs/research/intent-seeds-001-2026-11-06/component-analysis.csv','併用による通信判定精度向上を主張しない'),
        ('C7','静的な権限','別の静的参照素材で許可外の位置権限宣言を指摘','docs/research/intent-first-2026-11-06/status.json','権限実使用・位置情報送信・9端末試行に数えない'),
        ('C8','取得品質','18対照要求と対象6要求の候補対応を点検、全品質partial','docs/research/intent-seeds-001-2026-11-06/capture-quality-detail.json','取得完全性・独立したUID帰属精度を保証しない'),
    ]
    with (folder/'claim-evidence-ledger.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(['claim_id','topic','supported_conclusion','evidence_reference','scope_limit']);writer.writerows(claims)
    plan=dict(date_jst='2026-11-06',status='scope_frozen_for_writing_before_any_additional_experiment',
              required_additional_Android_trials=0,required_trials_scope='For the bounded design-and-case-evaluation claims in this plan; institutional requirements not inferred.',
              primary_trials=9,supplementary_historical_trials=29,combined_recorded_trials=38,
              retrospective_component_outputs=27,static_permission_case_separate=True,
              optional_90s_trials={'planned_if_scope_explicitly_expanded':3,'required_for_current_claims':False,'released_runner':False,'executed':0,
                                  'only_added_claim':'Additional evidence after a longer observation window in the same fixture'},
              remaining_working_days_estimate=[3,5],human_review_hours_estimate=[1,2],
              not_in_current_evaluation=['real_SDK_detection_accuracy','AI_generated_app_population','second_public_app_replication',
                                         'general_privacy_leak_detection','broad_device_or_OS_accuracy','adaptive_probe_superiority'],
              scope_change_rule='Do not append experiments as routine next steps; first identify an essential claim unsupported by evidence or a concrete supervisor requirement, show bounded cost and update the plan.',
              source_review_sha256=hashlib.sha256(review.read_bytes()).hexdigest(),
              evidence_checks_passed=True,general_accuracy_established=False,algorithmic_novelty_established=False)
    (folder/'scope-and-completion.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
    source='''# 実験を増やし続けないための研究完了計画

## 01｜研究の着地点を固定する

**今回の卒論は「開発意図と静的・動的解析を照合する確認支援システムの設計と、限定した事例評価」でまとめます。この主張の範囲では、追加のAndroid実験を必須にしません。** 指導教員の評価水準を推測して合格を保証するものではなく、現在の証拠から成立するまとめ方です。

目的は、開発者が解析前に宣言した条件と、APKの宣言・候補・指定操作下の通信を比較し、意図外の候補と確認不足を根拠付きで示すことです。静的・動的の差分は、その判断を説明するために使います。

| 論文で答える問い | 現在の根拠と答え |
| --- | --- |
| 宣言外の宛先に気づけるか | 固定先の3試行で不一致候補。別の静的素材で許可外の権限宣言も提示 |
| 許可入力先と観測不足を区別できるか | 入力先3試行は整合、対象未観測3試行は判定不能 |
| 判断の根拠へ戻れるか | 9試行のフロー・照合・対応表を再現し、証拠参照を点検 |

主結果は事前意図を保存した9試行です。既存29試行は取得・帰属・差分説明の補助結果として残します。計38試行を独立した38アプリや、同じ事前計画による精度標本にはしません。

:::key 論文の結論の中心
同一AVD・自作参照素材の条件で、許可入力先への要求、条件外の固定先への要求、対象未観測を分けて提示できた。静的側の宣言・候補と動的側の実通信を、事前意図と証拠へ結び付けて自己確認できる構成を実装した。
:::

一般精度や新アルゴリズムの優越、アプリ全体の安全性を結論へ加えません。AI支援開発とプライバシー確認は活用先として論じ、AI生成アプリや情報漏えいを評価済みとは書きません。

:::source 既存の9試行・27出力の再解析結果と静的補助素材を確認。主張と根拠8項目の台帳を作成。

<!-- page -->
## 02｜残作業と終了条件

必須の新規Android取得は0件とし、残りは主張・結果・本文・再現資料を一致させる作業に集中します。下表は実作業量の目安で、今後数日間の自動実行を予約した意味ではありません。

| 作業 | 担当・目安 | 完了の基準 |
| --- | --- | --- |
| 目的・RQ・主張の固定 | AI側で今回作成 | 主張と根拠8項目の台帳、追加実験の要否と対象外を保存 |
| 結果表と本文の統一 | AI、0.5〜1日 | 主評価9と補助29、事後27出力、静的素材を区別し数字が一致 |
| 関連研究との差の整理 | AI、0.5〜1日 | 既に確認した文献との入力・出力・限界を比較。独自性の記述を根拠の範囲へ絞る |
| 図・構成・考察の最終整理 | AI、1〜2日 | 意図→静的／動的→照合→根拠の図と1事例を入れ、主結果に沿って考察・結論を統一 |
| PDF・TeX・再現資料の確認 | AI、0.5〜1日 | PDFの表示・参照・表、資料hash、非公開原本の保護を確認 |
| 本人による確認 | 本人、1〜2時間 | 内容を自分の言葉で説明し、著者情報・大学様式・AI利用記録を確認 |

目安はAI側の整理を含む実作業3〜5日程度と、本人確認1〜2時間です。指導教員からの修正指示への対応期間は別に確保します。

:::key ここまで満たせば、この範囲の草稿を閉じる
目的・RQ・入力・出力が一致する。9試行の主結果と参照根拠がそろう。保留・品質partial・同一作者素材という制約を明記する。方式比較は精度向上と誤記しない。本文・表・要旨・結論が一致し、PDFと再現資料を検査する。
:::

次にこちらが進めるのは本文の整理と関連研究比較です。今、Macで新しい実験を回す作業はありません。指導教員への研究範囲の共有は、この計画と主結果の表を使えます。

:::source 29ページ草稿と既存の結果資料を仕上げる計画。大学の形式や指導方針について未確認の条件を作らない。

<!-- page -->
## 03｜何を今回は増やさないか

90秒観測は、今回の主張に対する必須条件から外します。今は30秒窓で未観測を保留したという結果を使い、長い窓でどう変化するかは今後の課題に置けます。90秒用ランナーは未配布で、Android実測も追加していません。

| 拡張候補 | 追加すれば答えられる問い | 今回の扱い |
| --- | --- | --- |
| 90秒観測3試行 | 長い窓で要求が観測され、保留から整合へ移るか | 任意。追加する場合も3試行という範囲を先に固定 |
| 実SDKを含むAPK | 登録SDK候補の検出が実SDKでも成立するか | 現在の主評価から外す |
| AI生成アプリ3〜5本 | AI支援で作った具体例に自己確認を適用できるか | 活用例の拡張。今回の成果とは数えない |
| 別公開アプリ・別AVD | 違う実装や環境へ一般化できるか | 今後の課題 |
| Home後・各種遅延・位置送信 | 条件ごとの検出範囲や本文内容を確認できるか | 今回の結論の対象に含めない |

:::key 追加実験を決めるルール
結果が出たという理由だけで次の実験を追加しません。現在の主張を成立させる本質的な根拠不足、または指導教員の具体的な要件が見つかった場合に、必要な問い・試行上限・所要時間・成功／不成立条件を示して計画を見直します。
:::

新規性については、既存の解析・自動操作・ポリシー照合・不明の扱いを踏まえ、構造化意図による自己確認の設計と証拠を示します。広い性能優越や未研究性を証明するまで実験を続ける計画にはしません。その水準の論文を目指す場合は、別の評価計画として範囲を合意します。

本人に必要なのは、「何を入力し、何を比較し、9試行から何が言えて何が言えないか」を説明できる状態にすることです。新しい実験の操作依頼より先に、この範囲の本文を完成形へ整えます。

:::source この計画は、直前の「次は90秒観測」という逐次提案を置き換える。今回の必須追加取得は0件。
'''
    (folder/'finish-plan.md').write_text(source)
    tex=base.render(source,expected_pages=3)
    replacements={
        'はじめて読む、この研究の全体像':'研究完了計画：主張・残作業・終了条件',
        '研究の目的・仕組み・実験・結果・結論を初心者向けに説明する入門ガイド':'既存証拠で完成させる卒業論文の範囲と作業計画',
        'APKと通信解析を理解する入門ガイド':'研究完了計画：追加実験より先に範囲を固定',
        '2026年11月5日版':'2026年11月6日版','RESEARCH GUIDE /':'COMPLETION PLAN /',
        '研究の範囲：指定操作下の解析支援と事例評価':'主評価9・補助29 / この主張の必須追加取得0'
    }
    for a,b in replacements.items():tex=tex.replace(a,b)
    path=ROOT/'docs/research-finish-plan-2026-11-06.tex';path.write_text(tex)
    env={**os.environ,'TEXMFVAR':str(ROOT/'.cache/texmf-var'),'TEXMFCONFIG':str(ROOT/'.cache/texmf-config'),'XDG_CACHE_HOME':str(ROOT/'.cache')}
    for _ in range(3):subprocess.run(['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error',path.name],cwd=path.parent,env=env,check=True)


if __name__=='__main__':main()
