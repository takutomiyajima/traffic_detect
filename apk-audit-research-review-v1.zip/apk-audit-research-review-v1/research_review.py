#!/usr/bin/env python3
"""Prepare evidence-first human review and score agreement without inventing gold.

Standalone stdlib tool. Historical review is retrospective, never a new trial.
Model answers are stored OUTSIDE the reviewer packet. Do not publish raw packets.
"""
import argparse
import csv
import hashlib
import json
import shutil
from collections import Counter
from pathlib import Path

VERDICTS = ('consistent_with_observed_evidence', 'mismatch_candidate', 'needs_review', 'not_evaluable')
COLUMNS = ['unit_id', 'reviewer_id', 'reviewer_relation', 'verdict', 'evidence_refs', 'reason']


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def prepare(index_path, out):
    out = Path(out)
    key_path = out.with_name(out.name+'.model-predictions.json')
    if out.exists() or key_path.exists():
        raise ValueError('Use a new review output; existing evidence and answers are never overwritten')
    entries = read(index_path)['runs']
    if len({entry['trial_id'] for entry in entries}) != len(entries):
        raise ValueError('Duplicate trial IDs')
    jobs, units, predictions = [], [], []
    for entry in entries:
        source = Path(entry['directory']).resolve()
        state, evidence = read(source/'run.json'), read(source/'evidence/index.json')
        result = read(source/'findings.json')
        findings = result['findings']
        if read(source/'intent.json') != result['intent']:
            raise ValueError('Review policy differs from the analyzed policy')
        flows = [json.loads(line) for line in (source/'flows.jsonl').read_text().splitlines() if line.strip()]
        # Purposeful sampling from recorded UID strata, not predicted verdicts.
        # One record per stratum per run; this is not a representative accuracy sample.
        selected = {}
        for flow in flows:
            if flow['destination_ip'] != entry['destination_ip'] or flow['port'] != entry['destination_port']:
                continue
            uid = flow.get('uid')
            stratum = 'missing_uid' if uid is None else 'installation_uid' if uid == state.get('target_uid') else 'different_uid'
            selected.setdefault(stratum, flow)
        if not selected:
            raise ValueError('No observed records for '+entry['trial_id']+'; do not label absence from an empty selection')
        for flow in selected.values():
            unit_id = 'U%04d' % (len(units)+1)
            candidates = [f for f in findings if f['subject'] in ('external_connection','connection_attribution','capture_failure') and flow['flow_id'] in f['evidence_ids']]
            if len(candidates) != 1:
                raise ValueError('Network-policy prediction is missing or ambiguous for '+flow['flow_id'])
            references = []
            for eid in flow['evidence_ids']:
                record = evidence[eid]
                path = (source/record['path']).resolve()
                if not path.is_relative_to(source) or not path.is_file() or digest(path) != record['sha256']:
                    raise ValueError('Evidence missing/modified: '+eid)
                references.append({'source':str(path), 'destination':unit_id+'/'+path.name, 'locator':record['locator']})
            # Installation and independent application/server records are factual
            # evidence, not the analyzer's explanation. Do not auto-join them.
            for name in ('app-package.txt','installed-apk-sha256.txt','app-logcat.txt','server-events.jsonl'):
                path = source/'raw/handoff'/name
                if path.is_file():
                    references.append({'source':str(path), 'destination':unit_id+'/'+name, 'locator':'Independent original; reviewer must justify any correspondence'})
            intent = read(source/'intent.json')
            units.append({'unit_id':unit_id, 'record_locator':flow['source_record'], 'observed_destination_ip':flow['destination_ip'],
                          'observed_port':flow['port'], 'recorded_uid':flow.get('uid'), 'recorded_package':flow.get('package'),
                          'target_package':state.get('package'), 'installation_uid_assertion':state.get('target_uid'),
                          'policy':intent, 'references':[{'path':'evidence/'+r['destination'], 'locator':r['locator']} for r in references]})
            predictions.append({'unit_id':unit_id,'trial_id':entry['trial_id'],'source_flow_id':flow['flow_id'],
                                'verdict':candidates[0]['verdict'],'source_run_sha256':digest(source/'run.json'),
                                'source_findings_sha256':digest(source/'findings.json')})
            jobs += references
    if not units:
        raise ValueError('No review units')
    out.mkdir(parents=True)
    for job in jobs:
        destination = out/'evidence'/job['destination']
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(job['source'],destination)
    (out/'tasks.json').write_text(json.dumps({'analysis_design':'retrospective_evidence_first_review','sampling':'one observed record per UID stratum per run at predefined destination; not population accuracy', 'units':units},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    with (out/'labels.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=COLUMNS);writer.writeheader()
        writer.writerows({'unit_id':unit['unit_id']} for unit in units)
    (out/'README.md').write_text('''# 人手による証拠レビュー

labels.csvをlabels-completed.csvへコピーし、tasks.jsonの各単位について原本とポリシーを読んでコピー側へ記入してください。元のlabels.csvは凍結したテンプレートなので編集しません。
モデル出力はこのフォルダに含めていません。モデル出力を見る前に一次注釈を完了してください。
verdictは以下の4値です。

- consistent_with_observed_evidence: 対象アプリの観測を、指定条件の範囲で整合と判断できる。
- mismatch_candidate: 対象アプリの観測が指定条件と矛盾する候補である。
- needs_review: 条件が未指定のため判断条件を補う必要がある。
- not_evaluable: 帰属やホスト等の証拠が不足する、または対象外の通信である。

reviewer_idは仮名で構いません。reviewer_relationにはindependent、developer、same_teamのいずれかを記入します。
evidence_refsには参照した原本のファイル名と行・イベントを、reasonには判断理由を記入します。
別UIDの通信を対象アプリの違反とせず、UID不明を対象通信なしにしないでください。
CSV表示だけでTLS成立や本文の意味を判断しないでください。原本間を人手で対応させた場合は、その根拠をreasonに明記してください。
判断できない場合もnot_evaluableと理由を記入してください。未記入は未評価のままです。
これは既存データの事後レビューです。独立したアプリ標本の精度評価、第三者審査済みの事前登録とはしません。
このフォルダには研究用原本が含まれます。GitHub等へ公開しないでください。
''',encoding='utf-8')
    key={'analysis_design':'retrospective_review','predictions':predictions}
    key_path.write_text(json.dumps(key,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    files={str(p.relative_to(out)):digest(p) for p in out.rglob('*') if p.is_file()}
    (out/'REVIEW-MANIFEST.json').write_text(json.dumps({'files':files,'model_key_sha256':digest(key_path)},indent=2)+'\n',encoding='utf-8')
    return {'review_units':len(units),'packet':str(out),'private_model_key':str(key_path),'human_annotations_completed':0}


def score(packet, labels, key):
    packet=Path(packet);manifest=read(packet/'REVIEW-MANIFEST.json')
    for relative, expected in manifest['files'].items():
        path=(packet/relative).resolve()
        if not path.is_relative_to(packet.resolve()) or digest(path)!=expected:
            raise ValueError('Original review packet changed; submit labels as a separate file: '+relative)
    if digest(key)!=manifest['model_key_sha256']:
        raise ValueError('Frozen model-key hash mismatch')
    predictions={row['unit_id']:row['verdict'] for row in read(key)['predictions']}
    units={row['unit_id'] for row in read(packet/'tasks.json')['units']}
    if set(predictions)!=units:
        raise ValueError('Review unit set differs from model key')
    seen=set(); annotated=matched=0;matrix=Counter();relations=Counter()
    with Path(labels).open(encoding='utf-8-sig',newline='') as stream:
        reader=csv.DictReader(stream)
        if reader.fieldnames!=COLUMNS:
            raise ValueError('Label columns differ from the frozen template')
        for row in reader:
            unit=row['unit_id']
            if unit not in units or unit in seen:
                raise ValueError('Unknown or duplicate review unit')
            seen.add(unit)
            if not row['verdict'].strip():
                continue
            if row['verdict'] not in VERDICTS or not row['reviewer_id'].strip() or row['reviewer_relation'] not in ('independent','developer','same_team') or not row['reason'].strip() or not row['evidence_refs'].strip():
                raise ValueError('Incomplete/invalid human annotation for '+unit)
            annotated+=1;relations[row['reviewer_relation']]+=1
            matched+=row['verdict']==predictions[unit]
            matrix[(row['verdict'],predictions[unit])]+=1
    return {'status':'pending' if annotated<len(units) else 'annotated','review_units':len(units),'annotated_units':annotated,
            'pending_units':len(units)-annotated,'exact_agreement':matched/annotated if annotated else None,
            'reviewer_relations':dict(relations),'confusion_matrix':[{'human':a,'model':b,'count':v} for (a,b),v in sorted(matrix.items())],
            'interpretation':'Agreement on a purposeful retrospective sample; not general accuracy or independent apps. Unfilled labels are pending, never negative.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('prepare');p.add_argument('--index',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    s=sub.add_parser('score');s.add_argument('--packet',type=Path,required=True);s.add_argument('--labels',type=Path,required=True);s.add_argument('--model-key',type=Path,required=True);s.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    if args.command=='prepare':result=prepare(args.index,args.out)
    else:
        if args.out.exists():raise ValueError('Score output exists')
        result=score(args.packet,args.labels,args.model_key)
        args.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
