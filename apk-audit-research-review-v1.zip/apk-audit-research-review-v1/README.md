# 人手レビューの準備・集計ツール

Python 3.11以上の標準ライブラリだけで動きます。受領原本・人手票・モデル回答はこの公開ZIPに含めていません。

準備: python research_review.py prepare --index input-index.json --out review

一次注釈ではreview内のlabels.csvをlabels-completed.csvにコピーして記入します。元のテンプレートは変更しません。モデル回答(review.model-predictions.json)は注釈者へ配布しません。

集計: python research_review.py score --packet review --labels labels-completed.csv --model-key review.model-predictions.json --out agreement.json

未記入は未評価のままです。これは目的抽出した単位の事後レビューであり、一般的な検出精度とはしません。
