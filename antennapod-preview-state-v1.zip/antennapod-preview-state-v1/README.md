# 開始状態と追加操作を記録するRSS予備確認 v1

既存のapk-audit-unified-v1と、前回のantennapod-rss-preview-v1をそのまま使います。
解析本体・前回補助ツールを書き換えず、既存の購読・再生データを消去しません。
Android動作は初回確認待ちです。初期状態は保持し、未購読の新規状態とは主張しません。

## 配置

ZIPをDocumentsへ展開し、次の3フォルダが並ぶようにします。
- apk-audit-unified-v1
- antennapod-rss-preview-v1
- antennapod-preview-state-v1

## 端末での準備

API35・arm64のemulator-5554を起動し、PCAPdroidの取得を停止します。
AntennaPodを開き、画面下のSubscriptionsを押して購読一覧を表示します。
前回の研究用フィードやその他の購読は残したままで構いません。
画面に見える範囲を記録し、購読総数や全データベース状態は推測しません。

## 実行

```bash
cd "$HOME/Documents/apk-audit-unified-v1"
source .venv/bin/activate
python "$HOME/Documents/antennapod-preview-state-v1/run_preview.py" --apk "$HOME/Downloads/de.danoeh.antennapod_3120395.apk" --out-name antennapod-rss-preview-002
```

開始前の購読一覧・UI階層と条件を保存した後、前回と同じRSS取得を実行します。
起動後5秒とRSS表示後60秒の間、アプリを追加操作しないでください。
制御・VPN同意画面だけ内容を確認します。手動サーバーは不要です。
既存の購読が旧URLへ更新する可能性もあるので、それを無条件に不正通信と扱いません。

終了後、ターミナルに追加操作の有無を聞きます。
- 0: 追加のアプリ操作なし
- 1: 購読・再生・画面移動などを行った
- 2: 不明

実際の操作に合う数字を入力してEnterを押します。これは実験記録で、追加操作の客観的な監視や承認ではありません。
入力しなかった場合は不明を保持します。なしの自己申告を独立した入力イベント証明へ置き換えません。

## 返すもの

`runs/antennapod-rss-preview-002.zip`を添付してください。開始前状態と終了後申告を同梱します。
元の取得ZIPは`runs/antennapod-rss-preview-002.capture-only.zip`として別に保存されます。
既存の結果ファイルは変更せず、最終ZIPのmanifestへ追加記録を含めます。
この段階は予備確認で、本評価の反復には自動的に算入しません。

```bash
open -R "runs/antennapod-rss-preview-002.zip"
```

試行名が既にある場合は、古い記録を保持し、`--out-name antennapod-rss-preview-003`へ変えます。
開始前確認で止まった場合は、handoffのcontextフォルダと表示内容を保存します。
途中で中断した場合は取得停止を待ち、PCAPdroidの稼働状態も確認します。
結果には端末の画面・通信記録を含み得るため、研究者用として扱います。

準備保存だけなら--prepare-onlyを付けます。Androidを操作せず、その試行名は消費されます。
