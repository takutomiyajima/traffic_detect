package org.example.context;

/** Development regression material. These methods are not execution evidence. */
public class ContextCases extends android.app.Activity {
    public static String documentation;
    public java.net.URL fixed() throws Exception {
        return new java.net.URL("https://fixed.example.org/path");
    }
    public java.net.URL concat() throws Exception {
        String prefix = "https://";
        String host = "concat.example.org/path";
        return new java.net.URL(prefix.concat(host));
    }
    public java.net.URL builder() throws Exception {
        StringBuilder value = new StringBuilder();
        value.append("https://");
        StringBuilder alias = value;
        alias.append("builder.example.org/path");
        return new java.net.URL(value.toString());
    }
    public java.net.URL decoy(String input) throws Exception {
        documentation = "https://decoy.example.org/documentation";
        return new java.net.URL(input);
    }
    public java.net.URL branch(boolean useConstant, String input) throws Exception {
        String destination;
        if (useConstant) destination = "https://branch.example.org/path";
        else destination = input;
        return new java.net.URL(destination);
    }
    public java.net.URL runtime(android.content.Intent input) throws Exception {
        return new java.net.URL(input.getDataString());
    }
}
