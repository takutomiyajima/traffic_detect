#!/usr/bin/env python3
"""Build the nine-page Japanese implementation guide with vector figures."""
from pathlib import Path
import os
import subprocess

import build_beginner_guide as base

ROOT = Path(__file__).resolve().parents[1]


def main():
    base.DIAGRAMS['research_pipeline'] = r'''
\begin{center}\begin{tikzpicture}[box/.style={rounded corners=2mm,fill=mint,draw=none,align=center,text width=135mm,minimum height=13mm,font=\small},a/.style={-{Stealth[length=2mm]},thick,draw=teal}]
\node[box] (a) {入力：APK・同じAPKの既存試行・登録済みURI操作};
\node[box,below=6mm of a,fill=bluewash] (b) {引数の使用文脈を解析し、静的候補を補強};
\node[box,below=6mm of b] (c) {差分が残り、実行可能な操作が予算内にあるか確認};
\node[box,below=6mm of c,fill=sand] (d) {A/B入力・対象UIDの要求・サーバー記録・取得対照を確認};
\node[box,below=6mm of d] (e) {説明を更新。不足は保留し、原本と計画を保存};
\draw[a](a)--(b);\draw[a](b)--(c);\draw[a](c)--(d);\draw[a](d)--(e);
\end{tikzpicture}\end{center}'''
    source = ROOT / 'docs/research/diagnostic-implementation-2026-11-06.md'
    text = base.render(source.read_text(), expected_pages=9)
    for before, after in {
        'はじめて読む、この研究の全体像':'文脈解析と対照実行による差分診断プロトタイプ',
        '研究の目的・仕組み・実験・結果・結論を初心者向けに説明する入門ガイド':'新しい引数解析・予算付き選択・対照実行の実装説明',
        'APKと通信解析を理解する入門ガイド':'文脈解析と対照実行：実装ガイド',
        '2026年11月5日版':'2026年11月6日版',
        '研究の範囲：指定操作下の解析支援と事例評価':'研究用プロトタイプ・新ランナーの端末検証は未実施',
        'RESEARCH GUIDE /':'IMPLEMENTATION /',
    }.items():
        text = text.replace(before, after)
    tex = ROOT / 'docs/diagnostic-implementation-2026-11-06.tex'
    tex.write_text(text)
    env = {**os.environ, 'TEXMFVAR':str(ROOT/'.cache/texmf-var'), 'TEXMFCONFIG':str(ROOT/'.cache/texmf-config'), 'XDG_CACHE_HOME':str(ROOT/'.cache')}
    for _ in range(3):
        subprocess.run(['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error',tex.name],cwd=tex.parent,env=env,check=True)


if __name__ == '__main__':
    main()
