#!/usr/bin/env python3
"""Compile a new real DEX fixture with the cached research toolchain; no device."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args();out = a.out.resolve()
    if out.exists():
        raise ValueError("Choose a new fixture build folder")
    sdk = ROOT / ".cache/android-toolchain"
    jar = sdk / "platform/android-35/android.jar"
    bt = sdk / "build-tools/android-15"
    ecj = sdk / "ecj-3.39.0.jar"
    if not all(x.is_file() for x in [jar, bt / "aapt2", bt / "d8", ecj]):
        raise ValueError("Cached Android research compiler not available")
    out.mkdir(parents=True);(out / "classes").mkdir();(out / "dex").mkdir()
    shutil.copy2(ROOT / "fixtures/research-context/ContextCases.java", out / "ContextCases.java")
    shutil.copy2(ROOT / "fixtures/research-context/expected.json", out / "expected.json")
    manifest = out / "AndroidManifest.xml"
    manifest.write_text('<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="org.example.context">'
                        '<uses-sdk android:minSdkVersion="24" android:targetSdkVersion="35"/>'
                        '<application><activity android:name=".ContextCases" android:exported="false"/></application></manifest>')
    def run(args):
        subprocess.run(list(map(str, args)), check=True, capture_output=True, timeout=120)
    run([bt / "aapt2", "link", "-I", jar, "--manifest", manifest, "-o", out / "resources.apk"])
    run(["java", "-jar", ecj, "-8", "-proc:none", "-classpath", jar, "-d", out / "classes", out / "ContextCases.java"])
    run([bt / "d8", "--min-api", "24", "--lib", jar, "--output", out / "dex", *list((out / "classes").rglob("*.class"))])
    apk = out / "context-development.apk"
    shutil.copy2(out / "resources.apk", apk)
    with zipfile.ZipFile(apk, "a") as archive:
        archive.write(out / "dex/classes.dex", "classes.dex")
    print(json.dumps({"apk": str(apk), "device_execution": False, "signed_or_installable_validated": False}))


if __name__ == "__main__":
    main()
