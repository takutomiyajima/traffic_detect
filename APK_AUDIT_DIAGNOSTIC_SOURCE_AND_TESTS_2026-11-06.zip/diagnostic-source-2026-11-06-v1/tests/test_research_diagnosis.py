import json
import urllib.request

import pytest

from apk_audit.core import AuditError, new_run, write_json, write_jsonl
from apk_audit.research_contrast import FeedServer, build_scenario
from apk_audit.research_diagnosis import default_plan, select_probe, plan_from_evidence


def test_planner_separates_conditional_models_with_equal_execution_budget():
    plan = default_plan()
    assert plan["selected_probe"] == "input_switch"
    assert plan["ranked_probes"][0]["separated_model_pairs"] == 1
    assert not plan["novelty_or_accuracy_established"]
    assert "retain all hypotheses" in plan["failure_policy"]


def test_no_budget_or_unavailable_probe_does_not_request_an_execution():
    assert default_plan(budget=0)["selected_probe"] is None
    assert default_plan(activity_available=False)["selected_probe"] is None


@pytest.mark.parametrize("cost", [0, -1, 0.5, True])
def test_invalid_costs_rejected(cost):
    with pytest.raises(AuditError):
        select_probe(["a", "b"], [{"probe_id": "probe", "cost_units": cost, "available": True,
                                  "valid_outcome_model": {"a": ["one"], "b": ["two"]}}], 4)


def test_outcome_overlap_does_not_count_as_separation():
    result = select_probe(["a", "b"], [{"probe_id": "overlap", "cost_units": 1, "available": True,
                                      "valid_outcome_model": {"a": ["one", "two"], "b": ["two"]}}], 1)
    assert result["selected_probe"] is None


def test_wrong_explicit_activity_rejected():
    with pytest.raises(AuditError):
        build_scenario("org.example.app", "org.other.app/.Activity", "http://10.0.2.2:1234/feed/" + "a"*32 + ".xml", 10)


def test_local_constant_reconstruction_can_avoid_device_probe(tmp_path):
    source=tmp_path/'input';source.write_bytes(b'synthetic fixture')
    baseline=tmp_path/'baseline';run=new_run(baseline,source)
    run.update(package='org.example.app',dynamic_status='partial',analysis_scenario={'steps':[{'action':'open_uri'}]})
    write_json(baseline/'run.json',run)
    write_json(baseline/'correspondence.json',{'counts':{'dynamic_only':1},'records':[{'status':'dynamic_only','flows':['flow1']}]})
    write_jsonl(baseline/'flows.jsonl',[{'flow_id':'flow1','attribution':'target','transport':'TCP','host':'concat.example.org','port':443}])
    context={'apk_sha256':run['apk_sha256'],'records':[{'status':'constant_url_argument','endpoint':{'host':'concat.example.org','port':443}}]}
    result=plan_from_evidence(baseline,context)
    assert result['selected_probe'] is None
    assert result['reason']=='dynamic_only_endpoints_have_local_constant_argument_candidates'
    assert result['evidence_basis']['contextual_endpoint_matches'][0]['code_to_runtime_link_proven'] is False
    context['apk_sha256']='different'
    with pytest.raises(AuditError,match='APK differ'):
        plan_from_evidence(baseline,context)


def test_server_distinguishes_HEAD_and_GET_and_rejects_other_paths():
    server = FeedServer();server.start()
    try:
        url = f"http://127.0.0.1:{server.port}/feed/" + "a"*32 + ".xml"
        with urllib.request.urlopen(urllib.request.Request(url, method="HEAD")) as response:
            assert response.read() == b"" and int(response.headers["Content-Length"]) > 0
        with urllib.request.urlopen(url) as response:
            assert b"Controlled empty feed" in response.read()
        events = server.snapshot()
        assert len(events) == 2 and events[0]["body_bytes"] == 0 and events[1]["body_bytes"] > 0
        assert all(r["write_completed"] for r in events)
        with pytest.raises(urllib.error.HTTPError):
            urllib.request.urlopen(f"http://127.0.0.1:{server.port}/unregistered")
    finally:
        server.close()
