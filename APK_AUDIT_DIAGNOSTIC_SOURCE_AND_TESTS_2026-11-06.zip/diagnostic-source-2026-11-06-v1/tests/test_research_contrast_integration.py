"""Synthetic device trace plus actual host HTTP server, never Android execution."""
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import struct
import urllib.request

import dpkt
import pytest

from apk_audit.core import AuditError, add_evidence, new_run, read_json, sha256, write_json, write_jsonl
from apk_audit.research_contrast import run_live
from apk_audit.research_diagnosis import assess
from apk_audit.research_bundle import restore


def synthetic_trial(apk, out, scenario, missing_request=False, uid=10213):
    out = Path(out)
    run = new_run(out, apk)
    run.update(package="de.danoeh.antennapod", target_uid=10213, bridge_uid=10212, control_port=8765,
               static_status="completed", dynamic_status="partial", analysis_mode="live", execution_status="completed",
               analysis_scenario=scenario, run_kind="synthetic_unit_test_not_device_evidence")
    write_json(out / "run.json", run)
    write_json(out / "static.json", {})
    write_json(out / "raw/installation-identity.json", {"package": run["package"], "uid": 10213, "apk_sha256": run["apk_sha256"]})
    trace = [{"action": "get_status", "result": {"running": False}},
             {"action": "start", "result": {"result_code": -1}}, {"action": "get_status", "result": {"running": True}},
             *[{"action": "probe", "request_id": r, "result": {"http_status": 200}} for r in ("pre", "post")],
             {"action": "stop", "result": {"result_code": -1}}, {"action": "get_status", "result": {"running": False}}]
    write_json(out / "raw/bridge-results.json", trace)
    write_jsonl(out / "raw/automatic-controls.jsonl", [{"event": "http_request_received", "run_id": r, "method": "GET"} for r in ("pre", "post")])
    write_jsonl(out / "flows.jsonl", [{"uid": 10212, "port": 8765, "destination_ip": "10.0.2.2", "application_protocol": "http"} for _ in range(2)])
    step = scenario["steps"][1]
    started = datetime.now(timezone.utc)
    write_jsonl(out / "ui_events.jsonl", [{"action": "open_uri", "uri": step["uri"], "success": True,
                                           "started_utc": started.isoformat(), "ended_utc": (started + timedelta(seconds=step["observe_s"])).isoformat()}])
    from urllib.parse import urlsplit
    url = urlsplit(step["uri"])
    request_time = datetime.now(timezone.utc).timestamp()
    if not missing_request:
        with urllib.request.urlopen(step["uri"].replace("10.0.2.2", "127.0.0.1")) as response:
            response.read()
    write_json(out / "automatic.metadata.json", {"clock_offset_s": 0})
    with (out / "raw/automatic.pcap").open("wb") as stream:
        writer = dpkt.pcap.Writer(stream)
        if not missing_request:
            data = ("GET " + url.path + " HTTP/1.1\r\nHost: 10.0.2.2\r\n\r\n").encode()
            tcp = dpkt.tcp.TCP(sport=45000, dport=url.port, data=data)
            ip = dpkt.ip.IP(src=b'\x0a\xd7\xad\x01', dst=b'\x0a\x00\x02\x02', p=6, data=tcp)
            ip.len = len(ip)
            frame = b'\0'*12 + b'\x08\x00' + bytes(ip)
            frame += b'\0' * (-len(frame) % 4) + struct.pack('!Ii20sI', 0x01072021, uid, b'test', 0)
            writer.writepkt(frame, ts=request_time)
    add_evidence(out, "test-pcap", out / "raw/automatic.pcap", "synthetic unit-test packet")
    return {"counts": {}, "error": None}, 0


@pytest.fixture
def synthetic_study(tmp_path, monkeypatch):
    import argparse
    import apk_audit.pipeline as pipeline
    import apk_audit.research_contrast as contrast
    apk = tmp_path / "synthetic-input.bin";apk.write_bytes(b"not-an-APK: synthetic test only")
    def fake_context(apk, out):
        result = {"profile": "synthetic-unit-test", "records": [], "apk_sha256": sha256(apk)}
        write_json(out, result);return result
    monkeypatch.setattr(contrast, "scan_bounded", fake_context)
    monkeypatch.setattr(pipeline, "analyze", lambda a: synthetic_trial(a.apk, a.out, read_json(a.scenario)))
    baseline=tmp_path/'baseline';run=new_run(baseline,apk)
    run.update(package='de.danoeh.antennapod',dynamic_status='partial',analysis_scenario={'steps':[{'action':'open_uri'}]})
    write_json(baseline/'run.json',run);write_json(baseline/'correspondence.json',{'counts':{'dynamic_only':1}})
    args = argparse.Namespace(out=tmp_path / "study", apk=apk, package="de.danoeh.antennapod",baseline_run=baseline,
        activity="de.danoeh.antennapod/.ui.screen.onlinefeedview.OnlineFeedViewActivity", pairs=1, budget=2,
        observe_s=1, serial="emulator-5554", snapshot=None, non_interactive=True)
    return args


def test_end_to_end_contrast_and_return_archive(synthetic_study, tmp_path):
    result, code = run_live(synthetic_study)
    assert code == 0 and result["diagnosis"] == "input_endpoint_association_observed"
    assert not result["causal_root_proven"] and result["remaining_hypotheses"]
    assert all(r["state_condition"] == "preserved_uncontrolled" for r in result["rows"])
    restored = restore(synthetic_study.out.with_suffix('.return.zip'), tmp_path / "restored")
    assert assess(restored) == result
    assert (restored / "diagnosis.html").is_file()


def test_missing_request_is_not_no_networking_or_independence(synthetic_study, monkeypatch):
    import apk_audit.pipeline as pipeline
    monkeypatch.setattr(pipeline, "analyze", lambda a: synthetic_trial(a.apk, a.out, read_json(a.scenario), missing_request=True))
    result, code = run_live(synthetic_study)
    assert result["diagnosis"] == "inconclusive" and result["remaining_hypotheses"]
    assert not result["supported_hypotheses"]


def test_post_capture_modification_refused(synthetic_study):
    run_live(synthetic_study)
    (synthetic_study.out / "trial-001-A/raw/automatic.pcap").write_bytes(b"modified")
    with pytest.raises(AuditError, match="modified"):
        assess(synthetic_study.out)


def test_unknown_packet_uid_does_not_become_target(synthetic_study, monkeypatch):
    import apk_audit.pipeline as pipeline
    monkeypatch.setattr(pipeline,"analyze",lambda a:synthetic_trial(a.apk,a.out,read_json(a.scenario),uid=-1))
    result,code=run_live(synthetic_study)
    assert result['diagnosis']=='inconclusive'
    assert all(not r['positive'] for r in result['rows'])


def test_budget_failure_does_not_touch_output(synthetic_study):
    synthetic_study.budget = 0
    with pytest.raises(AuditError, match="budget"):
        run_live(synthetic_study)
    assert not synthetic_study.out.exists()


def test_failed_pipeline_stops_later_conditions(synthetic_study, monkeypatch):
    import apk_audit.pipeline as pipeline
    def fail(a):
        result, _ = synthetic_trial(a.apk, a.out, read_json(a.scenario))
        return result, 4
    monkeypatch.setattr(pipeline, "analyze", fail)
    result, code = run_live(synthetic_study)
    assert code == 4 and result["recorded_trials"] == 1 and result["diagnosis"] == "inconclusive"
    assert not (synthetic_study.out / "trial-002-B").exists()
