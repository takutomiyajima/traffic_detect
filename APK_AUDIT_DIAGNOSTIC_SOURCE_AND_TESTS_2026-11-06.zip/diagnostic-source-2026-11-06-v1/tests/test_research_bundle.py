import json
from pathlib import Path
import zipfile

import pytest

from apk_audit.core import AuditError
from apk_audit.research_bundle import pack, restore


def test_apk_deduplication_and_byte_identical_restore(tmp_path):
    study=tmp_path/'study';study.mkdir()
    for name in ['A','B']:
        path=study/name/'raw';path.mkdir(parents=True)
        (path/'original.apk').write_bytes(b'synthetic identical APK bytes')
    (study/'result.json').write_text('{}')
    archive=pack(study)
    with zipfile.ZipFile(archive) as z:
        assert len([n for n in z.namelist() if n.startswith('shared/')])==1
    restored=restore(archive,tmp_path/'restored')
    for path in study.rglob('*'):
        if path.is_file():assert path.read_bytes()==(restored/path.relative_to(study)).read_bytes()


@pytest.mark.parametrize('bad_name',['../escape','/absolute','study/../../escape','study\\escape'])
def test_archive_path_rejected_before_any_writes(tmp_path,bad_name):
    archive=tmp_path/'unsafe.zip'
    with zipfile.ZipFile(archive,'w') as z:
        z.writestr(bad_name,b'bad');z.writestr('RETURN-MANIFEST.json','{}')
    dest=tmp_path/'restored'
    with pytest.raises(AuditError):restore(archive,dest)
    assert not dest.exists()
