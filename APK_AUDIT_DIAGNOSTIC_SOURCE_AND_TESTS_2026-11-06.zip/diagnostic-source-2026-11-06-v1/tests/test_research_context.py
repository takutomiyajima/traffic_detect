import pytest

from apk_audit.research_context import analyze_block

URL_API = "Ljava/net/URL;-><init>(Ljava/lang/String;)V"
LOC = {"dex": "classes.dex", "class": "Lfixture;", "method": "test", "descriptor": "()V", "block_start_bytes": 0}


def ins(op, offset, registers, **kwargs):
    return {"op": op, "offset": offset, "registers": registers, **kwargs}


def sink(register=1, offset=20):
    return ins("invoke-direct", offset, [0, register], method=URL_API)


def test_exact_argument_not_cooccurring_string():
    rows = analyze_block([ins("const-string", 0, [3], string="https://decoy.example.org"), sink()], LOC)
    assert rows[0]["status"] == "unresolved_argument" and rows[0]["endpoint"] is None


def test_moves_and_concat_keep_definition_offsets():
    rows = analyze_block([ins("const-string", 0, [1], string="https://"),
        ins("const-string", 2, [2], string="concat.example.org/path"),
        ins("invoke-virtual", 4, [1, 2], method="Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;"),
        ins("move-result-object", 6, [4]), ins("move-object/from16", 8, [1, 4]), sink()], LOC)
    assert rows[0]["endpoint"]["host"] == "concat.example.org"
    assert rows[0]["definition_offsets"] == [0, 2, 4]
    assert not rows[0]["execution_proven"] and not rows[0]["transmission_proven"]


def test_each_block_starts_unknown():
    analyze_block([ins("const-string", 0, [1], string="https://branch.example.org")], LOC)
    assert analyze_block([sink()], LOC)[0]["status"] == "unresolved_argument"


@pytest.mark.parametrize("op", ["iget-object", "sget-object", "aget-object", "const/4", "invoke-custom"])
def test_unknown_write_or_call_result_never_reuses_constant(op):
    instructions = [ins("const-string", 0, [1], string="https://old.example.org")]
    if op.startswith("invoke"):
        instructions += [ins(op, 2, [], method="unknown"), ins("move-result-object", 4, [1])]
    else:
        instructions += [ins(op, 2, [1])]
    assert analyze_block(instructions + [sink()], LOC)[0]["status"] == "unresolved_argument"


def test_builder_alias_mutation_and_escape():
    prefix = [ins("new-instance", 0, [1], type="Ljava/lang/StringBuilder;"),
        ins("invoke-direct", 2, [1], method="Ljava/lang/StringBuilder;-><init>()V"),
        ins("move-object", 4, [2, 1]), ins("const-string", 6, [3], string="https://builder.example.org"),
        ins("invoke-virtual", 8, [2, 3], method="Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;")]
    finish = [ins("invoke-virtual", 12, [1], method="Ljava/lang/StringBuilder;->toString()Ljava/lang/String;"),
              ins("move-result-object", 14, [4]), sink(4)]
    assert analyze_block(prefix + finish, LOC)[0]["endpoint"]["host"] == "builder.example.org"
    escape = [ins("invoke-static", 10, [2], method="Lother;->mutate(Ljava/lang/StringBuilder;)V")]
    assert analyze_block(prefix + escape + finish, LOC)[0]["status"] == "unresolved_argument"


def test_runtime_source_is_symbolic_not_a_known_endpoint():
    rows = analyze_block([ins("invoke-virtual", 0, [2], method="Landroid/content/Intent;->getDataString()Ljava/lang/String;"),
                          ins("move-result-object", 2, [1]), sink()], LOC)
    assert rows[0]["status"] == "runtime_value_argument" and rows[0]["value"] is None
    assert rows[0]["runtime_origins"] == ["intent_data"]


def test_constant_non_url_is_not_a_resolved_destination():
    row = analyze_block([ins("const-string", 0, [1], string="not a URL"), sink()], LOC)[0]
    assert row["status"] == "constant_non_url_argument" and row["endpoint"] is None
