# 研究発表・進捗報告の2種類

2026年11月5日時点の既存25試行と論文に基づく資料です。

- RESEARCH_PRESENTATION: 17枚。研究目的、システム、不確実性、評価方法、結果、先行研究、貢献と限界。約15分の発表を想定。
- PROGRESS_PRESENTATION: 10枚。目的、システムの範囲、RSSの具体例、訂正点、現在の結論、次の行動。約7〜10分の進捗報告を想定。

各PPTXは編集可能です。図や表もPowerPointの図形・テキストです。発表者ノートに説明と出典を入れ、同じ内容をNOTES.mdにも保存しました。PDFは閲覧・共有用です。表紙には必要に応じて発表者名・所属を追記してください。

Presentationsプラグインのツールはこのセッションで利用できなかったため、python-pptxで作成しLibreOfficeでPDF化しました。Presentationsで生成したとは表記しません。日本語フォントはNoto Sans CJK JPです。PowerPointでフォントが置換される場合はPDFを参照し、必要に応じて日本語フォントへ変更してください。

25は端末試行数で、25アプリや精度100%の意味ではありません。19試行の3方式比較と25試行の出力再現点検を区別しています。全取得品質partial、公開アプリ1本、独立人手評価なし、方法上の新規性未確立という範囲を維持しています。元APK・PCAP・通信本文ログ・人手ラベルは同梱しません。

再生成用のソースと入力スナップショットも同梱しています。Python、python-pptx、Pillow、LinuxのNoto CJK Regular/Boldフォントを使います。`python source/build_research_presentations.py --data-dir source/input --out generated` でPPTXとノートを作成できます。PDF化にはLibreOfficeが必要です。PPTXを編集・PDFを閲覧するだけなら再生成環境は不要です。
