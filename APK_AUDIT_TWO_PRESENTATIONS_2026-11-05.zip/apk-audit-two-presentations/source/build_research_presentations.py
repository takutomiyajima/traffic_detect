#!/usr/bin/env python3
"""Create two editable Japanese research decks from the checked study snapshot."""
import argparse
import csv
import json
from pathlib import Path
from PIL import ImageFont
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.xmlchemy import OxmlElement
from pptx.util import Inches, Pt

ROOT = Path(__file__).resolve().parents[1]
FONT = 'Noto Sans CJK JP'
FONT_DIR = Path('/usr/share/fonts/opentype/noto')
C = dict(bg='F7F8FA', navy='132A3A', teal='147D88', ink='203A4A', muted='5A6E7F',
         line='D7E1E7', white='FFFFFF', mint='E6F3F1', sand='FCF0DE', gold='A76A17',
         red='B2493E', rose='FAEBE7', blue='EAF0F8')
W, H = 13.333333, 7.5


def rgb(name):
    return RGBColor.from_string(C.get(name, name))


def font(size, bold=False):
    return ImageFont.truetype(str(FONT_DIR/('NotoSansCJK-Bold.ttc' if bold else 'NotoSansCJK-Regular.ttc')), round(size*4))


def wrap(text, width, size, bold=False):
    face = font(size, bold); limit = (width*72-5)*4
    lines = []
    for paragraph in str(text).split('\n'):
        current = ''
        for ch in paragraph:
            if current and face.getlength(current+ch) > limit:
                lines.append(current); current = ch
            else:
                current += ch
        lines.append(current)
    return lines


class Deck:
    def __init__(self, stem, audience):
        self.stem, self.audience = stem, audience
        self.prs = Presentation(); self.prs.slide_width = Inches(W); self.prs.slide_height = Inches(H)
        self.prs.core_properties.title = audience
        self.prs.core_properties.subject = 'APK静的情報と実行時通信の対応説明・既存25試行の事例評価'
        self.prs.core_properties.author = 'APK Audit Research'
        self.prs.core_properties.language = 'ja-JP'
        self.slides = []; self.text_log = []

    def shape(self, x, y, w, h, fill='white', line=None, kind=MSO_SHAPE.ROUNDED_RECTANGLE):
        s = self.slide.shapes.add_shape(kind, Inches(x), Inches(y), Inches(w), Inches(h))
        s.fill.solid(); s.fill.fore_color.rgb = rgb(fill)
        if line:
            s.line.color.rgb = rgb(line); s.line.width = Pt(0.8)
        else:
            s.line.fill.background()
        if kind == MSO_SHAPE.ROUNDED_RECTANGLE:
            s.adjustments[0] = 0.12
        return s

    def text(self, x, y, w, h, value, size=22, color='ink', bold=False, align=PP_ALIGN.LEFT, min_size=None):
        requested = size
        while True:
            lines = wrap(value, w, size, bold)
            needed = len(lines)*size*1.18/72+0.04
            if needed <= h:
                break
            if min_size is None or size <= min_size:
                raise ValueError(f'Text too high: {self.stem} slide {len(self.slides)} {value!r} needs {needed:.2f}, has {h}')
            size -= 1
        box = self.slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        tf = box.text_frame; tf.clear(); tf.word_wrap = False
        tf.margin_left = tf.margin_right = Inches(0.025)
        tf.margin_top = tf.margin_bottom = Inches(0.015)
        tf.vertical_anchor = MSO_ANCHOR.TOP
        for n, line in enumerate(lines):
            p = tf.paragraphs[0] if n == 0 else tf.add_paragraph()
            p.alignment = align; p.space_before = p.space_after = Pt(0); p.line_spacing = 1.18
            run = p.add_run(); run.text = line
            run.font.name = FONT; run.font.size = Pt(size); run.font.bold = bold; run.font.color.rgb = rgb(color)
            rpr = run._r.get_or_add_rPr()
            ea = OxmlElement('a:ea'); ea.set('typeface', FONT); rpr.append(ea)
        self.text_log.append({'slide':len(self.slides), 'text':str(value), 'size_pt':size,
                              'requested_size_pt':requested,'lines':len(lines),'box':[x,y,w,h]})
        return box

    def slide_new(self, title, section, source, notes='', dark=False):
        self.slide = self.prs.slides.add_slide(self.prs.slide_layouts[6])
        self.slide.background.fill.solid(); self.slide.background.fill.fore_color.rgb = rgb('navy' if dark else 'bg')
        self.slides.append({'title':title,'section':section,'source':source,'notes':notes,'dark':dark})
        self.text(.55,.2,11.8,.24,'APK AUDIT  /  '+section,10,'mint' if dark else 'teal',True)
        if not dark:
            self.text(.55,.72,12.1,1.12,title,30,'navy',True,min_size=27)
            self.shape(.58,1.91,.65,.055,'teal',kind=MSO_SHAPE.RECTANGLE)
        self.slide.notes_slide.notes_text_frame.text = ('発表者メモ\n'+notes+'\n\n出典・確認範囲\n'+source+
            '\n\n共通条件：2026年11月5日時点。追加実験を行ったという資料ではない。試行数・フロー・要求数を区別する。')
        return self

    def footer(self):
        total = len(self.slides)
        for n, (slide, info) in enumerate(zip(self.prs.slides,self.slides),1):
            self.slide = slide
            self.shape(.55,7.04,12.2,.01,'muted' if info['dark'] else 'line',kind=MSO_SHAPE.RECTANGLE)
            self.text(.56,7.15,11.6,.2,info['source'],8,'line' if info['dark'] else 'muted')
            self.text(12.15,7.12,.6,.25,f'{n:02d} / {total:02d}',10,'white' if info['dark'] else 'muted',align=PP_ALIGN.RIGHT)

    def card(self,x,y,w,h,title,body,fill='white',body_size=22):
        self.shape(x,y,w,h,fill)
        self.text(x+.22,y+.18,w-.44,.52,title,17,'teal',True,min_size=15)
        self.text(x+.22,y+.85,w-.44,h-1.02,body,body_size,min_size=max(17,body_size-3))

    def banner(self,value,y=6.13,fill='mint',color='teal',size=20):
        self.shape(.58,y,12.16,.63,fill)
        self.text(.8,y+.13,11.72,.42,value,size,color,True,min_size=17)

    def arrow(self,x,y,w=.28,h=.38):
        self.shape(x,y,w,h,'teal',kind=MSO_SHAPE.CHEVRON)

    def table(self, headers, rows, widths, x=.58, y=2.22, row_h=.67, font_size=18):
        cur=x
        for head,width in zip(headers,widths):
            self.shape(cur,y,width-.025,.57,'navy',kind=MSO_SHAPE.RECTANGLE)
            self.text(cur+.12,y+.12,width-.25,.4,head,16,'white',True,min_size=14);cur+=width
        for i,row in enumerate(rows):
            cur=x
            for value,width in zip(row,widths):
                self.shape(cur,y+.6+i*row_h,width-.025,row_h-.03,'white' if i%2==0 else 'blue',kind=MSO_SHAPE.RECTANGLE)
                self.text(cur+.12,y+.7+i*row_h,width-.25,row_h-.2,value,font_size,min_size=16);cur+=width

    def save(self,out):
        self.footer();out.mkdir(parents=True,exist_ok=True)
        self.prs.save(out/(self.stem+'.pptx'))
        (out/(self.stem+'-notes.md')).write_text('# '+self.audience+'\n\n'+''.join(
            f'## {n}. {s["title"]}\n\n{s["notes"]}\n\n出典：{s["source"]}\n\n' for n,s in enumerate(self.slides,1)),encoding='utf-8')
        (out/(self.stem+'-content.json')).write_text(json.dumps({'slides':self.slides,'text_layout':self.text_log},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def cover(d,title,subtitle,kicker,notes):
    d.slide_new(title,'RESEARCH' if d.stem.startswith('research') else 'PROGRESS','2026年11月5日時点｜既存25試行・AI支援による点検',notes,True)
    d.shape(.58,1.34,.12,4.9,'teal',kind=MSO_SHAPE.RECTANGLE)
    d.text(.98,1.36,11.15,.5,kicker,18,'mint',True)
    d.text(.98,2.05,11.15,1.85,title,37,'white',True,min_size=33)
    d.text(1.0,4.12,10.9,.9,subtitle,23,'line',min_size=21)
    for x,num,label in [(1.0,'25','端末試行'),(4.75,'1','公開アプリ'),(8.5,'AI','原本・結果の点検')]:
        d.shape(x,5.45,3.35,.95,'ink');d.text(x+.2,5.6,1.0,.55,num,28,'white',True);d.text(x+1.2,5.75,1.94,.45,label,16,'line',min_size=15)


def architecture(d, simple=False):
    y=2.3
    d.card(.58,y,2.55,2.64,'入力','APK\n操作シナリオ\n任意の条件',body_size=22)
    d.arrow(3.26,3.45)
    for yy,title,body,fill in [(y,'静的解析','権限・設定・URL候補','mint'),
                               (y+1.43,'動的観測','指定操作中の通信','blue')]:
        d.shape(3.65,yy,3.12,1.22,fill)
        d.text(3.85,yy+.15,2.72,.4,title,18,'teal',True)
        d.text(3.85,yy+.65,2.72,.4,body,18,min_size=17)
    d.arrow(6.9,3.45)
    d.card(7.3,y,2.5,2.64,'比較・状態整理','対応する？\n実測だけ？\n判断できる？',body_size=22)
    d.arrow(9.94,3.45)
    d.card(10.35,y,2.39,2.64,'説明と根拠','比較レポート\n証拠索引\n原本への参照',body_size=21)
    d.banner('対象は指定した操作と観測窓。すべての画面・通信を自動探索する仕組みではない。',y=5.6,size=19)


def research_deck():
    d=Deck('research-overview','研究内容とこれまでの取り組み｜研究発表用')
    cover(d,'APKの静的情報と実行時通信を\n証拠に基づいて説明する','解析支援システムの設計と、既存25試行による事例評価','研究内容・手法・結果・限界',
          '約15分を想定。発表者名・所属は利用前に追加する。目的は安全判定の万能化ではなく、指定操作下で言えることと言えないことを説明すること。')
    d.slide_new('URL候補があることと、通信したことは違う','01 / 背景','出典：論文草稿・AntennaPod通常起動／RSS事例',
                '静的解析は候補、動的観測は実行条件に依存した記録。同じ数にそろわないのは自然で、差を直ちに異常としない。')
    d.card(.58,2.25,3.87,3.32,'静的情報','APKに含まれる候補\n\n実行されたかは\n別に確認する',fill='mint')
    d.card(4.73,2.25,3.87,3.32,'実行時の通信','操作中に観測した記録\n\n全機能を網羅しない',fill='blue')
    d.card(8.88,2.25,3.87,3.32,'不足する情報','帰属・時刻・取得範囲\n\n推測で埋めない',fill='sand')
    d.banner('必要なのは、候補・実測・不足を区別して説明すること。')
    d.slide_new('研究目的は「比較説明」と「根拠の追跡」','02 / 研究課題','出典：研究デザイン RQ1–RQ3',
                '3つの問いを分ける。性能改善や全アプリの安全性は問いに含めない。明示ポリシーは利用者または研究者の宣言で、開発者の心理的意図ではない。')
    for y,rq,body in [(2.22,'RQ1','指定範囲の解析を実行し、失敗した段階も説明できるか'),(3.4,'RQ2','静的のみ・動的のみ・併用で、説明できる範囲はどう違うか'),(4.58,'RQ3','不明・未観測・取得失敗を、根拠のない断定へ変換しないか')]:
        d.shape(.58,y,1.23,.94,'teal');d.text(.75,y+.2,.95,.53,rq,25,'white',True)
        d.shape(2.0,y,10.74,.94,'white');d.text(2.25,y+.18,10.2,.6,body,23,min_size=21)
    d.banner('「比較できること」と「ポリシー違反を判定できること」は別。')
    d.slide_new('APK入力から説明レポートまでをつなぐ','03 / システム構成','出典：実装モジュール・現在のシステム構成図',
                'Python実装。ADBで選定AVD上のシナリオを実行し、PCAPdroidの取得原本を正規化する。同意画面は実施者が確認。参照サーバーとの突合はケース検証であり、一般的な全ログ自動結合ではない。')
    architecture(d)
    d.slide_new('1件の通信でも、4つの状態を分ける','04 / 不確実性の扱い','出典：状態モデル・照合規則 C02／C05／C07',
                '通信そのものの観測、対象アプリへの帰属、取得内容の可視性、証拠範囲の判定を独立に表す。unknownだから通信なし、HTTPが見えたから安全、と短絡しない。')
    for x,title,body,fill in [(0.58,'観測','通信試行／接続\nHTTP／未観測\n取得失敗','mint'),(3.72,'帰属','対象／別UID\n不明','blue'),(6.86,'可視性','メタデータ\n確認できた範囲','sand'),(10.0,'判定','整合／不一致候補\n要確認／評価不能','white')]:
        d.card(x,2.4,2.74,3.13,title,body,fill,20)
    d.banner('例：通信は見えても、対象アプリのものと確認できなければ保留する。',size=19)
    d.slide_new('25試行を、役割ごとに分けて評価する','05 / データと研究デザイン','出典：既存25試行の台帳（trials-25.csv）',
                '新しい前向き評価への読み替えはせず、事後的事例研究とする。25は独立したアプリ数ではない。全取得品質はpartial。19/25を感度や精度として用いない。')
    d.table(['データ群','試行数','評価上の役割'],[['初期CSV制御','13','HTTP・UDP・通信なし'],['追加制御','6','HTTP処理不成功・専用信頼HTTPS'],['自動HTTP PCAP','1','自動取得から比較までの経路'],['公開アプリ起動','1','実アプリの起動窓'],['公開アプリRSS','4','表示・追加操作・状態記録の事例']],[3.25,1.4,7.5],row_h=.57,font_size=18)
    d.banner('単一AVD・公開アプリ1本・全品質partial。一般精度の標本ではない。',y=6.17,size=19)
    d.slide_new('比較するのは、同じ証拠から得られる説明','06 / 評価手法','出典：3方式比較・UID構成要素比較',
                'S/D/SDには同じ取得条件を使う。外部資料をSDだけに足して効果を主張しない。UIDを外す方式は人工的アブレーションで、PCAPdroidやMobSFの実挙動ではない。')
    d.card(.58,2.24,3.86,2.54,'S：静的のみ','APK内の宣言・候補\n通信の実行は断定しない','mint',22)
    d.card(4.73,2.24,3.86,2.54,'D：動的のみ','指定窓の通信と取得条件\n静的な候補は分からない','blue',22)
    d.card(8.88,2.24,3.86,2.54,'SD：併用','両方の根拠を並べて対応\n差と不足を説明する','white',22)
    d.text(.72,5.05,11.9,.8,'別の比較：UID不明を「保持」「削除」「UID条件だけ除去」した場合の出力差',22,min_size=20)
    d.banner('原本・画面・サーバー記録を、解釈の検証資料として使う。',size=20)
    d.slide_new('自動HTTPでは、対応あり1・静的候補のみ1','07 / 制御実験の結果','出典：auto-http-002 原本検証・correspondence.json',
                '対象UIDのPOSTはパケット32、200応答は34。対象1フローを確認。静的候補docs.example.orgは実測に対応しない候補。ポリシー未指定なのでneeds_review。200はアプリが全本文を消費した証明ではない。')
    d.card(.58,2.3,5.9,2.9,'対応あり：1','APK内の宛先候補\n＋ 対象UIDのHTTP通信\n→ 対応する根拠を提示','mint',23)
    d.card(6.77,2.3,5.97,2.9,'静的候補のみ：1','APK内の別の候補\n→ この窓では対応未観測\n→ 未使用とは断定しない','blue',23)
    d.banner('取得・比較の経路は成立。ただし未指定ポリシーは「要確認」のまま。',size=19)
    d.slide_new('公開アプリでは、静的候補と実測の範囲が違う','08 / AntennaPodの事例','出典：AntennaPod 3.12.3 起動001／RSS006',
                '両者は同じAPKだが操作と初期状態は同一ではない。起動で通信しないことを証明したわけではない。実行時のローカルRSS宛先はAPKの固定文字列にないため動的のみになる。')
    d.table(['項目','通常起動','RSSプレビュー006'],[['静的な宛先候補','38組','38組'],['対象UIDのフロー','0','2'],['対象の実測宛先','未観測','ローカルの1組'],['読み取れること','候補と実測は別','実行時入力の宛先を観測']],[3.35,3.7,5.1],row_h=.77,font_size=21)
    d.banner('「動的のみ」は異常の意味ではない。実行時入力でも自然に生じる。',size=19)
    d.slide_new('HEADとGETを区別すると、結果の意味が変わる','09 / 通信の具体的な読み方','出典：RSS001・RSS006の限定HTTP本文検査',
                '006のRSS GET本文679 B、音声HEAD本文0 B。Content-Length16,044はGET時の表現サイズ。001の音声GET16,044 Bは購読・再生を含む申告下の事例。試行差の原因を操作だけに確定しない。')
    d.card(.58,2.24,5.9,2.53,'RSS006：表示の事例','RSS GET：679 B\n音声HEAD：本文0 B\n音声GET：保持記録では未観測','mint',23)
    d.card(6.77,2.24,5.97,2.53,'RSS001：追加操作を含む','RSS本文：679 B\n音声GET本文：16,044 B\n購読・再生等の申告あり','blue',23)
    d.text(.77,5.03,11.8,.68,'音声HEADの Content-Length 16,044 ≠ 音声本文を16,044 B受信',24,'gold',True,min_size=21)
    d.banner('本文hashは保持バイトの一致。アプリの処理・再生完了までは保証しない。',size=19)
    d.slide_new('UID不明4単位は、扱い方で説明が変わる','10 / 不確実性の構成要素比較','出典：13試行のUIDアブレーション（117出力、追加試行0）',
                '対象は選定された不明4単位。元の許可条件と事後の禁止条件を区別。UID条件を除去しても未指定条件では要確認になる。未支持の仮定であり、独立真値に対する4誤検出と呼ばない。')
    d.table(['方式','元の許可条件','事後の禁止条件'],[['不明を保持','4件を評価不能','4件を評価不能'],['不明行を削除','4件の記録が消える','4件の記録が消える'],['UID条件だけ除去','4件を整合扱い','4件を不一致候補扱い']],[3.4,4.4,4.35],row_h=.9,font_size=21)
    d.banner('削除は情報欠落、条件除去は未確認の対象帰属を追加。外部ツールの誤検出率ではない。',y=6.2,size=18)
    d.slide_new('再現性の確認と、意味の正しさは別に点検する','11 / AIによる結果点検','出典：AI原本点検4事例・保存入力の再生成25試行',
                '規則判定25件は保存値と一致。対応表は制御19件で件数、PCAP6件で主要フィールドを比較。E02の古いunknownも同じ入力なら再現するため、生PCAPのUID照合が必要。人手一致率は計算しない。')
    d.card(.58,2.3,5.9,2.8,'出力の整合性','25試行の規則判定を再生成\n対応表も照合範囲で一致\n原本の変更なし','mint',23)
    d.card(6.77,2.3,5.97,2.8,'原本による解釈の点検','公開起動の旧版にUID保持不具合\n原本と訂正版を区別\n同じ出力＝正しい、ではない','sand',22)
    d.banner('AI支援による点検。独立した人手評価・一般精度の検証ではない。',size=20)
    d.slide_new('制御19試行で、動的のみと併用の判定は一致した','12 / 比較結果の解釈','出典：元の取得条件の19試行・57処理結果',
                '一致は選定通信の判定・観測・帰属・可視性等の対象列について。レポート全体の同一性ではない。残る6試行を3方式比較済みへ数えない。併用の情報整理と精度改善を分ける。')
    d.text(.72,2.28,11.9,1.0,'今回、判定精度の向上は示していない。',33,'navy',True,min_size=30)
    d.card(.58,3.62,5.9,1.84,'確認できたこと','静的候補と実測を同じ説明の中で追跡できる','mint',23)
    d.card(6.77,3.62,5.97,1.84,'まだ示していないこと','未知アプリへの精度・安全性・作業時間削減','blue',23)
    d.banner('成果は、指定範囲の説明・根拠・限界を対応させた実装と事例評価。',size=19)
    d.slide_new('先行研究との差は、対象と設計範囲として述べる','13 / 関連研究','出典：PoliCheck 2020／PoliGraph 2023／PurPliance 2021／DroidBot 2017',
                'PoliCheck entityは受信組織で、送信元UIDとは異なる。PoliGraphには未指定ノードと元文保存がある。unknown、証拠追跡、自動操作自体を新規としない。性能比較は未実施。')
    d.table(['先行研究','主に扱う対象','本研究との関係'],[['PoliCheck','受信主体・データ型とポリシー','UID帰属とは異なる概念'],['PoliGraph','文をまたぐ知識グラフ・根拠文','未指定・根拠追跡は既存'],['PurPliance','データ利用目的の整合性','本実装は目的を推定しない'],['DroidBot','UIに基づく入力生成','自動操作自体は先行技術']],[2.55,4.4,5.2],row_h=.78,font_size=19)
    d.banner('独自アルゴリズムの新規性は未確立。具体的な実装と事例評価に限定する。',size=18)
    d.slide_new('本研究の貢献と、適用の限界','14 / まとめる範囲','出典：論文の考察・制約・主張と証拠の対応表',
                '制御素材は設計者自身が作成。公開アプリは1本、単一AVD、全取得品質partial。AI点検は同じ実装と資料に依存。これらは評価不能という意味でなく、主張の境界を定める。')
    d.card(.58,2.25,5.9,3.35,'具体的な成果','指定操作の解析パイプライン\n候補・実測・不足の比較説明\n原本・コード版・操作の追跡','mint',24)
    d.card(6.77,2.25,5.97,3.35,'限界','単一AVD・公開アプリ1本\n全取得品質partial\n独立人手評価・一般精度は未検証','sand',23)
    d.banner('自然言語ポリシー解析・全機能探索・通信網羅性・安全認証は対象にしない。',size=18)
    d.slide_new('結論：証拠から言える範囲を明確にする','15 / 結論と今後','出典：既存25試行の事後的事例評価',
                '研究の結論を一文で述べる。次は内容・著者情報・提出様式・研究の位置付けの確認。別アプリ、状態統制、独立評価は将来の適用範囲を調べる課題。追加15試行を現在の必須条件へ戻さない。')
    d.text(.75,2.3,11.8,1.12,'対応・差分・判断不能を、\n原本に戻れる形で説明する仕組みを実装した。',29,'navy',True,min_size=27)
    d.card(.58,3.92,5.9,1.8,'現在の次工程','原稿の内容確認・著者情報・提出形式の反映','mint',22)
    d.card(6.77,3.92,5.97,1.8,'将来の検証','別アプリ・状態統制・独立した説明評価','blue',22)
    d.banner('結論は選定した条件に限定する。整合性は安全性の保証ではない。',size=19)
    d.slide_new('主な出典とデータの所在','APPENDIX / REFERENCES','出典：提供論文本文・研究台帳・公開配布版',
                '発表後の質問用。本文・集計CSV・TeXを含む配布版のcommitを確認する。元APK/PCAPは公開配布物に含めない。')
    refs=[('PoliCheck','Andow et al., USENIX Security 2020, pp.985–1002.'),('PoliGraph','Cui et al., USENIX Security 2023, pp.1037–1054.'),('PurPliance','Bui et al., CCS 2021. DOI: 10.1145/3460120.3484536'),('DroidBot','Li et al., ICSE Companion 2017.'),('研究データ','既存25試行台帳／AI点検表／19試行3方式比較／UID条件比較')]
    for i,(name,body) in enumerate(refs):
        d.text(.7,2.22+i*.68,2.05,.42,name,19,'teal',True)
        d.text(2.95,2.22+i*.68,9.7,.5,body,19,min_size=17)
    d.text(.7,5.93,12,.64,'論文・集計データ：takutomiyajima/traffic_detect\n配布版 commit：4a7f1ead6e97c53d23be2f9d0f6008c5bb6a5f4a',15,'muted',min_size=14)
    return d


def progress_deck():
    d=Deck('progress-report','研究進捗報告｜目的と結果が伝わる説明用')
    cover(d,'「APKに書かれた候補」と\n「実際に見えた通信」を比べる','いま分かること、まだ分からないことを説明する研究','進捗報告｜説明用',
          '約7〜10分を想定。細かい判定式より、研究の目的と実例を先に伝える。25は端末での試行回数で、25アプリの評価ではない。')
    d.slide_new('知りたいのは「この差をどう読めばよいか」','01 / 目的','出典：研究目的・公開アプリのRSS事例',
                'APKはアプリの配布ファイル。中のURL候補を調べるだけでは、実際に通信したか分からない。操作して初めて渡すURLもある。')
    d.card(.58,2.3,5.9,2.8,'ファイルを調べる','アプリ内にURL候補がある\n→ 使われたとは限らない','mint',27)
    d.card(6.77,2.3,5.97,2.8,'実行して観測する','操作中の通信が見える\n→ アプリ全体は分からない','blue',27)
    d.banner('両方を見て、分かることと分からないことを整理する。',size=23)
    d.slide_new('いまは、APK入力から比較レポートまで動く','02 / システムのできること','出典：実装と自動HTTP・AntennaPodの取得記録',
                'APK・操作シナリオを与え、選定エミュレータで取得する。初回同意画面は人が確認する。すべての画面を自動操作するものではない。')
    architecture(d,True)
    d.slide_new('実験は25試行。次は原稿を仕上げる段階','03 / 進捗の全体像','出典：既存25試行台帳｜独立した25アプリではない',
                '同じセットアップの繰り返しは区切った。CSV制御19、自動HTTP1、公開アプリの起動1とRSS4。単一AVD、公開アプリ1本であり一般精度は示していない。')
    d.text(.7,2.23,3.2,1.35,'25',72,'teal',True)
    d.text(.77,3.64,3.0,.65,'保存済み端末試行',23,'navy',True)
    d.table(['取り組み','試行数'],[['初期のHTTP・UDP等','13'],['処理不成功・HTTPS','6'],['自動HTTP','1'],['公開アプリ起動／RSS','1 ＋ 4']],[6.6,1.7],x=4.45,y=2.28,row_h=.74,font_size=23)
    d.banner('「25回中何回安全だったか」を測った実験ではない。',size=23)
    d.slide_new('表示だけでも、音声の「情報確認」が起きた','04 / 分かりやすい実例','出典：AntennaPod RSS006｜限定HTTP本文検査',
                'プレビュー表示ではRSS本文679 Bと音声HEADを確認。HEADは音声の情報を問い合わせる要求で、音声本体をダウンロードしたことではない。')
    d.card(.58,2.23,3.86,3.15,'① フィードを開く','RSS GET\n\n本文679 Bを確認','mint',27)
    d.card(4.73,2.23,3.86,3.15,'② 音声情報を照会','音声HEAD\n\n応答本文は0 B','blue',27)
    d.card(8.88,2.23,3.86,3.15,'③ 結果を説明','音声GETは\n保持記録で未観測','sand',27)
    d.banner('画面の「16 kB」やContent-Lengthだけで、音声取得と決めない。',size=21)
    d.slide_new('「通信がない」と「分からない」を分ける','05 / この研究で大切にすること','出典：UID不明・対象未観測・取得品質の事例',
                '通信そのものがあっても、誰の通信か不明な場合がある。観測窓で対象通信が見えなくても、他の操作で通信する可能性がある。')
    for y,tag,body,fill in [(2.25,'帰属が不明','通信はあるが、対象アプリのものと確認できない','mint'),(3.5,'対象を未観測','この操作・時間では、対象の通信を確認できない','blue'),(4.75,'取得が不完全','記録が足りず、通信の有無を判断できない','sand')]:
        d.shape(.58,y,2.55,.95,fill);d.text(.78,y+.22,2.2,.52,tag,22,'teal',True)
        d.shape(3.36,y,9.38,.95,'white');d.text(3.57,y+.2,8.93,.59,body,25,min_size=23)
    d.banner('どれも、そのまま「安全」「違反」「通信しない」には置き換えない。',size=20)
    d.slide_new('原本を残したことで、過去の解釈を直せた','06 / 途中で分かったこと','出典：公開起動のUID訂正・RSS001の操作申告',
                '正規化不具合と、予定外の手動操作は別の問題。どちらも原本や申告を残すことで、結果の分類を訂正できた。今回新しく発見した2件という意味ではない。')
    d.card(.58,2.25,5.9,3.18,'起動ログの旧版','表示：帰属不明\n原本：別UIDでそろっていた\n→ UID保持の不具合を訂正','mint',25)
    d.card(6.77,2.25,5.97,3.18,'RSS001の操作','予定：表示だけ\n実際：購読・再生等の申告あり\n→ 追加操作を含む事例へ整理','blue',25)
    d.banner('結果だけでなく、元データと操作条件へ戻れることが重要。',size=23)
    d.slide_new('AIで結果を点検し、言い過ぎを避けている','07 / 現在の確認結果','出典：25試行の出力再生成・制御19試行の3方式比較',
                'AIによる再生成一致は、独立した精度ではない。19試行では動的のみと併用の判定が同じであり、精度向上は結果にしない。')
    d.card(.58,2.25,5.9,2.94,'確認できたこと','保存入力からの判定・対応表\n25試行で照合範囲が一致\n詳しく原本を点検：4事例','mint',24)
    d.card(6.77,2.25,5.97,2.94,'結論にしないこと','AI点検＝人の独立評価\n併用で判定精度が向上\nアプリ全体の安全を保証','sand',24)
    d.banner('現在の制御19試行では、動的のみと併用の選定通信の判定・状態が一致。',size=19)
    d.slide_new('成果は「根拠と限界が分かる説明」','08 / 現在の着地点','出典：結論・限界・先行研究との比較',
                '未知概念や最初の不明処理を提案する研究ではない。指定範囲の具体的なシステムと事例評価としてまとめる。単一AVD・公開アプリ1本・全partialの限界も説明する。')
    d.text(.75,2.25,11.8,1.2,'候補・実測・判断不能を、\n根拠付きで説明するシステムを作った。',32,'navy',True,min_size=30)
    d.card(.58,3.88,5.9,1.85,'いま示せる範囲','指定操作と既存25試行の事例','mint',25)
    d.card(6.77,3.88,5.97,1.85,'今後検証する範囲','別アプリ・状態統制・独立した評価','blue',25)
    d.banner('不明の区分・証拠追跡自体は先行研究にもある。新規性は限定して議論する。',size=18)
    d.slide_new('次は、内容確認と提出用の仕上げ','09 / 次の行動と相談事項','出典：現在の論文・データ配布版と次工程',
                '追加実験・人手CSV入力を今の必須工程へ戻さない。本人が目的・方法・結果・結論を理解して確認し、著者情報と提出形式を整える。指導教員にシステム設計と事例評価という位置付けを相談する。')
    for x,num,title,body in [(0.58,'1','本文の確認','実際の操作との一致\n説明の分かりやすさ'),(4.73,'2','提出形式の反映','著者情報・大学様式\n図表・引用の整合'),(8.88,'3','教員への相談','研究の主張範囲\n卒論に必要な水準')]:
        d.card(x,2.3,3.86,3.3,num+'  '+title,body,'white',25)
    d.banner('相談：この主張範囲でまとめることに、どこを補うべきか。',size=22)
    return d


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data-dir',type=Path,default=ROOT/'dist/current-paper-data-2026-11-05-v1')
    p.add_argument('--out',type=Path,default=ROOT/'docs/presentations/2026-11-05')
    args=p.parse_args();status=json.loads((args.data_dir/'RESEARCH-STATUS.json').read_text())
    assert status['device_trials']==25 and status['target_record_present']==19
    assert status['unknown_candidate']==4 and status['three_method_control_trials']==19
    assert status['human_annotations']==0 and status['novelty_established'] is False
    with (args.data_dir/'data/trials-25.csv').open(encoding='utf-8-sig',newline='') as f:
        trials=list(csv.DictReader(f));assert len(trials)==25
    decks=[research_deck(),progress_deck()]
    for d in decks:
        d.save(args.out)
        print(json.dumps({'file':str(args.out/(d.stem+'.pptx')),'slides':len(d.slides),'speaker_notes':True,'text_boxes':len(d.text_log)},ensure_ascii=False))
    (args.out/'DATA-STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':
    main()
