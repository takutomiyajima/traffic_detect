"""OS limit behavior simulated without changing this pytest process's limits."""
from types import SimpleNamespace

import pytest

from apk_audit import _worker as worker
from apk_audit.core import read_json


def test_darwin_does_not_call_nonportable_as_limit(monkeypatch):
    monkeypatch.setattr(worker.sys, 'platform', 'darwin')
    def forbidden(*args):
        raise AssertionError('Darwin must leave address-space limits unchanged')
    monkeypatch.setattr(worker.resource, 'setrlimit', forbidden)
    monkeypatch.setattr(worker.resource, 'getrlimit', forbidden)
    result = worker.configure_memory_limit()
    assert result['address_space']['status'] == 'not_enforced'
    assert 'parent_wall_clock_timeout' in result['other_guards']


@pytest.mark.parametrize('soft,hard,expected', [(-1,-1,3*1024**3), (1024**3,2*1024**3,1024**3), (-1,2*1024**3,2*1024**3), (4*1024**3,8*1024**3,3*1024**3)])
def test_linux_never_raises_an_inherited_limit(monkeypatch, soft, hard, expected):
    monkeypatch.setattr(worker.sys, 'platform', 'linux')
    monkeypatch.setattr(worker.resource, 'getrlimit', lambda which:(soft,hard))
    calls = []
    monkeypatch.setattr(worker.resource, 'setrlimit', lambda which, limits:calls.append(limits))
    result = worker.configure_memory_limit()
    assert calls == [(expected,hard)]
    assert result['address_space']['soft_bytes'] == expected


@pytest.mark.parametrize('platform,expected', [('darwin',4),('linux',4096)])
def test_rss_has_consistent_kib_units(monkeypatch, platform, expected):
    monkeypatch.setattr(worker.sys, 'platform', platform)
    monkeypatch.setattr(worker.resource, 'getrusage', lambda who:SimpleNamespace(ru_maxrss=4096))
    assert worker.peak_rss_kib() == expected


def test_darwin_worker_reaches_analysis_and_records_guard_status(monkeypatch, tmp_path):
    monkeypatch.setattr(worker.sys, 'platform', 'darwin')
    monkeypatch.setattr(worker.sys, 'argv', ['worker', 'test.apk', str(tmp_path)])
    def rejected(*args):
        raise ValueError('current limit exceeds maximum limit')
    monkeypatch.setattr(worker.resource, 'setrlimit', rejected)
    seen = []
    monkeypatch.setattr(worker, 'analyze', lambda *args:seen.append(args))
    assert worker.main() == 0
    result = read_json(tmp_path/'static-worker.json')
    assert seen and result['ok']
    assert result['resource_limits']['address_space']['status'] == 'not_enforced'


def test_linux_limit_failure_remains_an_error(monkeypatch, tmp_path):
    monkeypatch.setattr(worker.sys, 'platform', 'linux')
    monkeypatch.setattr(worker.sys, 'argv', ['worker', 'test.apk', str(tmp_path)])
    def rejected(*args): raise OSError('limit setup failed')
    monkeypatch.setattr(worker.resource, 'getrlimit', rejected)
    monkeypatch.setattr(worker, 'analyze', lambda *args:pytest.fail('Must not analyze after guard setup failure'))
    assert worker.main() == 4
    assert 'limit setup failed' in read_json(tmp_path/'static-worker.json')['error']
