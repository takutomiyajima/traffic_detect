"""Patch preserves old runs and refuses to overwrite unrelated modifications."""
import hashlib
import importlib.util
import json
from pathlib import Path

import pytest

spec = importlib.util.spec_from_file_location('macos_patch', Path(__file__).parents[1]/'tools/apply_macos_worker_fix.py')
patch = importlib.util.module_from_spec(spec)
spec.loader.exec_module(patch)


@pytest.fixture
def project_and_patch(tmp_path):
    project, package = tmp_path/'project', tmp_path/'patch'
    (project/'src/apk_audit').mkdir(parents=True)
    (package/'payload').mkdir(parents=True)
    old, fixed = b'VALUE = 1\n', b'VALUE = 2\n'
    (project/'src/apk_audit/_worker.py').write_bytes(old)
    (project/'pyproject.toml').write_text('[project]\n')
    (project/'runs/auto-http-001').mkdir(parents=True)
    (project/'runs/auto-http-001/run.json').write_text('failed-original')
    (package/'payload/_worker.py').write_bytes(fixed)
    (package/'PATCH-MANIFEST.json').write_text(json.dumps({'original_worker_sha256':hashlib.sha256(old).hexdigest(), 'fixed_worker_sha256':hashlib.sha256(fixed).hexdigest()}))
    return project, package


def test_patch_preserves_originals_and_is_idempotent(project_and_patch):
    project, package = project_and_patch
    assert patch.apply(project, package)['status'] == 'applied'
    assert (project/'src/apk_audit/_worker.py.before-macos-fix1').read_bytes() == b'VALUE = 1\n'
    assert (project/'runs/auto-http-001/run.json').read_text() == 'failed-original'
    assert patch.apply(project, package)['status'] == 'already_applied'


def test_patch_refuses_unknown_local_code(project_and_patch):
    project, package = project_and_patch
    target = project/'src/apk_audit/_worker.py'
    target.write_bytes(b'LOCAL = True\n')
    with pytest.raises(ValueError, match='differs'):
        patch.apply(project, package)
    assert target.read_bytes() == b'LOCAL = True\n'


def test_corrupt_patch_refused_before_backup_or_writes(project_and_patch):
    project, package = project_and_patch
    (package/'payload/_worker.py').write_text('corrupted')
    with pytest.raises(ValueError, match='hash mismatch'):
        patch.apply(project, package)
    assert not (project/'src/apk_audit/_worker.py.before-macos-fix1').exists()
