#!/usr/bin/env python3
"""Apply the packaged worker fix without changing experiments or dependencies."""
import argparse
import hashlib
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def apply(project, package):
    project, package = Path(project).resolve(), Path(package).resolve()
    manifest = json.loads((package/'PATCH-MANIFEST.json').read_text(encoding='utf-8'))
    source = package/'payload/_worker.py'
    target = project/'src/apk_audit/_worker.py'
    if target.is_symlink() or not target.is_file() or not (project/'pyproject.toml').is_file():
        raise ValueError('Specify the extracted apk-audit-unified-v1 project folder')
    original, fixed = target.read_bytes(), source.read_bytes()
    if digest(fixed) != manifest['fixed_worker_sha256']:
        raise ValueError('Patch payload hash mismatch; no files changed')
    compile(fixed, str(target), 'exec')
    current = digest(original)
    if current == manifest['fixed_worker_sha256']:
        return {'status':'already_applied', 'worker_sha256':current}
    if current != manifest['original_worker_sha256']:
        raise ValueError('Worker differs from the published v1; no files changed. Keep local modifications for review.')
    backup = target.with_name('_worker.py.before-macos-fix1')
    if backup.exists():
        if backup.read_bytes() != original:
            raise ValueError('Backup exists with different contents; no files changed')
    else:
        with backup.open('xb') as stream:
            stream.write(original)
    fd, temporary = tempfile.mkstemp(dir=target.parent, prefix='.worker-fix-')
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(fixed)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, target.stat().st_mode & 0o777)
        os.replace(temporary, target)
    finally:
        Path(temporary).unlink(missing_ok=True)
    receipt = {'status':'applied', 'patch_id':'macos-worker-fix1-2026-11-03',
               'applied_utc':datetime.now(timezone.utc).isoformat(), 'original_worker_sha256':current,
               'fixed_worker_sha256':digest(fixed), 'backup':str(backup.relative_to(project)),
               'experiment_files_changed':False, 'dependency_installation_required':False,
               'original_bundle_manifest_sha256':digest((project/'BUNDLE-MANIFEST.json').read_bytes()) if (project/'BUNDLE-MANIFEST.json').exists() else None}
    # The original bundle manifest remains an immutable record of the base ZIP.
    (project/'MACOS-WORKER-FIX1.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(apply(args.project, Path(__file__).resolve().parent), ensure_ascii=False, indent=2))


if __name__ == '__main__': main()
