# macOSでの静的ワーカー起動失敗の修正

利用者のMacで `ValueError: current limit exceeds maximum limit` が発生しました。原因箇所は静的解析ワーカーの `resource.setrlimit(RLIMIT_AS, (3 GiB, 3 GiB))` です。Android通信の取得前に停止しており、合否確認の後続項目がfalseになるのはこの失敗に伴うものです。

macOSではRLIMIT_ASによる上限を適用せず、未適用の理由をstatic-worker.jsonへ記録します。親の解析タイムアウト、APKとパーサのサイズ制限は維持します。Linuxでは既存のsoft/hard上限を引き上げず、3 GiB以下にsoft上限を設定します。max_rss_kibの単位もmacOSのbytesからKiBへ統一しました。

小さな更新ZIPをDocumentsに展開し、既存フォルダで以下を実行してください。依存関係の再インストールは不要です。

```bash
cd "$HOME/Documents/apk-audit-unified-v1"
source .venv/bin/activate
python "$HOME/Documents/apk-audit-macos-worker-fix-v1/apply_fix.py" --project .
```

パッチは配布済みv1と同じワーカーであることをハッシュで確認し、元ファイルをバックアップしてから1ファイルだけ置き換えます。ローカルに別の変更がある場合は上書きしません。旧BUNDLE-MANIFEST.jsonは維持し、MACOS-WORKER-FIX1.jsonに差分の適用記録を保存します。

今回のauto-http-001や以前の19試行の結果は削除しません。8765の参照サーバを起動した状態で、別の出力先へ再実行します。

```bash
apk-audit analyze --apk apks/control-http.apk --serial emulator-5554 --scenario examples/scenario-http-button.json --out runs/auto-http-002
python tools/check_automatic_trial.py --run runs/auto-http-002
open runs/auto-http-002/summary.html
```

端末に制御・VPNの同意画面が出たら内容を確認して許可してください。問題が続く場合はstatic-worker.json、run.jsonと表示内容を確認します。Mac固有の処理はホスト上でOSを模擬して検査していますが、実Mac上の再実行はまだ確認できていません。

研究上、今回の停止は新取得方式のセットアップ不具合として記録し、通信試行や収集精度の結果には数えません。旧19試行の原本とその評価条件は変更しません。
