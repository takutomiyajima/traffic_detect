追加評価12試行の集計とTeX資料です。原本PCAP・APK・個別要求tokenは含みません。
results/main.tex と thesis/thesis.tex は XeLaTeX で複数回コンパイルしてください。Noto Serif/Sans CJK JP 等のフォントが必要です。
12試行は参照素材での動作確認です。一般精度・第三者確認・作業時間削減は未実証です。
