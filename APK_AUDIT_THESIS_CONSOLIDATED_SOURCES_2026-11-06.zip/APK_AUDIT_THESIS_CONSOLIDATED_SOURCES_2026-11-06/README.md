# 本文整理済み卒論草稿・TeX・データ（2026-11-06）

docs/thesis.pdf：28ページの卒論草稿。目的・方法・結果・考察・結論を統一しました。
docs/research/manuscript-final-2026-11-06/READ_FIRST.md：最初に読む順序と、本人が最後に確認する事項。
同フォルダ：主張8項目と本文節、関連研究10件の比較、引用資料の確認範囲、整合検査記録。
docs/research/intent-seeds-001-2026-11-06/：主評価9試行の集計と27出力の事後構成要素比較。
docs/research/review-revision-2026-11-06/final29-trials.csv：補助29試行の台帳。

解析コード31ファイルと取得原本298ファイルは変更していません。追加Android試行は0件です。
許可入力先3試行は整合、固定先3試行は不一致候補、対象未観測3試行は判定不能でした。
動的のみと併用の主要通信判定が一致したことも結果に含めました。
一般精度・安全性保証・AI生成アプリ一般の評価を確立したとは記載していません。

## PDFを再生成する場合

XeLaTeX、TikZ、fancyvrb、xurlとNoto Serif CJK JP・Noto Sans CJK JP・DejaVu Sans Mono等を用います。
この構成を保持して bash tools/build_thesis.sh を実行します。新しいAndroid取得は不要です。
Python依存環境がある場合、以下で参照と公開集計の整合を確認できます。
python tools/check_manuscript_consistency.py --out /tmp/manuscript-check.json
研究者用の原本を持つ場合だけ --private-original /path/to/review/original を追加できます。
この検査は独立した科学的正解や大学の提出承認ではありません。

## 本人に残る確認

著者・所属・学籍番号・実提出日・大学指定形式を記入し、結論とAI利用記録を自分で確認してください。
新しい90秒観測、実SDK、AI生成アプリ等は今回の必須条件にしていません。
原本の追加送付や、既存9試行の再実行は必要ありません。

## プログラムと原本の扱い

srcと同梱dist/apk-audit-intent-v1.zipは、既に検証・配布した解析版の保存です。
この資料はMacの既存ソースを上書きする更新パッチではありません。
同梱ツールには自作の参照APKと取得補助APKを含みます。実験を再実行するために配布した新ランナーではありません。
ユーザーの原本APK・PCAP・生通信ログ・要求token・添付された論文PDFは収録していません。
研究者用原本がない状態で、全試行の原本点検まで再現できる資料とはしません。
