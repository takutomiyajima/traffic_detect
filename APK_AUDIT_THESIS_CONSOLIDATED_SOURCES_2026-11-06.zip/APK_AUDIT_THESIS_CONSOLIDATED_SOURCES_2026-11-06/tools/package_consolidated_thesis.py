#!/usr/bin/env python3
"""Package the consolidated manuscript and aggregate data without raw captures."""
from pathlib import Path
import ast
import hashlib
import json
import re
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[1]


def main():
    stage=ROOT/'dist/APK_AUDIT_THESIS_CONSOLIDATED_SOURCES_2026-11-06'
    if stage.exists():raise ValueError('Preserve the previous publication')
    files=set()
    def add(path):
        path=path.resolve();path.relative_to(ROOT)
        if path in files:return
        if not path.is_file():raise FileNotFoundError(path)
        files.add(path)
        if path.suffix=='.tex':
            for kind,name in re.findall(r'\\(input|include|includegraphics)(?:\[[^\]]*\])?\{([^}]+)\}',path.read_text()):
                child=ROOT/'docs'/name
                if not child.suffix and kind!='includegraphics':child=child.with_suffix('.tex')
                add(child)
        if path.parent==ROOT/'tools' and path.suffix=='.py':
            for node in ast.walk(ast.parse(path.read_text())):
                names=[]
                if isinstance(node,ast.ImportFrom) and node.module:names=[node.module.split('.')[0]]
                if isinstance(node,ast.Import):names=[a.name.split('.')[0] for a in node.names]
                for name in names:
                    child=ROOT/'tools'/(name+'.py')
                    if child.is_file():add(child)
    for name in ['docs/thesis.tex','docs/thesis.pdf','docs/thesis.log','tools/build_thesis.sh',
                 'tools/check_manuscript_consistency.py','tools/review_intent_seed_archive.py',
                 'tools/package_consolidated_thesis.py','dist/apk-audit-intent-v1.zip',
                 'pyproject.toml','requirements.lock','requirements-python311.lock',
                 'docs/research/review-revision-2026-11-06/final29-trials.csv',
                 'docs/research/finish-plan-2026-11-06/scope-and-completion.json',
                 'docs/research/primary-paper-review-2026-11-05/page-grounded-comparison.csv']:
        add(ROOT/name)
    for directory in ['docs/research/manuscript-final-2026-11-06','docs/research/intent-seeds-001-2026-11-06']:
        for path in (ROOT/directory).iterdir():
            if path.suffix in ('.md','.json','.csv'):add(path)
    for name in ['intent-v1.1.schema.json','status.json','posthoc-input-example.json','posthoc-input-example.csv']:
        add(ROOT/'docs/research/intent-first-2026-11-06'/name)
    for path in (ROOT/'src/apk_audit').rglob('*'):
        if path.is_file() and path.suffix in ('.py','.json','.apk'):add(path)
    for path in (ROOT/'examples').glob('intent-*-v1.1.json'):add(path)
    for path in (ROOT/'tests').glob('test_intent*.py'):add(path)
    for path in files:
        assert not path.is_relative_to(ROOT/'runs')
        assert path.suffix not in ('.pcap','.pcapng','.jsonl')
    stage.mkdir()
    for path in files:
        target=stage/path.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
    (stage/'README.md').write_text('''# 本文整理済み卒論草稿・TeX・データ（2026-11-06）

docs/thesis.pdf：28ページの卒論草稿。目的・方法・結果・考察・結論を統一しました。
docs/research/manuscript-final-2026-11-06/READ_FIRST.md：最初に読む順序と、本人が最後に確認する事項。
同フォルダ：主張8項目と本文節、関連研究10件の比較、引用資料の確認範囲、整合検査記録。
docs/research/intent-seeds-001-2026-11-06/：主評価9試行の集計と27出力の事後構成要素比較。
docs/research/review-revision-2026-11-06/final29-trials.csv：補助29試行の台帳。

解析コード31ファイルと取得原本298ファイルは変更していません。追加Android試行は0件です。
許可入力先3試行は整合、固定先3試行は不一致候補、対象未観測3試行は判定不能でした。
動的のみと併用の主要通信判定が一致したことも結果に含めました。
一般精度・安全性保証・AI生成アプリ一般の評価を確立したとは記載していません。

## PDFを再生成する場合

XeLaTeX、TikZ、fancyvrb、xurlとNoto Serif CJK JP・Noto Sans CJK JP・DejaVu Sans Mono等を用います。
この構成を保持して bash tools/build_thesis.sh を実行します。新しいAndroid取得は不要です。
Python依存環境がある場合、以下で参照と公開集計の整合を確認できます。
python tools/check_manuscript_consistency.py --out /tmp/manuscript-check.json
研究者用の原本を持つ場合だけ --private-original /path/to/review/original を追加できます。
この検査は独立した科学的正解や大学の提出承認ではありません。

## 本人に残る確認

著者・所属・学籍番号・実提出日・大学指定形式を記入し、結論とAI利用記録を自分で確認してください。
新しい90秒観測、実SDK、AI生成アプリ等は今回の必須条件にしていません。
原本の追加送付や、既存9試行の再実行は必要ありません。

## プログラムと原本の扱い

srcと同梱dist/apk-audit-intent-v1.zipは、既に検証・配布した解析版の保存です。
この資料はMacの既存ソースを上書きする更新パッチではありません。
同梱ツールには自作の参照APKと取得補助APKを含みます。実験を再実行するために配布した新ランナーではありません。
ユーザーの原本APK・PCAP・生通信ログ・要求token・添付された論文PDFは収録していません。
研究者用原本がない状態で、全試行の原本点検まで再現できる資料とはしません。
''')
    manifest={str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(stage.rglob('*')) if p.is_file()}
    (stage/'MANIFEST.json').write_text(json.dumps(dict(profile='consolidated-intent-audit-thesis',thesis_pages=28,
        primary_device_trials=9,historical_device_trials=29,new_device_trials=0,required_new_device_trials=0,
        retrospective_component_outputs=27,figures=2,citations=12,author_signoff_pending=True,
        raw_capture_or_user_APK_included=False,own_reference_APKs_and_bridge_included=True,files=manifest),ensure_ascii=False,indent=2)+'\n')
    archive=stage.with_suffix('.zip')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in sorted(stage.rglob('*')):
            if path.is_file():z.write(path,path.relative_to(stage.parent))
    pdf=ROOT/'dist/APK_AUDIT_THESIS_CONSOLIDATED_2026-11-06.pdf'
    if pdf.exists():raise ValueError('Preserve existing PDF artifact')
    shutil.copy2(ROOT/'docs/thesis.pdf',pdf)
    for path in [pdf,archive]:
        shutil.copy2(path,Path('/workspace/downloads')/path.name)
        print(json.dumps(dict(name=path.name,bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())))


if __name__=='__main__':main()
