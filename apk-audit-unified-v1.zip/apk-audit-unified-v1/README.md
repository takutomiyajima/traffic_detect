# APK Audit Unified v1

Mac向け操作手順: docs/research/unified-pipeline-2026-11-02.md

初回: bash tools/setup.sh

新しいCaptureCtrl自動取得経路はAndroid端末での確認待ちです。既存実測は旧方式で取得した結果です。
