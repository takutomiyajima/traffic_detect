Self-authored HTTP research control 1.1, unchanged APK. No public third-party APKs are redistributed.
