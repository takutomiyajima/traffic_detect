package org.example.apkaudit.capture;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;

/** Receives official CaptureCtrl results; ADB launch success is not capture success. */
public class ControlActivity extends Activity {
    private String request;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        request = state == null ? getIntent().getStringExtra("request_id") : state.getString("request");
        if (request == null || !request.matches("[a-f0-9]{32}")) { finish(); return; }
        if (state != null) return; // Do not issue a second start after recreation.
        final String action = getIntent().getStringExtra("action");
        try {
            if ("probe".equals(action)) {
                final String address = getIntent().getStringExtra("url");
                if (address == null || !address.matches("http://10\\.0\\.2\\.2:[0-9]+/health")) throw new Exception("Invalid local probe URL");
                new Thread(() -> {
                    JSONObject value = new JSONObject();
                    java.net.HttpURLConnection connection = null;
                    try {
                        connection = (java.net.HttpURLConnection) new java.net.URL(address).openConnection();
                        connection.setConnectTimeout(5000); connection.setReadTimeout(5000);
                        connection.setInstanceFollowRedirects(false);
                        connection.setRequestProperty("X-Audit-Run", request);
                        connection.setRequestProperty("Connection", "close");
                        value.put("http_status", connection.getResponseCode());
                        try (java.io.InputStream in = connection.getInputStream()) {
                            byte[] buffer = new byte[4096]; int total = 0, n;
                            while ((n = in.read(buffer)) != -1) { total += n; if (total > 65536) throw new Exception("Probe too large"); }
                        }
                        value.put("result_code", RESULT_OK);
                    } catch (Exception e) { try { value.put("error", e.getClass().getSimpleName()); } catch (Exception ignored) {} }
                    finally { if (connection != null) connection.disconnect(); }
                    final JSONObject result = value;
                    runOnUiThread(() -> save(result));
                }).start();
                return;
            }
            if (!"start".equals(action) && !"stop".equals(action) && !"get_status".equals(action)) throw new Exception("Invalid action");
            Intent intent = new Intent();
            intent.setClassName("com.emanuelef.remote_capture", "com.emanuelef.remote_capture.activities.CaptureCtrl");
            intent.putExtra("action", action);
            if ("start".equals(action)) {
                String name = getIntent().getStringExtra("pcap_name");
                if (name == null || !name.matches("audit-[a-f0-9]{32}\\.pcap")) throw new Exception("Invalid capture name");
                intent.putExtra("pcap_dump_mode", "pcap_file"); intent.putExtra("pcap_name", name);
                intent.putExtra("dump_extensions", true); intent.putExtra("pcapng_format", false);
                intent.putExtra("root_capture", false); intent.putExtra("tls_decryption", false);
                intent.putExtra("socks5_enabled", false); intent.putExtra("full_payload", true);
                intent.putExtra("block_quic", "never"); intent.putExtra("auto_block_private_dns", false);
            }
            startActivityForResult(intent, 100);
        } catch (Exception e) {
            JSONObject value = new JSONObject();
            try { value.put("error", e.getClass().getSimpleName()); } catch (Exception ignored) {}
            save(value);
        }
    }
    @Override public void onSaveInstanceState(Bundle state) { super.onSaveInstanceState(state); state.putString("request", request); }
    @Override protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        JSONObject value = new JSONObject();
        try {
            value.put("result_code", result);
            if (data != null && data.getExtras() != null) for (String key : data.getExtras().keySet()) {
                Object item = data.getExtras().get(key);
                if (item instanceof Number || item instanceof Boolean || item instanceof String) value.put(key, item);
            }
        } catch (Exception ignored) {}
        save(value);
    }
    private void save(JSONObject value) {
        try {
            value.put("request_id", request);
            File temporary = new File(getFilesDir(), request + ".tmp");
            try (FileOutputStream stream = new FileOutputStream(temporary)) { stream.write(value.toString().getBytes("UTF-8")); stream.getFD().sync(); }
            if (!temporary.renameTo(new File(getFilesDir(), request + ".json"))) throw new Exception("Rename failed");
        } catch (Exception e) { android.util.Log.e("AuditCapture", "Cannot save callback", e); }
        finish();
    }
}
