# Research-only TLS fixture

This self-signed lab certificate and deliberately distributable lab key serve only
the localhost reference server. The HTTPS v1.2 control APK embeds the certificate
as its application-specific trust anchor, with normal hostname verification.
No Android system CA store, other application trust, proxy or TLS decryption is changed.
This is a controlled trust profile, not the default trust configuration of arbitrary apps.

SANs: IP 10.0.2.2 and IP 127.0.0.1. Generated 2026-10-31, valid for 365 days.
Generation command is recorded in the cloud task; never treat this public fixture
key as a production identity. Replacing the certificate requires rebuilding and
repinning the HTTPS APK and freezing a new study version.
