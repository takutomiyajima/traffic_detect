#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m venv .venv
task_python_minor="$(.venv/bin/python -c 'import sys; print("%s.%s" % sys.version_info[:2])')"
task_requirements="requirements.lock"
if [[ "$task_python_minor" == "3.11" ]]; then
  task_requirements="requirements-python311.lock"
fi
.venv/bin/python -m pip install --require-hashes -r "$task_requirements"
.venv/bin/python -m pip install --no-deps -e .
.venv/bin/python -m pytest -q
