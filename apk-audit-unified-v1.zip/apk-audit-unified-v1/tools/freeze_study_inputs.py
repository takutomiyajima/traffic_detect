#!/usr/bin/env python3
"""Freeze prospective controls before their Android acquisition; never overwrite."""
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from run_guided_trial import CASES, policy_for

ROOT = Path(__file__).resolve().parents[1]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args()
    if args.out.exists():
        p.error('Frozen output already exists; create a new study version')
    args.out.mkdir(parents=True)
    cases = ['http_fail', 'https', 'offline']
    protocol = {
        'study_id': 'apk-policy-prospective-v1', 'version': '1.0',
        'frozen_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'prepared_before_future_acquisition_not_third_party_preregistration',
        'previous_13_trials': 'exploratory_retrospective_analysis_design; captured policies already predate acquisition',
        'environment': {'serial': 'emulator-5554', 'api': 35, 'abi': 'arm64-v8a', 'avd_name': 'Pixel_8_Edited_API_35', 'pcapdroid': '2.0.2', 'proxy': 'disabled_or_:0',
                        'capture': 'all_apps_VPN_no_TLS_decryption', 'target_host': '10.0.2.2'},
        'sequence': ['http_fail_001_review_then_002_003', 'https_001_review_then_002_003', 'recover_offline_archives_or_two_new_offline_trials_last'],
        'planned_new_repetitions': {'http_fail': 3, 'https': 3, 'offline': 'recover existing archives first; otherwise 2 additional'},
        'observe_seconds_after_app_result': 30,
        'analysis_policy_variants': ['captured', 'network_deny_all', 'network_unspecified'],
        'evidence_modes': ['static-only', 'dynamic-only', 'integrated'],
        'unit': 'trial and selected connection record kept separate; one application is not one independent sample per repeat',
        'metrics': ['evaluable_and_not_evaluable_counts', 'unsupported_assertions', 'unknown_information_loss', 'evidence_traceability'],
        'rules': ['UID unknown remains not_evaluable; never substitute no traffic',
                  'Partial capture and missing target rows cannot establish absence',
                  'A captured connection attempt does not establish TCP/TLS/HTTP success',
                  'An intentional application connection failure is not a collector failure',
                  'No automatic CSV/server join or protocol promotion'],
        'cases': {case: {'apk_sha256': CASES[case]['sha256'], 'policy': policy_for(case),
                         'allowed_app_results': CASES[case].get('expected_results', [CASES[case]['expected']])} for case in cases},
    }
    gold = {
        'kind': 'source_based_control_expectations_and_evidence_contract_not_observed_results',
        'third_party_review': 'not_performed', 'authors_of_material_and_evaluation': 'same research process; AI-assisted',
        'positive_controls': 'new browser GET before and after; retain UI/event ID or visual-attestation distinction',
        'cases': {
            'http_fail': {'operation': 'same HTTP v1.1 APK posts to 10.0.2.2:18765; host port bound without listener',
                          'expected_target_server_requests': 0, 'expected_app': ['ConnectException', 'SocketTimeoutException'],
                          'collection': 'Controls must succeed; missing/unknown UID remains review, not deleted or counted as no communication',
                          'known_uid_destination_verdict': 'consistent_with_observed_evidence for IP/port allowlist; not proof of successful connection'},
            'https': {'operation': 'HTTPS control v1.2 using only its embedded lab trust anchor; default hostname verification',
                      'expected_app': 'http_response=200', 'expected_server': 'one HTTPS POST with matching trial ID and body hash',
                      'csv_protocol': 'application_protocol remains unknown without cross-source linkage',
                      'trust_scope': 'this self-authored control only; no OS CA/proxy changes'},
            'offline': {'operation': 'offline v1.1 local action', 'expected_app': 'local_only_completed',
                        'expected_target_rows': 0, 'expected_target_receive_events': 0,
                        'verdict': 'no target network verdict must not be interpreted as proven absence'},
        },
        'acceptance': ['Recorded application outcome agrees with frozen case; anomalies are retained',
                       'Known UID/IP/port allowlist case evaluated; unknown UID not falsely attributed',
                       'No unsupported absence conclusion from partial capture',
                       'Cited evidence resolves and matches hashes'],
        'statistics': 'Report counts and denominators; no population accuracy or causal UDP lifetime effect',
    }
    for name, value in [('protocol.json', protocol), ('gold-spec.json', gold)]:
        (args.out / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    sources = [ROOT / 'tools/run_guided_trial.py', ROOT / 'src/apk_audit/control_server.py',
               ROOT / 'src/apk_audit/compare.py', ROOT / 'tools/compare_guided_trial.py',
               ROOT / 'fixtures/research-tls/lab-server-cert.pem']
    sources += [ROOT / CASES[case].get('apk_relative', 'runs/control-apks-v3-ui/' + case + '.apk') for case in cases]
    manifest = {'study_id': protocol['study_id'], 'frozen_utc': protocol['frozen_utc'],
                'files': [{'path': p.name, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(args.out.iterdir())],
                'implementation': [{'path': str(p.relative_to(ROOT)), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources]}
    (args.out / 'FROZEN-MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'saved': str(args.out), 'frozen_utc': protocol['frozen_utc']}))


if __name__ == '__main__':
    main()
