#!/usr/bin/env python3
"""Reproduce the captured-policy matrix and explicit uncertainty ablations.

This is retrospective evaluation of saved trials, not a preregistered benchmark.
Raw input ZIPs and evidence-linked HTML remain in the private output directory.
"""
import argparse
import csv
import json
import subprocess
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from apk_audit.core import read_json, read_jsonl, sha256, write_json
from review_guided_archives import review


def uncertainty_ablation(original, method):
    """Deliberate design ablations, not representations of external tools."""
    if original is None:
        return {'verdict': None, 'observation': None, 'attribution': None,
                'state': 'no_selected_record_in_partial_capture', 'information_lost': False,
                'unsupported_assertion': False}
    value = {k: original[k] for k in ('verdict', 'observation', 'attribution')}
    value.update(state='record_retained', information_lost=False, unsupported_assertion=False)
    if original['attribution'] == 'unknown':
        if method == 'drop_unknown':
            value.update(verdict=None, observation=None, attribution=None,
                         state='record_removed_by_baseline', information_lost=True)
        elif method == 'unknown_as_violation':
            value.update(verdict='mismatch_candidate', attribution='target_assumed_by_baseline',
                         state='unsupported_target_violation', unsupported_assertion=True)
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ledger', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--input-index', type=Path, help='JSON mapping trial ID to local ZIP path')
    parser.add_argument('--archives', nargs='*', type=Path)
    args = parser.parse_args()
    if args.out.exists():
        parser.error('Output exists; choose a new folder')
    ledger = read_json(args.ledger)
    expected = {r['trial_id']: r for r in ledger['trials']}
    paths = {}
    candidates = list(args.archives or [])
    if args.input_index:
        candidates.extend(Path(p) for p in read_json(args.input_index).values())
    for path in candidates:
        checked = review(path)
        tid = checked['trial_id']
        if tid not in expected or checked['archive_sha256'] != expected[tid]['archive_sha256']:
            raise ValueError(f'Archive not in the frozen received ledger: {tid}')
        paths[tid] = path.resolve()
    if set(paths) != set(expected):
        raise ValueError('Input ZIP inventory differs from ledger')
    args.out.mkdir(parents=True)
    matrix, ablations = [], []
    for tid in sorted(paths):
        target = args.out / tid
        subprocess.run([sys.executable, str(ROOT / 'tools/compare_guided_trial.py'),
                        '--archive', str(paths[tid]), '--out', str(target),
                        '--policy-set', 'captured'], check=True, capture_output=True)
        summary = read_json(target / 'comparison-summary.json')
        trial = expected[tid]
        flows = [r for _, r in read_jsonl(target / 'base-run/flows.jsonl')]
        # One known target or one destination/time-correspondence candidate.
        # Unknown candidates are never relabelled as a measured target UID.
        lines = {c['line'] for c in trial['candidate_rows']
                 if c['uid'] == trial['uid'] or c['uid'] < 0}
        selected = [f for f in flows if f['source_record']['line'] in lines]
        if trial['case'] != 'offline' and len(selected) != 1:
            raise ValueError('Selected controlled record is not unique')
        if trial['case'] == 'offline' and selected:
            raise ValueError('Offline trial has unexpected candidate')
        for mode in ('static-only', 'dynamic-only', 'integrated'):
            item = next(r for r in summary['results'] if r['evidence_mode'] == mode)
            findings = read_json(target / Path(item['report']).parent / 'findings.json')['findings']
            records = []
            if mode != 'static-only' and selected:
                f = selected[0]
                records = [r for r in findings if f['flow_id'] in r['evidence_ids'] and
                           r['subject'] in ('external_connection', 'connection_attribution')]
                if len(records) != 1:
                    raise ValueError('Expected exactly one candidate network/attribution finding')
            r = records[0] if records else None
            matrix.append({
                'trial_id': tid, 'case': trial['case'], 'evidence_mode': mode,
                'policy_mode': read_json(target / 'originals/intent-before-capture.json')['network']['mode'],
                'policy_basis': 'saved_before_capture', 'policy_sha256': trial['policy_sha256'],
                'verdict': r['verdict'] if r else None, 'observation': r['observation'] if r else None,
                'attribution': r['attribution'] if r else None,
                'content_visibility': r['content_visibility'] if r else None,
                'rule_id': r['rule_id'] if r else None,
                'evidence_ids': r['evidence_ids'] if r else [],
                'scope_state': 'dynamic_excluded' if mode == 'static-only' else 'selected_record' if r else 'no_target_record_in_partial_capture',
                'quality': trial['quality'], 'server_received_events': trial['server_events'],
                'report': str((target / item['report']).relative_to(args.out)),
            })
            if mode == 'integrated':
                for method in ('proposed', 'drop_unknown', 'unknown_as_violation'):
                    ablations.append({'trial_id': tid, 'case': trial['case'], 'method': method,
                                      'unit': 'one_controlled_destination_record_or_no_target_record_per_trial',
                                      **uncertainty_ablation(r, method)})
    aggregates = []
    for method in ('proposed', 'drop_unknown', 'unknown_as_violation'):
        rows = [r for r in ablations if r['method'] == method]
        aggregates.append({'method': method, 'trial_units': len(rows),
                           'selected_record_units': sum(r['case'] != 'offline' for r in rows),
                           'unknown_candidate_units_in_input': sum(r['attribution'] == 'unknown' for r in ablations if r['method'] == 'proposed'),
                           'information_lost_units': sum(r['information_lost'] for r in rows),
                           'unsupported_assertion_units': sum(r['unsupported_assertion'] for r in rows),
                           'verdict_counts': dict(Counter(r['verdict'] or 'no_network_verdict' for r in rows))})
    result = {'review_date_jst': '2026-10-31', 'kind': 'retrospective_captured_policy_processing_and_design_ablation',
              'analysis_code_sha256': {str(p.relative_to(ROOT)): sha256(p) for p in
                                      [ROOT / 'tools/evaluate_existing_trials.py', ROOT / 'tools/compare_guided_trial.py', ROOT / 'tools/review_guided_archives.py',
                                       ROOT / 'src/apk_audit/compare.py', ROOT / 'src/apk_audit/capture.py', ROOT / 'src/apk_audit/pcapdroid.py']},
              'ledger_sha256': sha256(args.ledger), 'unique_trials': len(paths),
              'captured_policy_reports': len(matrix), 'matrix': matrix, 'ablations': ablations,
              'aggregates': aggregates, 'new_android_trials': 0, 'accuracy_metrics_computed': False,
              'limitations': ['Baselines are explicit artificial uncertainty-handling ablations, not MobSF or PCAPdroid',
                             'Selected unknown CSV records remain correspondence candidates without measured target UIDs',
                             'Unsupported assertions are epistemic failures, not an independently measured population error rate',
                             'Removing a record is information loss; no absence assertion is attributed to that baseline',
                             'Null verdict means no corresponding target finding was emitted, never no communication',
                             'All capture quality remains partial; repeated trials are not independent applications',
                             'Original policies predate capture; analysis design and ablations are retrospective']}
    write_json(args.out / 'evaluation.json', result)
    for name, rows in [('matrix', matrix), ('ablations', ablations), ('aggregates', aggregates)]:
        with (args.out / (name + '.csv')).open('w', newline='', encoding='utf-8-sig') as stream:
            writer = csv.DictWriter(stream, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v for k,v in row.items()} for row in rows)
    print(json.dumps({'trials': len(paths), 'reports': len(matrix), 'aggregates': aggregates}, ensure_ascii=False))


if __name__ == '__main__':
    main()
