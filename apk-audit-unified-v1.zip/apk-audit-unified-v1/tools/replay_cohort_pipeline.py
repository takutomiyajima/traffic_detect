#!/usr/bin/env python3
"""Reanalyze verified historical trials through the unified pipeline; no ADB.

Requires the private, previously verified guided comparison directories.
The original 13 exploratory + 6 prospective acquisition cohorts are immutable.
"""
import argparse
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from apk_audit.cli import parser as audit_parser
from apk_audit.core import read_json, sha256, write_json
from apk_audit.pipeline import analyze
from review_guided_archives import review


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        parser.error('Use a new output directory')
    original = read_json(ROOT/'runs/research-cohort-review/all13-input-index.json')
    prospective = read_json(ROOT/'runs/prospective-batch-2026-11-01/input-index.json')
    # The historical index is a mapping; no inference from filename/date/version.
    print('Historical input index type:', type(original).__name__, flush=True)
    jobs = []
    for cohort, mapping, source in (
        ('exploratory_13', original, ROOT/'runs/all13-policy-evaluation-v3-2026-10-31'),
        ('prospective_controls_6', prospective, ROOT/'runs/prospective-batch-2026-11-01/comparisons')):
        for trial_id, archive in mapping.items():
            verified = review(Path(archive))
            if verified['trial_id'] != trial_id:
                raise ValueError('Trial identity mismatch')
            base = source/trial_id/'base-run'
            originals = source/trial_id/'originals'
            jobs.append((cohort, trial_id, Path(archive), verified, base, originals))
    args.out.mkdir(parents=True)
    rows = []
    for cohort, trial_id, archive, verified, base, originals in jobs:
        argv = ['analyze', '--apk', str(originals/'original.apk'), '--out', str(args.out/trial_id),
                '--capture', str(originals/'capture.csv'), '--metadata', str(base/'capture.metadata.json'),
                '--intent', str(originals/'intent-before-capture.json')]
        result, code = analyze(audit_parser().parse_args(argv))
        if code:
            raise RuntimeError(result)
        provenance = {'source_trial_id': trial_id, 'acquisition_cohort': cohort, 'archive_sha256': sha256(archive),
                      'original_apk_sha256': sha256(originals/'original.apk'),
                      'source_capture_sha256': sha256(originals/'capture.csv'),
                      'analysis_design': 'retrospective_validation_of_new_correspondence_layer',
                      'new_android_trial': False, 'independent_accuracy_sample': False,
                      'original_acquisition_policy_retained': True,
                      'original_UI_server_and_package_records': 'Preserved in the verified source archive; not automatically joined by this replay'}
        write_json(args.out/trial_id/'historical-provenance.json', provenance)
        write_json(args.out/trial_id/'source-archive-review.json', verified)
        state = read_json(args.out/trial_id/'run.json')
        state['historical_provenance'] = provenance
        write_json(args.out/trial_id/'run.json', state)
        from apk_audit.differential import build
        build(args.out/trial_id)
        row = {'trial_id': trial_id, 'cohort': cohort, 'case': verified['case'],
               'dynamic_status': result['dynamic_status'], **result['counts']}
        rows.append(row)
        print(json.dumps(row, ensure_ascii=False), flush=True)
    result = {'schema_version':'1.0', 'analysis_kind':'retrospective_system_validation',
              'new_android_trials':0, 'source_trials':len(rows), 'trials':rows,
              'interpretation':'Historical device experiments are retained as research evidence; this reanalysis is not prospective evaluation or an accuracy estimate.'}
    write_json(args.out/'cohort-reanalysis.json', result)
    with (args.out/'cohort-reanalysis.csv').open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    links = ''.join(f'<li>{r["trial_id"]} ({r["cohort"]}) — <a href="{r["trial_id"]}/summary.html">比較説明</a></li>' for r in rows)
    (args.out/'index.html').write_text('<!doctype html><meta charset="utf-8"><h1>既存19試行の再解析</h1><p>新しいAndroid実験ではありません。取得時の条件・ポリシーを保持した、比較説明機能の事後検証です。</p><ul>'+links+'</ul>', encoding='utf-8')


if __name__ == '__main__': main()
