#!/usr/bin/env python3
"""Build the small, source-provided CaptureCtrl callback bridge with pinned SDK."""
import argparse
import json
import shutil
import zipfile
from pathlib import Path
from build_control_apks import ROOT, SDK, run


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    jar = SDK/'platform/android-35/android.jar'
    bt = SDK/'build-tools/android-15'
    for folder in ('classes', 'dex'):
        (out/folder).mkdir()
    manifest = out/'AndroidManifest.xml'
    manifest.write_text('''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="org.example.apkaudit.capture" android:versionCode="1" android:versionName="0.1">
    <uses-sdk android:minSdkVersion="26" android:targetSdkVersion="35"/>
    <uses-permission android:name="android.permission.INTERNET"/>
    <queries><package android:name="com.emanuelef.remote_capture"/></queries>
    <application android:debuggable="true" android:label="APK Audit Capture Bridge" android:usesCleartextTraffic="true" android:allowBackup="false" android:theme="@android:style/Theme.Material.Light.NoActionBar">
    <activity android:name=".ControlActivity" android:exported="true" android:permission="android.permission.DUMP"/></application></manifest>''')
    run([bt/'aapt2', 'link', '-I', jar, '--manifest', manifest, '-o', out/'resources.apk'])
    source = ROOT/'fixtures/capture-controller/ControlActivity.java'
    run(['java', '-jar', SDK/'ecj-3.39.0.jar', '-8', '-proc:none', '-classpath', jar, '-d', out/'classes', source])
    run([bt/'d8', '--min-api', '26', '--lib', jar, '--output', out/'dex', *list((out/'classes').rglob('*.class'))])
    shutil.copyfile(out/'resources.apk', out/'unsigned.apk')
    with zipfile.ZipFile(out/'unsigned.apk', 'a') as archive:
        archive.write(out/'dex/classes.dex', 'classes.dex')
    run([bt/'zipalign', '-f', '4', out/'unsigned.apk', out/'aligned.apk'])
    apk = out/'capture-controller.apk'
    run([bt/'apksigner', 'sign', '--ks', SDK/'research-debug.keystore', '--ks-pass', 'pass:android', '--key-pass', 'pass:android', '--out', apk, out/'aligned.apk'])
    run([bt/'apksigner', 'verify', '--verbose', apk])
    from hashlib import sha256
    inventory = {'apk_sha256': sha256(apk.read_bytes()).hexdigest(), 'source_sha256': sha256(source.read_bytes()).hexdigest(),
                 'android_execution': 'not_validated_on_device', 'package': 'org.example.apkaudit.capture'}
    (out/'inventory.json').write_text(json.dumps(inventory, indent=2)+'\n')
    print(json.dumps(inventory))


if __name__ == '__main__':
    main()
