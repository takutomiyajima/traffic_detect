#!/usr/bin/env python3
"""Package a local unified-pipeline result with an inventory; no uploads."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path


def package(directory):
    directory = Path(directory).resolve()
    if not (directory/'run.json').is_file() or not (directory/'summary.html').is_file():
        raise ValueError('Specify a completed pipeline output directory, including partial results')
    destination = directory.with_suffix(directory.suffix + '.zip')
    if destination.exists():
        raise ValueError('Output ZIP exists; preserve it and choose another trial name')
    files = []
    for source in sorted(directory.rglob('*')):
        if source.is_symlink():
            raise ValueError('Symlinks are not included in research packages')
        if source.is_file():
            files.append(source)
    if sum(f.stat().st_size for f in files) > 512 * 1024**2:
        raise ValueError('Results exceed 512 MiB; keep the originals and select an appropriate transfer method')
    manifest = {'schema_version':'1.0', 'contains_private_research_logs':True,
                'files':{str(f.relative_to(directory)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}}
    try:
        with zipfile.ZipFile(destination, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
            for source in files:
                archive.write(source, directory.name + '/' + str(source.relative_to(directory)))
            archive.writestr(directory.name+'/RESULT-MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2)+'\n')
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    return destination


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True, type=Path)
    args = parser.parse_args()
    print(package(args.run))


if __name__ == '__main__': main()
