#!/usr/bin/env python3
"""Build a source-inclusive tool ZIP; never includes received research captures."""
import argparse
import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PREFIX = 'apk-audit-unified-v1'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=ROOT/'dist/apk-audit-unified-v1.zip')
    args = parser.parse_args()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    if args.out.exists():
        parser.error('ZIP already exists; preserve published artifacts')
    files = {}
    for folder, suffixes in [('src', {'.py','.json','.apk'}), ('tools', {'.py','.sh'}),
                             ('tests', {'.py'}), ('fixtures', {'.java','.in','.json','.pem','.md'}), ('examples', {'.json'})]:
        for path in sorted((ROOT/folder).rglob('*')):
            if path.is_file() and path.suffix in suffixes and '__pycache__' not in path.parts:
                files[str(path.relative_to(ROOT))] = path.read_bytes()
    for name in ('pyproject.toml','requirements.lock','requirements-python311.lock'):
        files[name] = (ROOT/name).read_bytes()
    for name in ('unified-pipeline-2026-11-02.md', 'unified-progress-2026-11-02.md'):
        files['docs/research/'+name] = (ROOT/'docs/research'/name).read_bytes()
    files['README.md'] = ('# APK Audit Unified v1\n\nMac向け操作手順: docs/research/unified-pipeline-2026-11-02.md\n\n'
                          '初回: bash tools/setup.sh\n\n新しいCaptureCtrl自動取得経路はAndroid端末での確認待ちです。既存実測は旧方式で取得した結果です。\n').encode()
    files['apks/control-http.apk'] = (ROOT/'runs/control-apks-v3-ui/http.apk').read_bytes()
    if hashlib.sha256(files['apks/control-http.apk']).hexdigest() != '7c7f24e82c80fb1e51df96923dda326571d3c706d496e03efb6373647df01382':
        raise ValueError('Historical HTTP fixture hash changed')
    files['apks/README.md'] = b'Self-authored HTTP research control 1.1, unchanged APK. No public third-party APKs are redistributed.\n'
    manifest = {'schema_version':'1.0', 'bundle_version':'unified-v1-2026-11-02',
                'created_utc':datetime.now(timezone.utc).isoformat(), 'android_execution_validation':'pending',
                'contains_user_capture_data':False, 'profile':'local API35 Emulator + PCAPdroid 2.0.2',
                'files':[{'path':name, 'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())]}
    files['BUNDLE-MANIFEST.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2)+'\n').encode()
    with zipfile.ZipFile(args.out, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name,data in sorted(files.items()): archive.writestr(PREFIX+'/'+name, data)
    print(json.dumps({'zip':str(args.out), 'files':len(files), 'sha256':hashlib.sha256(args.out.read_bytes()).hexdigest(), 'bytes':args.out.stat().st_size}))


if __name__ == '__main__': main()
