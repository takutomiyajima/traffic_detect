#!/usr/bin/env python3
"""Offline policy/evidence examples from a verified guided ZIP; no Android actions.

Captured policies are retained. Research counterfactuals are labelled as frozen
before capture or retrospective. No new Android trials or accuracy claims.
"""
import argparse
import copy
import csv
import html
import json
import shutil
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from apk_audit.capture import import_capture
from apk_audit.cli import static_stage
from apk_audit.compare import compare
from apk_audit.core import add_evidence, read_json, sha256, write_json
from apk_audit.report import report
from review_guided_archives import review


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--policy-set', choices=['examples', 'captured'], default='examples')
    args = parser.parse_args()
    if args.out.exists():
        parser.error('Output already exists; choose a new output folder')
    reviewed = review(args.archive)
    if reviewed['case'] not in ('http', 'http_fail', 'https', 'udp', 'udp_hold', 'offline'):
        parser.error('Unsupported guided control')
    out = args.out.resolve()
    out.mkdir(parents=True)
    originals = out / 'originals'
    originals.mkdir()
    with zipfile.ZipFile(args.archive) as z:
        prefix = reviewed['trial_id'] + '/'
        for name in z.namelist():
            destination = originals / name.removeprefix(prefix)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(z.read(name))
    trial = read_json(originals / 'trial.json')
    frozen_protocol = originals / 'frozen-protocol.json'
    predefined = (frozen_protocol.is_file() and sha256(frozen_protocol) == trial.get('frozen_protocol_sha256')
                  and read_json(frozen_protocol).get('analysis_policy_variants') == ['captured', 'network_deny_all', 'network_unspecified'])
    counterfactual_basis = 'predefined_research_counterfactual' if predefined else 'retrospective_counterfactual'
    write_json(out / 'archive-review.json', reviewed)
    base = out / 'base-run'
    run = static_stage(originals / 'original.apk', base)
    run.update(external_trial_id=trial['trial_id'], execution_status='completed',
               execution_method='previous_guided_manual_capture',
               comparison_kind='predefined_research_policy_comparison' if predefined else 'post_capture_processing_examples')
    run['limitations'] += [
        'No new Android trial was performed by this offline tool',
        'Network counterfactual basis: ' + counterfactual_basis + '; not the captured developer declaration',
        'Server evidence is retained but not automatically joined to CSV flows',
        'No independent gold labels or accuracy metrics are produced',
    ]
    write_json(base / 'run.json', run)
    handoff = base / 'raw' / 'handoff'
    shutil.copytree(originals, handoff)
    for file in handoff.iterdir():
        add_evidence(base, 'handoff-' + file.name.replace('.', '-'), file,
                     'Preserved guided-trial source; no automatic cross-source flow merge')
    bounds = trial['endpoint_compatible_offset_s']
    meta = {
        'schema_version': '1.0', 'run_id': run['run_id'], 'apk_sha256': run['apk_sha256'],
        'tool': 'PCAPdroid', 'tool_version': '2.0.2',
        'started_utc': (originals / 'capture-start-earliest.txt').read_text().strip(),
        'ended_utc': (originals / 'capture-stop-latest.txt').read_text().strip(),
        'clock_offset_s': (bounds['lower'] + bounds['upper']) / 2,
        'clock_alignment_status': 'conditional', 'clock_offset_interval_s': bounds,
        'clock_basis': 'Constant offset compatible with endpoint batches; no capture-wide drift bound',
        'controls_before': 'passed', 'controls_after': 'passed',
        'control_evidence': reviewed['control_verification'],
        'coverage_status': trial['coverage_status'], 'missing_intervals': [],
        'missing_intervals_basis': 'No enumerated known gaps; continuity is operator-attested',
        'target_identity': {'package': trial['package'], 'uid': trial['target_uid'],
                            'source': 'raw/handoff/app-package.txt and installed APK hash measured before capture'},
        'byte_counter_basis': 'Native PCAPdroid CSV counters, not application body bytes',
    }
    write_json(base / 'capture.metadata.json', meta)
    count = import_capture(base, originals / 'capture.csv', base / 'capture.metadata.json', 'pcapdroid-csv')
    captured = read_json(originals / 'intent-before-capture.json')
    expected_mode = 'deny_all' if reviewed['case'] == 'offline' else 'allowlist'
    if captured['network']['mode'] != expected_mode:
        raise ValueError('Captured policy does not match the control profile')
    deny, unspecified = copy.deepcopy(captured), copy.deepcopy(captured)
    deny['network'] = {'mode': 'deny_all'}
    deny['app_purpose'] = counterfactual_basis + ': network denied; not the captured developer declaration'
    unspecified['network'] = {'mode': 'unspecified'}
    unspecified['app_purpose'] = counterfactual_basis + ': network policy unspecified'
    captured_id = 'captured_deny_all' if reviewed['case'] == 'offline' else 'captured_allowlist'
    policies = {captured_id: captured}
    if args.policy_set == 'examples':
        if reviewed['case'] != 'offline':
            policies['counterfactual_deny_all'] = deny
        policies['counterfactual_unspecified'] = unspecified
    for name, policy in policies.items():
        write_json(out / 'policies' / (name + '.json'), policy)
    summary = []
    for policy_id, policy in policies.items():
        for mode in ('static-only', 'dynamic-only', 'integrated'):
            destination = out / 'comparisons' / policy_id / mode
            shutil.copytree(base, destination)
            result = compare(destination, copy.deepcopy(policy), mode)
            report(destination)
            network = [f for f in result['findings'] if f['subject'] == 'external_connection']
            unknown = [f for f in result['findings'] if f['subject'] == 'connection_attribution' and f['attribution'] == 'unknown']
            summary.append({
                'trial_id': trial['trial_id'], 'policy': policy_id, 'evidence_mode': mode,
                'policy_basis': 'before_capture' if policy_id.startswith('captured_') else counterfactual_basis,
                'target_network_findings': len(network),
                'target_network_verdicts': [f['verdict'] for f in network],
                'unknown_attribution_findings_all_flows': len(unknown),
                'finding_counts_not_connection_counts': result['counts'],
                'report': str((destination / 'report.html').relative_to(out)),
            })
    write_json(out / 'comparison-summary.json', {
        'trial_id': trial['trial_id'], 'archive_sha256': sha256(args.archive),
        'imported_csv_rows': count, 'review': reviewed, 'results': summary,
        'accuracy_metrics_computed': False,
        'limitations': read_json(base / 'run.json')['limitations'],
    })
    fields = ['trial_id', 'policy', 'evidence_mode', 'policy_basis', 'target_network_findings',
              'target_network_verdicts', 'unknown_attribution_findings_all_flows', 'report']
    with (out / 'comparison-summary.csv').open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        for row in summary:
            writer.writerow({**row, 'target_network_verdicts': json.dumps(row['target_network_verdicts'])})
    esc = lambda value: html.escape(str(value), quote=True)
    labels = {'captured_allowlist': '取得前の許可条件', 'captured_deny_all': '取得前の禁止条件', 'counterfactual_deny_all': '事後の禁止条件',
              'counterfactual_unspecified': '事後の未指定条件', 'static-only': '静的のみ',
              'dynamic-only': '動的のみ', 'integrated': '統合'}
    if predefined:
        labels.update(counterfactual_deny_all='事前定義した研究用禁止条件',
                      counterfactual_unspecified='事前定義した研究用未指定条件')
    description = ('取得前の意図と凍結した研究用比較条件を用いる解析です。禁止・未指定は研究用の反実仮想で、元の開発者の宣言とは区別します。' if predefined else
                   '保存済みの証拠を使う事後の処理例です。禁止・未指定は反実仮想です。')
    rows = []
    for row in summary:
        verdict = ', '.join(row['target_network_verdicts']) or '対象通信の判定なし（理由はレポートで確認）'
        rows.append('<tr><td>' + esc(labels[row['policy']]) + '</td><td>' + esc(labels[row['evidence_mode']])
                    + '</td><td>' + esc(verdict) + '</td><td><a href="' + esc(row['report']) + '">根拠付きレポート</a></td></tr>')
    (out / 'index.html').write_text('<!doctype html><html lang="ja"><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        '<title>ポリシー照合の比較</title><style>body{font:16px/1.8 sans-serif;max-width:1100px;margin:2rem auto;padding:1rem}'
        'table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccd;padding:.5rem;text-align:left}</style>'
        '<h1>' + esc(trial['trial_id']) + '：ポリシー照合の比較</h1>'
        '<p>' + description + 'この解析で新しい端末実験は行わず、一般精度の評価でもありません。'
        '対象通信の判定がない場合も、通信なしとは解釈せず、証拠の除外・帰属不明等の理由を確認してください。</p>'
        '<table><tr><th>条件</th><th>方式</th><th>対象通信の判定</th><th>結果</th></tr>' + ''.join(rows)
        + '</table><p><a href="comparison-summary.csv">比較CSV</a> / <a href="comparison-summary.json">詳細JSON</a></p></html>')
    print(json.dumps({'saved': str(out), 'reports': len(summary), 'new_android_trials': 0,
                      'accuracy_metrics_computed': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
