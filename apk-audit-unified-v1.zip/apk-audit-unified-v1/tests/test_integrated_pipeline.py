import copy
import io
import json
import struct
from pathlib import Path

import dpkt
import pytest

from apk_audit.capture import pcap_flows
from apk_audit.capture import import_capture
from apk_audit.cli import parser
from apk_audit.core import AuditError, read_json, write_json, write_jsonl
from apk_audit.demo import demo
from apk_audit.differential import build
from apk_audit.pcapdroid import extended_pcap_flows, trailer_uid
from apk_audit.pipeline import analyze, scenario_input
from apk_audit.automatic import installed_uid, installed_hash, execute_steps


@pytest.fixture
def run(tmp_path):
    out = tmp_path/'run'
    demo(out)
    data = read_json(out/'static.json')
    data['urls'] = [{'host': 'telemetry.example.org', 'port': 443, 'scheme': 'https',
                     'raw': 'https://telemetry.example.org/path', 'evidence_ids': ['demo'], 'location': {'file': 'classes.dex'}}]
    write_json(out/'static.json', data)
    return out


def mutate_flow(run, **values):
    flows = [json.loads(line) for line in (run/'flows.jsonl').read_text().splitlines()]
    flows[0].update(values)
    write_jsonl(run/'flows.jsonl', flows)


def test_correspondence_and_evidence_links(run):
    result = build(run)
    assert result['counts']['both'] == 1
    assert result['records'][0]['flows'] == ['capture-1-flow-1']
    assert 'report.html#e-capture-1-flow-1' in (run/'summary.html').read_text()
    assert 'HTTPS成立' in result['records'][0]['explanation']


def test_ip_never_guesses_hostname(run):
    mutate_flow(run, host=None, host_evidence=None)
    result = build(run)
    assert result['counts']['both'] == result['counts']['dynamic_only'] == 0
    assert result['counts']['indeterminate'] == 2


def test_literal_ip_can_correspond_without_hostname(run):
    data = read_json(run/'static.json')
    data['urls'][0]['host'] = '192.0.2.1'
    write_json(run/'static.json', data)
    mutate_flow(run, host=None)
    assert build(run)['counts']['both'] == 1


def test_unknown_uid_never_promoted_by_endpoint(run):
    mutate_flow(run, attribution='unknown', uid=None)
    result = build(run)
    assert result['counts']['both'] == result['counts']['static_only'] == 0
    assert result['counts']['indeterminate'] == 2


def test_other_uid_is_not_target_difference(run):
    mutate_flow(run, attribution='other')
    result = build(run)
    assert result['counts']['static_only'] == 1
    assert result['flow_counts']['other'] == 1


def test_dynamic_only_is_limited_to_static_coverage(run):
    mutate_flow(run, host='runtime.example.org')
    assert build(run)['counts']['dynamic_only'] == 1
    state = read_json(run/'run.json')
    state['static_status'] = 'partial'
    write_json(run/'run.json', state)
    assert build(run)['counts']['dynamic_only'] == 0


def test_missing_capture_is_not_unobserved(run):
    state = read_json(run/'run.json')
    state.update(dynamic_status='failed', captures=[])
    write_json(run/'run.json', state)
    write_jsonl(run/'flows.jsonl', [])
    result = build(run)
    assert result['counts']['static_only'] == 0
    assert result['counts']['indeterminate'] == 1


def test_reference_hints_retained_and_html_escaped(run):
    static = read_json(run/'static.json')
    static['urls'].append({'host': 'www.w3.org', 'port': 80, 'raw': 'http://www.w3.org/2001/XMLSchema'})
    write_json(run/'static.json', static)
    state = read_json(run/'run.json')
    state['package'] = '<script>alert(1)</script>'
    write_json(run/'run.json', state)
    assert len(build(run)['reference_hints']) == 1
    assert '<script>' not in (run/'summary.html').read_text()


def test_reference_filter_does_not_hide_general_w3_website(run):
    static = read_json(run/'static.json')
    static['urls'].append({'host':'www.w3.org', 'port':443, 'scheme':'https', 'raw':'https://www.w3.org/news', 'location':{}, 'evidence_ids':['demo']})
    write_json(run/'static.json', static)
    result = build(run)
    assert not result['reference_hints']
    assert any(r['endpoint'] == 'www.w3.org:443' for r in result['records'])


def test_correspondence_checks_evidence_integrity(run):
    (run/'raw/capture-1.jsonl').write_text('tampered')
    with pytest.raises(AuditError, match='Modified correspondence evidence'):
        build(run)


def frame(uid=10123, extended=True):
    udp = dpkt.udp.UDP(sport=40000, dport=443, data=b'hello')
    udp.ulen = len(udp)
    ip = dpkt.ip.IP(src=b'\x0a\xd7\xad\x01', dst=b'\xc0\x00\x02\x01', p=17, data=udp)
    ip.len = len(ip)
    raw = b'\0'*12 + b'\x08\x00' + bytes(ip)
    if extended:
        raw += b'\0' * (-len(raw) % 4) + struct.pack('!Ii20sI', 0x01072021, uid, b'Not a package', 0)
    return raw


def pcap(tmp_path, frames):
    path = tmp_path/'test.pcap'
    with path.open('wb') as stream:
        writer = dpkt.pcap.Writer(stream)
        for n, data in enumerate(frames):
            writer.writepkt(data, ts=1767225600+n/100)
    return path


def metadata():
    return {'tool': 'PCAPdroid', 'tool_version': '2.0.2', 'clock_offset_s': 0,
            'started_utc': '2026-01-01T00:00:00Z', 'ended_utc': '2026-01-01T00:01:00Z',
            'client_ips': ['10.215.173.1']}


@pytest.mark.parametrize('uid,expected', [(10123, 10123), (-1, None)])
def test_trailer_identity(uid, expected):
    assert trailer_uid(frame(uid)) == expected


def test_bad_magic_truncation_and_forged_payload_are_not_uid():
    raw = frame()
    assert trailer_uid(raw[:-1]) is None
    assert trailer_uid(raw[:-32] + b'\0'*32) is None
    assert trailer_uid(raw[:-32] + b'x' + raw[-32:]) is None
    assert trailer_uid(frame(extended=False)) is None


@pytest.mark.parametrize('uids,expected', [([10123,10123], 'target'), ([10123,-1], 'unknown'), ([10123,10124], 'unknown'), ([10124,10124], 'other')])
def test_packet_uid_consensus(tmp_path, uids, expected):
    path = pcap(tmp_path, [frame(uid) for uid in uids])
    flows = list(extended_pcap_flows(path, {'package':'org.example.app', 'target_uid':10123}, metadata()))
    assert len(flows) == 1
    assert flows[0]['attribution'] == expected
    assert flows[0]['package'] is None
    assert flows[0]['source_record']['packet_numbers'] == [1,2]


def test_generic_pcap_does_not_elevate_uid_even_with_metadata_flag(tmp_path):
    path = pcap(tmp_path, [frame()])
    meta = metadata()
    meta['pcapdroid_extensions'] = True
    assert list(pcap_flows(path, {'target_uid':10123}, meta))[0]['attribution'] == 'unknown'


def test_wrong_pcapdroid_version_rejected(tmp_path):
    path = pcap(tmp_path, [frame()])
    meta = metadata()
    meta['tool_version'] = '9.9'
    with pytest.raises(AuditError, match='2.0.2'):
        list(extended_pcap_flows(path, {}, meta))


def test_default_scenario_and_invalid_durations():
    assert scenario_input()['steps'][0]['action'] == 'launch'
    with pytest.raises(AuditError):
        scenario_input(observe_s=float('nan'))
    with pytest.raises(AuditError):
        scenario_input(observe_s=-1)


def test_existing_output_cannot_be_modified(run):
    before = (run/'run.json').read_bytes()
    args = parser().parse_args(['analyze', '--apk', 'missing.apk', '--out', str(run)])
    with pytest.raises(AuditError, match='empty'):
        analyze(args)
    assert (run/'run.json').read_bytes() == before


class FakeAdb:
    def __init__(self, output): self.output = output
    def call(self, *args): return self.output


def test_api35_uid_format_is_exact_not_substring():
    adb = FakeAdb('package:org.example.app uid:10207\npackage:org.example.app.extra uid:11111\n')
    assert installed_uid(adb, 'org.example.app') == 10207
    with pytest.raises(AuditError): installed_uid(adb, 'org.example.missing')


def test_split_installation_refused():
    with pytest.raises(AuditError, match='split'):
        installed_hash(FakeAdb('package:/data/base.apk\npackage:/data/split.apk\n'), 'org.example.app')


def test_failed_launch_retains_failed_event(tmp_path, monkeypatch):
    import apk_audit.automatic as automatic
    monkeypatch.setattr(automatic, 'foreground', lambda *args: False)
    monkeypatch.setattr(automatic.time, 'sleep', lambda *args: None)
    ticks = iter([0, 11])
    monkeypatch.setattr(automatic.time, 'monotonic', lambda: next(ticks))
    with pytest.raises(AuditError, match='foreground'):
        execute_steps(FakeAdb('ok'), 'org.example.app', scenario_input(observe_s=0), tmp_path)
    assert json.loads((tmp_path/'ui_events.jsonl').read_text())['success'] is False


def prepare_live(monkeypatch, run, bridge_behavior, scenario_error=False):
    import apk_audit.automatic as automatic
    from apk_audit.core import sha256
    apk = run/'source.apk'; apk.write_bytes(b'input')
    controller = run/'bridge.apk'; controller.write_bytes(b'bridge')
    state = read_json(run/'run.json')
    state.update(package='org.example.app', apk_sha256=sha256(apk), captures=[])
    write_json(run/'run.json', state)
    calls = []
    class Adb:
        deadline = None
        def call(self, *args, **kwargs):
            calls.append(args)
            if args == ('get-state',): return 'device'
            if 'get-current-user' in args: return '0'
            if 'http_proxy' in args: return ':0'
            if 'ro.build.version.sdk' in args: return '35'
            if 'ro.product.cpu.abilist' in args: return 'arm64-v8a'
            if args[0] == 'install': return 'Success'
            return ''
    monkeypatch.setattr(automatic, 'Adb', lambda *args: Adb())
    monkeypatch.setattr(automatic, 'installed_hash', lambda adb,p: sha256(controller if p == automatic.BRIDGE else apk))
    monkeypatch.setattr(automatic, 'installed_uid', lambda *args: 10123)
    monkeypatch.setattr(automatic, 'clock_sample', lambda *args: {'offset_lower_s':0, 'offset_upper_s':0.1})
    class Bridge:
        permission_timeout = 0
        def __init__(self, *args): pass
        def request(self, action, **extras):
            calls.append(('bridge', action))
            return bridge_behavior(action)
    monkeypatch.setattr(automatic, 'Bridge', Bridge)
    return automatic, apk, controller, calls


def test_active_capture_is_never_stopped_or_replaced(run, monkeypatch):
    module, apk, controller, calls = prepare_live(monkeypatch, run, lambda action: {'version_name':'2.0.2', 'running':True})
    with pytest.raises(AuditError, match='already active'):
        module.execute(apk, run, 'emulator-5554', scenario_input(), controller)
    assert ('bridge','start') not in calls and ('bridge','stop') not in calls


def test_start_timeout_retains_manual_cleanup_without_unowned_stop(run, monkeypatch):
    def request(action):
        if action == 'get_status': return {'version_name':'2.0.2', 'running':False}
        raise AuditError('callback timeout')
    module, apk, controller, calls = prepare_live(monkeypatch, run, request)
    with pytest.raises(AuditError, match='timeout'):
        module.execute(apk, run, 'emulator-5554', scenario_input(), controller)
    assert read_json(run/'run.json')['manual_cleanup_required']
    assert ('bridge','stop') not in calls


def test_confirmed_start_is_stopped_after_control_failure(run, monkeypatch):
    statuses = iter([False, True, False])
    def request(action):
        if action == 'get_status': return {'version_name':'2.0.2', 'running':next(statuses)}
        if action == 'probe': raise AuditError('control failed')
        return {'result_code':-1}
    module, apk, controller, calls = prepare_live(monkeypatch, run, request)
    with pytest.raises(AuditError, match='control failed'):
        module.execute(apk, run, 'emulator-5554', scenario_input(), controller)
    assert ('bridge','stop') in calls
    assert read_json(run/'run.json')['execution_status'] == 'failed'


def test_clock_boundary_is_not_asserted_after_home(run):
    row = json.loads((run/'raw/demo-flow-input.jsonl').read_text())
    row.update(started_utc='2026-01-01T00:00:00.500Z', ended_utc='2026-01-01T00:00:01Z')
    write_jsonl(run/'boundary.jsonl', [row])
    meta = read_json(run/'demo.metadata.json')
    meta['clock_offset_interval_s'] = [-1, 1]
    write_json(run/'boundary.metadata.json', meta)
    import_capture(run, run/'boundary.jsonl', run/'boundary.metadata.json', 'app-flow')
    flow = json.loads((run/'flows.jsonl').read_text().splitlines()[-1])
    assert flow['ui_phase_status'] == 'boundary_uncertain'
    assert not flow['after_home'] and not flow['ui_phase_known']


def test_invalid_clock_bounds_do_not_import(run):
    meta = read_json(run/'demo.metadata.json')
    meta['clock_offset_interval_s'] = {'lower':1, 'upper':-1}
    write_json(run/'invalid-clock.json', meta)
    with pytest.raises(AuditError, match='bracket'):
        import_capture(run, run/'raw/demo-flow-input.jsonl', run/'invalid-clock.json', 'app-flow')


def test_static_failure_still_produces_honest_summary(tmp_path):
    source = tmp_path/'bad.apk'; source.write_bytes(b'not a zip file')
    out = tmp_path/'failed'
    result, code = analyze(parser().parse_args(['analyze', '--apk', str(source), '--out', str(out), '--static-only']))
    assert code == 4 and result['static_status'] == 'failed'
    assert (out/'summary.html').is_file()
    assert '静的解析のみ' in (out/'summary.html').read_text()


def test_replay_wrong_apk_is_rejected_before_new_run(tmp_path):
    source = tmp_path/'input.apk'; source.write_bytes(b'input')
    meta = tmp_path/'meta.json'; write_json(meta, {'apk_sha256':'wrong'})
    out = tmp_path/'not-created'
    args = parser().parse_args(['analyze', '--apk', str(source), '--out', str(out), '--capture', str(tmp_path/'capture.csv'), '--metadata', str(meta)])
    with pytest.raises(AuditError, match='APK hash'):
        analyze(args)
    assert not out.exists()
