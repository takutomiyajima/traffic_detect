"""Information deletion and unsupported assertion are distinct outcomes."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[1] / 'tools'))
from evaluate_existing_trials import uncertainty_ablation


def test_unknown_deletion_does_not_invent_a_no_communication_verdict():
    original = {'verdict': 'not_evaluable', 'observation': 'connection_attempt', 'attribution': 'unknown'}
    deleted = uncertainty_ablation(original, 'drop_unknown')
    assert deleted['information_lost'] and deleted['verdict'] is None
    assert not deleted['unsupported_assertion']
    asserted = uncertainty_ablation(original, 'unknown_as_violation')
    assert asserted['unsupported_assertion'] and asserted['verdict'] == 'mismatch_candidate'
    assert original['verdict'] == 'not_evaluable'


def test_missing_target_record_stays_without_a_communication_verdict():
    for method in ('proposed', 'drop_unknown', 'unknown_as_violation'):
        assert uncertainty_ablation(None, method)['verdict'] is None


def test_known_target_is_not_rewritten_by_uncertainty_ablations():
    original = {'verdict': 'consistent_with_observed_evidence', 'observation': 'connection_attempt', 'attribution': 'target'}
    for method in ('proposed', 'drop_unknown', 'unknown_as_violation'):
        result = uncertainty_ablation(original, method)
        assert result['verdict'] == original['verdict']
        assert not result['unsupported_assertion'] and not result['information_lost']
