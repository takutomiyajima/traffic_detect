"""Local Emulator capture through the official PCAPdroid 2.0.2 app API.

Device validation is pending. Consent is performed on Android, never bypassed.
"""
from __future__ import annotations

import json
import re
import shlex
import subprocess
import time
import uuid
from pathlib import Path

from .android import Adb
from .capture import import_capture, iso
from .control_server import ControlServers
from .core import AuditError, read_json, read_jsonl, sha256, utc_now, write_json, write_jsonl

BRIDGE = "org.example.apkaudit.capture"
VPN_CLIENTS = ["10.215.173.1", "fd00:2:fd00:1:fd00:1:fd00:1"]


def installed_uid(adb, package):
    rows = adb.call("shell", "pm", "list", "packages", "-U", package).splitlines()
    values = [int(m.group(1)) for row in rows
              if (m := re.fullmatch(r"package:" + re.escape(package) + r" uid:(\d+)", row.strip()))]
    if len(values) != 1:
        raise AuditError("Cannot establish unique installed package UID", 3)
    return values[0]


def installed_hash(adb, package):
    paths = [line[8:] for line in adb.call("shell", "pm", "path", package).splitlines() if line.startswith("package:")]
    if len(paths) != 1:
        raise AuditError("This runner requires a single APK installation (split APKs unsupported)", 3)
    value = adb.call("shell", "toybox", "sha256sum", shlex.quote(paths[0])).split()[0]
    if not re.fullmatch(r"[a-f0-9]{64}", value):
        raise AuditError("Installed APK SHA-256 unavailable", 3)
    return value


class Bridge:
    def __init__(self, adb, out, permission_timeout=120):
        self.adb, self.out, self.permission_timeout = adb, Path(out), permission_timeout
        self.trace = []

    def request(self, action, **extras):
        request = uuid.uuid4().hex
        args = ["shell", "am", "start", "-W", "-n", BRIDGE + "/.ControlActivity", "--es", "request_id", request, "--es", "action", action]
        for key, value in extras.items():
            args += ["--es", key, str(value)]
        started = utc_now()
        self.adb.call(*args)
        # run-as reads only this debuggable bridge's private callback file.
        until = time.monotonic() + self.permission_timeout
        while time.monotonic() < until:
            try:
                raw = self.adb.call("shell", "run-as", BRIDGE, "cat", "files/" + request + ".json")
                value = json.loads(raw)
            except AuditError:
                time.sleep(0.4)
                continue
            if value.get("request_id") != request:
                raise AuditError("Capture callback identity mismatch", 4)
            self.trace.append({"action": action, "request_id": request, "started_utc": started, "ended_utc": utc_now(), "result": value})
            write_json(self.out / "raw/bridge-results.json", self.trace)
            if value.get("result_code") != -1 or value.get("error"):
                raise AuditError(f"Android bridge {action} rejected/failed: {value}", 4)
            return value
        self.trace.append({"action": action, "request_id": request, "started_utc": started, "ended_utc": utc_now(), "error": "callback_timeout"})
        write_json(self.out / "raw/bridge-results.json", self.trace)
        raise AuditError(f"Android bridge {action}: no successful callback; check Android consent screen", 4)


def clock_sample(adb):
    before = time.time()
    mono = time.monotonic()
    text = adb.call("shell", "date", "+%s.%N").strip()
    after = time.time()
    elapsed = time.monotonic() - mono
    if not re.fullmatch(r"\d{10,}\.\d{1,9}", text) or abs(after - before - elapsed) > 0.05:
        raise AuditError("Android clock measurement invalid/discontinuous", 4)
    quantum = 10 ** -len(text.split(".")[1])
    return {"host_before": before, "host_after": after, "device": text,
            "offset_lower_s": before - float(text) - quantum, "offset_upper_s": after - float(text)}


def foreground(adb, package):
    text = adb.call("shell", "dumpsys", "activity", "activities")
    return any(re.search(r"\b" + re.escape(package) + r"/", row)
               for row in text.splitlines() if "mResumedActivity" in row or "topResumedActivity" in row)


def execute_steps(adb, package, scenario, out):
    events, phase = [], "foreground"
    for step in scenario["steps"]:
        event = {"event_id": step["id"], "action": step["action"], "started_utc": utc_now(), "success": False, "phase": phase}
        events.append(event)
        try:
            if step["action"] == "launch":
                adb.call("shell", "monkey", "-p", package, "-c", "android.intent.category.LAUNCHER", "1")
                until = time.monotonic() + 10
                while not foreground(adb, package):
                    if time.monotonic() > until:
                        raise AuditError("Target Activity did not reach foreground; intervention required", 4)
                    time.sleep(0.3)
                phase = "foreground"
            elif step["action"] == "tap":
                if not foreground(adb, package):
                    raise AuditError("Target is not foreground; tap refused", 4)
                node = adb.element(step["resource_id"])
                bounds = re.fullmatch(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", node.get("bounds", "")) if node is not None else None
                if not bounds or node.get("enabled") != "true":
                    raise AuditError("Requested UI resource missing/disabled; intervention required", 4)
                x1, y1, x2, y2 = map(int, bounds.groups())
                adb.call("shell", "input", "tap", (x1+x2)//2, (y1+y2)//2)
            elif step["action"] == "home":
                adb.call("shell", "input", "keyevent", "KEYCODE_HOME")
                if foreground(adb, package):
                    raise AuditError("Home transition not confirmed", 4)
                phase = "after_home"
                event["phase_confirmed_utc"] = utc_now()
            if step.get("expect_resource_id"):
                until = time.monotonic() + 10
                while adb.element(step["expect_resource_id"]) is None:
                    if time.monotonic() > until:
                        raise AuditError("Expected UI resource not reached", 4)
                    time.sleep(0.3)
            if adb.deadline is not None and time.monotonic() + step["observe_s"] > adb.deadline:
                raise AuditError("Trial deadline insufficient for planned observation", 4)
            time.sleep(step["observe_s"])
            event.update(success=True, phase=phase)
        finally:
            event["ended_utc"] = utc_now()
            write_jsonl(Path(out) / "ui_events.jsonl", events)


def execute(apk, out, serial, scenario, bridge_apk, max_seconds=600):
    out = Path(out)
    run = read_json(out / "run.json")
    package = run["package"]
    if not re.fullmatch(r"[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+", package) or package in (BRIDGE, "com.emanuelef.remote_capture"):
        raise AuditError("Unsupported target package", 3)
    adb = Adb(serial, time.monotonic() + max_seconds)
    bridge = Bridge(adb, out)
    start_attempted = False
    owned = False
    clocks = []
    filename = "audit-" + uuid.uuid4().hex + ".pcap"
    capture = out / "raw/automatic.pcap"
    error = None
    before = after = "unknown"
    started = utc_now()
    run.update(capture_backend="PCAPdroid 2.0.2 CaptureCtrl + UID extended PCAP", execution_status="pending",
               capture_backend_validation="pending_device_validation", serial=serial, initial_app_data="preserved",
               capture_settings={"vpn": True, "root": False, "tls_decryption": False, "dump_extensions": True,
                                 "all_apps": True, "full_payload": True, "proxy_changes": False})
    write_json(out / "run.json", run)
    try:
        if adb.call("get-state").strip() != "device" or adb.call("shell", "am", "get-current-user").strip() != "0":
            raise AuditError("Selected owner-user Emulator unavailable", 3)
        proxy = adb.call("shell", "settings", "get", "global", "http_proxy").strip()
        if proxy not in ("null", "", ":0"):
            raise AuditError("Global HTTP proxy is set; correct it manually before capture: " + proxy, 3)
        run["android"] = {"api": adb.call("shell", "getprop", "ro.build.version.sdk").strip(),
                          "abi": adb.call("shell", "getprop", "ro.product.cpu.abilist").strip(),
                          "fingerprint": adb.call("shell", "getprop", "ro.build.fingerprint").strip()}
        static = read_json(out / "static.json")
        if static.get("min_sdk") and int(static["min_sdk"]) > int(run["android"]["api"]):
            raise AuditError("Target minSdk exceeds selected Emulator", 3)
        if static.get("abis") and not set(static["abis"]).intersection(run["android"]["abi"].split(",")):
            raise AuditError("Target native ABI is incompatible with Emulator", 3)
        for target in (bridge_apk, apk):
            if "Success" not in adb.call("install", "-r", str(Path(target).resolve()), timeout=90):
                raise AuditError("APK install was not confirmed", 3)
        if installed_hash(adb, package) != run["apk_sha256"]:
            raise AuditError("Installed target APK differs from input", 4)
        if installed_hash(adb, BRIDGE) != sha256(bridge_apk):
            raise AuditError("Installed controller differs from input bridge", 4)
        run["target_uid"] = installed_uid(adb, package)
        run["bridge_uid"] = installed_uid(adb, BRIDGE)
        write_json(out / "raw/installation-identity.json", {"package": package, "uid": run["target_uid"], "apk_sha256": run["apk_sha256"], "bridge_uid": run["bridge_uid"]})
        print("Androidに制御の許可画面が出た場合は内容を確認して許可してください。初回の準備を確認中です。", flush=True)
        status = bridge.request("get_status")
        if status.get("version_name") != "2.0.2":
            raise AuditError("This automatic backend supports PCAPdroid 2.0.2 only", 3)
        if status.get("running") is not False:
            raise AuditError("A capture is already active or state unknown; stop it manually before running", 3)
        adb.call("shell", "am", "force-stop", package)
        clocks.append(clock_sample(adb))
        started = utc_now()
        print("AndroidにPCAPdroid制御・VPNの許可画面が出た場合は許可してください。応答を待っています。", flush=True)
        start_attempted = True
        bridge.request("start", pcap_name=filename)
        owned = True
        if bridge.request("get_status").get("running") is not True:
            raise AuditError("PCAPdroid start callback returned but service is not running", 4)
        with ControlServers(out / "raw/automatic-controls.jsonl") as server:
            port = server.addresses["http"][1]
            run["control_port"] = port
            def probe():
                result = bridge.request("probe", url=f"http://10.0.2.2:{port}/health")
                records = [v for _, v in read_jsonl(out / "raw/automatic-controls.jsonl")]
                confirmed = result.get("http_status") == 200 and any(v.get("run_id") == result["request_id"] and v.get("event") == "http_request_received" for v in records)
                if not confirmed:
                    raise AuditError("Pre/post control lacks matching successful device/server evidence", 4)
                return "passed"
            before = probe()
            execute_steps(adb, package, scenario, out)
            after = probe()
        run["execution_status"] = "completed"
    except (Exception, KeyboardInterrupt) as exc:
        error = exc
        run["execution_status"] = "failed"
        run["errors"].append({"stage": "automatic_capture", "type": type(exc).__name__, "message": str(exc)})
        try:
            from xml.etree.ElementTree import tostring
            (out / "raw/ui-on-error.xml").write_bytes(tostring(adb.ui(), encoding="utf-8"))
        except Exception:
            pass  # Never replace the original failure with diagnostic failure.
    finally:
        adb.deadline = time.monotonic() + 60
        bridge.permission_timeout = 20
        if owned:
            try:
                bridge.request("stop")
                if bridge.request("get_status").get("running") is not False:
                    raise AuditError("Capture stop not confirmed", 4)
                adb.call("pull", "/sdcard/Download/PCAPdroid/" + filename, str(capture), timeout=30)
                clocks.append(clock_sample(adb))
            except (Exception, KeyboardInterrupt) as exc:
                error = error or exc
                run.update(cleanup_failed=True, manual_cleanup_required=True)
                run["errors"].append({"stage": "capture_cleanup", "message": str(exc)})
        elif start_attempted:
            # Ownership is uncertain if start timed out. Never terminate another session blindly.
            run["manual_cleanup_required"] = True
        ended = utc_now()
        write_json(out / "raw/clock-samples.json", clocks)
        run.update(dynamic_status="failed", run_status="partial", ended_utc=ended)
        write_json(out / "run.json", run)
    if capture.exists():
        lower = max(c["offset_lower_s"] for c in clocks)
        upper = min(c["offset_upper_s"] for c in clocks)
        if len(clocks) != 2 or lower > upper:
            raise AuditError("Clock offset intervals disagree; raw PCAP retained, alignment not imported", 4)
        meta = {"schema_version": "1.0", "run_id": run["run_id"], "apk_sha256": run["apk_sha256"], "tool": "PCAPdroid", "tool_version": "2.0.2",
                "started_utc": iso(time_from_iso(started) - 1), "ended_utc": iso(time_from_iso(ended) + 1),
                "clock_offset_s": (lower+upper)/2, "clock_offset_interval_s": [lower, upper],
                "clock_basis": "pre/post host-bracketed device clock; drift between samples not bounded", "clock_alignment_status": "conditional",
                "coverage_status": "incomplete" if error else "unknown", "controls_before": before, "controls_after": after,
                "missing_intervals": [], "client_ips": VPN_CLIENTS,
                "target_identity": {"package": package, "uid": run["target_uid"], "source": "raw/installation-identity.json (ADB UID + installed hash)"}}
        write_json(out / "automatic.metadata.json", meta)
        import_capture(out, capture, out / "automatic.metadata.json", "pcapdroid-pcap")
    if error:
        raise AuditError(f"Automatic observation incomplete; raw evidence retained: {error}", 4)


def time_from_iso(value):
    from .core import timestamp
    return timestamp(value)
