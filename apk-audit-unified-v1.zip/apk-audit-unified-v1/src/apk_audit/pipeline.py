"""Single entry point for static analysis, observation, policy and explanation."""
from __future__ import annotations

import shutil
import math
from pathlib import Path

from .contracts import SCENARIO_SCHEMA, validate_intent
from .core import AuditError, read_json, sha256, validate_schema, write_json


def scenario_input(path=None, observe_s=30):
    scenario = read_json(path) if path else {"schema_version": "1.0", "scenario_id": "launch-wait-v1",
                "execution": "automatic", "repetitions": 1,
                "steps": [{"id": "launch", "action": "launch", "observe_s": observe_s}]}
    validate_schema(scenario, SCENARIO_SCHEMA)
    if scenario["execution"] != "automatic" or scenario["repetitions"] != 1:
        raise AuditError("analyze accepts one automatic scenario per output; use separate outputs for repeats")
    ids = [step["id"] for step in scenario["steps"]]
    if len(ids) != len(set(ids)) or scenario.get("preconditions"):
        raise AuditError("Scenario IDs must be unique; establish/log preconditions before this runner")
    for step in scenario["steps"]:
        if not math.isfinite(step["observe_s"]):
            raise AuditError("Observation interval must be finite")
        if step["action"] == "manual_checkpoint":
            raise AuditError("Use a recorded resource-ID scenario; manual checkpoints unsupported by analyze")
        if step["action"] == "tap" and (not step.get("resource_id") or not step.get("expect_resource_id")):
            raise AuditError("tap requires resource_id and expect_resource_id")
    return scenario


def analyze(args):
    from .cli import static_stage
    from .capture import import_capture
    from .compare import compare
    from .differential import build
    from .report import report

    out = Path(args.out)
    if out.exists() and any(out.iterdir()):
        raise AuditError("Output directory must be empty; previous evidence is never overwritten")
    if args.dynamic_timeout <= 0:
        raise AuditError("Dynamic timeout must be positive")
    if bool(args.capture) != bool(args.metadata):
        raise AuditError("Saved capture requires both --capture and --metadata")
    if args.static_only and (args.capture or args.scenario):
        raise AuditError("--static-only cannot be combined with capture/scenario")
    if args.capture and args.scenario:
        raise AuditError("Replay cannot execute a new scenario")
    scenario = scenario_input(args.scenario, args.observe_s) if not args.capture and not args.static_only else None
    intent = validate_intent(read_json(args.intent) if args.intent else {
        "schema_version": "1.0", "app_purpose": "未指定（システムによる推定なし）", "network": {"mode": "unspecified"},
        "sdk": {"mode": "unspecified"}, "permissions": {"mode": "unspecified"}})
    if args.capture:
        original_meta = read_json(args.metadata)
        if original_meta.get("apk_sha256") != sha256(args.apk):
            raise AuditError("Saved capture APK hash differs from input APK")
    mode = "replay" if args.capture else "static" if args.static_only else "live"
    failure = None
    try:
        run = static_stage(args.apk, out, args.timeout, args.max_apk_mib)
    except AuditError as exc:
        if not (out / "run.json").exists():
            raise
        run = read_json(out / "run.json")
        failure = exc
    run.update(analysis_mode=mode, analysis_version="unified-pipeline-v1-2026-11-02",
               intent_source="supplied" if args.intent else "unspecified_default")
    package_dir = Path(__file__).parent
    write_json(out / "raw/analysis-code-manifest.json", {"files": {
        str(path.relative_to(package_dir)): sha256(path) for path in sorted(package_dir.rglob("*"))
        if path.is_file() and path.suffix in (".py", ".json", ".apk") and "__pycache__" not in path.parts}})
    run["analysis_code_manifest_sha256"] = sha256(out / "raw/analysis-code-manifest.json")
    if scenario:
        run["analysis_scenario"] = scenario
        write_json(out / "scenario.json", scenario)
    write_json(out / "intent.json", intent)
    write_json(out / "run.json", run)
    try:
        if failure:
            raise failure
        if args.capture:
            shutil.copyfile(args.metadata, out / "raw/replay-original.metadata.json")
            meta = dict(original_meta)
            meta.update(run_id=run["run_id"], replay_source_run_id=original_meta["run_id"],
                        replay_original_metadata_sha256=sha256(args.metadata))
            write_json(out / "replay.metadata.json", meta)
            import_capture(out, args.capture, out / "replay.metadata.json", args.adapter)
        elif not args.static_only:
            from .automatic import execute
            data = Path(__file__).parent / "data"
            bridge_apk = data / "capture-controller.apk"
            if not bridge_apk.exists() or sha256(bridge_apk) != read_json(data / "capture-controller.json")["apk_sha256"]:
                raise AuditError("Bundled capture bridge missing/modified; use a complete distribution", 3)
            execute(args.apk, out, args.serial, scenario, bridge_apk, args.dynamic_timeout)
    except (Exception, KeyboardInterrupt) as exc:
        failure = exc
        run = read_json(out / "run.json")
        if run["dynamic_status"] == "not_run":
            run["dynamic_status"] = "failed"
        run["run_status"] = "partial"
        run["errors"].append({"stage": "pipeline", "type": type(exc).__name__, "message": str(exc)})
        write_json(out / "run.json", run)
    compare(out, intent)
    report(out)
    result = build(out)
    state = read_json(out / "run.json")
    return {"report": str((out / "summary.html").resolve()), "mode": mode,
            "static_status": state["static_status"], "dynamic_status": state["dynamic_status"],
            "counts": result["counts"], "error": str(failure) if failure else None}, (4 if failure else 0)
