#!/usr/bin/env python3
"""Package aggregate results and reproducible TeX/source; omit private evidence."""
from pathlib import Path
import ast
import hashlib
import json
import re
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[1]


def main():
    stage=ROOT/'dist/APK_AUDIT_INTENT_SEEDS_001_DATA_AND_TEX_2026-11-06'
    if stage.exists():raise ValueError('Preserve prior publication')
    files=set()
    def add(p):
        p=p.resolve();p.relative_to(ROOT)
        if p in files:return
        if not p.is_file():raise FileNotFoundError(p)
        files.add(p)
        if p.suffix=='.tex':
            for kind,name in re.findall(r'\\(input|include|includegraphics)(?:\[[^\]]*\])?\{([^}]+)\}',p.read_text()):
                q=ROOT/'docs'/name
                if not q.suffix and kind!='includegraphics':q=q.with_suffix('.tex')
                add(q)
        if p.parent==ROOT/'tools' and p.suffix=='.py':
            for node in ast.walk(ast.parse(p.read_text())):
                if isinstance(node,ast.ImportFrom) and node.module:
                    q=ROOT/'tools'/(node.module.split('.')[0]+'.py')
                    if q.is_file():add(q)
                if isinstance(node,ast.Import):
                    for alias in node.names:
                        q=ROOT/'tools'/(alias.name.split('.')[0]+'.py')
                        if q.is_file():add(q)
    for n in ['docs/thesis.tex','docs/thesis.pdf','docs/intent-seeds-001-results-2026-11-06.tex',
              'docs/intent-seeds-001-results-2026-11-06.pdf','tools/build_thesis.sh',
              'tools/build_intent_seed_report.py','tools/review_intent_seed_archive.py',
              'tools/package_intent_seed_results.py','dist/apk-audit-intent-v1.zip',
              'pyproject.toml','requirements-python311.lock','requirements.lock']:
        add(ROOT/n)
    for directory in ['docs/research/intent-seeds-001-2026-11-06','docs/research/intent-first-2026-11-06']:
        for p in (ROOT/directory).iterdir():
            if p.suffix in ('.json','.csv','.md') and p.name!='research-direction.md':add(p)
    for p in (ROOT/'src/apk_audit').rglob('*'):
        if p.is_file() and p.suffix in ('.py','.json','.apk'):add(p)
    for p in (ROOT/'tests').glob('test_intent*.py'):add(p)
    for p in (ROOT/'examples').glob('intent-*-v1.1.json'):add(p)
    for p in files:
        assert p.suffix not in ('.pcap','.pcapng','.jsonl')
        assert not p.is_relative_to(ROOT/'runs')
    stage.mkdir()
    for p in files:
        target=stage/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
    (stage/'README.md').write_text('''# 開発意図との照合：9試行の結果・データ・TeX（2026-11-06）

- docs/intent-seeds-001-results-2026-11-06.pdf：4ページの説明資料。
- docs/thesis.pdf：9試行を主結果へ反映した卒論草稿（29ページ）。
- docs/research/intent-seeds-001-2026-11-06/：試行別CSV、27出力の事後構成要素比較、根拠と制約、停止統計差の記録。
- tools/review_intent_seed_archive.py：既知の配布版で原本を再解析する点検コード。

原本9試行は入力先への整合3、固定先への不一致候補3、対象未観測の判定不能3でした。
自作3 APK、同一AVD、同じ開発側のソース期待値に対する結果です。一般精度100%ではありません。
静的のみ・動的のみ・併用の27出力は同じ原本の事後解析です。端末試行数に加えません。
75秒後の送信予定は約31〜32秒でアプリを停止しており、遅延送信の検出結果ではありません。
全取得品質partial、2試行の停止統計差を保持しています。原本298ファイルは変更していません。

TeX再生成：XeLaTeXとNoto CJK等を導入し bash tools/build_thesis.sh を実行します。
説明資料は python tools/build_intent_seed_report.py で再生成できます。
原本点検には別途、研究者用の非公開return ZIPとPython依存環境が必要です。
PYTHONPATH=src python tools/review_intent_seed_archive.py --archive /private/intent-seeds-001.return.zip --out runs/review-new

dist/apk-audit-intent-v1.zipは既に配布した同一の取得追加ツールです。既存Macプロジェクトと仮想環境が必要です。
この資料には新しい90秒観測ランナーを含めていません。現行--suiteは30秒窓の9試行のままです。
既存9試行を再実行する必要はありません。90秒条件は今後の計画であり実施結果ではありません。

ユーザー原本APK・PCAP・要求token・通信本文ログ・提供論文PDFは収録していません。
自作の参照APK・取得補助APKとソースは同梱ツール内に含みます。src/dataの取得補助APKも自作です。
AI支援の点検・執筆を独立した第三者評価とは扱いません。
''')
    entries={str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(stage.rglob('*')) if p.is_file()}
    (stage/'MANIFEST.json').write_text(json.dumps(dict(profile='intent-seed-001-reviewed-results',
        received_device_trials=9,cloud_device_trials=0,previous_supplementary_trials=29,
        retrospective_component_outputs=27,thesis_pages=29,results_pages=4,
        independent_accuracy_established=False,user_raw_data_included=False,
        own_reference_and_bridge_APKs_included=True,files=entries),ensure_ascii=False,indent=2)+'\n')
    zpath=stage.with_suffix('.zip')
    with zipfile.ZipFile(zpath,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(stage.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(stage.parent))
    artifacts=[zpath]
    for name,source in {
        'APK_AUDIT_INTENT_SEEDS_001_RESULTS_2026-11-06.pdf':'docs/intent-seeds-001-results-2026-11-06.pdf',
        'APK_AUDIT_INTENT_SEEDS_001_DRAFT_2026-11-06.pdf':'docs/thesis.pdf'
    }.items():
        target=ROOT/'dist'/name
        if target.exists():raise ValueError('Artifact exists: '+name)
        shutil.copy2(ROOT/source,target);artifacts.append(target)
    for p in artifacts:
        shutil.copy2(p,Path('/workspace/downloads')/p.name)
        print(json.dumps(dict(name=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())))


if __name__=='__main__':main()
