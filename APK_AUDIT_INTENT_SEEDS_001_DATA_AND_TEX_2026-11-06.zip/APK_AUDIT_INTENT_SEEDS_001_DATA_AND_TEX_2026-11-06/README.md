# 開発意図との照合：9試行の結果・データ・TeX（2026-11-06）

- docs/intent-seeds-001-results-2026-11-06.pdf：4ページの説明資料。
- docs/thesis.pdf：9試行を主結果へ反映した卒論草稿（29ページ）。
- docs/research/intent-seeds-001-2026-11-06/：試行別CSV、27出力の事後構成要素比較、根拠と制約、停止統計差の記録。
- tools/review_intent_seed_archive.py：既知の配布版で原本を再解析する点検コード。

原本9試行は入力先への整合3、固定先への不一致候補3、対象未観測の判定不能3でした。
自作3 APK、同一AVD、同じ開発側のソース期待値に対する結果です。一般精度100%ではありません。
静的のみ・動的のみ・併用の27出力は同じ原本の事後解析です。端末試行数に加えません。
75秒後の送信予定は約31〜32秒でアプリを停止しており、遅延送信の検出結果ではありません。
全取得品質partial、2試行の停止統計差を保持しています。原本298ファイルは変更していません。

TeX再生成：XeLaTeXとNoto CJK等を導入し bash tools/build_thesis.sh を実行します。
説明資料は python tools/build_intent_seed_report.py で再生成できます。
原本点検には別途、研究者用の非公開return ZIPとPython依存環境が必要です。
PYTHONPATH=src python tools/review_intent_seed_archive.py --archive /private/intent-seeds-001.return.zip --out runs/review-new

dist/apk-audit-intent-v1.zipは既に配布した同一の取得追加ツールです。既存Macプロジェクトと仮想環境が必要です。
この資料には新しい90秒観測ランナーを含めていません。現行--suiteは30秒窓の9試行のままです。
既存9試行を再実行する必要はありません。90秒条件は今後の計画であり実施結果ではありません。

ユーザー原本APK・PCAP・要求token・通信本文ログ・提供論文PDFは収録していません。
自作の参照APK・取得補助APKとソースは同梱ツール内に含みます。src/dataの取得補助APKも自作です。
AI支援の点検・執筆を独立した第三者評価とは扱いません。
