# 改善版の原稿・計画・変更ソース

docs/thesis.pdf：29ページ。既存9主評価・29補助は保持。追加12試行は実施前の計画。
docs/research/followup-2026-11-10/main.pdf：6ページの改善対応と実行手順。
同フォルダのREVIEW-RESPONSE.md、FROZEN-PROTOCOL.json、offline-validation.jsonを参照してください。

実行は別配布のapk-audit-followup-v1をDocumentsへ置き、既存apk-audit-unified-v1へ追加読込みします。
このソースZIPのsrcをMacの元ファイルへ上書きしないでください。
変更した4モジュール・追加素材ソース・新しい19検査等を収録しました。全テストの再現には既存プロジェクトが必要です。
原稿PDFの再生成は、構成を保持してbash tools/build_thesis.shを実行します。XeLaTeXとNoto等が必要です。
計画書のTeXはそのフォルダでxelatex main.texを2回実行します。
生PCAP、利用者の原APK、実際の要求tokenは収録していません。
