#!/usr/bin/env python3
"""Two manifest variants with identical Java/DEX; no Android execution."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from apk_audit.core import sha256, write_json


def main():
    p = argparse.ArgumentParser(); p.add_argument('--out', type=Path, required=True); a = p.parse_args()
    out = a.out.resolve()
    if out.exists(): raise ValueError('Preserve previous build; choose a new folder')
    sdk = ROOT / '.cache/android-toolchain'; bt = sdk / 'build-tools/android-15'
    jar = sdk / 'platform/android-35/android.jar'; key = sdk / 'research-debug.keystore'
    def run(*args):
        result = subprocess.run(list(map(str, args)), capture_output=True, text=True, timeout=120)
        if result.returncode: raise RuntimeError(result.stdout + result.stderr)
        return result.stdout
    out.mkdir(parents=True); (out / 'classes').mkdir(); (out / 'dex').mkdir()
    source = out / 'MainActivity.java'; shutil.copy2(ROOT / 'fixtures/followup/MainActivity.java.in', source)
    run('java', '-jar', sdk / 'ecj-3.39.0.jar', '-8', '-proc:none', '-classpath', jar, '-d', out / 'classes', source)
    run(bt / 'd8', '--min-api', '24', '--lib', jar, '--output', out / 'dex', *sorted((out / 'classes').rglob('*.class')))
    dex = out / 'dex/classes.dex'; rows = []
    base = ('<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="org.example.apkaudit.followup" android:versionCode="1" android:versionName="1.0">'
            '<uses-sdk android:minSdkVersion="24" android:targetSdkVersion="35"/><uses-permission android:name="android.permission.INTERNET"/>@EXTRA@'
            '<application android:theme="@android:style/Theme.Material.Light.NoActionBar" android:label="Intent follow-up" android:usesCleartextTraffic="true">'
            '<activity android:name=".MainActivity" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/>'
            '<category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>')
    for name, extra in [('base', ''), ('permission', '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>')]:
        work = out / name; work.mkdir(); manifest = work / 'AndroidManifest.xml'; manifest.write_text(base.replace('@EXTRA@', extra))
        run(bt / 'aapt2', 'link', '-I', jar, '--manifest', manifest, '-o', work / 'resources.apk')
        shutil.copy2(work / 'resources.apk', work / 'unsigned.apk')
        with zipfile.ZipFile(work / 'unsigned.apk', 'a') as z: z.write(dex, 'classes.dex')
        run(bt / 'zipalign', '-f', '4', work / 'unsigned.apk', work / 'aligned.apk')
        apk = out / (name + '.apk')
        run(bt / 'apksigner', 'sign', '--ks', key, '--ks-pass', 'pass:android', '--key-pass', 'pass:android', '--out', apk, work / 'aligned.apk')
        (work / 'signature-check.txt').write_text(run(bt / 'apksigner', 'verify', '--verbose', apk))
        rows.append({'case_id': name, 'package': 'org.example.apkaudit.followup', 'apk': apk.name, 'apk_sha256': sha256(apk),
                     'source_sha256': sha256(source), 'dex_sha256': sha256(dex), 'manifest_sha256': sha256(manifest), 'device_executed': False})
    assert rows[0]['dex_sha256'] == rows[1]['dex_sha256']
    write_json(out / 'inventory.json', {'profile': 'intent-followup-materials-v1', 'cases': rows, 'new_Android_trials': 0,
                                      'source_defined_same_author': True, 'same_DEX_both_APKs': True})
    print(json.dumps({'out': str(out), 'compiled_APKs': 2, 'same_DEX': True, 'new_Android_trials': 0}))


if __name__ == '__main__': main()
