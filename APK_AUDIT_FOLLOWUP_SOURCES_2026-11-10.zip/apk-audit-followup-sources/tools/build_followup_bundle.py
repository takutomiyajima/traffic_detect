#!/usr/bin/env python3
"""Distribute only owned research APKs and additive code, never user captures."""
import argparse
import json
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from apk_audit.core import sha256, write_json
from apk_audit.followup import prepare_plan


def main():
    p = argparse.ArgumentParser(); p.add_argument('--out', type=Path, required=True); a = p.parse_args()
    out = a.out.resolve()
    if out.exists(): raise ValueError('Keep existing bundles; choose a new name')
    built = ROOT / 'runs/intent-followup-build-v1'; prepare_plan(built)
    out.mkdir(parents=True); payload = out / 'payload'; payload.mkdir(); (payload / 'data').mkdir()
    modules = ['contracts.py','compare.py','pipeline.py','differential.py','explanation.py','intent_extensions.py','intent_overview.py',
               'report.py','support.py','followup.py','research_bundle.py','research_context.py','research_diagnosis.py',
               'research_contrast.py','research_comparison.py','research_switch.py']
    for name in modules: shutil.copy2(ROOT / 'src/apk_audit' / name, payload / name)
    for name in ('capture-controller.apk','capture-controller.json'): shutil.copy2(ROOT / 'src/apk_audit/data' / name, payload / 'data' / name)
    shutil.copy2(ROOT / 'tools/run_followup.py', out / 'run_followup.py')
    fixtures = out / 'fixtures'; fixtures.mkdir()
    for name in ('base.apk','permission.apk','inventory.json'): shutil.copy2(built / name, fixtures / name)
    source = out / 'reference-source'; source.mkdir(); shutil.copy2(built / 'MainActivity.java', source / 'MainActivity.java')
    for case in ('base','permission'): shutil.copy2(built / case / 'AndroidManifest.xml', source / (case + '-AndroidManifest.xml'))
    old = json.loads((ROOT / 'runs/diagnostic-ab-002-reviewed-2026-11-06/original/trial-001-A/raw/analysis-code-manifest.json').read_text())['files']
    compatible = {n:h for n,h in old.items() if n not in modules}
    for name,digest in compatible.items():
        if sha256(ROOT / 'src/apk_audit' / name) != digest: raise ValueError('Unplanned core change: ' + name)
    protocol = {'profile':'intent-followup-12-v1','status':'prepared_not_executed_on_Android','planned_trials':12,
                'conditions':{'normal':2,'outside':2,'mixed':2,'permission':2,'delay30':2,'delay100':2},
                'observation_s':{'normal':30,'outside':30,'mixed':30,'permission':30,'delay30':30,'delay100':100},
                'delay_s':75,'ports':{'allowed':18862,'outside':18861,'unused_candidate':18864},
                'same_DEX_both_variants':True,'same_APK_for_delay_windows':True,
                'paired_input_policy':'Same path/token inside each normal/outside/permission group; identical URI inside each delay-window pair. Time separates server candidates.',
                'new_conditions_relative_to_prior_nine':True,'independent_or_unseen_accuracy_sample':False,
                'development_use':'Built materials and static/synthetic checks before future captures; same author source contract.',
                'stop_rule':'At most 12, stop on execution/capture/cleanup failure, no automatic retries.',
                'remaining_manual':['Android run and consent','post-capture additional-operation declaration','independent review if feasible'],
                'not_included':['new Android HTTPS condition','real SDK evaluation','different-host Android condition','human task-time study']}
    write_json(out / 'FROZEN-PROTOCOL.json', protocol)
    (out / 'README.md').write_text(README)
    files = {str(q.relative_to(out)):sha256(q) for q in sorted(out.rglob('*')) if q.is_file()}
    write_json(out / 'BUNDLE-MANIFEST.json', {'profile':'intent-followup-additive-v1','files':files,'compatible_core':compatible,
        'contains_user_capture':False,'contains_user_APK':False,'contains_owned_reference_APKs':True,'modifies_existing_project':False})
    archive = out.with_suffix('.zip')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for q in sorted(out.rglob('*')):
            if q.is_file(): z.write(q,q.relative_to(out.parent))
    print(json.dumps({'archive':str(archive),'sha256':sha256(archive),'files':len(files),'compatible_core_files':len(compatible),'new_Android_trials':0}))


README = '''# 追加評価：6条件×2回、計12試行（followup-v1）

このフォルダをMacのDocumentsへ展開してください。既存のapk-audit-unified-v1は保持し、
中身を移動・上書きしません。この追加版はpayloadを優先読込みします。
既存のPython環境とソースの互換hash、配布ファイルのhashを開始前に確認します。

## ここで終える範囲

normal、outside、mixed、permission、delay30、delay100を各2回、計12試行です。
同じAPKで実行条件を変え、permission版は同一DEXでManifestの権限だけ異なります。
遅延要求は同じAPKで75秒後、観測時間は30秒と100秒です。
固定許可先は10.0.2.2:18862、許可外は同じホストの18861です。
18864の未使用URL候補はAPKへ含めますが、このソースでは要求しません。
異なるホストや一般HTTPS・実SDKの精度評価を追加した版ではありません。

開始前に計画・意図・期待出力・APKとコードのhashをローカル保存します。
正常・許可外・権限版は反復内で同じパスとtokenを使い、短窓と長窓も同じURIを使います。
受信候補は端点・tokenに加えて各試行の補正時刻で分離します。
素材は静的・合成入力の開発確認に使用済みなので、独立した未見標本とは呼びません。

## Macで実行する手順

1. Android Studioで既存のPixel_8_Edited_API_35を起動します。
2. 次でemulator-5554がdeviceになっていることを確認します。

```sh
adb devices -l
```

3. 他のPCAPdroid取得を停止して、以下を実行します。18861/18862を別サーバーが使っている場合は
   そのサーバーを手元で確認してください。このツールが無関係なプロセスを停止することはありません。

```sh
"$HOME/Documents/apk-audit-unified-v1/.venv/bin/python" \\
  "$HOME/Documents/apk-audit-followup-v1/run_followup.py" suite \\
  --out "$HOME/Documents/apk-audit-unified-v1/runs/intent-followup-001"
```

目安20〜35分です。同意待ちで変動します。追加タップ等はせず、Androidの制御・VPN同意だけ確認します。
最後の追加操作の質問に、実際の状況（0=なし、1=あり、2=不明）を答えます。
`intent-followup-001.return.zip` をチャットへ返してください。原本PCAPを含むのでGitHubへ公開しません。

同名出力があれば削除せず別名を選びます。取得・実行・cleanup失敗で後続は停止します。
失敗時はエラーとreturn.zipを返し、同じ条件を自己判断で何度も追加しません。
研究用パッケージorg.example.apkaudit.followupだけをインストール・停止します。
登録外APKがこの名前を使っていれば上書きを拒否します。公開アプリのデータ消去・アンインストールや
AVDの状態復元は行いません。ソースはデータを保存せず、前後の対象package状態を記録します。
この状態記録は、OSのキャッシュやAVD全体が同一である証明ではありません。

## 結果と再解析

各試行のsummary.htmlには、意図との照合、静的候補と観測の対応、指摘ごとの根拠と取得品質が出ます。
trial-results.jsonはソース仕様に対する確認で、合格数を一般精度へ変換しません。
混在では許可・許可外両方、権限版では通信に加えて静的権限を確認します。
同じ原本の3方式再解析はcomponent-replayへ分離し、36解析出力を新しい36端末試行に数えません。
短窓の保留と長窓の指摘は、原本が支持した場合にのみ結果とします。予定どおりでなければそのまま記録します。

## 自分の意図・シナリオを作る補助（今回の12試行とは別）

以下はファイルを生成するだけで、Androidを動かしません。目的と条件を確認してから解析に使います。
未指定カテゴリを自動で禁止にせず、入力先から無条件に許可先も学習しません。

```sh
"$HOME/Documents/apk-audit-unified-v1/.venv/bin/python" \\
  "$HOME/Documents/apk-audit-followup-v1/run_followup.py" init \\
  --network allowlist_or_recorded_inputs --package org.example.myapp \\
  --out "$HOME/Documents/my-intent-starter-001"
```

上の既定シナリオは起動・待機のみです。URI入力例外を使う場合は、対象のActivityとURIを
`--activity org.example.myapp/.MainActivity --uri http://example.org/feed` のように明示します。
固定APIを使う場合は`--network allowlist --endpoint https://api.example.org/`のように指定します。
実際のパッケージや許可先へ変更してください。設定生成の利用者効果はまだ測定していません。

## 検証状況

この配布時点ではAPKコンパイル・署名・静的抽出と、合成PCAP等の自動検査までです。
12試行の新しいAndroid実測、独立した第三者確認、作業時間削減効果は未実施です。
TLS/SNIだけでHTTPS本文・成立を確認済みにすることや、partialを完全取得へ変更することはありません。
'''


if __name__ == '__main__': main()
