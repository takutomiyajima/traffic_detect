"""Source-defined follow-up checks. No physical Android execution."""
from copy import deepcopy
from pathlib import Path

import pytest

from apk_audit.compare import compare, destination_verdict
from apk_audit.core import AuditError, read_json, read_jsonl, sha256, write_json, write_jsonl
from apk_audit.demo import demo
from apk_audit.followup import create_starter, intention, prepare_plan, run_suite, compare_components
from apk_audit.support import build_support, html_section


def materials(tmp_path):
    out = tmp_path / 'materials'; out.mkdir(); rows = []
    for name in ('base', 'permission'):
        apk = out / (name + '.apk'); apk.write_bytes(('unit-test-only-' + name).encode())
        rows.append({'case_id': name, 'apk': apk.name, 'apk_sha256': sha256(apk), 'dex_sha256': 'same-synthetic-dex',
                     'package': 'org.example.apkaudit.followup'})
    write_json(out / 'inventory.json', {'cases': rows})
    return out


def mixed_record(tmp_path):
    out = tmp_path / 'run'; demo(out)
    state = read_json(out / 'run.json'); state['dynamic_status'] = 'partial'; write_json(out / 'run.json', state)
    flows = [r for _, r in read_jsonl(out / 'flows.jsonl')]; first = flows[0]
    first.update(host='10.0.2.2', destination_ip='10.0.2.2', port=18862, transport='TCP', application_protocol='http', observation='http_observed', attribution='target')
    second = deepcopy(first); second.update(flow_id='synthetic-second-flow', port=18861)
    write_jsonl(out / 'flows.jsonl', [first, second])
    static = read_json(out / 'static.json'); static['permissions'] = [
        {'name': 'android.permission.INTERNET', 'evidence_ids': ['demo']},
        {'name': 'android.permission.ACCESS_FINE_LOCATION', 'evidence_ids': ['demo']}]
    write_json(out / 'static.json', static)
    return out


def test_mixed_allowed_and_outside_requests_survive_independently(tmp_path):
    out = mixed_record(tmp_path); result = compare(out, intention())
    rows = [r for r in result['findings'] if r['subject'] == 'external_connection']
    assert {(r['port'], r['verdict']) for r in rows} == {(18862, 'consistent_with_observed_evidence'), (18861, 'mismatch_candidate')}
    before = sha256(out / 'findings.json'); support = build_support(out, result)
    assert sha256(out / 'findings.json') == before and support['capture_quality'] == 'partial'
    assert not support['policy_verdicts_changed'] and all(not r['absence_supported'] for r in support['findings'])
    assert any(r['subject'] == 'permission_declaration' and r['verdict'] == 'mismatch_candidate' for r in result['findings'])


def test_unknown_owner_does_not_gain_target_status_in_support(tmp_path):
    out = mixed_record(tmp_path); flows = [r for _, r in read_jsonl(out / 'flows.jsonl')]
    for f in flows: f.update(attribution='unknown', uid=None)
    write_jsonl(out / 'flows.jsonl', flows); result = compare(out, intention()); support = build_support(out, result)
    assert not any(r['subject'] == 'external_connection' for r in result['findings'])
    assert any(r['subject'] == 'connection_attribution' and r['attribution'] == 'unknown' for r in support['findings'])
    assert '帰属不明' in html_section(support) and '不存在' in html_section(support)


def test_support_distinguishes_no_reference_and_modified_reference(tmp_path):
    out = mixed_record(tmp_path); result = compare(out, intention())
    result['findings'][0]['evidence_ids'] = []
    support = build_support(out, result); assert support['findings'][0]['evidence_integrity'] == 'not_referenced'
    item = next(iter(read_json(out / 'evidence/index.json').values())); (out / item['path']).write_text('changed synthetic input')
    support = build_support(out, result)
    assert any(r['evidence_integrity'] == 'missing_or_modified' for r in support['findings'])


def test_support_escapes_untrusted_fields(tmp_path):
    out = mixed_record(tmp_path); result = compare(out, intention())
    next(r for r in result['findings'] if r['subject'] == 'external_connection')['finding_id'] = '<script>alert(1)</script>'
    rendered = html_section(build_support(out, result))
    assert '<script>' not in rendered and '&lt;script&gt;' in rendered


def test_plan_is_twelve_conditions_and_same_apk_for_two_delay_windows(tmp_path):
    plan = prepare_plan(materials(tmp_path)); assert len(plan['trials']) == 12
    short = [r for r in plan['trials'] if r['condition'] == 'delay30']; long = [r for r in plan['trials'] if r['condition'] == 'delay100']
    assert len(short) == len(long) == 2
    assert {r['apk_sha256'] for r in short + long} == {short[0]['apk_sha256']}
    assert {r['observe_s'] for r in short} == {30} and {r['observe_s'] for r in long} == {100}
    assert all(not r['expected_request_ports'] for r in short) and all(r['expected_request_ports'] == [18861] for r in long)
    for repetition in (1,2):
        group = [r for r in plan['trials'] if r['repetition'] == repetition]
        assert len({r['token'] for r in group if r['condition'] in ('normal','outside','permission')}) == 1
        assert len({r['url'] for r in group if r['condition'].startswith('delay')}) == 1


def test_changed_materials_fail_before_device_operations(tmp_path):
    out = materials(tmp_path); (out / 'base.apk').write_bytes(b'changed')
    with pytest.raises(AuditError, match='identity'): prepare_plan(out)


def test_no_device_has_no_output(tmp_path, monkeypatch):
    import apk_audit.research_contrast as contrast
    monkeypatch.setattr(contrast, 'device_preflight', lambda s: (_ for _ in ()).throw(AuditError('device missing')))
    with pytest.raises(AuditError, match='device missing'): run_suite(materials(tmp_path), tmp_path / 'study')
    assert not (tmp_path / 'study').exists()


def test_first_pipeline_failure_stops_later_trials_and_keeps_primary_error(tmp_path, monkeypatch):
    import apk_audit.research_contrast as contrast
    import apk_audit.research_comparison as comparison
    import apk_audit.pipeline as pipeline
    import apk_audit.android as android
    monkeypatch.setattr(contrast, 'device_preflight', lambda s: {'synthetic': True})
    class Server:
        def __init__(self, port): pass
        def start(self): pass
        def close(self): pass
        def snapshot(self): return []
    class Adb:
        def __init__(self, serial): pass
        def call(self, *args):
            if args[:3] == ('shell', 'am', 'force-stop'): raise AuditError('secondary cleanup failure')
            return ''
    monkeypatch.setattr(comparison, 'ReferenceServer', Server); monkeypatch.setattr(android, 'Adb', Adb)
    called = []
    def fail(args):
        called.append(args); assert (args.out.parent / 'PREPARED.json').exists(); return {'error': 'primary pipeline failure'}, 4
    monkeypatch.setattr(pipeline, 'analyze', fail)
    result, code = run_suite(materials(tmp_path), tmp_path / 'study', non_interactive=True)
    assert code == 4 and len(called) == 1 and result['completed_trials'] == 0
    assert result['error']['message'] == 'primary pipeline failure'
    assert read_json(tmp_path / 'study/attempts.json')[0]['cleanup_error'] == 'secondary cleanup failure'
    assert (tmp_path / 'study.return.zip').is_file()


@pytest.mark.parametrize('host,protocol,expected', [('api.example.org','tls','not_evaluable'), (None,'tls','not_evaluable'),
                                                   ('elsewhere.example.org','http','mismatch_candidate')])
def test_https_and_hostname_boundary_is_not_guessed_from_port(host, protocol, expected):
    policy = {'mode': 'allowlist', 'allowed_destinations': [{'host': 'api.example.org', 'ports': [443], 'include_subdomains': False, 'application_protocols': ['https']}]}
    flow = {'host': host, 'destination_ip': '192.0.2.10', 'port': 443, 'application_protocol': protocol}
    assert destination_verdict(policy, flow)[0] == expected


def test_starter_preserves_unspecified_and_explicit_input_action(tmp_path):
    create_starter(tmp_path / 'config', 'allowlist_or_recorded_inputs', [], 'org.example.app', 'org.example.app/.MainActivity', 'http://example.org/feed')
    intent = read_json(tmp_path / 'config/intent.json')
    assert intent['permissions']['mode'] == intent['sdk']['mode'] == 'unspecified'
    assert read_json(tmp_path / 'config/scenario.json')['steps'][1]['action'] == 'open_uri'
    assert not read_json(tmp_path / 'config/preparation.json')['declaration_confirmed_by_user']


def test_component_copies_are_marked_replay_and_stale_summary_removed(tmp_path):
    out = mixed_record(tmp_path); compare(out, intention()); (out / 'summary.html').write_text('old live summary')
    rows = compare_components(out, tmp_path / 'components')
    assert len(rows) == 3 and not (tmp_path / 'components/static-only/summary.html').exists()
    assert read_json(tmp_path / 'components/integrated/run.json')['analysis_mode'] == 'replay'
    assert rows[1]['permission_mismatches'] == 0 and rows[2]['permission_mismatches'] == 1


@pytest.mark.parametrize('change,expected', [('none',True),('unknown',False),('server_duplicate',False),
                                           ('retransmission',True),('truncated',False),('old_time',False)])
def test_packet_witness_requires_UID_clock_and_unique_server_candidate(tmp_path, change, expected):
    import dpkt
    import struct
    from datetime import datetime, timezone
    from apk_audit.core import new_run
    from apk_audit.followup import request_evidence
    apk = tmp_path / 'synthetic.bin'; apk.write_bytes(b'synthetic-only')
    out = tmp_path / 'packet-run'; state = new_run(out, apk); state['target_uid'] = 10111; write_json(out / 'run.json', state)
    token = 'a' * 32; now = datetime.now(timezone.utc); path = '/feed/' + token + '.xml'
    data = (f'GET {path} HTTP/1.1\r\nHost: 10.0.2.2:18862\r\nX-Apk-Audit-Token: {token}\r\n\r\n').encode()
    if change == 'truncated': data = data[:-3]
    tcp = dpkt.tcp.TCP(sport=49000,dport=18862,seq=100,data=data)
    ip = dpkt.ip.IP(src=b'\x0a\xd7\xad\x01',dst=b'\x0a\x00\x02\x02',p=6,data=tcp); ip.len = len(ip)
    frame = b'\0'*12 + b'\x08\x00' + bytes(ip)
    frame += b'\0'*(-len(frame)%4) + struct.pack('!Ii20sI',0x01072021,-1 if change == 'unknown' else 10111,b'test',0)
    with (out/'raw/automatic.pcap').open('wb') as stream:
        writer = dpkt.pcap.Writer(stream); writer.writepkt(frame,ts=now.timestamp() - (10 if change == 'old_time' else 0))
        if change == 'retransmission': writer.writepkt(frame,ts=now.timestamp()+.001)
    write_json(out/'automatic.metadata.json',{'clock_offset_s':0})
    write_jsonl(out/'flows.jsonl',[{'flow_id':'synthetic','uid':10111,'attribution':'target','port':18862,'source_record':{'packet_numbers':[1,2]}}])
    events = [{'token':token,'path':path,'port':18862,'method':'GET','status':200,'write_completed':True,'started_utc':now.isoformat()}]
    if change == 'server_duplicate': events *= 2
    rows = request_evidence(out,token,events)
    assert bool([r for r in rows if r['candidate_match']]) == expected
    if change == 'retransmission': assert len(rows) == 1
