"""Opt-in Android URI contrast runner. Default preserves existing application data."""
from __future__ import annotations

import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import re
import threading
import uuid

from .core import AuditError, read_json, sha256, utc_now, write_json
from .research_context import scan_bounded
from .research_diagnosis import assess, capture_gate, plan_from_evidence, write_plan_report


class FeedServer:
    def __init__(self):
        owner = self
        self.events, self.lock = [], threading.Lock()
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_):
                pass
            def do_GET(self):
                owner.respond(self, False)
            def do_HEAD(self):
                owner.respond(self, True)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.port = self.server.server_address[1]
        self.thread = None

    def respond(self, handler, head):
        valid = re.fullmatch(r"/feed/[a-f0-9]{32}\.xml", handler.path) is not None
        body = (f'<?xml version="1.0"?><rss version="2.0"><channel><title>APK Contrast Research</title>'
                f'<link>http://10.0.2.2:{self.port}/</link><description>Controlled empty feed</description></channel></rss>').encode()
        status = 200 if valid else 404
        if not valid:
            body = b"not found"
        row = {"started_utc": utc_now(), "method": handler.command, "path": handler.path,
               "status": status, "write_completed": False, "body_bytes": 0 if head else len(body)}
        try:
            handler.send_response(status)
            handler.send_header("Content-Type", "application/rss+xml; charset=utf-8")
            handler.send_header("Content-Length", str(len(body)))
            handler.send_header("Cache-Control", "no-store")
            handler.end_headers()
            if not head:
                handler.wfile.write(body)
                handler.wfile.flush()
            row["write_completed"] = True
        except (BrokenPipeError, ConnectionResetError) as exc:
            row["error"] = type(exc).__name__
        finally:
            row["ended_utc"] = utc_now()
            with self.lock:
                self.events.append(row)

    def start(self):
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def close(self):
        if self.thread:
            self.server.shutdown()
            self.thread.join(timeout=5)
        self.server.server_close()

    def snapshot(self):
        with self.lock:
            return list(self.events)


def build_scenario(package, activity, url, observe_s):
    from .contracts import validate_open_uri
    scenario = {"schema_version": "1.0", "scenario_id": "controlled-input-switch-v1", "execution": "automatic", "repetitions": 1,
                "steps": [{"id": "launch", "action": "launch", "observe_s": 5},
                          {"id": "input", "action": "open_uri", "activity": activity, "uri": url, "observe_s": observe_s}]}
    validate_open_uri(scenario["steps"][1], package)
    return scenario


def device_preflight(serial):
    """Fail before creating a study if the selected emulator is unavailable."""
    from .android import Adb
    try:
        adb = Adb(serial)
        state = adb.call("get-state").strip()
        if state != "device":
            raise AuditError("ADB state=" + state)
        boot = adb.call("shell", "getprop", "sys.boot_completed").strip()
        if boot != "1":
            raise AuditError("Android boot is not complete (sys.boot_completed=" + boot + ")")
    except AuditError as exc:
        raise AuditError("選択したエミュレータ " + serial + " を使用できません。Android StudioのDevice Managerで起動し、"
                         "adb devices -l で同じ番号が device と表示されることを確認してください。元のエラー: " + str(exc), 3) from exc
    return {"serial": serial, "adb_state": state, "boot_completed": boot, "checked_utc": utc_now()}


def run_live(args):
    from .android import Adb
    from .pipeline import analyze
    from .cli import parser

    out = Path(args.out).resolve()
    apk = Path(args.apk).resolve()
    if out.exists():
        raise AuditError("Study output exists; choose a new folder")
    if not 1 <= args.observe_s <= 120 or not 1 <= args.pairs <= 5 or not re.fullmatch(r"[A-Za-z0-9_.]+", args.package):
        raise AuditError("Invalid package or observation duration")
    if args.snapshot and not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", args.snapshot):
        raise AuditError("Use a simple existing research snapshot name")
    if args.budget < 2 * args.pairs:
        raise AuditError("No discriminating probe fits the budget")
    preflight = device_preflight(args.serial)
    out.mkdir(parents=True)
    write_json(out / "device-preflight.json", preflight)
    context = scan_bounded(apk, out / "context.json")
    selection = plan_from_evidence(args.baseline_run, context, args.pairs, args.budget)
    write_json(out / "selection.json", selection)
    write_plan_report(out / "plan.html", selection, context)
    if selection["selected_probe"] != "input_switch" or selection["evidence_basis"]["package"] != args.package:
        if selection["reason"] == "dynamic_only_endpoints_have_local_constant_argument_candidates":
            result = {"diagnosis": "local_constant_argument_candidates_found", "new_device_trials": 0,
                      "causal_root_proven": False, "selection": selection, "report": str(out / "plan.html")}
            write_json(out / "diagnosis.json", result)
            return result, 0
        raise AuditError("Baseline does not support the implemented URI contrast; no Android trial started")
    servers = {"A": FeedServer(), "B": FeedServer()}
    # Alternating pair order AB, BA, AB...; this is not randomized or independent.
    order = [arm for i in range(args.pairs) for arm in (("A", "B") if i % 2 == 0 else ("B", "A"))]
    frozen = []
    for i, arm in enumerate(order, 1):
        trial_id = f"trial-{i:03}-{arm}"
        url = f"http://10.0.2.2:{servers[arm].port}/feed/{uuid.uuid4().hex}.xml"
        frozen.append({"trial_id": trial_id, "arm": arm, "url": url, "directory": trial_id,
                       "scenario": build_scenario(args.package, args.activity, url, args.observe_s)})
    plan = {"schema_version": "1.0", "runner_revision": "v1.1-startup-and-primary-errors", "prepared_utc": utc_now(), "apk_sha256": sha256(apk), "package": args.package,
            "serial": args.serial, "order": order, "trials": frozen, "selection": selection,
            "endpoints": {arm: s.port for arm, s in servers.items()},
            "state_policy": "restore_named_snapshot" if args.snapshot else "preserve_app_data_uncontrolled",
            "snapshot": args.snapshot, "new_device_trials_planned": len(order),
            "context_profile": context["profile"],
            "limitations": ["No complete GUI exploration or arbitrary causal diagnosis.",
                            "Snapshot loading is opt-in; preserved data are not matched initial state.",
                            "Each arm has a different per-trial nonce path; effect target is the first controlled request."]}
    write_json(out / "study-plan.json", plan)
    from . import research_context, research_diagnosis, research_bundle
    write_json(out / "RESEARCH-CODE-MANIFEST.json", {"files": {"research_context.py": sha256(research_context.__file__),
               "research_diagnosis.py": sha256(research_diagnosis.__file__), "research_contrast.py": sha256(__file__),
               "research_bundle.py": sha256(research_bundle.__file__)},
               "base_pipeline_sha256": sha256(__import__("apk_audit.pipeline", fromlist=["__file__"]).__file__)})
    write_json(out / "PREPARED-MANIFEST.json", {"files": {n: sha256(out / n) for n in ("study-plan.json", "context.json", "RESEARCH-CODE-MANIFEST.json")}})
    completed, attempts, failure = [], [], None
    phase = "preparation"
    try:
        for server in servers.values():
            server.start()
        for spec in frozen:
            state = "preserved_uncontrolled"
            if args.snapshot:
                # Restoring a named snapshot is explicitly requested by CLI.
                adb = Adb(args.serial)
                text = adb.call("emu", "avd", "snapshot", "load", args.snapshot)
                if "OK" not in text or "KO" in text:
                    raise AuditError("Snapshot restore not confirmed; no comparison made", 4)
                state = "named_snapshot_restore_acknowledged"
                write_json(out / (spec["trial_id"] + "-snapshot.json"), {"snapshot": args.snapshot, "console_result": text, "utc": utc_now()})
            scenario_path = out / (spec["trial_id"] + "-scenario.json")
            write_json(scenario_path, spec["scenario"])
            print(f"入力条件{spec['arm']}の観測です。購読・再生・画面移動は追加せず、制御・VPNの同意だけ確認してください。", flush=True)
            phase = "pipeline"
            attempt = {"trial_id": spec["trial_id"], "arm": spec["arm"], "directory": spec["directory"],
                       "started_utc": utc_now(), "status": "started"}
            attempts.append(attempt)
            write_json(out / "pipeline-attempts.json", attempts)
            cli = parser().parse_args(["analyze", "--apk", str(apk), "--serial", args.serial,
                                       "--scenario", str(scenario_path), "--out", str(out / spec["directory"])])
            result, code = analyze(cli)
            attempt.update(ended_utc=utc_now(), exit_code=code, pipeline_result=result,
                           status="pipeline_failed" if code or result.get("error") else "pipeline_completed")
            write_json(out / "pipeline-attempts.json", attempts)
            events_name = spec["trial_id"] + "-server.json"
            gate_name = spec["trial_id"] + "-gate.json"
            write_json(out / events_name, servers[spec["arm"]].snapshot())
            if code or result.get("error"):
                # Do not read capture evidence after an earlier failure; doing
                # so masks the primary error with a missing-file exception.
                message = result.get("error") or f"Pipeline returned exit code {code}"
                raise AuditError(message, 4)
            phase = "capture_gate"
            gate = capture_gate(out / spec["directory"])
            write_json(out / gate_name, gate)
            completed.append({**{k: spec[k] for k in ("trial_id", "arm", "url", "directory")},
                              "server_events": events_name, "capture_gate": gate_name, "state_condition": state,
                              "pipeline_exit_code": code, "pipeline_result": result})
            write_json(out / "trials.json", completed)
            if code or not gate["passed"]:
                raise AuditError("Trial/capture controls incomplete; remaining trials stopped", 4)
    except (Exception, KeyboardInterrupt) as exc:
        failure = {"type": type(exc).__name__, "message": str(exc), "phase": phase}
        if attempts:
            attempts[-1].setdefault("ended_utc", utc_now())
            if attempts[-1]["status"] == "started":
                attempts[-1]["status"] = "exception"
            attempts[-1]["exception"] = {"type": type(exc).__name__, "message": str(exc)}
            run_path = out / attempts[-1]["directory"] / "run.json"
            if run_path.is_file():
                run_state = read_json(run_path)
                failure["run_errors"] = run_state.get("errors", [])
                failure["static_status"] = run_state.get("static_status")
                failure["dynamic_status"] = run_state.get("dynamic_status")
            write_json(out / "pipeline-attempts.json", attempts)
        write_json(out / "failure.json", failure)
        import sys
        print("途中停止の原因: " + str(exc), file=sys.stderr, flush=True)
        print("詳細: " + str(out / "failure.json"), file=sys.stderr, flush=True)
    finally:
        for server in servers.values():
            server.close()
        import sys
        action_report = "unknown"
        if sys.stdin.isatty() and not getattr(args, "non_interactive", False) and failure is None:
            try:
                answer = input("観測中のアプリ追加操作：0=なし、1=あり、2=不明。数字を入力してEnter: ").strip()
                action_report = {"0": "none", "1": "reported"}.get(answer, "unknown")
            except (EOFError, KeyboardInterrupt):
                action_report = "unknown"
        write_json(out / "operator-report.json", {"recorded_utc": utc_now(), "additional_actions": action_report,
                   "basis": "post_capture_self_report" if action_report != "unknown" else "unknown",
                   "all_input_objectively_monitored": False})
        write_json(out / "trials.json", completed)
        prepared = read_json(out / "PREPARED-MANIFEST.json")["files"]
        if any(sha256(out / name) != digest for name, digest in prepared.items()):
            raise AuditError("Prepared study plan changed during execution", 4)
        write_json(out / "STUDY-MANIFEST.json", {"files": {str(p.relative_to(out)): sha256(p)
                   for p in sorted(out.rglob("*")) if p.is_file() and p.name not in ("STUDY-MANIFEST.json", "diagnosis.json", "diagnosis.html")},
                   "origin": "local_runner_integrity_not_independent_authentication"})
    result = assess(out)
    from .research_bundle import pack
    archive = pack(out)
    print("返却用ZIP（原本APKの重複をまとめて保存）: " + str(archive), flush=True)
    return result, 4 if failure else 0
