"""Developer-intent seed trial suite: three conditions x three repetitions.

Own reference APKs only. Existing public-app studies and app data stay intact.
"""
from pathlib import Path
import sys
import uuid

from .core import AuditError,read_json,sha256,utc_now,write_json
from .research_bundle import pack
from .research_comparison import ReferenceServer
from .research_contrast import build_scenario,device_preflight
from .research_switch import HOST,PORTS


def run_suite(fixtures,intent_file,out,serial='emulator-5554',non_interactive=False):
    from .android import Adb
    from .cli import parser
    from .pipeline import analyze
    from .contracts import validate_intent
    fixtures,out=Path(fixtures).resolve(),Path(out).resolve()
    if out.exists():raise AuditError('Output exists; preserve it and choose another name')
    intent=validate_intent(read_json(intent_file))
    if intent['network'].get('mode')!='allowlist_or_recorded_inputs' or intent['network']['allowed_destinations']:
        raise AuditError('Reference suite requires the frozen recorded-input-only intention')
    inventory=read_json(fixtures/'inventory.json')
    bycase={r['case_id']:r for r in inventory['cases']}
    selected=['input','fixed','delayed']
    for name in selected:
        identity=bycase[name]
        if (identity['package']!='org.example.apkaudit.compare.'+name
                or sha256(fixtures/identity['apk'])!=identity['apk_sha256']):
            raise AuditError('Reference APK changed: '+name)
    preflight=device_preflight(serial)
    servers=[]
    try:
        for port in PORTS.values():servers.append(ReferenceServer(port))
    except OSError as exc:
        for s in servers:s.close()
        raise AuditError('Research port 18761/18762/18763 is busy; no trial started: '+str(exc)) from exc
    out.mkdir(parents=True);write_json(out/'intent-before-analysis.json',intent)
    write_json(out/'device-preflight.json',preflight)
    trials=[]
    for rep in range(1,4):
        for name in selected:
            arm='A' if rep%2 else 'B';identity=bycase[name]
            url=f'http://{HOST}:{PORTS[arm]}/feed/{uuid.uuid4().hex}.xml'
            trials.append({'trial_id':name+f'-{rep:03}','condition':name,'repetition':rep,'arm':arm,
                'package':identity['package'],'apk':identity['apk'],'apk_sha256':identity['apk_sha256'],
                'scenario':build_scenario(identity['package'],identity['package']+'/.MainActivity',url,30)})
    expected={'input':'consistent_with_observed_evidence','fixed':'mismatch_candidate','delayed':'withheld_not_no_networking'}
    plan={'profile':'developer-intent-seeded-v1','prepared_utc':utc_now(),'physical_trials_planned':9,
        'intent_sha256':sha256(out/'intent-before-analysis.json'),'intent':intent,'trials':trials,
        'source_defined_expected_connection_results':expected,'oracle_basis':'same-author source contract, not independent app accuracy',
        'state_policy':'reference packages stopped before/after; no clear/uninstall; no public-app operation',
        'scope':'Endpoint consistency and withholding only; no payload leakage, purpose, real-SDK accuracy or AI-app population claim'}
    write_json(out/'seed-plan.json',plan)
    write_json(out/'materials-before-analysis.json',inventory)
    extensions={p.name:sha256(p) for p in Path(__file__).parent.glob('*.py')}
    write_json(out/'code-before-analysis.json',{'module_files':extensions,'basis':'local source snapshot, not execution attestation'})
    rows=[];attempts=[];failure=None;adb=Adb(serial)
    try:
        for server in servers:server.start()
        for spec in trials:
            print(f"意図照合 {len(attempts)+1}/9：{spec['trial_id']}。アプリを追加操作せず、同意画面だけ確認してください。",flush=True)
            attempts.append({'trial_id':spec['trial_id'],'started_utc':utc_now()});write_json(out/'attempts.json',attempts)
            scenario=out/(spec['trial_id']+'-scenario.json');write_json(scenario,spec['scenario'])
            primary=None
            try:
                args=parser().parse_args(['analyze','--apk',str(fixtures/spec['apk']),'--intent',str(out/'intent-before-analysis.json'),
                    '--scenario',str(scenario),'--serial',serial,'--out',str(out/spec['trial_id'])])
                result,code=analyze(args)
                if code or result.get('error'):raise AuditError(result.get('error') or 'Pipeline failed; later conditions stopped')
            except (Exception,KeyboardInterrupt) as exc:
                primary=exc;raise
            finally:
                try:adb.call('shell','am','force-stop',spec['package']);attempts[-1]['reference_stop_confirmed']=True
                except (Exception,KeyboardInterrupt) as exc:
                    attempts[-1]['cleanup_error']=str(exc)
                    if primary is None:raise
                finally:
                    attempts[-1]['ended_utc']=utc_now();write_json(out/'attempts.json',attempts)
            findings=read_json(out/spec['trial_id']/'findings.json')
            if findings['intent']!=intent:raise AuditError('Intention changed during trial')
            if findings.get('intent_declaration_basis')!='locally_recorded_before_static_analysis':
                raise AuditError('Pre-analysis declaration was not established; do not score this as prospective')
            connections=[r for r in findings['findings'] if r['subject']=='external_connection']
            rows.append({'trial_id':spec['trial_id'],'condition':spec['condition'],'connection_findings':connections,
                'declaration_basis':findings.get('intent_declaration_basis'),'quality':read_json(out/spec['trial_id']/'run.json')['dynamic_status'],
                'no_target_request_is_not_no_networking':True})
            write_json(out/'trial-results.json',rows)
            from .research_diagnosis import capture_gate
            gate=capture_gate(out/spec['trial_id']);write_json(out/(spec['trial_id']+'-capture-gate.json'),gate)
            if not gate['passed']:raise AuditError('Positive capture controls failed; later trials stopped')
    except (Exception,KeyboardInterrupt) as exc:
        failure={'type':type(exc).__name__,'message':str(exc)};write_json(out/'failure.json',failure)
    finally:
        for server in servers:server.close()
        report='unknown'
        if sys.stdin.isatty() and not non_interactive and failure is None:
            try:report={'0':'none','1':'reported','2':'unknown'}.get(input('観測中の追加操作：0=なし、1=あり、2=不明: ').strip(),'unknown')
            except (EOFError,KeyboardInterrupt):pass
        write_json(out/'operator-report.json',{'additional_actions':report,'basis':'post_capture_self_report','all_input_objectively_monitored':False})
        write_json(out/'trial-results.json',rows)
        write_json(out/'server-events.json',{str(s.server.server_address[1]):s.snapshot() for s in servers})
        write_json(out/'SEED-EVIDENCE.json',{'files':{str(p.relative_to(out)):sha256(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SEED-EVIDENCE.json'},
            'origin':'local integrity record, not independent attestation'})
    archive=pack(out)
    return {'profile':plan['profile'],'completed_trials':len(rows),'attempted_trials':len(attempts),'planned_trials':9,
        'error':failure,'archive':str(archive),'independent_accuracy_established':False},4 if failure else 0
