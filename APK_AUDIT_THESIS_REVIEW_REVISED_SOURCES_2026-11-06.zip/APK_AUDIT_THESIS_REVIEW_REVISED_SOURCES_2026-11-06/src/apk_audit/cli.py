from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path

from .contracts import INTENT_SCHEMA, SCENARIO_SCHEMA, validate_intent, validate_scenario
from .core import AuditError, new_run, read_json, sha256, write_json


def static_stage(apk, out, timeout=600, max_mib=200):
    if timeout <= 0 or max_mib <= 0:
        raise AuditError("Timeout and APK size limit must be positive")
    from .static import check_apk
    # Size guard before hashing/copying. Errors after run creation are always recorded.
    apk = Path(apk)
    if apk.stat().st_size > max_mib * 1024**2:
        raise AuditError("APK exceeds configured size limit")
    run = new_run(out, apk)
    out = Path(out)
    started = time.monotonic()
    try:
        check_apk(apk, max_mib)
        with (out / "raw/static-worker.log").open("w") as log:
            process = subprocess.run([sys.executable, "-m", "apk_audit._worker", str(apk.resolve()), str(out.resolve()), "--max-mib", str(max_mib)], stdout=log, stderr=log, timeout=timeout)
        info = read_json(out / "static-worker.json") if (out / "static-worker.json").exists() else {"error": "Worker terminated without result"}
        if process.returncode:
            raise AuditError(info.get("error", "Static worker failed"), 4)
        result = read_json(out / "static.json")
        partial = any(x["file"].endswith(".dex") or "scan limit" in x["reason"] for x in result["coverage"]["unprocessed"]) or any("unresolved" in w or "partial" in w for w in result["coverage"]["warnings"])
        run.update(package=result["package"], static_status="partial" if partial else "completed", run_status="partial" if partial else "completed", static_resources=info)
    except (AuditError, subprocess.TimeoutExpired, KeyboardInterrupt) as e:
        run.update(static_status="failed", run_status="failed")
        run["errors"].append({"stage": "static", "type": type(e).__name__, "message": str(e)})
        raise AuditError(f"Static analysis failed; see {out / 'run.json'}: {e}", e.code if isinstance(e, AuditError) else 4) from e
    finally:
        run["static_duration_s"] = time.monotonic() - started
        write_json(out / "run.json", run)
    return run


def parser():
    p = argparse.ArgumentParser(description="APK通信と開発意図の照合支援（安全性・漏えいの断定は行いません）")
    p.add_argument("--version", action="version", version="apk-audit 0.1.0")
    commands = p.add_subparsers(dest="command", required=True)
    a = commands.add_parser("analyze", help="APK → 静的解析・自動取得・比較説明。保存済みログも再解析できます")
    a.add_argument("--apk", required=True, type=Path)
    a.add_argument("--out", required=True, type=Path)
    a.add_argument("--serial", default="emulator-5554")
    a.add_argument("--intent", type=Path)
    a.add_argument("--scenario", type=Path)
    a.add_argument("--observe-s", default=30, type=float)
    a.add_argument("--static-only", action="store_true")
    a.add_argument("--capture", type=Path)
    a.add_argument("--metadata", type=Path)
    a.add_argument("--adapter", choices=["app-flow", "pcap", "pcapdroid-csv", "pcapdroid-pcap"], default="pcapdroid-csv")
    a.add_argument("--timeout", default=600, type=int)
    a.add_argument("--dynamic-timeout", default=600, type=int)
    a.add_argument("--max-apk-mib", default=200, type=int)
    doctor = commands.add_parser("doctor", help="Inspect local/Android prerequisites")
    doctor.add_argument("--profile", choices=["metadata"], default="metadata")
    doctor.add_argument("--serial")
    s = commands.add_parser("static", help="Analyze a single original APK")
    r = commands.add_parser("run", help="Run scenarios on a separately validated local emulator")
    for cmd in (s, r):
        cmd.add_argument("--apk", required=True, type=Path)
        cmd.add_argument("--out", required=True, type=Path)
        cmd.add_argument("--timeout", default=600, type=int)
        cmd.add_argument("--max-apk-mib", default=200, type=int)
    r.add_argument("--intent", required=True, type=Path)
    r.add_argument("--scenario", required=True, type=Path)
    r.add_argument("--serial", required=True)
    r.add_argument("--control-ip", required=True, help="Reachable IPv4 test host, used for pre/post capture controls")
    r.add_argument("--profile", choices=["metadata"], default="metadata")
    i = commands.add_parser("import", help="Import app-flow JSONL or PCAP with provenance metadata")
    i.add_argument("--run", required=True, type=Path)
    i.add_argument("--adapter", required=True, choices=["app-flow", "pcap", "pcapdroid-csv", "pcapdroid-pcap"])
    i.add_argument("--capture", required=True, type=Path)
    i.add_argument("--metadata", required=True, type=Path)
    c = commands.add_parser("compare")
    c.add_argument("--run", required=True, type=Path)
    c.add_argument("--intent", required=True, type=Path)
    c.add_argument("--evidence-mode", choices=["static-only", "dynamic-only", "integrated"], default="integrated")
    report = commands.add_parser("report")
    report.add_argument("--run", required=True, type=Path)
    demo = commands.add_parser("demo", help="Produce a synthetic example, not empirical results")
    demo.add_argument("--out", required=True, type=Path)
    schema = commands.add_parser("schemas")
    schema.add_argument("--out", required=True, type=Path)
    share = commands.add_parser("share", help="Export a minimal redacted summary without raw logs or endpoints")
    share.add_argument("--run", required=True, type=Path)
    share.add_argument("--out", required=True, type=Path)
    return p


def dispatch(a):
    if a.command == "analyze":
        from .pipeline import analyze
        result, code = analyze(a)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return code
    if a.command == "doctor":
        from .android import doctor
        info = doctor(a.serial)
        print(json.dumps(info, ensure_ascii=False, indent=2))
        return 0 if a.serial and info.get("state") == "device" else 3
    if a.command == "static":
        run = static_stage(a.apk, a.out, a.timeout, a.max_apk_mib)
        print(json.dumps({"run_id": run["run_id"], "static_status": run["static_status"], "out": str(a.out)}, ensure_ascii=False))
        return 0 if run["static_status"] == "completed" else 4
    if a.command == "run":
        from .android import execute
        from .compare import compare
        from .report import report
        intent = validate_intent(read_json(a.intent))
        scenario = validate_scenario(read_json(a.scenario))
        if a.out.exists() and any(a.out.iterdir()):
            raise AuditError("Output must be empty")
        results = []
        failure = None
        for index in range(scenario["repetitions"]):
            out = a.out if scenario["repetitions"] == 1 else a.out / f"repetition-{index+1:03}"
            try:
                run = static_stage(a.apk, out, a.timeout, a.max_apk_mib)
                run.update(repetition=index+1, intent_sha256=sha256(a.intent), scenario_sha256=sha256(a.scenario))
                write_json(out / "run.json", run)
                execute(a.apk, out, scenario, a.serial, a.control_ip, a.timeout)
            except (AuditError, subprocess.TimeoutExpired, KeyboardInterrupt) as e:
                failure = e if isinstance(e, AuditError) else AuditError(str(e), 4)
                if (out / "run.json").exists():
                    run = read_json(out / "run.json")
                    run.update(run_status="partial", execution_status="failed")
                    if run["static_status"] == "completed":
                        run["dynamic_status"] = "failed"
                    run["errors"].append({"stage": "run", "message": str(e)})
                    write_json(out / "run.json", run)
            if (out / "run.json").exists():
                compare(out, intent)
                report(out)
                results.append({"directory": str(out), "run_id": read_json(out / "run.json")["run_id"], "success": failure is None})
            if failure:
                break  # Never run another repetition after cleanup/observation failures.
        a.out.mkdir(parents=True, exist_ok=True)
        write_json(a.out / "experiment.json", {"planned_repetitions": scenario["repetitions"], "trials": results})
        if failure:
            raise failure
        return 0
    if a.command == "import":
        from .capture import import_capture
        print(f"Imported {import_capture(a.run, a.capture, a.metadata, a.adapter)} flow records (sources remain separate)")
        return 0 if read_json(a.run / "run.json")["dynamic_status"] == "completed" else 4
    if a.command == "compare":
        from .compare import compare
        print(json.dumps(compare(a.run, read_json(a.intent), a.evidence_mode)["counts"], ensure_ascii=False))
    elif a.command == "report":
        from .report import report
        print(f"Report written: {report(a.run)} findings")
    elif a.command == "demo":
        from .demo import demo
        print(f"Synthetic demonstration (not measurement): {demo(a.out)}")
    elif a.command == "schemas":
        write_json(a.out / "intent.schema.json", INTENT_SCHEMA)
        write_json(a.out / "scenario.schema.json", SCENARIO_SCHEMA)
    elif a.command == "share":
        from .share import export_summary
        export_summary(a.run, a.out)
    return 0


def main():
    try:
        return dispatch(parser().parse_args())
    except AuditError as e:
        print(f"apk-audit: {e}", file=sys.stderr)
        return e.code
    except (OSError, ValueError, KeyError, TypeError) as e:
        print(f"apk-audit: {type(e).__name__}: {e}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("apk-audit: interrupted", file=sys.stderr)
        return 4
    except Exception as e:
        print(f"apk-audit: internal failure: {type(e).__name__}: {e}", file=sys.stderr)
        return 5


if __name__ == "__main__":
    raise SystemExit(main())
