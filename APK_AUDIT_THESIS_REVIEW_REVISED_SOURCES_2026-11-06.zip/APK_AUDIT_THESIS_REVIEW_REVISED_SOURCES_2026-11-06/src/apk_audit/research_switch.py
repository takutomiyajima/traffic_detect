"""Evidence-gated URI switch assessment for the source-defined reference study.

Complete single-packet HTTP request headers only. A fixed positive endpoint is
an observed pattern, not proof of cache use or general input independence.
"""
from __future__ import annotations

import ipaddress
import re
from pathlib import Path
from urllib.parse import urlsplit

from .core import AuditError, read_json, read_jsonl, timestamp
from .pcapdroid import trailer_uid
from .research_diagnosis import capture_gate, verify_run

PROFILE = "registered-token-uri-switch-v1"
HOST = "10.0.2.2"
PORTS = {"fixed": 18761, "A": 18762, "B": 18763}
TOKEN_HEADER = b"x-apk-audit-token"


def classify(rows, order=("A", "B", "B", "A")):
    """Require positive witnesses in every condition; missing is not negative."""
    result = {"profile": PROFILE, "diagnosis": "inconclusive", "rows": rows,
              "complete_order": [r.get("arm") for r in rows] == list(order),
              "causal_root_proven": False, "general_accuracy_established": False,
              "remaining_hypotheses": ["input_endpoint_dependency", "input_independent_behavior"],
              "support_kind": "positive_observed_pattern_only"}
    if (not result["complete_order"] or len(rows) < 4 or set(order) != {"A", "B"}
            or any(not r.get("controls_passed") or not r.get("scenario_confirmed")
                   or r.get("unmatched_target_requests", 0) for r in rows)):
        return result
    endpoints = []
    for row in rows:
        observed = {(w["host"], w["port"]) for w in row.get("witnesses", [])}
        if len(observed) != 1:
            return result
        endpoints.append(next(iter(observed)))
    expected = [(HOST, r["input_port"]) for r in rows]
    if len(set(expected)) != 2:
        return result
    if endpoints == expected:
        result["diagnosis"] = "input_endpoint_association_observed"
    elif len(set(endpoints)) == 1:
        result["diagnosis"] = "fixed_positive_endpoint_observed_under_switch"
        result["fixed_endpoint"] = {"host": endpoints[0][0], "port": endpoints[0][1]}
    return result


def request_observations(directory, spec, server_events):
    """Inspect all registered-port target requests carrying this trial's token.

    Both intended and alternative ports are searched. Server matches are
    candidates: nonce/header + target UID + destination + conditional clock.
    """
    import dpkt

    directory = Path(directory)
    run = verify_run(directory)
    gate = capture_gate(directory)
    u = urlsplit(spec["url"])
    if (u.scheme != "http" or u.hostname != HOST or u.port != PORTS[spec["arm"]]
            or not re.fullmatch(r"/feed/[a-f0-9]{32}\.xml", u.path) or u.query or u.fragment):
        raise AuditError("Unexpected registered comparison URI")
    token = u.path[6:-4]
    row = {"trial_id": spec["trial_id"], "arm": spec["arm"], "input_port": u.port,
           "controls_passed": gate["passed"], "scenario_confirmed": False,
           "witnesses": [], "unknown_UID_packets_with_token": 0,
           "unmatched_target_requests": 0, "quality": run.get("dynamic_status")}
    missing = [n for n in ("automatic.metadata.json", "ui_events.jsonl") if not (directory/n).is_file()]
    if not gate["passed"] or missing:
        row["missing_evidence"] = missing + gate.get("missing_files", [])
        return row
    metadata = read_json(directory / "automatic.metadata.json")
    offset = metadata.get("clock_offset_s")
    actions = [r for _,r in read_jsonl(directory / "ui_events.jsonl")
               if r.get("action") == "open_uri" and r.get("success") is True and r.get("uri") == spec["url"]]
    scenario_ok = run.get("analysis_scenario") == spec["scenario"]
    actions = [r for r in actions if timestamp(r["ended_utc"]) - timestamp(r["started_utc"])
               >= spec["scenario"]["steps"][1]["observe_s"]]
    row["scenario_confirmed"] = bool(scenario_ok and actions)
    if (not gate["passed"] or not row["scenario_confirmed"] or type(offset) not in (int, float)):
        return row
    uid = run.get("target_uid")
    seen = set()
    with (directory / "raw/automatic.pcap").open("rb") as stream:
        reader = dpkt.pcap.Reader(stream)
        if reader.datalink() != dpkt.pcap.DLT_EN10MB:
            raise AuditError("Comparison requires Ethernet PCAPdroid extensions")
        for number, (ts, frame) in enumerate(reader, 1):
            try:
                ip = dpkt.ethernet.Ethernet(frame).data
                if (not isinstance(ip, dpkt.ip.IP) or ip.mf or ip.offset
                        or not isinstance(ip.data, dpkt.tcp.TCP) or str(ipaddress.ip_address(ip.dst)) != HOST):
                    continue
                tcp = ip.data
                if tcp.dport not in PORTS.values() or b"\r\n\r\n" not in tcp.data:
                    continue
                lines = tcp.data.split(b"\r\n\r\n", 1)[0].split(b"\r\n")
                first = lines[0].split(b" ")
                if len(first) != 3 or first[0] != b"GET" or first[2] not in (b"HTTP/1.0", b"HTTP/1.1"):
                    continue
                headers = [line.split(b":", 1) for line in lines[1:] if b":" in line]
                tokens = [v.strip() for k,v in headers if k.lower() == TOKEN_HEADER]
                hosts = [v.strip() for k,v in headers if k.lower() == b"host"]
                if tokens != [token.encode()] or hosts != [f"{HOST}:{tcp.dport}".encode()]:
                    continue
                packet_uid = trailer_uid(frame)
                if packet_uid is None:
                    row["unknown_UID_packets_with_token"] += 1
                    continue
                if packet_uid != uid:
                    continue
                key = (ip.src, tcp.sport, tcp.dport, tcp.seq, bytes(tcp.data))
                if key in seen:
                    continue
                seen.add(key)
                path = first[1].decode("ascii")
                host_time = float(ts) + offset
                in_window = any(timestamp(a["started_utc"]) - 1 <= host_time <= timestamp(a["ended_utc"]) + 1 for a in actions)
                matches = [i for i,e in enumerate(server_events, 1)
                           if e.get("token") == token and e.get("path") == path and e.get("port") == tcp.dport
                           and e.get("method") == "GET" and e.get("status") == 200 and e.get("write_completed") is True
                           and abs(timestamp(e["started_utc"]) - host_time) <= 1]
                if not in_window or len(matches) != 1:
                    row["unmatched_target_requests"] += 1
                    continue
                row["witnesses"].append({"packet": number, "uid": uid, "host": HOST, "port": tcp.dport,
                    "path": path, "server_record": matches[0], "token": token,
                    "correlation": "candidate_by_registered_header_destination_UID_and_conditional_clock"})
            except (ValueError, UnicodeError, dpkt.UnpackError, AttributeError):
                continue
    return row
