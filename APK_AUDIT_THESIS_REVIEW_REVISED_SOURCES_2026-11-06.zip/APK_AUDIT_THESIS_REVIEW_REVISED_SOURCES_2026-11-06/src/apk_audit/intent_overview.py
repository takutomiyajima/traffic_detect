"""Japanese policy-first overview; correspondence stays supporting evidence."""
from collections import Counter
import html


def section(result):
    esc=lambda x:html.escape(str(x),quote=True)
    names={"mismatch_candidate":"宣言との不一致候補","consistent_with_observed_evidence":"証拠の範囲で整合",
           "needs_review":"要確認","not_evaluable":"判定不能"}
    counts=Counter(r["verdict"] for r in result["findings"])
    selected=[r for r in result["findings"] if r["subject"]=='external_connection' or
              r["verdict"] in ("mismatch_candidate","not_evaluable") and r.get('attribution')!='other']
    selected.sort(key=lambda r:r['verdict']!='mismatch_candidate')
    rows=[]
    for r in selected[:30]:
        scope="宣言・静的候補" if r["observation"]=="static_only" else "観測・取得状態"
        links=' '.join('<a href="report.html#e-'+esc(e)+'">'+esc(e)+'</a>' for e in r["evidence_ids"])
        subject={'external_connection':'対象アプリの接続','permission_declaration':'権限宣言','sdk_candidate':'SDK候補',
                 'connection_attribution':'通信の帰属','target_observation_coverage':'対象通信の観測範囲'}.get(r['subject'],r['subject'])
        message=r['message']
        basis=r.get('permission_basis')
        if basis=='recorded_input_endpoint':message='記録された入力先・プロトコル・操作区間と整合しました。送信内容や利用目的の確認とは区別します。'
        elif basis=='outside_registered_and_explicit_endpoints':message='固定許可先・記録された入力先との照合結果です。'+('宣言外の接続候補として確認してください。' if r['verdict']=='mismatch_candidate' else '宛先情報が不足するため判断を保留します。')
        elif r['subject']=='permission_declaration':message='Manifestの権限宣言を意図と比較しました。実際の使用や送信を示すものではありません。 '+str(r.get('value',''))
        elif r['subject']=='sdk_candidate':message='登録ルールに一致するSDK候補を意図と比較しました。初期化・送信・正確なSDK識別の証明ではありません。 '+str(r.get('value',''))
        elif r['subject']=='target_observation_coverage':message='対象UIDの要求をこの観測範囲で確認できません。通信しないという結論にはしません。'
        elif r['subject']=='excluded_dynamic_scope':message='今回は静的解析のみです。通信の発生や不存在は評価していません。'
        rows.append('<tr><td>'+esc(names[r["verdict"]])+'</td><td>'+esc(scope)+' / '+esc(subject)+'</td><td>'+esc(message)+'</td><td>'+links+'</td></tr>')
    timing=result.get("intent_declaration_basis","未記録")
    return ('<section><h2>開発意図との照合（主結果）</h2><p>'+esc(' / '.join(names[k]+': '+str(counts[k]) for k in names))+'</p>'
        '<p>件数は対象外通信の注記も含む指摘数です。1件の通信に複数の指摘が付くため、通信回数へ合算しません。権限・SDK・URLの静的候補と、対象UIDの通信観測を区別します。</p>'
        '<p>意図の記録時点：'+esc(timing)+'。利用者入力の許可は、登録された操作・宛先・プロトコル・時刻区間が確認できた場合に限って適用します。</p>'
        '<table><tr><th>判定</th><th>証拠の範囲</th><th>内容</th><th>根拠</th></tr>'+''.join(rows)+'</table>'
        '<p><a href="report.html">全指摘・開発意図・証拠索引</a> / <a href="findings.json">照合JSON</a></p></section>')
