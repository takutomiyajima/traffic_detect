from .core import AuditError, normalize_host, validate_schema

POLICY = {"type": "string", "enum": ["allow", "forbid", "unspecified"]}
MODE = {"type": "string", "enum": ["allowlist", "deny_all", "unspecified"]}


def rule_schema(field, items):
    return {"type": "object", "additionalProperties": False, "required": ["mode"],
            "properties": {"mode": MODE, field: {"type": "array", "uniqueItems": True, "items": items}},
            "allOf": [{"if": {"properties": {"mode": {"const": "allowlist"}}},
                       "then": {"required": [field], "properties": {field: {"minItems": 1}}},
                       "else": {"properties": {field: {"maxItems": 0}}}}]}


DESTINATION = {"type": "object", "additionalProperties": False,
               "required": ["host", "include_subdomains", "ports", "application_protocols"],
               "properties": {"host": {"type": "string", "minLength": 1}, "include_subdomains": {"type": "boolean"},
                              "ports": {"type": "array", "minItems": 1, "uniqueItems": True, "items": {"type": "integer", "minimum": 1, "maximum": 65535}},
                              "application_protocols": {"type": "array", "uniqueItems": True,
                                                        "items": {"enum": ["http", "https", "dns", "tls", "quic", "other"]}}}}
INTENT_SCHEMA = {"$schema": "https://json-schema.org/draft/2020-12/schema", "type": "object", "additionalProperties": False,
                 "required": ["schema_version", "app_purpose", "network", "sdk", "permissions"],
                 "properties": {"schema_version": {"const": "1.0"}, "app_purpose": {"type": "string"},
                                "network": rule_schema("allowed_destinations", DESTINATION),
                                "sdk": rule_schema("allowed_ids", {"type": "string", "minLength": 1}),
                                "permissions": rule_schema("allowed", {"type": "string", "minLength": 1}),
                                "cleartext_policy": POLICY, "background_network_policy": POLICY}}
SCENARIO_SCHEMA = {"$schema": "https://json-schema.org/draft/2020-12/schema", "type": "object", "additionalProperties": False,
                   "required": ["schema_version", "scenario_id", "execution", "steps", "repetitions"],
                   "properties": {"schema_version": {"const": "1.0"}, "scenario_id": {"type": "string", "minLength": 1},
                                  "execution": {"enum": ["manual", "automatic"]}, "preconditions": {"type": "array", "items": {"type": "string"}},
                                  "repetitions": {"type": "integer", "minimum": 1, "maximum": 100},
                                  "steps": {"type": "array", "minItems": 1, "items": {
                                      "type": "object", "additionalProperties": False, "required": ["id", "action", "observe_s"],
                                      "properties": {"id": {"type": "string", "pattern": "^[A-Za-z0-9_-]+$"},
                                                     "action": {"enum": ["launch", "home", "tap", "wait", "manual_checkpoint", "open_uri"]},
                                                     "description": {"type": "string"}, "resource_id": {"type": "string"},
                                                     "uri": {"type": "string"}, "activity": {"type": "string"},
                                                     "expect_resource_id": {"type": "string"},
                                                     "observe_s": {"type": "number", "minimum": 0, "maximum": 600}}}}}}


def validate_intent(value):
    if isinstance(value,dict) and value.get("schema_version") == "1.1":
        from .intent_extensions import validate_extended
        return validate_extended(value)
    validate_schema(value, INTENT_SCHEMA)
    for dest in value["network"].get("allowed_destinations", []):
        dest["host"] = normalize_host(dest["host"])
    value.setdefault("cleartext_policy", "unspecified")
    value.setdefault("background_network_policy", "unspecified")
    return value


def validate_scenario(value):
    validate_schema(value, SCENARIO_SCHEMA)
    ids = [s["id"] for s in value["steps"]]
    if len(set(ids)) != len(ids):
        raise AuditError("Scenario step IDs must be unique")
    for s in value["steps"]:
        if s["action"] == "open_uri":
            raise AuditError("open_uri is supported only by analyze, not the legacy console runner")
        if s["action"] == "tap" and not s.get("resource_id"):
            raise AuditError("tap requires resource_id")
        if s["action"] in ("tap", "launch") and not s.get("expect_resource_id"):
            raise AuditError("launch/tap require expect_resource_id to confirm UI success")
        if value["execution"] == "automatic" and s["action"] == "manual_checkpoint":
            raise AuditError("automatic scenarios cannot contain manual checkpoints")
    return value


def validate_open_uri(step, package=None):
    """Only explicit, same-package Activities and HTTP(S) URLs are supported."""
    import re
    from urllib.parse import urlsplit
    uri, activity = step.get("uri", ""), step.get("activity", "")
    if not uri or any(ord(c) <= 32 or ord(c) == 127 for c in uri):
        raise AuditError("open_uri requires an HTTP(S) URL without control characters")
    try:
        parsed = urlsplit(uri)
        valid = parsed.scheme in ("http", "https") and bool(parsed.hostname) and parsed.username is None and parsed.password is None and not parsed.fragment
        if parsed.port is not None and not 1 <= parsed.port <= 65535:valid=False
    except ValueError:
        valid = False
    if not valid:
        raise AuditError("open_uri requires an HTTP(S) URL without credentials or fragment")
    match = re.fullmatch(r"([A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+)/([.]?[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)*)", activity)
    if not match or (package is not None and match[1] != package):
        raise AuditError("open_uri requires an explicit Activity in the target package")
    return uri, activity
