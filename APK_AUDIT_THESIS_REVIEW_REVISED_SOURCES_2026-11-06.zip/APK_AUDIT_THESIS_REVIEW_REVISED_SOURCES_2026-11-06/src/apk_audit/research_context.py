"""Bounded intrablock def-use for URL arguments; separate from frozen analysis.

No method reachability, cross-block propagation, or proof of transmission.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from pathlib import Path
import re
import subprocess
import sys
import zipfile

from .core import AuditError, sha256, url_candidate, write_json

PROFILE = "url-argument-context-v1"
SINKS = {
    "Ljava/net/URL;-><init>(Ljava/lang/String;)V": (1, "url_construction"),
    "Ljava/net/URI;-><init>(Ljava/lang/String;)V": (1, "uri_construction"),
    "Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;": (1, "request_configuration"),
    "Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V": (1, "webview_request_api"),
}
RUNTIME_SOURCES = {
    "Landroid/content/Intent;->getDataString()Ljava/lang/String;": "intent_data",
    "Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;": "intent_extra",
}


@dataclass(frozen=True)
class Value:
    text: str | None
    offsets: tuple[int, ...] = ()
    origins: tuple[str, ...] = ()


@dataclass(frozen=True)
class Builder:
    identity: int


def combine(a, b, offset):
    if not isinstance(a, Value) or not isinstance(b, Value):
        return None
    text = a.text + b.text if a.text is not None and b.text is not None else None
    if text is not None and len(text) > 4096:
        return None
    return Value(text, tuple(sorted(set(a.offsets + b.offsets + (offset,)))),
                 tuple(sorted(set(a.origins + b.origins))))


def analyze_block(instructions, location):
    """Interpret normalized DEX instructions within one actual basic block.

    Each invocation has its exact argument registers. Co-occurrence is never a
    def-use link. Unknown instructions invalidate tracked values conservatively.
    """
    registers, heap, pending, rows = {}, {}, None, []
    for ins in instructions:
        name, offset, regs = ins["op"], ins["offset"], ins.get("registers", [])
        if name.startswith("move-result"):
            if regs:
                registers[regs[0]] = pending
            pending = None
            continue
        pending = None
        if name in ("const-string", "const-string/jumbo"):
            registers[regs[0]] = Value(ins["string"], (offset,))
        elif name.startswith("move-object"):
            registers[regs[0]] = registers.get(regs[1])
        elif name == "new-instance":
            registers[regs[0]] = Builder(offset) if ins.get("type") == "Ljava/lang/StringBuilder;" else None
            if isinstance(registers[regs[0]], Builder):
                heap[offset] = None  # Not initialized until its constructor.
        elif name.startswith("invoke-"):
            method = ins.get("method", "").replace(" ", "")
            args = [registers.get(r) for r in regs]
            if method in SINKS:
                arg_index, usage = SINKS[method]
                value = args[arg_index] if len(args) > arg_index else None
                endpoint = url_candidate(value.text) if isinstance(value, Value) and value.text else None
                status = ("constant_url_argument" if endpoint else "constant_non_url_argument") if isinstance(value, Value) and value.text is not None else (
                    "runtime_value_argument" if isinstance(value, Value) and value.origins else "unresolved_argument")
                rows.append({**location, "offset_bytes": offset, "api": method, "usage_kind": usage,
                             "argument_register": regs[arg_index] if len(regs) > arg_index else None,
                             "status": status, "value": value.text if isinstance(value, Value) else None,
                             "endpoint": endpoint, "definition_offsets": list(value.offsets) if isinstance(value, Value) else [],
                             "runtime_origins": list(value.origins) if isinstance(value, Value) else [],
                             "execution_proven": False, "transmission_proven": False})
            receiver = args[0] if args else None
            if method in RUNTIME_SOURCES:
                pending = Value(None, (offset,), (RUNTIME_SOURCES[method],))
            elif method == "Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;" and len(args) == 2:
                pending = combine(args[0], args[1], offset)
            elif method.startswith("Ljava/lang/StringBuilder;->") and isinstance(receiver, Builder):
                identity = receiver.identity
                if method == "Ljava/lang/StringBuilder;-><init>()V":
                    heap[identity] = Value("", (offset,))
                elif method == "Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V" and len(args) == 2:
                    heap[identity] = args[1] if isinstance(args[1], Value) else None
                elif method == "Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;" and len(args) == 2:
                    heap[identity] = combine(heap.get(identity), args[1], offset)
                    pending = receiver
                elif method == "Ljava/lang/StringBuilder;->toString()Ljava/lang/String;":
                    pending = heap.get(identity)
                else:
                    heap[identity] = None
            else:
                # Unmodeled calls may mutate any builder argument, including an
                # aliased receiver. Immutable String values remain unchanged.
                for arg in args:
                    if isinstance(arg, Builder):
                        heap[arg.identity] = None
        elif name == "check-cast":
            pass
        elif name.startswith(("if-", "goto", "return", "throw")) or name == "nop":
            pass  # Real blocks terminate here; no state crosses a block edge.
        else:
            # Covers unmodeled register writes, fields, array operations, etc.
            # Clearing all is deliberately conservative, not a full DEX model.
            registers.clear()
            heap.clear()
    return rows


def normalize_instruction(instruction, offset):
    operands = instruction.get_operands()
    result = {"op": instruction.get_name(), "offset": offset,
              "registers": [o[1] for o in operands if int(o[0]) == 0]}
    for operand in operands:
        if len(operand) < 3:
            continue
        if int(operand[0]) == 257:
            result["string"] = operand[2]
        elif int(operand[0]) == 256:
            result["method"] = operand[2]
        elif int(operand[0]) == 259:
            result["type"] = operand[2]
    return result


def scan_apk(apk, max_instructions=2_000_000, max_methods=150_000):
    from loguru import logger
    logger.disable("androguard")
    from androguard.core.dex import DEX
    from androguard.core.analysis.analysis import MethodAnalysis
    from .static import check_apk

    check_apk(apk)
    records, unprocessed, dex_hashes = [], [], {}
    methods, instructions, blocks = 0, 0, 0
    with zipfile.ZipFile(apk) as archive:
        for name in sorted(archive.namelist()):
            if not re.fullmatch(r"classes\d*\.dex", name):
                continue
            import hashlib
            raw = archive.read(name)
            dex_hashes[name] = hashlib.sha256(raw).hexdigest()
            try:
                dex = DEX(raw)
                for cls in dex.get_classes():
                    for method in cls.get_methods():
                        methods += 1
                        if methods > max_methods:
                            raise AuditError("Context method budget exceeded")
                        has_sink = False
                        for instruction in method.get_instructions():
                            instructions += 1
                            if instructions > max_instructions:
                                raise AuditError("Context instruction budget exceeded")
                            if instruction.get_name().startswith("invoke-"):
                                text = instruction.get_output().replace(" ", "")
                                has_sink |= any(api in text for api in SINKS)
                        if not has_sink:
                            continue
                        for block in MethodAnalysis(dex, method).get_basic_blocks().get():
                            location = {"dex": name, "class": cls.get_name(), "method": method.get_name(),
                                        "descriptor": method.get_descriptor(), "block_start_bytes": block.get_start()}
                            offset, normalized = block.get_start(), []
                            for instruction in block.get_instructions():
                                normalized.append(normalize_instruction(instruction, offset))
                                offset += instruction.get_length()
                            records.extend(analyze_block(normalized, location))
                            blocks += 1
            except Exception as exc:
                unprocessed.append({"dex": name, "reason": type(exc).__name__ + ": " + str(exc)})
                if isinstance(exc, AuditError):
                    break
    return {"schema_version": "1.0", "profile": PROFILE, "apk_sha256": sha256(apk),
            "analysis_status": "partial" if unprocessed else "completed_within_supported_scope",
            "supported_apis": SINKS, "counts": dict(Counter(r["status"] for r in records)),
            "coverage": {"methods_seen": methods, "instructions_seen": instructions,
                         "sink_method_blocks_analyzed": blocks, "unprocessed": unprocessed, "dex_sha256": dex_hashes},
            "records": records,
            "limitations": ["Intrablock only: no call graph, method reachability, cross-block or cross-method proof.",
                            "URL/URI construction and request configuration do not prove transmission.",
                            "Unsupported operations invalidate values; unresolved is not unused.",
                            "Resource lookup, reflection, native code, general builder behavior are not modeled.",
                            "Static runtime-source tags do not prove actual runtime use or cause."]}


def scan_bounded(apk, out, timeout=180):
    """Disposable worker; no original APK or established analysis is rewritten."""
    import apk_audit
    out = Path(out)
    if out.exists():
        raise AuditError("Context output already exists; choose a new path")
    out.parent.mkdir(parents=True, exist_ok=True)
    code = ("import sys;sys.path.insert(0,sys.argv[1]);import apk_audit;"
            "apk_audit.__path__.insert(0,sys.argv[2]);"
            "from apk_audit._worker import configure_memory_limit;limits=configure_memory_limit();"
            "from apk_audit.research_context import scan_apk;from apk_audit.core import write_json;"
            "result=scan_apk(sys.argv[3]);result['worker_resource_limits']=limits;write_json(sys.argv[4],result)")
    log = out.with_suffix(".log")
    with log.open("w") as stream:
        try:
            subprocess.run([sys.executable, "-c", code, str(Path(apk_audit.__file__).resolve().parents[1]),
                            str(Path(__file__).parent), str(Path(apk).resolve()), str(out.resolve())],
                           stdout=stream, stderr=stream, check=True, timeout=timeout)
        except (subprocess.SubprocessError, OSError) as exc:
            write_json(out, {"profile": PROFILE, "analysis_status": "failed", "error": type(exc).__name__ + ": " + str(exc),
                             "apk_sha256": sha256(apk), "records": [], "counts": {}})
            raise AuditError(f"Context worker failed; see {log}", 4) from exc
    from .core import read_json
    return read_json(out)
