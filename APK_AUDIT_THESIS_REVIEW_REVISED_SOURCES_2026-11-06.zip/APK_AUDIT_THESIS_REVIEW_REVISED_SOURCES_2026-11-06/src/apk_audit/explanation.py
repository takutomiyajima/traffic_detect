"""Deterministic explanations of correspondence, not inferred root causes.

This layer consumes the existing static/flow comparison.  It does not change
its matching, assign an unknown UID, infer developer intent, or claim coverage.
"""
from __future__ import annotations

import csv
import html
from collections import Counter
from pathlib import Path

from .core import is_ip, read_json, read_jsonl, write_json
from .report import csv_safe

PROFILE = "static-dynamic-difference-explanation-v1"
LABELS = {"both": "静的候補と実測が対応", "static_only": "静的候補に対応する実測なし",
          "dynamic_only": "実測に対応する静的候補なし", "indeterminate": "対応の判断に不足あり"}
GAPS = {
    "capture_unavailable": "有効な動的取得がなく、未観測と判断する前提が不足しています。",
    "static_incomplete": "静的解析が完了しておらず、候補の有無を確定する前提が不足しています。",
    "attribution_unresolved": "関連する通信に対象UIDと確認できない記録があります。",
    "capture_failed": "関連する記録が取得失敗を表しています。",
    "hostname_unavailable": "関連する通信にホスト名の記録がなく、ドメインとの対応が不足しています。",
    "transport_outside_matcher": "現在のURL候補の対応規則はTCPに限られ、この通信方式は規則の範囲外です。",
    "insufficient_correspondence": "保存された対応表だけでは対応を確定できません。",
}


def explain(out, correspondence):
    """Write additive JSON/CSV explanations next to a validated run.

    Called by differential.build only after its evidence hashes are verified.
    Every factual item has a source file/field locator; observational statements
    also retain evidence IDs.  Hypotheses never become factual reason codes.
    """
    out = Path(out)
    run = read_json(out / "run.json")
    flows = {f["flow_id"]: f for _, f in read_jsonl(out / "flows.jsonl")}
    records = []
    usable = run.get("dynamic_status") in ("completed", "partial") and bool(run.get("captures"))
    for ordinal, row in enumerate(correspondence["records"], 1):
        status = row["status"]
        selected = [flows[fid] for fid in row["flows"]]
        facts = [{"kind": "analysis_condition", "text":
                  f"静的処理={run.get('static_status')}、動的取得={run.get('dynamic_status')}。",
                  "source_file": "run.json", "fields": ["static_status", "dynamic_status"], "evidence_ids": []}]
        static = row.get("static")
        if static:
            facts.append({"kind": "static_candidate", "text":
                          f"APKのURL文字列を{static['host']}:{static['port']}に集約した候補があります。",
                          "source_file": "static.json", "fields": ["urls"],
                          "evidence_ids": sorted(set(static.get("evidence_ids", []))),
                          "source_locations": static.get("locations", [])})
        for flow in selected:
            facts.append({"kind": "captured_flow", "text":
                          f"記録{flow['flow_id']}は帰属={flow.get('attribution')}、"
                          f"方式={flow.get('transport')}、観測段階={flow.get('observation')}です。",
                          "source_file": "flows.jsonl", "flow_id": flow["flow_id"],
                          "fields": ["attribution", "transport", "observation", "host", "destination_ip", "port"],
                          "evidence_ids": flow.get("evidence_ids", []),
                          "host": flow.get("host"), "destination_ip": flow.get("destination_ip"),
                          "port": flow.get("port"), "host_evidence": flow.get("host_evidence")})
        # Describe the set operation performed by this implementation, not a
        # causal conclusion such as dead code, malicious traffic, or user input.
        statements = {
            "both": "URL文字列候補と対象UIDの通信記録が、現在のホスト／明示IP・ポートの規則で対応しました。",
            "static_only": "有効な取得の範囲に、この静的候補と現在の対応規則で一致する対象通信の記録がありません。",
            "dynamic_only": "対象UIDとホスト名のある実測に、現在のTCP対応規則と抽出済みURL文字列候補で対応するものがありません。",
            "indeterminate": "対応表の分類は判断不能です。以下の不足を分けて確認できます。",
        }
        facts.append({"kind": "comparison_result", "text": statements[status],
                      "source_file": "correspondence.json", "record_index": ordinal - 1,
                      "fields": ["records", "status"], "evidence_ids": row["evidence_ids"]})
        gaps = []
        if status == "indeterminate":
            if not usable:
                gaps.append("capture_unavailable")
            if run.get("static_status") != "completed":
                gaps.append("static_incomplete")
            if any(f.get("attribution") in ("unknown", "related_candidate") for f in selected):
                gaps.append("attribution_unresolved")
            if any(f.get("observation") == "capture_failed" for f in selected):
                gaps.append("capture_failed")
            if (not static or not is_ip(static["host"])) and any(not f.get("host") for f in selected):
                gaps.append("hostname_unavailable")
            if not gaps:
                gaps.append("insufficient_correspondence")
        if any(f.get("transport") != "TCP" for f in selected):
            gaps = [g for g in gaps if g != "insufficient_correspondence"]
            gaps.append("transport_outside_matcher")
        hypotheses = {
            "both": [],
            "static_only": ["今回実行しなかった機能で使われる候補かもしれません。",
                            "参照用・未使用文字列、実行条件の差、取得漏れの可能性もあります。"],
            "dynamic_only": ["実行時入力や組み立て、設定、解析対象外のコードから宛先が決まる可能性があります。"],
            "indeterminate": [],
        }[status]
        forbidden = {
            "both": "対応だけではURLパス、コード上の送信箇所、目的、HTTPS成立、安全性は確定しません。",
            "static_only": "通信しない・不要コード・安全とは断定しません。",
            "dynamic_only": "不正通信・漏えい・静的解析の誤りとは断定しません。",
            "indeterminate": "対象通信・無通信・ポリシー違反へ補完しません。",
        }[status]
        checks = {
            "both": ["必要なら要求パスや受信側ログを別途照合する。"],
            "static_only": ["候補の所在と、実施した機能・時間・取得範囲を確認する。"],
            "dynamic_only": ["入力URL・設定と要求の記録を照合し、原因を確認できた場合だけ説明へ追加する。"],
            "indeterminate": ["不足項目に対応する原本・収集条件を確認し、推測で埋めない。"],
        }[status]
        records.append({"explanation_id": f"difference-{ordinal}", "status": status,
                        "endpoint": row["endpoint"], "flows": row["flows"],
                        "facts": facts, "comparison_basis": status,
                        "evidence_gaps": [{"code": g, "text": GAPS[g]} for g in gaps],
                        "unconfirmed_hypotheses": hypotheses, "not_established": forbidden,
                        "suggested_checks": checks, "evidence_ids": row["evidence_ids"]})
    result = {"schema_version": "1.0", "profile": PROFILE, "run_id": run["run_id"],
              "analysis_kind": "deterministic_explanation_of_saved_correspondence",
              "causal_inference": False, "policy_verdicts_changed": False,
              "units": {"explanation_rows": len(records),
                        "static_endpoint_groups": correspondence["static_candidate_counts"]["endpoint_groups"],
                        "target_flow_records": sum(f.get("attribution") == "target" for f in flows.values()),
                        "other_flow_records": sum(f.get("attribution") == "other" for f in flows.values()),
                        "all_flow_records": len(flows)},
              "status_counts": correspondence["counts"],
              "gap_row_counts": dict(Counter(g["code"] for r in records for g in r["evidence_gaps"])),
              "scope": {"analysis_mode": run.get("analysis_mode", "existing_run"),
                        "scenario": run.get("analysis_scenario", run.get("scenario")),
                        "initial_app_data": run.get("initial_app_data", "not_recorded_here"),
                        "dynamic_status": run.get("dynamic_status"),
                        "static_status": run.get("static_status")},
              "limitations": ["Template explanations of implementation outputs, not independent ground truth.",
                              "A candidate host/port match is not a code-to-request data-flow link.",
                              "Hypotheses are possibilities, not confirmed causes; no payload or intent inference.",
                              "Rows, endpoint groups and flows are different units; no precision or coverage estimate."],
              "records": records}
    write_json(out / "difference-explanation.json", result)
    with (out / "difference-explanation.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["説明ID", "比較分類", "宛先", "確認した事実", "不足", "未確認の原因候補", "断定しないこと", "証拠ID"])
        for r in records:
            writer.writerow([csv_safe(v) for v in [r["explanation_id"], LABELS[r["status"]], r["endpoint"],
                " / ".join(f["text"] for f in r["facts"]), " / ".join(g["text"] for g in r["evidence_gaps"]),
                " / ".join(r["unconfirmed_hypotheses"]), r["not_established"], ", ".join(r["evidence_ids"])]])
    return result


def html_section(result):
    """HTML fragment embedded by the regular summary renderer."""
    esc = lambda text: html.escape(str(text), quote=True)
    rows = []
    for r in result["records"]:
        def items(values):
            return "<ul>" + "".join(f"<li>{esc(v)}</li>" for v in values) + "</ul>"
        facts = items(f["text"] for f in r["facts"])
        gaps = items(g["text"] for g in r["evidence_gaps"]) if r["evidence_gaps"] else "追加の不足分類なし"
        hypotheses = items(r["unconfirmed_hypotheses"]) if r["unconfirmed_hypotheses"] else "原因は推定しません。"
        links = " ".join(f'<a href="report.html#e-{esc(e)}">{esc(e)}</a>' for e in r["evidence_ids"])
        rows.append(f'<details><summary>{esc(LABELS[r["status"]])}：{esc(r["endpoint"])}</summary>'
                    f'<h3>確認した事実</h3>{facts}<h3>不足する情報</h3>{gaps}'
                    f'<h3>未確認の原因候補</h3>{hypotheses}<p>{esc(r["not_established"])}</p>'
                    f'<h3>次に確認するなら</h3>{items(r["suggested_checks"])}<p>原本への索引：{links}</p></details>')
    return ('<section id="difference-explanations"><h2>差分をどう説明するか</h2>'
            '<p>確認した事実・不足・未確認の原因候補を分けて示します。原因候補は事実ではありません。'
            '対応はホスト／明示IP・ポート単位であり、コード上の送信箇所まで確定していません。</p>'
            + ''.join(rows) + '<p><a href="difference-explanation.json">構造化説明JSON</a> / '
            '<a href="difference-explanation.csv">説明CSV</a></p></section>')
