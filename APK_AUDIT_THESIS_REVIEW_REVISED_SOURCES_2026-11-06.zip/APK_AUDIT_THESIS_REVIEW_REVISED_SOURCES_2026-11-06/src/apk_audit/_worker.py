"""Disposable static-analysis worker; parent enforces wall-clock timeout."""
import argparse
import resource
import sys

from .core import AuditError, write_json
from .static import analyze


def configure_memory_limit():
    """Never raise inherited limits; Darwin's RLIMIT_AS is not a portable guard.

    On macOS, setrlimit may reject the value or constrain the already reserved
    address space rather than resident memory. Keep the parent's timeout and
    APK/parser size guards, and explicitly record that no AS cap was applied.
    """
    requested = 3 * 1024**3
    if sys.platform == "darwin":
        return {"address_space": {"status": "not_enforced", "requested_bytes": requested,
                "reason": "Darwin RLIMIT_AS is unsupported/unreliable for this worker; inherited limits unchanged"},
                "other_guards": ["parent_wall_clock_timeout", "apk_size_limit", "parser_size_limits"]}
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    cap = min([requested] + [value for value in (soft, hard) if value != resource.RLIM_INFINITY])
    resource.setrlimit(resource.RLIMIT_AS, (cap, hard))
    return {"address_space": {"status": "enforced", "requested_bytes": requested,
            "soft_bytes": cap, "hard_bytes": None if hard == resource.RLIM_INFINITY else hard},
            "other_guards": ["parent_wall_clock_timeout", "apk_size_limit", "parser_size_limits"]}


def peak_rss_kib():
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    # getrusage uses bytes on Darwin and KiB on Linux.
    return value / 1024 if sys.platform == "darwin" else value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("apk")
    parser.add_argument("out")
    parser.add_argument("--max-mib", type=int, default=200)
    args = parser.parse_args()
    limits = {}
    try:
        limits = configure_memory_limit()
        result = analyze(args.apk, args.out, args.max_mib)
        write_json(args.out + "/static-worker.json", {"ok": True, "max_rss_kib": peak_rss_kib(), "resource_limits": limits})
        return 0
    except Exception as e:
        write_json(args.out + "/static-worker.json", {"ok": False, "error": type(e).__name__ + ": " + str(e), "resource_limits": limits})
        return e.code if isinstance(e, AuditError) else 4


if __name__ == "__main__":
    raise SystemExit(main())
