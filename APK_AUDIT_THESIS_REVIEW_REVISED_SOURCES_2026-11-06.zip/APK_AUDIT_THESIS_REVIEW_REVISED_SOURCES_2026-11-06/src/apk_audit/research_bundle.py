"""Private return bundle: store identical APK copies once, restore before review."""
from pathlib import Path, PurePosixPath
import json
import shutil
import stat
import zipfile

from .core import AuditError, sha256, write_json


def pack(study):
    study = Path(study).resolve()
    target = study.with_suffix(".return.zip")
    if target.exists():
        raise AuditError("Return ZIP exists; preserve it")
    files = [p for p in sorted(study.rglob("*")) if p.is_file()]
    duplicates, originals, inventory = {}, {}, {}
    for path in files:
        if path.is_symlink():
            raise AuditError("Study return bundle does not follow symlinks")
        relative = str(path.relative_to(study))
        digest = sha256(path)
        if path.name == "original.apk":
            shared = "shared/" + digest + ".apk"
            originals.setdefault(shared, path)
            duplicates[relative] = {"shared": shared, "sha256": digest}
        else:
            inventory[relative] = digest
    manifest = {"profile": "deduplicated-private-study-v1", "files": inventory,
                "shared_files": {name: sha256(path) for name, path in originals.items()},
                "restore_files": duplicates, "contains_private_capture": True,
                "note": "Restore to a new folder before evidence validation; no code is executed."}
    with zipfile.ZipFile(target, "x", zipfile.ZIP_DEFLATED) as archive:
        for relative in inventory:
            archive.write(study / relative, "study/" + relative)
        for name, path in originals.items():
            archive.write(path, name)
        archive.writestr("RETURN-MANIFEST.json", json.dumps(manifest, indent=2))
    return target


def restore(archive_path, out):
    import hashlib
    out = Path(out).resolve()
    if out.exists():
        raise AuditError("Restore only into a new folder")
    with zipfile.ZipFile(archive_path) as archive:
        infos = archive.infolist();names = [i.filename for i in infos]
        if len(names) > 20000 or len(names) != len(set(names)) or sum(i.file_size for i in infos) > 1024**3:
            raise AuditError("Excessive or duplicate return archive")
        for info in infos:
            p = PurePosixPath(info.filename)
            if p.is_absolute() or ".." in p.parts or "\\" in info.filename or str(p) != info.filename or stat.S_ISLNK(info.external_attr >> 16):
                raise AuditError("Unsafe archive path")
        if archive.getinfo("RETURN-MANIFEST.json").file_size > 16 * 1024**2:
            raise AuditError("Return manifest too large")
        manifest = json.loads(archive.read("RETURN-MANIFEST.json"))
        expected = {"study/" + n: d for n, d in manifest["files"].items()} | manifest["shared_files"]
        if set(names) != set(expected) | {"RETURN-MANIFEST.json"}:
            raise AuditError("Return archive and manifest differ")
        for name, digest in expected.items():
            with archive.open(name) as stream:
                h = hashlib.sha256()
                for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                    h.update(chunk)
            if h.hexdigest() != digest:
                raise AuditError("Modified return archive member")
        # Validate all reconstruction destinations before any filesystem writes.
        for name, row in manifest["restore_files"].items():
            p = PurePosixPath(name)
            if (p.is_absolute() or ".." in p.parts or "\\" in name or str(p) != name or name in manifest["files"]
                    or row["shared"] not in manifest["shared_files"] or row["sha256"] != manifest["shared_files"][row["shared"]]):
                raise AuditError("Invalid deduplicated original reference")
        expanded = sum(archive.getinfo('study/' + name).file_size for name in manifest['files'])
        expanded += sum(archive.getinfo(row['shared']).file_size for row in manifest['restore_files'].values())
        if expanded > 1024**3:
            raise AuditError("Restored study exceeds expansion limit")
        out.mkdir(parents=True)
        for name in manifest["files"]:
            dest = out / name;dest.parent.mkdir(parents=True, exist_ok=True)
            with archive.open("study/" + name) as src, dest.open("wb") as dst:
                shutil.copyfileobj(src, dst)
        for name, row in manifest["restore_files"].items():
            dest = out / name;dest.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(row["shared"]) as src, dest.open("wb") as dst:
                shutil.copyfileobj(src, dst)
    return out
