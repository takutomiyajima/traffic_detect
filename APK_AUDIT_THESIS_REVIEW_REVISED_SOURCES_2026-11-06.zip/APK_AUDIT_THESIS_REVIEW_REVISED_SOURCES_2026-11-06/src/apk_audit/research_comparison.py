"""Source-defined four-case comparison; distinct from the public-app v1 study.

Fixed ABBA captures are shared for policy replay. Replay costs are allocation
counts, never independently measured M3 execution time or new device trials.
"""
from __future__ import annotations

import csv
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import html
from pathlib import Path
import re
import threading
import time
import uuid

from .core import AuditError, read_json, sha256, utc_now, write_json
from .research_context import scan_bounded
from .research_contrast import build_scenario, device_preflight
from .research_diagnosis import capture_gate, plan_from_evidence, verify_run
from .research_switch import HOST, PORTS, classify, request_observations

PROFILE = "source-reference-comparison-v1"
ORDER = ["A", "B", "B", "A"]
BODY = b'<?xml version="1.0"?><rss version="2.0"><channel><title>Comparison reference</title><description>Empty research feed</description></channel></rss>'


class ReferenceServer:
    def __init__(self, port):
        self.events = []
        self.lock = threading.Lock()
        owner = self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_):pass
            def do_GET(self):owner.respond(self)
        self.server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
        self.thread = None

    def respond(self, request):
        tokens = request.headers.get_all("X-Apk-Audit-Token", [])
        token = tokens[0] if len(tokens) == 1 else ""
        valid = bool(re.fullmatch(r"[a-f0-9]{32}", token) and request.path in ("/fixed.xml", "/feed/"+token+".xml"))
        status = 200 if valid else 404
        body = BODY if valid else b"not found"
        row = {"started_utc": utc_now(), "port": self.server.server_address[1], "token": token,
               "path": request.path, "method": "GET", "status": status, "write_completed": False}
        try:
            request.send_response(status)
            request.send_header("Content-Type", "application/rss+xml")
            request.send_header("Content-Length", str(len(body)))
            request.send_header("Cache-Control", "no-store")
            request.end_headers()
            request.wfile.write(body);request.wfile.flush()
            row["write_completed"] = True
        except (BrokenPipeError, ConnectionResetError) as exc:
            row["error"] = type(exc).__name__
        finally:
            row["ended_utc"] = utc_now()
            with self.lock:self.events.append(row)

    def start(self):
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def snapshot(self):
        with self.lock:return list(self.events)

    def close(self):
        if self.thread:
            self.server.shutdown();self.thread.join(timeout=5)
        self.server.server_close()


def freeze_plan(fixtures):
    fixtures = Path(fixtures)
    inventory = read_json(fixtures/"inventory.json")
    cases = read_json(fixtures/"cases.json")["cases"]
    if [c["case_id"] for c in cases] != ["concat", "input", "fixed", "delayed"]:
        raise AuditError("Unexpected reference case order")
    if sha256(fixtures/"cases.json") != inventory["case_spec_sha256"]:
        raise AuditError("Reference source specification changed")
    planned = []
    for case in cases:
        identity = next(r for r in inventory["cases"] if r["case_id"] == case["case_id"])
        apk = fixtures/identity["apk"]
        if sha256(apk) != identity["apk_sha256"] or identity["package"] != case["package"]:
            raise AuditError("Reference APK identity differs")
        trials = []
        for i,arm in enumerate(["A", *ORDER]):
            role = "baseline" if i == 0 else f"switch-{i:03}-{arm}"
            token = uuid.uuid4().hex
            url = f"http://{HOST}:{PORTS[arm]}/feed/{token}.xml"
            trials.append({"trial_id": role, "arm": arm, "url": url,
                "directory": case["case_id"]+"/"+role,
                "scenario": build_scenario(case["package"],case["package"]+"/.MainActivity",url,30)})
        planned.append({"case_id":case["case_id"],"package":case["package"],"apk":identity["apk"],
                        "apk_sha256":identity["apk_sha256"],"trials":trials})
    return {"profile":PROFILE,"prepared_utc":utc_now(),"cases":planned,"ports":PORTS,"switch_order":ORDER,
        "physical_trials_planned":20,"additional_trial_budget_per_method_case":4,
        "observation_seconds":{"launch":5,"input":30},
        "state_policy":"reference_packages_do_not_store_data; force_stop_before_and_after_each_trial; no_pm_clear",
        "comparison_mode":"M0_M1_baseline_and_M2_M3_shared_capture_policy_replay",
        "stop_rule":"Stop on first pipeline/capture/cleanup failure; keep partial evidence; never retry automatically.",
        "oracle_basis":"Separate source contract from analyzer output; same-author reference materials, not independent app accuracy."}


def _registered(study, name, manifest):
    p = (study/name).resolve()
    if not p.is_relative_to(study) or name not in manifest or not p.is_file() or sha256(p) != manifest[name]:
        raise AuditError("Unregistered or modified comparison evidence: "+name)
    return p


def assess_comparison(study, out):
    study, out = Path(study).resolve(), Path(out).resolve()
    if out.exists():
        raise AuditError("Assessment output exists; preserve it")
    manifest = read_json(study/"COMPARISON-EVIDENCE.json")["files"]
    for name in manifest:_registered(study,name,manifest)
    prepared = read_json(_registered(study,"PREPARED.json",manifest))["files"]
    for name,digest in prepared.items():
        if sha256(_registered(study,name,manifest)) != digest:raise AuditError("Prepared inputs changed")
    plan = read_json(_registered(study,"comparison-plan.json",manifest))
    if plan.get("profile") != PROFILE or plan["physical_trials_planned"] != 20:
        raise AuditError("Unexpected comparison profile")
    completed = read_json(_registered(study,"completed.json",manifest))
    recorded = {r["directory"]:r for r in completed}
    if len(recorded) != len(completed):raise AuditError("Duplicate trial directory")
    cases = []
    seen_runs = set()
    simulated_traces = 0
    for case in plan["cases"]:
        rows = []
        baseline = None
        for spec in case["trials"]:
            if spec["directory"] not in recorded:continue
            record = recorded[spec["directory"]]
            directory = (study/spec["directory"]).resolve()
            if not directory.is_relative_to(study):raise AuditError("Trial outside study")
            run = verify_run(directory)
            if (run.get("package") != case["package"] or run["apk_sha256"] != case["apk_sha256"]
                    or run["run_id"] in seen_runs or record.get("cleanup_confirmed") is not True):
                raise AuditError("Trial identity/reuse/cleanup differs")
            seen_runs.add(run["run_id"])
            simulated_traces += int(str(run.get("run_kind", "")).startswith("synthetic"))
            events = read_json(_registered(study,record["server_events"],manifest))
            row = request_observations(directory,spec,events)
            if spec["trial_id"] == "baseline":baseline=(directory,row)
            else:rows.append(row)
        pattern = classify(rows)
        methods = {}
        if baseline:
            directory, base_row = baseline
            context = read_json(_registered(study,case["case_id"]+"/context.json",manifest))
            selection = plan_from_evidence(directory,context,2,4)
            corr = read_json(directory/"correspondence.json")
            weak = ["static_candidate_matches_observation"] if corr["counts"].get("both",0) else []
            candidate = ["local_constant_argument_candidate"] if selection["evidence_basis"]["contextual_endpoint_matches"] else []
            base_valid = base_row["controls_passed"] and base_row["scenario_confirmed"]
            extra_label = [] if pattern["diagnosis"] == "inconclusive" else [pattern["diagnosis"]]
            selected = selection["selected_probe"] == "input_switch"
            m3_cost = 4 if selected else 0
            methods = {
                "M0":{"labels":[],"weak_facts":weak,"additional_trial_allocation":0,"evidence_valid":base_valid},
                "M1":{"labels":candidate,"weak_facts":weak,"additional_trial_allocation":0,"evidence_valid":base_valid},
                "M2":{"labels":sorted(set(candidate+extra_label)),"weak_facts":weak,"additional_trial_allocation":4,
                      "evidence_valid":base_valid and len(rows)==4 and all(r["controls_passed"] and r["scenario_confirmed"] for r in rows)},
                "M3":{"labels":sorted(set(candidate+(extra_label if selected else []))),"weak_facts":weak,
                      "additional_trial_allocation":m3_cost,"selection_reason":selection["reason"],
                      "evidence_valid":base_valid and (not selected or len(rows)==4 and all(r["controls_passed"] and r["scenario_confirmed"] for r in rows))},
            }
        cases.append({"case_id":case["case_id"],"baseline":baseline[1] if baseline else None,
                      "switch":pattern,"methods":methods})
    # The source oracle is loaded after inference; no oracle label enters the
    # static matching, probe selection, raw witnesses or pattern classification.
    oracle = read_json(_registered(study,"source-cases.json",manifest))["cases"]
    scores = []
    for c in cases:
        gold = next(x for x in oracle if x["case_id"]==c["case_id"])
        allowed = {gold["expected_primary_label"],gold["expected_switch_pattern"]} - {None,"inconclusive"}
        for name,m in c["methods"].items():
            scores.append({"case_id":c["case_id"],"method":name,"evidence_valid":m["evidence_valid"],
                "supported_primary":gold["expected_primary_label"] in m["labels"] if gold["expected_primary_label"] and m["evidence_valid"] else None,
                "unsupported_specific_labels":sorted(set(m["labels"])-allowed),
                "withheld":not m["labels"],"additional_trial_allocation":m["additional_trial_allocation"]})
    failure = read_json(study/"failure.json") if "failure.json" in manifest else None
    result = {"profile":PROFILE,"assessment_kind":"source_reference_check_and_shared_capture_policy_replay",
        "recorded_device_trials":len(completed)-simulated_traces,"recorded_trace_trials":len(completed),
        "simulated_trace_trials":simulated_traces,"planned_device_trials":20,"cases":cases,"scores":scores,"failure":failure,
        "complete":len(completed)==20 and failure is None,
        "independent_accuracy_established":False,"causal_root_proven":False,"selection_superiority_established":False,
        "comparison_time_measured_independently":False,
        "limitations":["Source-defined cases and oracle share an author with the analyzer.",
            "M2 and M3 share captures; allocation counts are policy replay, not separately measured execution time.",
            "Positive controls and PCAP UID are not independent collector accuracy.",
            "Single-packet complete request headers and conditional clock/NAT candidate correlation only.",
            "No positive request is inconclusive, including the delayed reference; not proof of no networking."]}
    out.mkdir(parents=True)
    write_json(out/"results.json",result)
    with (out/"method-results.csv").open("w",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(scores[0]) if scores else ["case_id","method"])
        writer.writeheader();writer.writerows(scores)
    esc=lambda x:html.escape(str(x),quote=True)
    trs=''.join('<tr>'+''.join('<td>'+esc(r[k])+'</td>' for k in ('case_id','method','evidence_valid','supported_primary','withheld','additional_trial_allocation','unsupported_specific_labels'))+'</tr>' for r in scores)
    (out/"summary.html").write_text('<!doctype html><meta charset="utf-8"><title>差分説明の参照比較</title>'
        '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'">'
        '<style>body{font:16px/1.8 sans-serif;max-width:1200px;margin:2rem auto}table{border-collapse:collapse}td,th{border:1px solid #abc;padding:.5rem}</style>'
        '<h1>差分説明の参照比較</h1><p>保存トレース数：'+esc(len(completed))+' / 20。端末試行：'+esc(len(completed)-simulated_traces)+'。取得品質と独立評価は別に扱います。</p>'
        '<p>同じ取得の方式別再利用です。割当回数を新しい端末試行や独立した実行時間へ換算しません。保留は正解陰性に採点しません。</p>'
        '<table><tr><th>ケース</th><th>方式</th><th>証拠条件</th><th>主説明を支持</th><th>保留</th><th>追加割当</th><th>未支持ラベル</th></tr>'+trs+'</table>'
        '<p><a href="results.json">詳細JSON</a> / <a href="method-results.csv">CSV</a></p>')
    return result


def run_live(fixtures, out, serial="emulator-5554", non_interactive=False):
    from .android import Adb
    from .cli import parser
    from .pipeline import analyze
    from .research_bundle import pack

    fixtures,out=Path(fixtures).resolve(),Path(out).resolve()
    if out.exists():raise AuditError("Output exists; choose a new name and preserve previous results")
    plan=freeze_plan(fixtures)
    preflight=device_preflight(serial)
    servers=[]
    try:
        for port in PORTS.values():servers.append(ReferenceServer(port))
    except OSError as exc:
        for server in servers:server.close()
        raise AuditError("Research ports 18761/18762/18763 are in use; no trial started: "+str(exc)) from exc
    out.mkdir(parents=True)
    write_json(out/"device-preflight.json",preflight)
    write_json(out/"comparison-plan.json",plan)
    write_json(out/"source-cases.json",read_json(fixtures/"cases.json"))
    write_json(out/"fixture-inventory.json",read_json(fixtures/"inventory.json"))
    import apk_audit.research_switch as switch
    from . import core as core_module
    extension_dir=Path(__file__).parent
    extensions={p.name:sha256(p) for p in extension_dir.glob('research_*.py')}
    core_dir=Path(core_module.__file__).parent
    core_versions={p.name:sha256(p) for p in core_dir.glob('*.py') if not p.name.startswith('research_')}
    write_json(out/"COMPARISON-CODE.json",{"extensions":extensions,"base_modules":core_versions,
               "base_pipeline":sha256(__import__('apk_audit.pipeline',fromlist=['__file__']).__file__)})
    completed=[];attempts=[];failure=None;start=time.monotonic();adb=Adb(serial)
    try:
        for case in plan["cases"]:
            scan_bounded(fixtures/case["apk"],out/case["case_id"]/"context.json")
        prepared=["comparison-plan.json","source-cases.json","fixture-inventory.json","COMPARISON-CODE.json"]+[c["case_id"]+"/context.json" for c in plan["cases"]]
        write_json(out/"PREPARED.json",{"files":{n:sha256(out/n) for n in prepared}})
        for server in servers:server.start()
        for case in plan["cases"]:
            for spec in case["trials"]:
                print(f"参照比較 {len(completed)+1}/20：{case['case_id']} / {spec['trial_id']}。追加操作は不要です。",flush=True)
                scenario=out/(spec["directory"]+"-scenario.json");write_json(scenario,spec["scenario"])
                before={s.server.server_address[1]:len(s.snapshot()) for s in servers}
                t=time.monotonic();cleanup=False
                attempt={"directory":spec["directory"],"started_utc":utc_now(),"status":"started"}
                attempts.append(attempt);write_json(out/"attempts.json",attempts)
                primary=None
                try:
                    args=parser().parse_args(["analyze","--apk",str(fixtures/case["apk"]),"--serial",serial,
                        "--scenario",str(scenario),"--out",str(out/spec["directory"])])
                    result,code=analyze(args)
                except (Exception,KeyboardInterrupt) as exc:
                    primary=exc
                    raise
                finally:
                    # Only these newly installed reference packages are stopped.
                    # No data clear, uninstall, or public-app state modification.
                    try:
                        adb.call("shell","am","force-stop",case["package"]);cleanup=True
                    except (Exception,KeyboardInterrupt) as exc:
                        attempt["cleanup_error"]={"type":type(exc).__name__,"message":str(exc)}
                        if primary is None:raise
                    finally:
                        attempt.update(ended_utc=utc_now(),cleanup_confirmed=cleanup,
                                       status="interrupted_or_error" if primary or not cleanup else "pipeline_returned")
                        write_json(out/"attempts.json",attempts)
                events=[e for s in servers for e in s.snapshot()[before[s.server.server_address[1]]:]]
                events_name=spec["directory"]+"-server.json";write_json(out/events_name,events)
                if code or result.get("error"):raise AuditError(result.get("error") or "Pipeline failed")
                gate=capture_gate(out/spec["directory"])
                completed.append({"directory":spec["directory"],"server_events":events_name,
                    "cleanup_confirmed":cleanup,"wall_clock_s_including_cleanup":time.monotonic()-t,
                    "capture_gate":gate})
                write_json(out/"completed.json",completed)
                if not gate["passed"]:raise AuditError("Capture controls failed; later trials not executed")
    except (Exception,KeyboardInterrupt) as exc:
        failure={"type":type(exc).__name__,"message":str(exc)};write_json(out/"failure.json",failure)
    finally:
        for server in servers:server.close()
        report="unknown"
        import sys
        if not non_interactive and sys.stdin.isatty() and failure is None:
            try:report={"0":"none","1":"reported","2":"unknown"}.get(input("観測中のアプリ追加操作：0=なし、1=あり、2=不明: ").strip(),"unknown")
            except (EOFError,KeyboardInterrupt):pass
        write_json(out/"operator-report.json",{"additional_actions":report,"basis":"post_capture_self_report","all_input_objectively_monitored":False})
        write_json(out/"completed.json",completed)
        write_json(out/"timing.json",{"whole_study_wall_clock_s":time.monotonic()-start,"independent_M3_timing":False})
        write_json(out/"COMPARISON-EVIDENCE.json",{"files":{str(p.relative_to(out)):sha256(p) for p in sorted(out.rglob('*'))
            if p.is_file() and p.name!='COMPARISON-EVIDENCE.json'},"origin":"local_integrity_not_independent_attestation"})
    if (out/"PREPARED.json").exists():
        try:assess_comparison(out,out/"assessment")
        except (Exception,KeyboardInterrupt) as exc:
            error={"stage":"assessment","type":type(exc).__name__,"message":str(exc)}
            write_json(out/"assessment-failure.json",error)
            failure=failure or error
    archive=pack(out)
    print("返却用ZIP: "+str(archive),flush=True)
    return {"profile":PROFILE,"recorded_trials":len(completed),"attempted_trials":len(attempts),"planned_trials":20,
            "error":failure,"archive":str(archive),"report":str(out/"assessment/summary.html")},4 if failure else 0
