"""Version 1.1 developer declarations and evidence-bound input destinations.

This permits declared endpoint metadata, not purposes, payloads or safety. It
does not turn a dynamic-only destination into a permitted user input by itself.
"""
from copy import deepcopy
import math
from pathlib import Path
from urllib.parse import urlsplit

from .core import AuditError, normalize_host, read_json, read_jsonl, sha256, timestamp, validate_schema

INPUT_MODE = "allowlist_or_recorded_inputs"


def extended_schema():
    from .contracts import INTENT_SCHEMA, DESTINATION
    schema = deepcopy(INTENT_SCHEMA)
    schema["properties"]["schema_version"] = {"const":"1.1"}
    schema["properties"]["intent_id"] = {"type":"string","pattern":"^[A-Za-z0-9_.-]{1,100}$"}
    schema["required"] += ["intent_id"]
    schema["properties"]["network"] = {"oneOf":[deepcopy(INTENT_SCHEMA["properties"]["network"]),
        {"type":"object","additionalProperties":False,
         "required":["mode","allowed_destinations","recorded_input_protocols"],
         "properties":{"mode":{"const":INPUT_MODE},
            "allowed_destinations":{"type":"array","uniqueItems":True,"items":DESTINATION},
            "recorded_input_protocols":{"type":"array","minItems":1,"uniqueItems":True,
                                        "items":{"enum":["http","https"]}}}}]}
    return schema


def validate_extended(value):
    validate_schema(value,extended_schema())
    for dest in value["network"].get("allowed_destinations",[]):dest["host"]=normalize_host(dest["host"])
    value.setdefault("cleartext_policy","unspecified")
    value.setdefault("background_network_policy","unspecified")
    return value


def indexed_file(out,name):
    out=Path(out).resolve();p=out/name
    if not p.is_file() or not (out/"evidence/index.json").is_file():return []
    ids=[]
    for eid,item in read_json(out/"evidence/index.json").items():
        q=(out/item["path"]).resolve()
        if q==p and q.is_relative_to(out) and item["sha256"]==sha256(p):ids.append(eid)
    return ids


def recorded_input_verdict(out,policy,flow,run):
    """Authorize exact endpoint + observed protocol under a registered interval.

    Missing attribution/capture is excluded by compare before this function.
    UI hashes and plan matching are necessary; they are not attestation that
    the developer's declaration is complete or that the code path is causal.
    """
    from .compare import destination_verdict,OK,UNKNOWN,MATCH
    from .contracts import validate_open_uri
    out=Path(out)
    fixed={"mode":"allowlist","allowed_destinations":policy["allowed_destinations"]}
    if fixed["allowed_destinations"]:
        verdict,message=destination_verdict(fixed,flow)
        if verdict==OK:return verdict,message,[],"explicit_allowlist"
    if type(run.get("target_uid")) is not int or run["target_uid"]<0 or flow.get("uid")!=run["target_uid"] or flow.get("transport")!="TCP":
        return UNKNOWN,"Input exception requires this run's nonnegative target UID and supported TCP evidence",[],"input_attribution_or_transport_unknown"
    ui_ids=indexed_file(out,"ui_events.jsonl")
    scenario_ids=indexed_file(out,"scenario.json")
    if not ui_ids or not scenario_ids:
        return UNKNOWN,"Recorded-input permission needs intact indexed scenario and UI evidence",[],"missing_input_evidence"
    scenario=read_json(out/"scenario.json")
    if scenario!=run.get("analysis_scenario"):
        return UNKNOWN,"Saved scenario differs from run registration",ui_ids+scenario_ids,"scenario_mismatch"
    steps={s.get("id"):s for s in scenario.get("steps",[]) if s.get("action")=="open_uri"}
    inputs=[]
    for _,event in read_jsonl(out/"ui_events.jsonl"):
        step=steps.get(event.get("event_id"))
        if (not step or event.get("action")!="open_uri" or event.get("success") is not True
                or event.get("uri")!=step.get("uri") or event.get("activity")!=step.get("activity")):
            continue
        try:
            validate_open_uri(step,run.get("package"))
            uri=urlsplit(step["uri"])
            inputs.append((event,normalize_host(uri.hostname),uri.port or (443 if uri.scheme=="https" else 80),uri.scheme))
        except (AuditError,ValueError):continue
    basis=ui_ids+scenario_ids
    if not inputs:return UNKNOWN,"No successful registered URI operation supports the input exception",basis,"input_not_established"
    host=flow.get("host") or flow.get("destination_ip")
    if not host:return UNKNOWN,"Observed endpoint is incomplete",basis,"endpoint_unknown"
    host=normalize_host(host)
    matching=[r for r in inputs if r[1]==host and r[2]==flow.get("port")]
    if not matching:
        rules=policy["allowed_destinations"]+[{"host":h,"ports":[p],"include_subdomains":False,"application_protocols":[s]} for _,h,p,s in inputs if s in policy["recorded_input_protocols"]]
        verdict,message=destination_verdict({"mode":"allowlist","allowed_destinations":rules},flow)
        return verdict,message,basis,"outside_registered_and_explicit_endpoints"
    matching=[r for r in matching if r[3] in policy["recorded_input_protocols"]]
    if not matching:return MATCH,"Recorded input scheme is outside the declared input permission",basis,"input_scheme_not_allowed"
    epsilon=flow.get("clock_alignment_half_width_s")
    if type(epsilon) not in (int,float) or not math.isfinite(epsilon) or epsilon<0:
        return UNKNOWN,"Clock uncertainty for the input interval is unavailable",basis,"clock_unknown"
    try:
        start,end=timestamp(flow["started_utc"]),timestamp(flow["ended_utc"])
        active=[r for r in matching if timestamp(r[0]["started_utc"])<=start-epsilon
                and end+epsilon<=timestamp(r[0]["ended_utc"])]
    except (KeyError,AuditError):active=[]
    if not active:return UNKNOWN,"Endpoint matches an input but interval correspondence is uncertain",basis,"input_interval_uncertain"
    decisions=[]
    for _,h,p,scheme in active:
        verdict,message=destination_verdict({"mode":"allowlist","allowed_destinations":[
            {"host":h,"ports":[p],"include_subdomains":False,"application_protocols":[scheme]}]},flow)
        if verdict==OK:return OK,"Observed endpoint and protocol match a successful registered input under clock assumptions",basis,"recorded_input_endpoint"
        decisions.append(verdict)
    if decisions and UNKNOWN not in decisions:return MATCH,"Observed application protocol conflicts with the registered input permission",basis,"input_protocol_mismatch"
    return UNKNOWN,"Input endpoint matched; required application protocol is not established",basis,"input_protocol_unknown"
