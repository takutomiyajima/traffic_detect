"""CSV contract read from upstream PCAPdroid 2.0.2 source.

Selected operator-provided Emulator exports were parsed and imported; this is
not a general validation of collector accuracy or other versions.

Source commit: 66f7b3514540c20add8655a74dfee93d00a9563b
ConnectionsAdapter.dumpConnectionsCsv(), values/strings.xml, Utils.java.
The export loses exact connection state and hostname provenance. Preserve
unknowns rather than infer TLS success or SNI from translated display fields.
"""
from pathlib import Path
import struct

from .core import AuditError
from .capture import normalize_app_rows

SOURCE_COMMIT = "66f7b3514540c20add8655a74dfee93d00a9563b"


def trailer_uid(frame):
    """v2.0.2 pcap_dump.h/c: fake Ethernet, complete IP, padding, 32-byte trailer.

    App name is deliberately ignored. This validates layout, not collector truth
    or a cryptographic signature. Missing/truncated extensions stay unknown.
    """
    if len(frame) < 66 or frame[:12] != b"\0" * 12:
        return None
    ethertype = int.from_bytes(frame[12:14], "big")
    if ethertype == 0x0800 and frame[14] >> 4 == 4:
        length = int.from_bytes(frame[16:18], "big")
        if length < 20 or length < (frame[14] & 15) * 4:
            return None
    elif ethertype == 0x86dd and frame[14] >> 4 == 6:
        length = 40 + int.from_bytes(frame[18:20], "big")
    else:
        return None
    end = 14 + length
    padding = (-end) % 4
    if len(frame) != end + padding + 32 or any(frame[end:end+padding]):
        return None
    magic, uid = struct.unpack("!Ii", frame[-32:-24])
    return uid if magic == 0x01072021 and uid >= 0 else None


def extended_pcap_flows(path, run, meta):
    from .capture import pcap_flows
    import dpkt
    if meta.get("tool") != "PCAPdroid" or meta.get("tool_version") != "2.0.2":
        raise AuditError("pcapdroid-pcap requires inspected PCAPdroid 2.0.2")
    with Path(path).open("rb") as stream:
        reader = dpkt.pcap.Reader(stream)
        if reader.datalink() != dpkt.pcap.DLT_EN10MB:
            raise AuditError("PCAPdroid extensions require Ethernet PCAP; enable dump_extensions")
    meta["pcapdroid_extensions"] = True
    for flow in pcap_flows(path, run, meta, extensions=True):
        flow["adapter_source_commit"] = SOURCE_COMMIT
        yield flow
HEADER = "IPProto,SrcIP,SrcPort,DstIp,DstPort,UID,App,PackageName,Proto,Status,Info,BytesSent,BytesRcvd,PktsSent,PktsRcvd,FirstSeen,LastSeen".split(",")


def pcapdroid_flows(path, run, meta):
    if meta.get("tool") != "PCAPdroid" or meta.get("tool_version") != "2.0.2":
        raise AuditError("pcapdroid-csv requires PCAPdroid tool_version 2.0.2; other formats unverified")
    def rows():
        with Path(path).open(encoding="utf-8-sig") as f:
            header = f.readline().rstrip("\r\n").split(",")
            if header not in (HEADER, HEADER + ["Malicious"]):
                raise AuditError("PCAPdroid CSV header differs from the inspected upstream contract")
            for line, text in enumerate(f, 2):
                if not text.strip(): continue
                # Upstream concatenates fields without RFC4180 quoting. Reject
                # commas/newlines in names rather than silently shift UID/IP columns.
                values = text.rstrip("\r\n").split(",")
                if len(values) != len(header):
                    raise AuditError(f"PCAPdroid CSV line {line}: ambiguous columns; retain original and export JSON with explicit mapping")
                row = dict(zip(header, values))
                try:
                    ipproto = int(row["IPProto"])
                    if ipproto not in (6, 17):
                        raise AuditError(f"PCAPdroid CSV line {line}: only TCP/UDP supported")
                    uid = int(row["UID"])
                    yield line, {"started_utc": row["FirstSeen"], "ended_utc": row["LastSeen"],
                                 "destination_ip": row["DstIp"], "destination_port": int(row["DstPort"]),
                                 "transport": "TCP" if ipproto == 6 else "UDP", "uid": uid if uid >= 0 else None,
                                 "package": row["PackageName"] or None, "bytes_sent": int(row["BytesSent"]), "bytes_received": int(row["BytesRcvd"]),
                                 "host": None, "application_protocol": None, "observation": "connection_attempt",
                                 "content_visibility": "metadata_only", "source_status": "PCAPdroid display: " + row["Status"]}
                except ValueError as e:
                    raise AuditError(f"PCAPdroid CSV line {line}: invalid numeric field") from e
    for flow in normalize_app_rows(rows(), run, meta):
        flow["host_unknown_reason"] = "CSV Info field has no SNI/DNS/HTTP provenance; retained in original CSV"
        flow["limitations"] += ["pcapdroid_csv_source_contract_only", "display_status_cannot_prove_transport_or_tls_success", "protocol_label_not_promoted_to_http_evidence"]
        flow["adapter_source_commit"] = SOURCE_COMMIT
        yield flow
