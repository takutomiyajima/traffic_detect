# レビュー反映版の論文・TeX・データ（2026-11-06）

本文は28ページです。主評価9試行は、同一ホストの別ポート、75秒予定と30秒窓、既知の組立て素材に対する規則の動作確認として記載しました。
主評価の帰属不明0と、補助群のUDP4単位の事後解析を区別し、端末実行は全て著者本人だったことを明記しました。

- docs/thesis.pdf：修正版草稿。
- docs/research/reviewer-revision-2026-11-06/READ_FIRST.md：変更と未確認事項、本人の手順。
- 同フォルダ/review-response.json：レビュー各項目の対応状況。
- 同フォルダ/REPRODUCE.md：本文から移したMac固有パスと実行方法。
- 同フォルダ/new-primary-paper-checks.json：Agrigento本文の確認箇所。ReCon・Haystack/Lumenは本文未確認として残す。

独立した第三者確認は未実施です。12件の確認票を用意しただけで、結果や一致率は記入していません。
第三者には別配布の独立確認用ZIPか、reviewer-packetフォルダだけを渡してください。
researcher-system-outputs.jsonはシステムの参照出力で、独立した正解ではありません。記入前には確認者へ渡さないでください。
確認者が既に草稿の結果を知っていた場合も、その情報を宣言へ記録します。完全な盲検とは呼びません。

## 再生成と点検

XeLaTeX・TikZ・fancyvrb・xurl、Noto CJKとDejaVuのフォントを使い、bash tools/build_thesis.shで生成します。
python tools/check_manuscript_consistency.py --out /tmp/check.jsonで公開集計と文書参照を検査できます。
研究者用の原本がある場合だけ --private-original /path/to/review/original を追加できます。
取得プログラムと原本は変更していません。追加のAndroid実験や過去試行の再実行は不要です。

## 収録範囲

ユーザーの原本APK・PCAP・生通信ログ・nonce・第三者の論文PDFは収録していません。
確認票には自作研究素材の意図と、UID・研究用宛先・時刻・Manifest等の抜粋を含みます。原本そのものではありません。
同梱の従来ツールには自作参照APKと取得補助APKを含みます。新ランナーの導入を求める資料ではありません。
著者情報・大学様式・AI利用実態と内容の本人確認は引き続き必要です。
