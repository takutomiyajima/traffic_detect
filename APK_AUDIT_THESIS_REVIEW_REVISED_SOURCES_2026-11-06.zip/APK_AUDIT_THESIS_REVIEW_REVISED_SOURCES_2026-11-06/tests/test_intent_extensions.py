"""Policy declarations with negative evidence cases; no Android execution."""
from copy import deepcopy
from datetime import datetime,timedelta,timezone
from pathlib import Path

import pytest

from apk_audit.compare import compare
from apk_audit.contracts import validate_intent
from apk_audit.core import AuditError,add_evidence,new_run,read_json,read_jsonl,write_json,write_jsonl


def policy():
    return read_json(Path(__file__).parents[1]/'examples/intent-recorded-input-v1.1.json')


@pytest.fixture
def recorded(tmp_path):
    source=tmp_path/'synthetic-input';source.write_bytes(b'unit-test-not-an-APK')
    out=tmp_path/'run';run=new_run(out,source)
    now=datetime.now(timezone.utc)
    step={'id':'input','action':'open_uri','observe_s':30,'uri':'http://10.0.2.2:18762/feed/a.xml',
          'activity':'org.example.fixture/.MainActivity'}
    scenario={'schema_version':'1.0','scenario_id':'fixture','execution':'automatic','repetitions':1,'steps':[step]}
    run.update(target_uid=111,package='org.example.fixture',static_status='completed',dynamic_status='partial',
               analysis_mode='live',analysis_scenario=scenario)
    write_json(out/'run.json',run);write_json(out/'static.json',{'permissions':[],'sdk_candidates':[],'urls':[]})
    write_json(out/'scenario.json',scenario)
    write_jsonl(out/'ui_events.jsonl',[{'event_id':'input','action':'open_uri','success':True,'uri':step['uri'],
        'activity':step['activity'],'started_utc':now.isoformat(),'ended_utc':(now+timedelta(seconds=30)).isoformat()}])
    (out/'raw/synthetic-flow.txt').write_text('Synthetic evidence only')
    for eid,name in [('analysis-scenario','scenario.json'),('ui-events','ui_events.jsonl'),('test-flow','raw/synthetic-flow.txt')]:
        add_evidence(out,eid,out/name,'synthetic test input')
    flow={'flow_id':'test-flow','evidence_ids':['test-flow'],'uid':111,'attribution':'target','host':'10.0.2.2',
          'destination_ip':'10.0.2.2','port':18762,'transport':'TCP','application_protocol':'http',
          'observation':'http_observed','content_visibility':'metadata_only','limitations':[],
          'started_utc':(now+timedelta(seconds=1)).isoformat(),'ended_utc':(now+timedelta(seconds=2)).isoformat(),
          'clock_alignment_half_width_s':.01,'ui_phase_known':True,'after_home':False}
    write_jsonl(out/'flows.jsonl',[flow]);return out,flow


def connection(out,intent=None):
    return [r for r in compare(out,intent or policy())['findings'] if r['subject']=='external_connection']


def test_registered_input_endpoint_is_permitted_with_its_evidence(recorded):
    out,flow=recorded;r=connection(out)[0]
    assert r['verdict']=='consistent_with_observed_evidence'
    assert r['permission_basis']=='recorded_input_endpoint'
    assert set(r['evidence_ids'])=={'test-flow','analysis-scenario','ui-events'}


@pytest.mark.parametrize('mutation,expected',[('other_port','mismatch_candidate'),('unknown_uid','not_evaluable'),
    ('other_uid','not_evaluable'),('boundary','not_evaluable'),('outside_interval','not_evaluable'),
    ('no_clock','not_evaluable'),('no_host','not_evaluable'),('tls_only','mismatch_candidate'),
    ('failed_capture','not_evaluable')])
def test_missing_and_disallowed_facts_are_not_auto_permitted(recorded,mutation,expected):
    out,flow=recorded
    if mutation=='other_port':flow['port']=18761
    elif mutation=='unknown_uid':flow.update(uid=None,attribution='unknown')
    elif mutation=='other_uid':flow['uid']=222
    elif mutation=='boundary':flow['clock_alignment_half_width_s']=5
    elif mutation=='outside_interval':flow['started_utc']='2020-01-01T00:00:00+00:00'
    elif mutation=='no_clock':flow.pop('clock_alignment_half_width_s')
    elif mutation=='no_host':flow.update(host=None,destination_ip=None)
    elif mutation=='tls_only':flow.update(application_protocol='tls',observation='connection_attempt')
    elif mutation=='failed_capture':flow['observation']='capture_failed'
    write_jsonl(out/'flows.jsonl',[flow])
    rows=connection(out)
    if mutation in ('unknown_uid','failed_capture'):
        assert not rows and any(r['verdict']=='not_evaluable' for r in read_json(out/'findings.json')['findings'])
    else:assert rows[0]['verdict']==expected


@pytest.mark.parametrize('mode',['missing_ui_hash','modified_ui','unregistered_scenario','failed_dispatch'])
def test_user_input_claim_requires_matching_intact_operation_records(recorded,mode):
    out,flow=recorded
    if mode=='missing_ui_hash':
        idx=read_json(out/'evidence/index.json');idx.pop('ui-events');write_json(out/'evidence/index.json',idx)
    elif mode=='modified_ui':(out/'ui_events.jsonl').write_text('changed')
    elif mode=='unregistered_scenario':
        scenario=read_json(out/'scenario.json');scenario['steps'][0]['uri']='http://10.0.2.2:18761/changed';write_json(out/'scenario.json',scenario)
        add_evidence(out,'analysis-scenario',out/'scenario.json','changed test scenario')
    else:
        ui=[{'event_id':'input','action':'open_uri','success':False}];write_jsonl(out/'ui_events.jsonl',ui)
        add_evidence(out,'ui-events',out/'ui_events.jsonl','failed synthetic dispatch')
    assert connection(out)[0]['verdict']=='not_evaluable'


def test_input_scheme_permission_and_fixed_allowlist_are_explicit(recorded):
    out,flow=recorded;p=policy();p['network']['recorded_input_protocols']=['https']
    assert connection(out,p)[0]['verdict']=='mismatch_candidate'
    p['network']['allowed_destinations']=[{'host':'10.0.2.2','include_subdomains':False,'ports':[18762],'application_protocols':['http']}]
    assert connection(out,p)[0]['verdict']=='consistent_with_observed_evidence'
    p['network']={'mode':'deny_all'}
    assert connection(out,p)[0]['verdict']=='mismatch_candidate'


def test_tls_does_not_prove_https_application_semantics(recorded):
    out,flow=recorded
    scenario=read_json(out/'scenario.json');scenario['steps'][0]['uri']=scenario['steps'][0]['uri'].replace('http:','https:')
    state=read_json(out/'run.json');state['analysis_scenario']=scenario
    ui=list(read_jsonl(out/'ui_events.jsonl'))[0][1]
    ui['uri']=scenario['steps'][0]['uri'];write_json(out/'run.json',state);write_json(out/'scenario.json',scenario)
    write_jsonl(out/'ui_events.jsonl',[ui]);flow.update(application_protocol='tls',observation='connection_attempt')
    write_jsonl(out/'flows.jsonl',[flow])
    add_evidence(out,'analysis-scenario',out/'scenario.json','synthetic HTTPS scenario')
    add_evidence(out,'ui-events',out/'ui_events.jsonl','synthetic HTTPS operation')
    assert connection(out)[0]['verdict']=='not_evaluable'


def test_extra_permission_is_a_declaration_finding_not_location_transmission(recorded):
    out,_=recorded
    write_json(out/'static.json',{'permissions':[{'name':'android.permission.ACCESS_FINE_LOCATION','evidence_ids':['test-flow']}],
                                  'sdk_candidates':[],'urls':[]})
    row=next(r for r in compare(out,policy())['findings'] if r['rule_id']=='C04')
    assert row['verdict']=='mismatch_candidate' and row['observation']=='static_only'


def test_explicit_udp_allowlist_is_not_restricted_by_the_tcp_input_exception(recorded):
    out,flow=recorded;p=policy();flow.update(transport='UDP',port=53,application_protocol='dns')
    write_jsonl(out/'flows.jsonl',[flow])
    p['network']['allowed_destinations']=[{'host':'10.0.2.2','include_subdomains':False,'ports':[53],'application_protocols':['dns']}]
    assert connection(out,p)[0]['verdict']=='consistent_with_observed_evidence'


@pytest.mark.parametrize('version',['1.0','1.1'])
def test_input_extension_cannot_be_smuggled_into_legacy_or_empty_policy(version):
    p=policy();p['schema_version']=version
    if version=='1.1':p['network']['recorded_input_protocols']=[]
    with pytest.raises(AuditError):validate_intent(p)


def test_posthoc_and_pre_capture_declarations_have_different_labels(recorded):
    out,_=recorded;p=validate_intent(policy());state=read_json(out/'run.json')
    assert compare(out,p)['intent_declaration_basis']=='not_established_or_retrospective'
    before=(datetime.fromisoformat(state['created_utc'])-timedelta(seconds=1)).isoformat()
    declaration={'intent':deepcopy(p),'loaded_utc':before,'load_stage':'before_static_analysis',
                 'analysis_mode':'live','retrospective_capture':False}
    write_json(out/'raw/intent-declaration.json',declaration)
    add_evidence(out,'intent-declaration',out/'raw/intent-declaration.json','synthetic declaration')
    assert compare(out,p)['intent_declaration_basis']=='locally_recorded_before_static_analysis'
    declaration['retrospective_capture']=True;declaration['analysis_mode']='replay';state['analysis_mode']='replay'
    write_json(out/'run.json',state);write_json(out/'raw/intent-declaration.json',declaration)
    add_evidence(out,'intent-declaration',out/'raw/intent-declaration.json','synthetic replay declaration')
    assert compare(out,p)['intent_declaration_basis']=='declared_before_reanalysis_of_existing_capture'
