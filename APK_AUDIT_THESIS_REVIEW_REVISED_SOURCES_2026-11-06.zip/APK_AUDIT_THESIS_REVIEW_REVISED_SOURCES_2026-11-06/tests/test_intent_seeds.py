"""Nine synthetic traces + host server; zero actual Android execution."""
from datetime import datetime,timedelta
from pathlib import Path

import pytest

from apk_audit.core import AuditError,add_evidence,read_json,read_jsonl,sha256,write_json,write_jsonl
from apk_audit.intent_seeds import run_suite
from test_research_switch import synthetic_trial


def seed_materials(tmp_path):
    fixtures=tmp_path/'materials';fixtures.mkdir();cases=[]
    for name in ('input','fixed','delayed'):
        apk=fixtures/(name+'.apk');apk.write_bytes(('synthetic-'+name).encode())
        cases.append({'case_id':name,'package':'org.example.apkaudit.compare.'+name,'apk':apk.name,'apk_sha256':sha256(apk)})
    write_json(fixtures/'inventory.json',{'cases':cases});return fixtures


def test_primary_pipeline_error_survives_cleanup_error_and_stops_later_trials(tmp_path,monkeypatch):
    import apk_audit.intent_seeds as suite
    import apk_audit.pipeline as pipeline
    import apk_audit.android as android
    fixtures=seed_materials(tmp_path);root=Path(__file__).parents[1]
    monkeypatch.setattr(suite,'device_preflight',lambda s:{'source':'synthetic unit test'})
    class BrokenCleanup:
        def __init__(self,serial):pass
        def call(self,*args):raise AuditError('secondary cleanup failure')
    monkeypatch.setattr(android,'Adb',BrokenCleanup)
    monkeypatch.setattr(pipeline,'analyze',lambda a:({'error':'primary pipeline error'},4))
    result,code=run_suite(fixtures,root/'examples/intent-recorded-input-v1.1.json',tmp_path/'study',non_interactive=True)
    assert code==4 and result['attempted_trials']==1 and result['completed_trials']==0
    assert result['error']['message']=='primary pipeline error'
    assert read_json(tmp_path/'study/attempts.json')[0]['cleanup_error']=='secondary cleanup failure'
    assert not (tmp_path/'study/fixed-001').exists() and (tmp_path/'study.return.zip').is_file()


def test_missing_device_has_no_output_or_install_side_effect(tmp_path,monkeypatch):
    import apk_audit.intent_seeds as suite
    fixtures=seed_materials(tmp_path);root=Path(__file__).parents[1]
    def unavailable(serial):raise AuditError('device missing')
    monkeypatch.setattr(suite,'device_preflight',unavailable)
    with pytest.raises(AuditError,match='device missing'):
        run_suite(fixtures,root/'examples/intent-recorded-input-v1.1.json',tmp_path/'must-not-exist',non_interactive=True)
    assert not (tmp_path/'must-not-exist').exists()


def test_seed_suite_predeclares_and_keeps_missing_request_unknown(tmp_path,monkeypatch):
    import apk_audit.intent_seeds as suite
    import apk_audit.pipeline as pipeline
    import apk_audit.android as android
    from apk_audit.compare import compare
    root=Path(__file__).parents[1];fixtures=tmp_path/'fixtures';fixtures.mkdir()
    cases=[]
    for name in ('input','fixed','delayed'):
        apk=fixtures/(name+'.apk');apk.write_bytes(('synthetic-only-'+name).encode())
        cases.append({'case_id':name,'package':'org.example.apkaudit.compare.'+name,'apk':apk.name,'apk_sha256':sha256(apk)})
    write_json(fixtures/'inventory.json',{'cases':cases})
    monkeypatch.setattr(suite,'device_preflight',lambda s:{'source':'synthetic unit test'})
    calls=[]
    class FakeAdb:
        def __init__(self,serial):pass
        def call(self,*args):calls.append(args);return ''
    monkeypatch.setattr(android,'Adb',FakeAdb)
    def fake(a):
        scenario=read_json(a.scenario);step=scenario['steps'][1];case=a.apk.stem
        arm='A' if str(suite.PORTS['A']) in step['uri'].split('/')[2] else 'B'
        synthetic_trial(a.apk,a.out,{'scenario':scenario,'url':step['uri'],'arm':arm},suite.PORTS,case=case)
        run=read_json(a.out/'run.json');intent=read_json(a.intent)
        write_json(a.out/'static.json',{'permissions':[],'sdk_candidates':[],'urls':[]})
        write_json(a.out/'scenario.json',scenario)
        ui=list(read_jsonl(a.out/'ui_events.jsonl'))[0][1];ui.update(activity=step['activity'],event_id=step['id']);write_jsonl(a.out/'ui_events.jsonl',[ui])
        before=(datetime.fromisoformat(run['created_utc'])-timedelta(seconds=1)).isoformat()
        write_json(a.out/'raw/intent-declaration.json',{'intent':intent,'load_stage':'before_static_analysis','loaded_utc':before,
            'analysis_mode':'live','retrospective_capture':False})
        for eid,name in [('intent-declaration','raw/intent-declaration.json'),('analysis-scenario','scenario.json'),('ui-events','ui_events.jsonl')]:
            add_evidence(a.out,eid,a.out/name,'synthetic unit test only')
        flows=[]
        for _,f in read_jsonl(a.out/'flows.jsonl'):
            f.update(evidence_ids=['test-pcap'],observation='http_observed',content_visibility='metadata_only',limitations=[],
                attribution='target' if f['uid']==10213 else 'other',transport='TCP',
                started_utc=(datetime.fromisoformat(ui['started_utc'])+timedelta(seconds=1)).isoformat(),
                ended_utc=(datetime.fromisoformat(ui['started_utc'])+timedelta(seconds=2)).isoformat(),
                clock_alignment_half_width_s=.01,ui_phase_known=True,after_home=False)
            flows.append(f)
        write_jsonl(a.out/'flows.jsonl',flows);compare(a.out,intent)
        return {'error':None},0
    monkeypatch.setattr(pipeline,'analyze',fake)
    result,code=run_suite(fixtures,root/'examples/intent-recorded-input-v1.1.json',tmp_path/'study',non_interactive=True)
    assert code==0 and result['completed_trials']==9
    rows=read_json(tmp_path/'study/trial-results.json')
    for r in rows:
        assert r['declaration_basis']=='locally_recorded_before_static_analysis'
        if r['condition']=='input':assert [x['verdict'] for x in r['connection_findings']]==['consistent_with_observed_evidence']
        elif r['condition']=='fixed':assert [x['verdict'] for x in r['connection_findings']]==['mismatch_candidate']
        else:assert not r['connection_findings'] and r['no_target_request_is_not_no_networking']
    assert len(calls)==9 and all(c[:3]==('shell','am','force-stop') and c[3].startswith('org.example.apkaudit.compare.') for c in calls)
    assert (tmp_path/'study.return.zip').is_file()
    with pytest.raises(AuditError,match='Output exists'):
        run_suite(fixtures,root/'examples/intent-recorded-input-v1.1.json',tmp_path/'study',non_interactive=True)
