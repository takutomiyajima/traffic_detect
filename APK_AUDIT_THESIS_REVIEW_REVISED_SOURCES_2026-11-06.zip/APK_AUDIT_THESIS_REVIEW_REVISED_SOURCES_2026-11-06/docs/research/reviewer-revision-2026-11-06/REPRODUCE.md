# 再現手順と端末試行の役割（2026-11-06）

本文のMac固有パスをここへ移しました。以下は既に実施した方法の記録であり、追加実験を依頼するものではありません。
すべての端末試行は著者本人がMac／Emulatorでコマンドを実行し、制御・VPNの許可画面と操作状況を確認しました。
APK・ランナー作成、Linuxでのオフライン再解析、集計、執筆は生成AIの支援を用いました。

## 配置と実行例

既存のDocuments/apk-audit-unified-v1と、既存の追加版Documents/apk-audit-intent-v1を使用します。
意図JSONは解析結果を見る前に作成します。下記は任意のAPKへの入口例で、パスを実際の入力へ置き換えます。

```sh
"$HOME/Documents/apk-audit-unified-v1/.venv/bin/python" \
  "$HOME/Documents/apk-audit-intent-v1/run_intent.py" \
  --apk "/path/to/app.apk" \
  --intent "/path/to/intent.json" \
  --scenario "/path/to/scenario.json" \
  --out "$HOME/Documents/apk-audit-unified-v1/runs/app-001"
open "$HOME/Documents/apk-audit-unified-v1/runs/app-001/summary.html"
```

シナリオを省略すると起動・待機のみです。インストール済みデータは保持し、全画面探索はしません。
主評価の実行済み条件はintent-seeds-001の9試行です。もう一度--suiteを実行する必要はありません。
90秒観測、実SDK、AI生成アプリ等は今回は追加していません。

## 原本と再解析

研究者用return ZIPを別の新しい場所へ復元し、インデックスのhash・APK・意図・UI・取得対照を確認します。
生PCAPと原本APKは公開ZIPに含めず、公開資料は集計とTeX・ソースを提供します。
論文の再生成は bash tools/build_thesis.sh、公開集計の点検は python tools/check_manuscript_consistency.py --out /tmp/check.json で実行できます。
