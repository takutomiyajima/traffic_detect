#!/usr/bin/env python3
"""Check manuscript structure, aggregate evidence and optional private originals.

No Android execution or claim of independent scientific truth is performed.
"""
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT=Path(__file__).resolve().parents[1]


def check(private_original=None):
    sources={}
    def read(path):
        path=path.resolve();path.relative_to(ROOT/'docs')
        if path in sources:return
        text=path.read_text();sources[path]=text
        for name in re.findall(r'\\(?:input|include)\{([^}]+)\}',text):
            child=ROOT/'docs'/name
            if not child.suffix:child=child.with_suffix('.tex')
            read(child)
    read(ROOT/'docs/thesis.tex');alltext='\n'.join(sources.values())
    labels=re.findall(r'\\label\{([^}]+)\}',alltext)
    refs=re.findall(r'\\(?:ref|eqref|pageref)\{([^}]+)\}',alltext)
    assert len(labels)==len(set(labels)), 'Duplicate labels'
    assert set(refs)<=set(labels), 'Missing reference targets'
    cited={k.strip() for group in re.findall(r'\\cite\{([^}]+)\}',alltext) for k in group.split(',')}
    bibliography=set(re.findall(r'\\bibitem\{([^}]+)\}',alltext))
    assert cited==bibliography, 'Citations or unused reference entries differ'
    for item in re.findall(r'\\bibitem\{[^}]+\}(.*?)(?=\\bibitem|\\end\{thebibliography\})',alltext,re.S):
        assert re.search(r'2026年\d+月\d+日',item), 'Missing source-check date'
    assert '--intent intent.json' in alltext and 'python run_intent.py' in alltext
    assert '$HOME/Documents' not in alltext
    main_source=sources[(ROOT/'docs/thesis.tex').resolve()]
    assert main_source.index('\\subsection{開発意図の明示性}') < main_source.index('\\subsection{部分情報に基づく判定}') < main_source.index('\\input{generated/difference-model-2026-11-06.tex}')
    assert '主評価9試行には帰属不明の通信はなく' in alltext
    assert '自己確認支援が成立した' not in alltext
    assert '端末試行はすべて著者が手元のMac' in alltext
    assert 'source .venv/bin/activate\napk-audit analyze --apk app.apk' not in alltext
    assert all(f'\\item[RQ{n}]' in alltext for n in (1,2,3))
    assert '2026-11-06.intent-1.1' in alltext
    assert not any(x in alltext for x in ['主評価前','新しい端末評価の結果は未取得','現クラウドではADB・Emulator・KVMが利用できず本連携は未検証'])
    review=json.loads((ROOT/'docs/research/intent-seeds-001-2026-11-06/review.json').read_text())
    counts=Counter((r['condition'],r['verdict']) for r in review['rows'])
    assert counts==Counter({('input','consistent_with_observed_evidence'):3,('fixed','mismatch_candidate'):3,('delayed','not_evaluable'):3})
    assert review['raw_control_requests_verified']==18 and review['raw_target_requests_with_candidate_server_match']==6
    assert review['independent_accuracy_established'] is False
    with (ROOT/'docs/research/review-revision-2026-11-06/final29-trials.csv').open(encoding='utf-8-sig') as stream:
        historical=list(csv.DictReader(stream))
    assert len(historical)==29
    component=json.loads((ROOT/'docs/research/intent-seeds-001-2026-11-06/component-analysis.json').read_text())
    assert len(component['rows'])==27 and component['new_device_trials']==0
    for trial in review['rows']:
        bymode={r['evidence_mode']:r for r in component['rows'] if r['trial_id']==trial['trial_id']}
        assert len(bymode)==3
        for field in ('external_consistent','external_mismatch','permission_mismatch','target_unobserved'):
            assert bymode['dynamic-only'][field]==bymode['integrated'][field]
    scope=json.loads((ROOT/'docs/research/finish-plan-2026-11-06/scope-and-completion.json').read_text())
    assert scope['required_additional_Android_trials']==0
    for logname in ['docs/thesis.log']:
        log=(ROOT/logname).read_text()
        assert not any(x in log for x in ['Overfull','undefined references','undefined citations','Missing character','LaTeX Error']), 'PDF build warnings/errors'
    report={'status':'passed_selected_document_and_data_checks','tex_source_files':len(sources),'citations':len(cited),
            'figures':len(re.findall(r'\\begin\{figure\}',alltext)),'primary_trials':9,'historical_trials':29,
            'retrospective_component_outputs':27,'new_Android_trials':0,'required_additional_Android_trials':0,
            'independent_accuracy_established':False,'human_signoff_pending':True,
            'pdf_sha256':hashlib.sha256((ROOT/'docs/thesis.pdf').read_bytes()).hexdigest(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    info=subprocess.check_output(['pdfinfo',str(ROOT/'docs/thesis.pdf')],text=True)
    report['pdf_pages']=int(re.search(r'^Pages:\s+(\d+)',info,re.M)[1])
    if private_original:
        private_original=Path(private_original).resolve()
        expected=json.loads((private_original.parent/'original-fingerprint.json').read_text())
        actual={str(p.relative_to(private_original)):hashlib.sha256(p.read_bytes()).hexdigest() for p in private_original.rglob('*') if p.is_file()}
        assert actual==expected
        d=private_original/'fixed-001'
        findings=json.loads((d/'findings.json').read_text())['findings']
        finding=next(f for f in findings if f['finding_id']=='F00006')
        assert finding['rule_id']=='C02' and finding['verdict']=='mismatch_candidate' and finding['port']==18761
        index=json.loads((d/'evidence/index.json').read_text())
        assert index['capture-1-flow-4']['locator']['packet_numbers']==list(range(15,25))
        assert all(e in index for e in finding['evidence_ids'])
        report['private_original_files_unchanged']=len(actual)
        report['walkthrough_checked_against_original']=True
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--private-original',type=Path);parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();result=check(args.private_original)
    args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
