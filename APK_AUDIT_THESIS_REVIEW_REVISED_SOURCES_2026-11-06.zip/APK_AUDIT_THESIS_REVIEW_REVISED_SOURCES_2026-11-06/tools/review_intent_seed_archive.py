#!/usr/bin/env python3
"""Review the frozen v1 intent suite without executing uploaded code or Android.

Inputs are private evidence. Public summary deliberately omits tokens, paths,
UID numbers and raw traffic. Replays use local, release-pinned modules only.
"""
import argparse
from collections import Counter
import copy
import csv
import json
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'tools')]
from apk_audit.core import read_json, read_jsonl, sha256, timestamp, write_json, write_jsonl
from apk_audit.research_bundle import restore
from apk_audit.research_diagnosis import capture_gate, verify_run
from apk_audit.research_switch import request_observations
from apk_audit.capture import import_capture
from apk_audit.compare import compare
from apk_audit.differential import build
from review_automatic_archive import packet_headers
from review_rss_archive import clock_interval, uid_disagreements, planned_intervals

RELEASE_SHA = 'feea6da52b89d4461d9fff855780926edc262210062b529b1e044779d54903be'


def fingerprint(path):
    return {str(p.relative_to(path)): sha256(p) for p in sorted(path.rglob('*')) if p.is_file()}


def semantic_static(value):
    value = copy.deepcopy(value)
    value.pop('analysis_duration_s', None)
    return value


def review(archive, out):
    archive, out = Path(archive), Path(out)
    original = out / 'original'
    if not original.exists():
        out.mkdir(parents=True, exist_ok=True)
        restore(archive, original)
        write_json(out / 'original-fingerprint.json', fingerprint(original))
    before = read_json(out / 'original-fingerprint.json')
    assert fingerprint(original) == before
    audit = out / 'audit'
    if audit.exists():
        raise ValueError('Preserve existing review and select a new folder')
    audit.mkdir()
    release = ROOT / 'dist/apk-audit-intent-v1.zip'
    assert sha256(release) == RELEASE_SHA
    with zipfile.ZipFile(release) as z:
        prefix = 'apk-audit-intent-v1/'
        manifest = json.loads(z.read(prefix + 'BUNDLE-MANIFEST.json'))
        import hashlib
        assert all(hashlib.sha256(z.read(prefix + p)).hexdigest() == digest for p, digest in manifest['files'].items())
        expected_intent = json.loads(z.read(prefix + 'examples/intent-recorded-input-v1.1.json'))
        inventory = json.loads(z.read(prefix + 'fixtures/inventory.json'))
    expected_code = dict(manifest['compatible_core'])
    expected_code.update({p.removeprefix('payload/'): d for p,d in manifest['files'].items() if p.startswith('payload/')})
    assert all(sha256(ROOT / 'src/apk_audit' / p) == d for p,d in expected_code.items())
    extension = {p.removeprefix('payload/'): d for p,d in manifest['files'].items() if p.startswith('payload/') and p.endswith('.py')}
    assert read_json(original / 'code-before-analysis.json')['module_files'] == extension
    seed_index = read_json(original / 'SEED-EVIDENCE.json')['files']
    assert seed_index == {p:d for p,d in before.items() if p != 'SEED-EVIDENCE.json'}
    plan = read_json(original / 'seed-plan.json')
    assert plan['intent'] == expected_intent == read_json(original / 'intent-before-analysis.json')
    assert plan['intent_sha256'] == sha256(original / 'intent-before-analysis.json')
    assert read_json(original / 'materials-before-analysis.json') == inventory
    trials = plan['trials']
    assert [s['trial_id'] for s in trials] == [f'{c}-{n:03}' for n in range(1,4) for c in ('input','fixed','delayed')]
    attempts = read_json(original / 'attempts.json')
    assert len(attempts) == len(trials) == plan['physical_trials_planned'] == 9
    assert [a['trial_id'] for a in attempts] == [s['trial_id'] for s in trials]
    assert all(a.get('reference_stop_confirmed') is True and 'cleanup_error' not in a for a in attempts)
    assert not (original / 'failure.json').exists()
    server_events = [e for events in read_json(original / 'server-events.json').values() for e in events]
    assert len(server_events) == 6
    inventory = {s['case_id']:s for s in inventory['cases']}
    static_reference = {}
    from apk_audit.cli import static_stage
    for condition in ('input','fixed','delayed'):
        dest = out / 'static-reparse' / condition
        static_stage(original / f'{condition}-001/raw/original.apk', dest)
        static_reference[condition] = semantic_static(read_json(dest / 'static.json'))
    rows, details = [], []
    for spec, attempt in zip(trials, attempts):
        trial_id, condition = spec['trial_id'], spec['condition']
        d = original / trial_id
        run = verify_run(d)
        assert run['apk_sha256'] == spec['apk_sha256'] == inventory[condition]['apk_sha256'] == sha256(d / 'raw/original.apk')
        assert run['package'] == spec['package'] == inventory[condition]['package']
        assert timestamp(plan['prepared_utc']) <= timestamp(attempt['started_utc']) <= timestamp(run['created_utc'])
        code = read_json(d / 'raw/analysis-code-manifest.json')
        assert code['files'] == expected_code
        assert sha256(d / 'raw/analysis-code-manifest.json') == run['analysis_code_manifest_sha256']
        identity = read_json(d / 'raw/installation-identity.json')
        assert identity == dict(package=run['package'], uid=run['target_uid'], bridge_uid=run['bridge_uid'], apk_sha256=run['apk_sha256'])
        assert semantic_static(read_json(d / 'static.json')) == static_reference[condition]
        declaration = read_json(d / 'raw/intent-declaration.json')
        assert declaration['intent'] == expected_intent and declaration['load_stage'] == 'before_static_analysis'
        assert declaration['retrospective_capture'] is False and declaration['analysis_mode'] == 'live'
        assert timestamp(plan['prepared_utc']) <= timestamp(declaration['loaded_utc']) <= timestamp(run['created_utc'])
        assert run['analysis_scenario'] == spec['scenario'] == read_json(d / 'scenario.json')
        events = [e for _,e in read_jsonl(d / 'ui_events.jsonl')]
        assert planned_intervals(spec, events)
        assert timestamp(attempt['ended_utc']) - timestamp(events[1]['started_utc']) < 75
        meta = read_json(d / 'automatic.metadata.json')
        lower, upper = clock_interval(meta, read_json(d / 'raw/clock-samples.json'))
        assert sha256(d / 'raw/automatic.pcap') == sha256(d / 'raw/capture-1.pcap')
        headers, packets = packet_headers(d / 'raw/automatic.pcap', meta)
        flows = [f for _,f in read_jsonl(d / 'flows.jsonl')]
        assert not uid_disagreements(flows, packets, run['target_uid'])
        gate = capture_gate(d)
        assert gate['passed'] and gate == read_json(original / f'{trial_id}-capture-gate.json')
        trace = read_json(d / 'raw/bridge-results.json')
        controls = [r for _,r in read_jsonl(d / 'raw/automatic-controls.jsonl')]
        probe_packets = []
        for probe in [t for t in trace if t['action'] == 'probe']:
            hits = [h for h in headers if h['uid'] == run['bridge_uid'] and h['run_marker'] == probe['request_id'] and h['method'] == 'GET' and h['destination_port'] == run['control_port']]
            received = [s for s in controls if s.get('run_id') == probe['request_id'] and s.get('event') == 'http_request_received']
            assert len(hits) == len(received) == 1
            probe_packets.append(hits[0]['packet'])
        assert len(probe_packets) == 2
        raw = request_observations(d, dict(spec, url=spec['scenario']['steps'][1]['uri']), server_events)
        assert raw['controls_passed'] and raw['scenario_confirmed'] and raw['unmatched_target_requests'] == raw['unknown_UID_packets_with_token'] == 0
        # Re-import into a copy. Keep recorded live mode for declaration-basis
        # reproduction; this does not execute a live observation in the cloud.
        dest = out / 'recomputed' / trial_id
        shutil.copytree(d, dest)
        rr = copy.deepcopy(run); rr['captures'] = []
        write_json(dest / 'run.json', rr); write_jsonl(dest / 'flows.jsonl', [])
        import_capture(dest, d / 'raw/automatic.pcap', d / 'automatic.metadata.json', 'pcapdroid-pcap')
        assert [f for _,f in read_jsonl(dest / 'flows.jsonl')] == flows
        findings = compare(dest, expected_intent)
        assert findings == read_json(d / 'findings.json')
        assert findings['intent_declaration_basis'] == 'locally_recorded_before_static_analysis'
        for f in findings['findings']:
            assert f['evidence_ids'] and all(e in read_json(d / 'evidence/index.json') for e in f['evidence_ids'])
        correspondence = build(dest)
        assert correspondence == read_json(d / 'correspondence.json')
        connections = [f for f in findings['findings'] if f['subject'] == 'external_connection']
        coverage = [f for f in findings['findings'] if f['subject'] == 'target_observation_coverage']
        owners = Counter(f['attribution'] for f in flows)
        if condition == 'delayed':
            assert not connections and not raw['witnesses'] and owners['target'] == 0
            assert len(coverage) == 1 and coverage[0]['verdict'] == 'not_evaluable' and coverage[0]['observation'] == 'not_observed'
            verdict, observation, basis, port = 'not_evaluable', 'not_observed', 'window_insufficient', None
        else:
            assert len(connections) == len(raw['witnesses']) == owners['target'] == 1
            f = connections[0]
            verdict, observation, basis, port = f['verdict'], f['observation'], f['permission_basis'], f['port']
            assert verdict == plan['source_defined_expected_connection_results'][condition]
            assert port == raw['witnesses'][0]['port'] == (18761 if condition == 'fixed' else (18763 if spec['arm']=='B' else 18762))
        stop = next(t['result'] for t in trace if t['action'] == 'stop')
        reported = stop['pkts_sent'] + stop['pkts_rcvd']
        rows.append(dict(trial_id=trial_id, condition=condition, input_arm=spec['arm'], observed_port=port,
            verdict=verdict, observation=observation, permission_basis=basis,
            packets=len(packets), stop_packets=reported, packet_counter_delta=len(packets)-reported,
            target_flows=owners['target'], other_flows=owners['other'], unknown_flows=owners['unknown'],
            quality=run['dynamic_status'], capture_controls_passed=True, raw_server_candidate_count=len(raw['witnesses']),
            clock_lower_s=lower, clock_upper_s=upper,
            observation_window_s=round(timestamp(events[1]['ended_utc'])-timestamp(events[1]['started_utc']),6),
            stop_after_input_s=round(timestamp(attempt['ended_utc'])-timestamp(events[1]['started_utc']),6),
            mismatch_findings=sum(f['verdict']=='mismatch_candidate' for f in findings['findings']),
            evidence_references_verified=True, source_expected_outcome_observed=True))
        details.append(dict(trial_id=trial_id, raw=raw, control_packets=probe_packets,
                            correspondence_counts=correspondence['counts']))
    assert sum(len(r['raw']['witnesses']) for r in details) == len(server_events)
    assert fingerprint(original) == before
    result = dict(study_id='intent-seeds-001', profile='developer-intent-seeded-v1', review_date_jst='2026-11-06',
        archive_sha256=sha256(archive), archive_bytes=archive.stat().st_size, restored_files=len(before),
        original_files_unchanged=True, device_trials=9, cloud_device_trials=0, independent_accuracy_established=False,
        general_novelty_established=False, intention_timing='locally_recorded_before_static_analysis_not_independent_attestation',
        source_oracle='same_author_source_contract', operator_report=read_json(original/'operator-report.json'),
        all_nine_expected_outcomes_reproduced=True, raw_control_requests_verified=18,
        raw_target_requests_with_candidate_server_match=6, rows=rows,
        limitations=['One AVD, three self-authored APKs; repetitions are not independent application samples.',
                     'Delay is outside observation and cancelled before 75s; not evidence of delayed-transmission detection.',
                     'UID is collector-asserted; clocks are conditional; server correlation is candidate.',
                     'Positive capture controls do not establish complete traffic coverage.',
                     'No HTTPS payload, SDK activation, permission use, AI-app accuracy or safety inference.'],
        review_script_sha256=sha256(Path(__file__)))
    write_json(audit/'review.json', result);write_json(audit/'private-detail.json', details)
    with (audit/'trial-results.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print(json.dumps(dict(status='verified_source_defined_nine_trial_case', rows=rows),ensure_ascii=False,indent=2))
    return result


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--archive',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();review(a.archive,a.out)
