#!/usr/bin/env python3
"""Acceptance for an exploratory public-app launch; zero target flows is valid.

Uses recorded run/evidence/control records, not an independent UID accuracy
oracle. Raw PCAP is to be rechecked separately after receipt.
"""
import argparse
import hashlib
import json
from datetime import datetime
from pathlib import Path


def read(path,default=None):
    return json.loads(Path(path).read_text(encoding='utf-8')) if Path(path).is_file() else default


def rows(path):
    return [json.loads(s) for s in Path(path).read_text(encoding='utf-8').splitlines() if s.strip()] if Path(path).is_file() else []


def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def epoch(text):
    value=datetime.fromisoformat(text.replace('Z','+00:00'))
    if value.tzinfo is None:raise ValueError('Timestamp timezone required')
    return value.timestamp()


def check(directory,spec):
    directory=Path(directory);run=read(directory/'run.json',{})
    flows=rows(directory/'flows.jsonl');trace=read(directory/'raw/bridge-results.json',[])
    events=rows(directory/'ui_events.jsonl');server=rows(directory/'raw/automatic-controls.jsonl')
    identity=read(directory/'raw/installation-identity.json',{})
    index=read(directory/'evidence/index.json',{})
    failures=[]
    for eid,record in index.items():
        source=(directory/record['path']).resolve()
        if not source.is_relative_to(directory.resolve()) or not source.is_file() or digest(source)!=record['sha256']:
            failures.append(eid)
    statuses=[e['result'].get('running') for e in trace if e['action']=='get_status' and 'result' in e]
    probes=[e for e in trace if e['action']=='probe' and e.get('result',{}).get('http_status')==200]
    matched=[p for p in probes if any(e.get('event')=='http_request_received' and e.get('run_id')==p['request_id'] and e.get('method')=='GET' for e in server)]
    positive_flows=[f for f in flows if f.get('uid')==run.get('bridge_uid') and f.get('port')==run.get('control_port') and f.get('destination_ip')=='10.0.2.2' and f.get('application_protocol')=='http']
    target=[f for f in flows if f.get('attribution')=='target']
    planned=spec['scenario']
    launches=[e for e in events if e.get('event_id')=='launch' and e.get('action')=='launch' and e.get('success')]
    try:wait_ok=len(launches)==1 and epoch(launches[0]['ended_utc'])-epoch(launches[0]['started_utc'])>=spec['observe_s']
    except (ValueError,KeyError):wait_ok=False
    android=run.get('android',{})
    valid_uid=type(run.get('target_uid')) is int and run['target_uid']>=0
    valid_bridge_uid=type(run.get('bridge_uid')) is int and run['bridge_uid']>=0 and run['bridge_uid']!=run.get('target_uid')
    intent=read(directory/'intent.json',{})
    versions=[e['result'].get('version_name') for e in trace if e['action']=='get_status' and 'result' in e]
    checks={
      'live_mode':run.get('analysis_mode')=='live',
      'expected_apk_package':run.get('apk_sha256')==spec['apk_sha256'] and run.get('package')==spec['package'],
      'apk_copy_hash':(directory/'raw/original.apk').is_file() and digest(directory/'raw/original.apk')==spec['apk_sha256'],
      'static_completed':run.get('static_status')=='completed',
      'same_planned_scenario':run.get('analysis_scenario')==planned,
      'unspecified_network_condition':intent.get('network',{}).get('mode')=='unspecified',
      'launch_observation_recorded':wait_ok,
      'selected_environment':run.get('serial')==spec['serial'] and android.get('api')=='35' and 'arm64-v8a' in android.get('abi','').split(','),
      'execution_completed':run.get('execution_status')=='completed' and not run.get('errors'),
      'capture_retained':run.get('dynamic_status') in ('partial','completed') and bool(run.get('captures')),
      'start_stop_confirmed':statuses==[False,True,False] and all(any(e['action']==action and e.get('result',{}).get('result_code')==-1 for e in trace) for action in ('start','stop')),
      'collector_version':versions==['2.0.2','2.0.2','2.0.2'],
      'cleanup_confirmed':not run.get('cleanup_failed') and not run.get('manual_cleanup_required'),
      'recorded_installation_identity':valid_uid and valid_bridge_uid and identity.get('uid')==run.get('target_uid') and identity.get('bridge_uid')==run.get('bridge_uid') and identity.get('package')==spec['package'] and identity.get('apk_sha256')==spec['apk_sha256'],
      'two_device_server_controls':len(matched)==2 and len({p['request_id'] for p in matched})==2,
      'two_uid_control_flows':len(positive_flows)>=2,
      'evidence_hashes':bool(index) and not failures,
      'report_present':(directory/'summary.html').is_file() and (directory/'correspondence.json').is_file(),
    }
    return {'schema_version':'1.0','acceptance_profile':spec['pilot_id'],'scope':'exploratory_launch_only',
            'status':'passed_exploratory_capture' if all(checks.values()) else 'incomplete',
            'checks':checks,'target_flow_count':len(target),'total_flow_count':len(flows),
            'unknown_attribution_count':sum(f.get('attribution')=='unknown' for f in flows),
            'failed_evidence_ids':failures,'dynamic_quality':run.get('dynamic_status'),
            'interpretation':'A pass confirms execution and positive capture controls for this launch window. Zero target flows is not proof of no networking. This is not RSS retrieval, app coverage, safety, TLS success or UID accuracy evaluation.'}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',type=Path,required=True);p.add_argument('--spec',type=Path,required=True);a=p.parse_args()
    result=check(a.run,read(a.spec))
    (a.run/'public-pilot-acceptance.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['status']=='passed_exploratory_capture' else 4


if __name__=='__main__':raise SystemExit(main())
