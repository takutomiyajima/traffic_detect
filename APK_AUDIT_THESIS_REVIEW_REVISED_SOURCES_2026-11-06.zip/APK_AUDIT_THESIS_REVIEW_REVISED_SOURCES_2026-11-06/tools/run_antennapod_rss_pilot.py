#!/usr/bin/env python3
"""Serve a controlled local RSS and run one explicit feed-preview pilot.

No subscription, media playback, app-data clearing, proxy, root or TLS changes.
The first device result is still pending; failures and originals are retained.
"""
import argparse
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import uuid
import wave
from datetime import datetime,timezone
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path

from check_public_pilot import check,read,digest
from run_public_pilot import run_analysis,ui_snapshot,initial_app_state

PACKAGE='de.danoeh.antennapod'
APK_HASH='6e79f28f69cef1a8b2e4f5f88c9c3cf3c3d7c51356f01394ac23b0dc5d56a00b'


def now():return datetime.now(timezone.utc).isoformat()


class RssServer:
    def __init__(self,nonce):
        if not re.fullmatch('[a-f0-9]{32}',nonce):raise ValueError('Invalid nonce')
        self.nonce=nonce;self.events=[];self.lock=threading.Lock()
        owner=self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_GET(self):owner.respond(self,False)
            def do_HEAD(self):owner.respond(self,True)
        self.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        self.port=self.server.server_address[1]
        self.feed_path='/feed/'+nonce+'.xml';self.audio_path='/audio/'+nonce+'.wav'
        self.url=f'http://10.0.2.2:{self.port}{self.feed_path}'
        self.title='APK Audit Research Feed '+nonce[:8]
        audio=io.BytesIO()
        with wave.open(audio,'wb') as f:
            f.setnchannels(1);f.setsampwidth(2);f.setframerate(8000);f.writeframes(b'\0'*16000)
        self.audio=audio.getvalue()
        self.body=(f'<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel>'
                   f'<title>{self.title}</title><link>{self.url}</link>'
                   '<description>Local controlled research feed. No external resources.</description><language>en</language>'
                   f'<item><title>Research sample episode</title><guid isPermaLink="false">{nonce}</guid>'
                   '<description>One second of generated silence; playback is outside this pilot.</description>'
                   '<pubDate>Tue, 03 Nov 2026 00:00:00 GMT</pubDate>'
                   f'<enclosure url="http://10.0.2.2:{self.port}{self.audio_path}" length="{len(self.audio)}" type="audio/wav"/>'
                   '</item></channel></rss>').encode()
        self.thread=None

    def respond(self,handler,head):
        started=now();path=handler.path
        if path==self.feed_path:status,body,mime=200,self.body,'application/rss+xml; charset=utf-8'
        elif path==self.audio_path:status,body,mime=200,self.audio,'audio/wav'
        elif path=='/health':status,body,mime=200,b'{"ok":true}','application/json'
        else:status,body,mime=404,b'not found','text/plain'
        row={'event':'rss_request','started_utc':started,'method':handler.command,'path':path,
             'peer_ip':handler.client_address[0],'peer_port':handler.client_address[1],
             'status':status,'body_bytes':len(body),'body_sha256':hashlib.sha256(body).hexdigest(),'write_completed':False}
        try:
            handler.send_response(status);handler.send_header('Content-Type',mime)
            handler.send_header('Content-Length',str(len(body)));handler.send_header('Cache-Control','no-store');handler.end_headers()
            if not head:handler.wfile.write(body);handler.wfile.flush()
            row['write_completed']=True
        except (BrokenPipeError,ConnectionResetError) as exc:row['error']=type(exc).__name__
        finally:
            row['ended_utc']=now()
            with self.lock:self.events.append(row)

    def start(self):
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()

    def close(self):
        if self.thread:self.server.shutdown();self.thread.join(timeout=5)
        self.server.server_close()


def prepare(project,apk,name,assets,server):
    project,apk,assets=Path(project).resolve(),Path(apk).resolve(),Path(assets).resolve()
    if not re.fullmatch('[A-Za-z0-9_-]{1,64}',name):raise ValueError('Select a simple new trial name')
    if not apk.is_file() or digest(apk)!=APK_HASH:raise ValueError('Use the unchanged AntennaPod 3.12.3 APK')
    patch=read(assets/'PATCH-MANIFEST.json')
    for module,record in patch['modules'].items():
        if digest(project/'src/apk_audit'/module)!=record['fixed_sha256']:raise ValueError('Apply the supplied RSS preparation patch first: '+module)
    if digest(project/'src/apk_audit/_worker.py')!='646507a76bee12a6479c0bc9f3628acf8bb2b1beba945241c0d0fad686133fcf':raise ValueError('The existing macOS worker fix is required')
    registration=project/'handoff'/name;out=project/'runs'/name
    if registration.exists() or out.exists():raise ValueError('Trial name exists; preserve it and use --out-name with a new name')
    scenario={'schema_version':'1.0','scenario_id':'antennapod-3.12.3-controlled-rss-preview-pilot-v1','execution':'automatic','repetitions':1,
              'steps':[{'id':'launch','action':'launch','observe_s':5},
                       {'id':'rss-preview','action':'open_uri','uri':server.url,
                        'activity':PACKAGE+'/.ui.screen.onlinefeedview.OnlineFeedViewActivity','observe_s':60,
                        'expect_resource_id':PACKAGE+':id/fragmentContainer'}]}
    intent={'schema_version':'1.0','app_purpose':'研究者が設定したローカルRSSプレビューの試験条件。開発者の意図を推定したものではない。',
            'network':{'mode':'allowlist','allowed_destinations':[{'host':'10.0.2.2','include_subdomains':False,'ports':[server.port],'application_protocols':['http']}]},
            'sdk':{'mode':'unspecified'},'permissions':{'mode':'unspecified'},'cleartext_policy':'allow','background_network_policy':'unspecified'}
    spec={'schema_version':'1.0','pilot_id':'antennapod-controlled-rss-preview-pilot-v1','package':PACKAGE,'apk_sha256':APK_HASH,
          'serial':'emulator-5554','scenario':scenario,'observe_s':5,'rss_url':server.url,'rss_path':server.feed_path,
          'rss_port':server.port,'rss_title':server.title,'rss_body_sha256':hashlib.sha256(server.body).hexdigest(),
          'capture_scope':'exploratory_controlled_feed_preview_not_formal_accuracy','network_policy_origin':'researcher_test_condition',
          'planned_observables':{'rss_positive_gate':'target UID HTTP GET and HTTP 200 headers plus nonce/time local server candidate',
                                 'expected_correspondence':'controlled input URL can be dynamic_only; not a static parser error or privacy violation',
                                 'unknown_or_missing':'incomplete RSS confirmation; never convert to no networking or violation',
                                 'ui_parse_success':'separate end-screen inspection; not inferred from server send'},
          'local_prepared_utc':now(),'application_state':'preserved_no_clear_no_subscribe','device_validation':'pending_first_result'}
    registration.mkdir(parents=True)
    for filename,value in [('scenario.json',scenario),('intent.json',intent),('rss-spec.json',spec)]:
        (registration/filename).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    (registration/'feed.xml').write_bytes(server.body);(registration/'sample.wav').write_bytes(server.audio)
    for filename in ('run_rss.py','check_public_pilot.py','run_public_pilot.py','PATCH-MANIFEST.json'):
        shutil.copyfile(assets/filename,registration/filename)
    (registration/'PREPARED-MANIFEST.json').write_text(json.dumps({'files':{p.name:digest(p) for p in registration.iterdir() if p.is_file()}},indent=2)+'\n')
    return registration,out,spec


def check_rss(out,spec,server_events):
    """Inspect captured HTTP header + target UID and candidate server match."""
    # Generic capture checks reuse the launch checker while explicitly checking
    # the research allowlist separately; the received intent file stays intact.
    base=check(out,spec)
    intent=read(Path(out)/'intent.json',{})
    expected={'mode':'allowlist','allowed_destinations':[{'host':'10.0.2.2','include_subdomains':False,'ports':[spec['rss_port']],'application_protocols':['http']}]}
    base['checks'].pop('unspecified_network_condition')
    base['checks']['research_network_condition']=intent.get('network')==expected
    run=read(Path(out)/'run.json',{})
    matches=[];diagnostics=[]
    try:
        import dpkt,ipaddress
        from apk_audit.pcapdroid import trailer_uid
        meta=read(Path(out)/'automatic.metadata.json',{});offset=meta['clock_offset_s']
        headers=[]
        with (Path(out)/'raw/automatic.pcap').open('rb') as stream:
            for number,(ts,frame) in enumerate(dpkt.pcap.Reader(stream),1):
                ip=dpkt.ethernet.Ethernet(frame).data
                if not isinstance(ip,dpkt.ip.IP) or not isinstance(ip.data,dpkt.tcp.TCP):continue
                tcp=ip.data
                if b'\r\n\r\n' not in tcp.data:continue
                first=tcp.data.split(b'\r\n',1)[0]
                headers.append({'packet':number,'uid':trailer_uid(frame),'epoch':float(ts)+offset,
                                'src':str(ipaddress.ip_address(ip.src)),'dst':str(ipaddress.ip_address(ip.dst)),
                                'sport':tcp.sport,'dport':tcp.dport,'first':first})
        for request in headers:
            if request['first']!=('GET '+spec['rss_path']+' HTTP/1.1').encode() or request['uid']!=run['target_uid'] or request['dst']!='10.0.2.2' or request['dport']!=spec['rss_port']:continue
            responses=[h for h in headers if h['uid']==run['target_uid'] and h['src']=='10.0.2.2' and h['sport']==spec['rss_port'] and h['dport']==request['sport'] and h['first'].startswith(b'HTTP/1.') and b' 200 ' in h['first']]
            # VPN forwarding and Emulator NAT may rewrite the source port. Do
            # not assert an original 5-tuple equals the host-side peer tuple.
            received=[e for e in server_events if e['method']=='GET' and e['path']==spec['rss_path'] and e['status']==200 and e['write_completed'] and e['body_sha256']==spec['rss_body_sha256'] and abs(datetime.fromisoformat(e['started_utc']).timestamp()-request['epoch'])<=1]
            if responses and received:matches.append({'request_packet':request['packet'],'response_packets':[h['packet'] for h in responses],
                                                    'server_started_utc':[e['started_utc'] for e in received],
                                                    'original_source_port':request['sport'],'server_peer_ports':[e['peer_port'] for e in received],
                                                    'correlation':'candidate by nonce path, destination, target UID, corrected time within 1 s; NAT port mapping unknown and clock conditional'})
    except Exception as exc:diagnostics.append(type(exc).__name__+': '+str(exc))
    event_path=Path(out)/'ui_events.jsonl'
    events=[json.loads(s) for s in event_path.read_text().splitlines() if s.strip()] if event_path.is_file() else []
    base['checks']['rss_action_completed']=any(e.get('event_id')=='rss-preview' and e.get('action')=='open_uri' and e.get('uri')==spec['rss_url'] and e.get('success') for e in events)
    base['checks']['target_uid_http_and_local_server_candidate']=bool(matches)
    base.update(acceptance_profile=spec['pilot_id'],scope='exploratory_controlled_rss_preview',
                status='passed_controlled_rss_fetch' if all(base['checks'].values()) else 'incomplete',
                rss_candidate_matches=matches,diagnostics=diagnostics,
                interpretation='Checks explicit dispatch, capture controls, target-UID HTTP GET/200 headers and a candidate local server match. Not full TCP reassembly, app parsing success, safety, privacy compliance or general accuracy. Local server completion does not prove the app consumed the whole body.')
    base['evidence_references']={name:{'path':name,'sha256':digest(Path(out)/name)}
                                for name in ('raw/automatic.pcap','raw/rss-server-events.jsonl','raw/rss-preparation/rss-spec.json','ui_events.jsonl')
                                if (Path(out)/name).is_file()}
    return base


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--apk',type=Path,required=True);p.add_argument('--project',type=Path,default=Path.cwd());p.add_argument('--out-name',default='antennapod-rss-preview-001');p.add_argument('--prepare-only',action='store_true');a=p.parse_args()
    project=a.project.resolve();assets=Path(__file__).resolve().parent;server=RssServer(uuid.uuid4().hex)
    try:
        registration,out,spec=prepare(project,a.apk,a.out_name,assets,server)
        if a.prepare_only:print(json.dumps({'status':'prepared_only_no_android_actions','conditions':str(registration)},ensure_ascii=False));return 0
        initial_app_state(registration,spec);server.start()
        env={**os.environ,'PYTHONPATH':str(project/'src')}
        print('研究用RSSのプレビューを自動起動して60秒観測します。追加タップ・購読・再生はしないでください。制御・VPNの同意が出た場合だけ確認してください。',flush=True)
        code,interruption=run_analysis([sys.executable,'-m','apk_audit.cli','analyze','--apk',str(a.apk.resolve()),
                                      '--serial',spec['serial'],'--scenario',str(registration/'scenario.json'),
                                      '--intent',str(registration/'intent.json'),'--out',str(out)],project,env)
    finally:server.close()
    if not (out/'run.json').exists():print('出力がありません。handoffの条件と表示されたエラーを保存してください。');return code or 4
    shutil.copytree(registration,out/'raw/rss-preparation')
    (out/'raw/rss-server-events.jsonl').write_text(''.join(json.dumps(e,ensure_ascii=False)+'\n' for e in server.events))
    ui_snapshot(project,out,spec)
    sys.path.insert(0,str(project/'src'))
    result=check_rss(out,spec,server.events)
    if interruption:result.update(status='incomplete',wrapper_interruption=interruption)
    (out/'rss-preview-acceptance.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
    pack=subprocess.run([sys.executable,str(project/'tools/package_automatic_result.py'),'--run',str(out)],cwd=project,env=env)
    print('レポート: '+str(out/'summary.html'))
    return 0 if code==0 and pack.returncode==0 and result['status']=='passed_controlled_rss_fetch' else 4


if __name__=='__main__':raise SystemExit(main())
