#!/usr/bin/env python3
"""Small stdlib wrapper around the already installed unified APK analysis tool.

Freezes pilot conditions before capture and preserves failure results. Does not
modify the installed framework, clear app data or make post-hoc gold labels.
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
from datetime import datetime,timezone
from pathlib import Path

from check_public_pilot import check,read,digest


def prepare(project,apk,out_name,assets):
    project,apk,assets=Path(project).resolve(),Path(apk).resolve(),Path(assets).resolve()
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',out_name):raise ValueError('Use a simple new trial name')
    if not (project/'src/apk_audit/pipeline.py').is_file():raise ValueError('Specify the existing apk-audit-unified-v1 project')
    spec=read(assets/'pilot-spec.json');scenario=read(assets/'scenario-launch.json')
    if spec['scenario']!=scenario:raise ValueError('Pilot scenario differs from the specification')
    if not apk.is_file() or digest(apk)!=spec['apk_sha256']:raise ValueError('APK hash differs from the analyzed AntennaPod 3.12.3 original')
    if digest(project/'src/apk_audit/_worker.py')!=spec['expected_worker_sha256']:raise ValueError('Apply the previously supplied macOS worker fix before this pilot')
    out=project/'runs'/out_name;registration=project/'handoff'/out_name
    if out.exists() or registration.exists():raise ValueError('Trial name exists; preserve old data and select a new name')
    registration.mkdir(parents=True)
    for name in ('pilot-spec.json','scenario-launch.json'):shutil.copyfile(assets/name,registration/name)
    condition={'scope':'exploratory_not_formal_evaluation','prepared_utc':datetime.now(timezone.utc).isoformat(),
               'trial_id':out_name,'apk_sha256':digest(apk),'initial_app_data':'preserve; no pm clear or uninstall',
               'policy':'CLI default unspecified; no developer intent inferred','target_network_requirement':'No minimum target flow count; positive collector controls required',
               'scripts':{name:digest(assets/name) for name in ('run_pilot.py','check_public_pilot.py') if (assets/name).is_file()}}
    (registration/'pilot-preparation.json').write_text(json.dumps(condition,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    hashes={p.name:digest(p) for p in registration.iterdir() if p.is_file()}
    (registration/'PREPARED-MANIFEST.json').write_text(json.dumps({'files':hashes},indent=2)+'\n',encoding='utf-8')
    return registration,out,spec


def ui_snapshot(project,out,spec):
    """After capture only: never relaunch/tap to improve a result or its screenshot."""
    record={'phase':'after_capture','action':'inspect current UI without changing it'}
    try:
        r=subprocess.run(['adb','-s',spec['serial'],'shell','dumpsys','activity','activities'],capture_output=True,text=True,timeout=15)
        lines=[line for line in r.stdout.splitlines() if 'mResumedActivity' in line or 'topResumedActivity' in line]
        record['resumed_records']=lines
        record['target_foreground']=any(spec['package']+'/' in line for line in lines)
        if record['target_foreground']:
            p=subprocess.run(['adb','-s',spec['serial'],'exec-out','uiautomator','dump','/dev/tty'],capture_output=True,timeout=20)
            (out/'raw/pilot-end-ui.txt').write_bytes(p.stdout)
            image=subprocess.run(['adb','-s',spec['serial'],'exec-out','screencap','-p'],capture_output=True,timeout=15)
            if image.returncode==0 and image.stdout.startswith(b'\x89PNG') and len(image.stdout)<16*1024**2:
                (out/'raw/pilot-end-screen.png').write_bytes(image.stdout)
    except (OSError,subprocess.SubprocessError) as e:record['diagnostic_error']=type(e).__name__
    (out/'raw/pilot-end-ui-observation.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def run_analysis(argv,project,env):
    process=subprocess.Popen(argv,cwd=project,env=env)
    interruption=None
    try:
        return process.wait(timeout=1500),None
    except (subprocess.TimeoutExpired,KeyboardInterrupt) as exc:
        interruption={'error':type(exc).__name__,'manual_capture_status_check_required':True}
        print('中断しました。解析側の取得停止処理を待ちます。',flush=True)
        if process.poll() is None:
            try:process.send_signal(signal.SIGINT)
            except ProcessLookupError:pass
        try:process.wait(timeout=95)
        except (subprocess.TimeoutExpired,KeyboardInterrupt):
            process.terminate()
            try:process.wait(timeout=10)
            except subprocess.TimeoutExpired:process.kill();process.wait(timeout=10)
            interruption['forced_host_process_stop']=True
        return 4,interruption


def initial_app_state(registration,spec):
    record={'phase':'before_install','package':spec['package'],'changes_to_app_data':False}
    try:
        p=subprocess.run(['adb','-s',spec['serial'],'shell','pm','list','packages',spec['package']],capture_output=True,text=True,timeout=15)
        record.update(command_returncode=p.returncode,output=p.stdout,stderr=p.stderr,
                      package_listed=('package:'+spec['package']) in p.stdout.splitlines())
    except (OSError,subprocess.SubprocessError) as exc:record['error']=type(exc).__name__
    (registration/'initial-installation-state.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',type=Path,default=Path.cwd());p.add_argument('--apk',type=Path,required=True)
    p.add_argument('--out-name',default='antennapod-launch-001');p.add_argument('--prepare-only',action='store_true');a=p.parse_args()
    assets=Path(__file__).resolve().parent
    registration,out,spec=prepare(a.project,a.apk,a.out_name,assets)
    if a.prepare_only:
        print(json.dumps({'status':'prepared_only_no_android_actions','conditions':str(registration)},ensure_ascii=False));return 0
    initial_app_state(registration,spec)
    env={**os.environ,'PYTHONPATH':str(a.project.resolve()/'src')}
    argv=[sys.executable,'-m','apk_audit.cli','analyze','--apk',str(a.apk.resolve()),'--serial',spec['serial'],
          '--scenario',str(registration/'scenario-launch.json'),'--out',str(out)]
    print('起動・60秒待機の予備観測です。画面操作は追加せず、制御・VPNの許可画面が出た場合だけ確認してください。',flush=True)
    returncode,interruption=run_analysis(argv,a.project,env)
    if interruption:
        (registration/'wrapper-interruption.json').write_text(json.dumps(interruption)+'\n',encoding='utf-8')
        print('PCAPdroidの稼働状態も確認してください。状態不明のセッションを自動では終了しません。',flush=True)
    if not (out/'run.json').exists():
        print('解析の出力が作られていません。handoff内の条件記録と端末表示を確認してください。');return returncode or 4
    shutil.copytree(registration,out/'raw/pilot-preparation')
    ui_snapshot(a.project,out,spec)
    result=check(out,spec)
    if interruption:
        result.update(status='incomplete',wrapper_interruption=interruption)
    (out/'public-pilot-acceptance.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
    package=subprocess.run([sys.executable,str(a.project.resolve()/'tools/package_automatic_result.py'),'--run',str(out)],cwd=a.project,env=env,check=False)
    if package.returncode:print('結果フォルダは保存されています。ZIP作成の表示を確認してください。')
    print('レポート: '+str(out/'summary.html'))
    return 0 if returncode==0 and result['status']=='passed_exploratory_capture' and package.returncode==0 else 4


if __name__=='__main__':raise SystemExit(main())
