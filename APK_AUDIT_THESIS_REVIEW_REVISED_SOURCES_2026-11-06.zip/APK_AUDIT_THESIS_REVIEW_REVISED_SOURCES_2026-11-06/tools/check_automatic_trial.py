#!/usr/bin/env python3
"""Acceptance check for the first local automatic HTTP control trial."""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from apk_audit.core import read_json, read_jsonl, write_json
from apk_audit.differential import build
from apk_audit.report import report


def check(out):
    out = Path(out)
    run = read_json(out/'run.json')
    bridge = read_json(out/'raw/bridge-results.json') if (out/'raw/bridge-results.json').exists() else []
    flows = [v for _, v in read_jsonl(out/'flows.jsonl')]
    servers = [v for _, v in read_jsonl(out/'raw/automatic-controls.jsonl')] if (out/'raw/automatic-controls.jsonl').exists() else []
    statuses = [r['result'].get('running') for r in bridge if r['action'] == 'get_status' and 'result' in r]
    probes = [r for r in bridge if r['action'] == 'probe' and r.get('result', {}).get('http_status') == 200]
    matched_controls = [r for r in probes if any(s.get('run_id') == r['request_id'] and s.get('event') == 'http_request_received' and s.get('method') == 'GET' for s in servers)]
    control_flows = [f for f in flows if f.get('uid') == run.get('bridge_uid') and f.get('port') == run.get('control_port')
                     and f.get('destination_ip') == '10.0.2.2' and f.get('application_protocol') == 'http']
    target = [f for f in flows if f.get('attribution') == 'target' and f.get('destination_ip') == '10.0.2.2'
              and f.get('port') == 8765 and f.get('application_protocol') == 'http']
    checks = {'live_mode': run.get('analysis_mode') == 'live', 'http_fixture_package': run.get('package') == 'org.example.apkaudit.http',
              'static_completed': run['static_status'] == 'completed', 'scenario_completed': run.get('execution_status') == 'completed',
              'capture_retained': run['dynamic_status'] in ('completed', 'partial'),
              'start_and_stop_confirmed': statuses == [False, True, False] and all(any(r['action'] == a and r.get('result', {}).get('result_code') == -1 for r in bridge) for a in ('start','stop')),
              'cleanup_confirmed': not run.get('cleanup_failed') and not run.get('manual_cleanup_required'),
              'two_device_server_controls': len(matched_controls) == 2, 'two_uid_pcap_control_flows': len(control_flows) >= 2,
              'target_uid_http_request': bool(target)}
    # Rebuild checks every referenced file digest; a modified log fails acceptance.
    try:
        report(out)
        result = build(out)
        checks['evidence_integrity'] = True
        checks['static_dynamic_correspondence'] = result['counts']['both'] >= 1
    except Exception as exc:
        checks['evidence_integrity'] = False
        checks['static_dynamic_correspondence'] = False
    return {'schema_version':'1.0', 'acceptance_profile':'automatic-http-control-v1', 'checks':checks,
            'status':'passed' if all(checks.values()) else 'incomplete',
            'limitations':['A pass confirms this local smoke trial only; not general capture accuracy, application coverage, or HTTP 200 success of the target app.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    args = parser.parse_args()
    result = check(args.run)
    write_json(args.run/'automatic-acceptance.json', result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['status'] == 'passed' else 4


if __name__ == '__main__': raise SystemExit(main())
