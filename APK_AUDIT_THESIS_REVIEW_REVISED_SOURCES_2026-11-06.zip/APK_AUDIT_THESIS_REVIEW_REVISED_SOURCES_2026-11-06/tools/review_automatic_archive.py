#!/usr/bin/env python3
"""Verify an automatic HTTP smoke archive and reproduce analysis without Android.

Raw originals are extracted only after inventory/hash/path checks. No uploaded
program is executed. The source implementation is checked against known releases.
This profile establishes one control trial, never general capture accuracy.
"""
import argparse
import copy
import hashlib
import ipaddress
import json
import re
import shutil
import stat
import sys
import zipfile
from pathlib import Path, PurePosixPath

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT/'tools'))
from apk_audit.capture import import_capture
from apk_audit.cli import static_stage
from apk_audit.compare import compare
from apk_audit.core import read_json, read_jsonl, sha256, timestamp, write_json
from apk_audit.differential import build
from apk_audit.pcapdroid import trailer_uid
from apk_audit.report import report
from check_automatic_trial import check as acceptance


def require(condition,message):
    if not condition:raise ValueError(message)


def inspect_archive(path):
    """No filesystem writes until every member is bounded and verified."""
    with zipfile.ZipFile(path) as archive:
        infos=archive.infolist();names=[i.filename for i in infos]
        require(len(names)<=4096 and len(names)==len(set(names)),'Duplicate or excessive ZIP entries')
        require(sum(i.file_size for i in infos)<=512*1024**2,'Archive exceeds uncompressed limit')
        for entry in infos:
            p=PurePosixPath(entry.filename)
            require(not p.is_absolute() and '..' not in p.parts and '\\' not in entry.filename and str(p)==entry.filename,'Unsafe or noncanonical ZIP path')
            require(not stat.S_ISLNK(entry.external_attr>>16) and not entry.is_dir() and not entry.flag_bits&1,'Unsupported ZIP member')
        manifests=[n for n in names if n.endswith('/RESULT-MANIFEST.json')]
        require(len(manifests)==1,'Expected one result manifest')
        prefix=manifests[0][:-len('RESULT-MANIFEST.json')]
        require(prefix.count('/')==1,'Expected one top-level trial directory')
        manifest=json.loads(archive.read(manifests[0]))
        require(set(names)=={prefix+n for n in manifest['files']}|set(manifests),'ZIP and manifest inventory differ')
        for relative,digest in manifest['files'].items():
            require(hashlib.sha256(archive.read(prefix+relative)).hexdigest()==digest,'Manifest hash mismatch: '+relative)
        return prefix,manifest


def known_code():
    base=ROOT/'dist/apk-audit-unified-v1.zip'
    patch=ROOT/'dist/apk-audit-macos-worker-fix-v1.zip'
    require(sha256(base)=='b4628068c5cd1f3eb42541d1e2133d545ce9a99fbc2cc2a79236b039986da0f1','Unexpected base distribution')
    require(sha256(patch)=='15d96efaae413adae6b7676e8e3aa8c3723e4f7bbf8a40563b5c04b33ef100f1','Unexpected patch distribution')
    with zipfile.ZipFile(base) as z:
        prefix='apk-audit-unified-v1/src/apk_audit/'
        expected={n.removeprefix(prefix):hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith(prefix)}
    with zipfile.ZipFile(patch) as z:
        expected['_worker.py']=hashlib.sha256(z.read('apk-audit-macos-worker-fix-v1/payload/_worker.py')).hexdigest()
    return expected


def packet_headers(path,meta):
    """Complete headers in a single segment only; no stream reconstruction."""
    import dpkt
    rows=[];packets=[]
    with Path(path).open('rb') as stream:
        reader=dpkt.pcap.Reader(stream)
        require(reader.datalink()==dpkt.pcap.DLT_EN10MB,'Expected extended Ethernet PCAP')
        for number,(ts,frame) in enumerate(reader,1):
            uid=trailer_uid(frame)
            packets.append({'packet':number,'uid':uid})
            ip=dpkt.ethernet.Ethernet(frame).data
            if not isinstance(ip,(dpkt.ip.IP,dpkt.ip6.IP6)) or not isinstance(ip.data,dpkt.tcp.TCP):continue
            tcp=ip.data
            if b'\r\n\r\n' not in tcp.data:continue
            try:
                lines=tcp.data.split(b'\r\n\r\n',1)[0].decode('ascii').split('\r\n')
                request=re.fullmatch(r'(GET|POST) ([^ ]+) HTTP/1\.[01]',lines[0])
                response=re.fullmatch(r'HTTP/1\.[01] (\d{3}) .*',lines[0])
                if not request and not response:continue
                headers={}
                for line in lines[1:]:
                    key,value=line.split(':',1);key=key.lower()
                    require(key not in headers,'Ambiguous duplicate HTTP header')
                    headers[key]=value.strip()
                rows.append({'packet':number,'uid':uid,'epoch':float(ts)+meta['clock_offset_s'],
                             'source_ip':str(ipaddress.ip_address(ip.src)),
                             'destination_ip':str(ipaddress.ip_address(ip.dst)),
                             'source_port':tcp.sport,'destination_port':tcp.dport,
                             'method':request[1] if request else None,'path':request[2] if request else None,
                             'status':int(response[1]) if response else None,'run_marker':headers.get('x-audit-run')})
            except (ValueError,UnicodeError):continue
    return rows,packets


def review(archive_path,out):
    archive_path,out=Path(archive_path),Path(out)
    require(not out.exists(),'Review output already exists')
    prefix,manifest=inspect_archive(archive_path)
    out.mkdir(parents=True);source=out/'original';source.mkdir()
    with zipfile.ZipFile(archive_path) as z:
        for name in z.namelist():
            target=source/name.removeprefix(prefix);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
    run=read_json(source/'run.json');checks={'result_manifest_hashes':True}
    require(sha256(source/'raw/original.apk')==run['apk_sha256']=='7c7f24e82c80fb1e51df96923dda326571d3c706d496e03efb6373647df01382','This profile requires the unchanged HTTP control APK')
    checks['known_control_apk']=True
    code=read_json(source/'raw/analysis-code-manifest.json')
    require(sha256(source/'raw/analysis-code-manifest.json')==run['analysis_code_manifest_sha256'],'Code manifest digest differs')
    require(code['files']==known_code(),'Recorded source code differs from v1 plus worker fix')
    checks['known_release_plus_macos_worker_fix']=True
    identity=read_json(source/'raw/installation-identity.json')
    require(identity=={'package':run['package'],'uid':run['target_uid'],'bridge_uid':run['bridge_uid'],'apk_sha256':run['apk_sha256']},'Installation record disagrees')
    checks['installation_record_consistent']=True
    worker=read_json(source/'static-worker.json')
    require(worker['ok'] and worker['resource_limits']['address_space']['status']=='not_enforced','Darwin fix status differs')
    checks['darwin_worker_fix_observed']=True
    index=read_json(source/'evidence/index.json')
    for eid,record in index.items():
        path=(source/record['path']).resolve()
        require(path.is_relative_to(source.resolve()) and path.is_file() and sha256(path)==record['sha256'],'Evidence differs: '+eid)
    checks['all_evidence_index_hashes']=True
    meta=read_json(source/'automatic.metadata.json');clocks=read_json(source/'raw/clock-samples.json')
    require(len(clocks)==2,'Expected pre/post clock brackets')
    for c in clocks:
        quantum=10**-len(c['device'].split('.')[1]);device=float(c['device'])
        require(c['host_before']<=c['host_after'],'Invalid host bracket')
        require(abs(c['offset_lower_s']-(c['host_before']-device-quantum))<1e-6 and abs(c['offset_upper_s']-(c['host_after']-device))<1e-6,'Clock sample calculation differs')
    lower=max(c['offset_lower_s'] for c in clocks);upper=min(c['offset_upper_s'] for c in clocks)
    require(lower<=upper and meta['clock_offset_interval_s']==[lower,upper] and meta['clock_offset_s']==(lower+upper)/2,'Clock intersection differs')
    checks['clock_interval_recomputed']=True
    require(sha256(source/'raw/automatic.pcap')==sha256(source/'raw/capture-1.pcap'),'Two copies of same capture differ')
    replay=out/'replay';replay_run=static_stage(source/'raw/original.apk',replay)
    original_static=read_json(source/'static.json');replay_static=read_json(replay/'static.json')
    for d in (original_static,replay_static):d.pop('analysis_duration_s',None)
    checks['static_reproduced_excluding_duration']=original_static==replay_static
    replay_run.update(analysis_mode='replay',execution_status=run['execution_status'])
    write_json(replay/'run.json',replay_run);shutil.copyfile(source/'ui_events.jsonl',replay/'ui_events.jsonl')
    replay_meta=copy.deepcopy(meta);replay_meta['run_id']=replay_run['run_id'];write_json(replay/'capture.metadata.json',replay_meta)
    import_capture(replay,source/'raw/automatic.pcap',replay/'capture.metadata.json','pcapdroid-pcap')
    original_flows=[f for _,f in read_jsonl(source/'flows.jsonl')];replay_flows=[f for _,f in read_jsonl(replay/'flows.jsonl')]
    def normalized(rows):return [{k:v for k,v in r.items() if k!='run_id'} for r in rows]
    checks['all_flows_reproduced']=normalized(original_flows)==normalized(replay_flows)
    compare(replay,read_json(source/'intent.json'));report(replay);correspondence=build(replay)
    old_findings=read_json(source/'findings.json')['findings'];new_findings=read_json(replay/'findings.json')['findings']
    checks['policy_findings_reproduced']=normalized(old_findings)==normalized(new_findings)
    original_correspondence=read_json(source/'correspondence.json')
    checks['correspondence_reproduced']=all(correspondence[k]==original_correspondence[k] for k in ('counts','records','flow_counts','static_candidate_counts'))
    # Run the trusted local checker only on a copy, keeping received files intact.
    checker_copy=out/'checker-copy';shutil.copytree(source,checker_copy)
    independently_checked=acceptance(checker_copy)
    checks['acceptance_recomputed']=independently_checked==read_json(source/'automatic-acceptance.json') and independently_checked['status']=='passed'
    headers,packets=packet_headers(source/'raw/automatic.pcap',meta)
    trace=read_json(source/'raw/bridge-results.json');controls=[v for _,v in read_jsonl(source/'raw/automatic-controls.jsonl')]
    control_evidence=[]
    epsilon=(upper-lower)/2
    for event in [e for e in trace if e['action']=='probe']:
        matching=[h for h in headers if h['method']=='GET' and h['path']=='/health' and h['uid']==run['bridge_uid'] and h['destination_ip']=='10.0.2.2' and h['destination_port']==run['control_port'] and h['run_marker']==event['request_id']]
        server=[e for e in controls if e.get('event')=='http_request_received' and e.get('run_id')==event['request_id'] and e.get('method')=='GET']
        require(len(matching)==len(server)==1,'Control packet/server nonce correspondence differs')
        require(timestamp(event['started_utc'])-epsilon<=matching[0]['epoch']<=timestamp(event['ended_utc'])+epsilon,'Control packet time outside callback interval')
        require(timestamp(event['started_utc'])<=timestamp(server[0]['utc'])<=timestamp(event['ended_utc']),'Server control outside callback interval')
        control_evidence.append({'request_id':event['request_id'],'request_packet':matching[0]['packet'],'server_event_id':server[0]['event_id']})
    checks['two_raw_packet_server_nonce_controls']=len(control_evidence)==2
    target=[f for f in original_flows if f['attribution']=='target'];require(len(target)==1,'Expected one target control flow')
    numbers=set(target[0]['source_record']['packet_numbers'])
    target_headers=[h for h in headers if h['packet'] in numbers]
    requests=[h for h in target_headers if h['method']=='POST' and h['path']=='/collect' and h['destination_port']==8765]
    responses=[h for h in target_headers if h['status'] is not None and h['source_port']==8765]
    require(all(p['uid']==run['target_uid'] for p in packets if p['packet'] in numbers),'Target packet UID inconsistency')
    checks['target_post_from_uid_trailer']=len(requests)==1
    stops=[e for e in trace if e['action']=='stop'];require(len(stops)==1,'Stop count differs')
    require(len(packets)==stops[0]['result']['pkts_sent']+stops[0]['result']['pkts_rcvd'],'Captured packet count differs from stop stats')
    checks['packet_count_matches_collector_stop_stats']=True
    result={'schema_version':'1.0','trial_id':prefix.rstrip('/'),'review_profile':'automatic-http-raw-review-v1','archive_sha256':sha256(archive_path),
            'status':'verified' if all(checks.values()) else 'needs_review','checks':checks,
            'manifest_files':len(manifest['files']),'apk_sha256':run['apk_sha256'],'target_uid':run['target_uid'],'bridge_uid':run['bridge_uid'],
            'capture_packets':len(packets),'flow_count':len(original_flows),'target_flows':len(target),
            'target_request_packets':[h['packet'] for h in requests],
            'target_http_response_headers':[{'packet':h['packet'],'status':h['status']} for h in responses],
            'controls':control_evidence,'clock_offset_interval_s':[lower,upper],'clock_offset_midpoint_s':meta['clock_offset_s'],
            'clock_half_width_s':epsilon,'quality':run['dynamic_status'],'comparison_counts':correspondence['counts'],
            'static_only_endpoints':[r['endpoint'] for r in correspondence['records'] if r['status']=='static_only'],
            'limitations':['Single self-authored HTTP control on one API35 AVD; not general accuracy or application coverage.',
                           'UID is checked against recorded installation and capture assertions; no independent live ADB measurement was possible.',
                           'Clock samples bound endpoint assumptions, not capture-wide drift or external UTC accuracy.',
                           'HTTP 200 header in PCAP does not prove the application consumed the response; no target application log is included.',
                           'Packet header inspection is single-segment only; no general TCP reassembly.','Raw originals preserved; analysis on copies only.']}
    write_json(out/'review.json',result)
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--archive',type=Path,required=True);parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
    result=review(args.archive,args.out);print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['status']=='verified' else 4


if __name__=='__main__':raise SystemExit(main())
