#!/usr/bin/env python3
"""Package review revisions and an unfilled independent-review packet."""
from pathlib import Path
import ast
import hashlib
import json
import re
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[1]


def main():
    stage=ROOT/'dist/APK_AUDIT_THESIS_REVIEW_REVISED_SOURCES_2026-11-06'
    if stage.exists():raise ValueError('Preserve the previous publication')
    files=set()
    def add(path):
        path=path.resolve();path.relative_to(ROOT)
        if path in files:return
        if not path.is_file():raise FileNotFoundError(path)
        files.add(path)
        if path.suffix=='.tex':
            for kind,name in re.findall(r'\\(input|include|includegraphics)(?:\[[^\]]*\])?\{([^}]+)\}',path.read_text()):
                child=ROOT/'docs'/name
                if not child.suffix and kind!='includegraphics':child=child.with_suffix('.tex')
                add(child)
        if path.parent==ROOT/'tools' and path.suffix=='.py':
            for node in ast.walk(ast.parse(path.read_text())):
                names=[]
                if isinstance(node,ast.ImportFrom) and node.module:names=[node.module.split('.')[0]]
                if isinstance(node,ast.Import):names=[a.name.split('.')[0] for a in node.names]
                for name in names:
                    child=ROOT/'tools'/(name+'.py')
                    if child.is_file():add(child)
    for name in ['docs/thesis.tex','docs/thesis.pdf','docs/thesis.log','tools/build_thesis.sh',
                 'tools/check_manuscript_consistency.py','tools/review_intent_seed_archive.py','tools/build_independent_review_packet.py',
                 'tools/package_review_revision.py','dist/apk-audit-intent-v1.zip',
                 'pyproject.toml','requirements.lock','requirements-python311.lock',
                 'docs/research/review-revision-2026-11-06/final29-trials.csv',
                 'docs/research/finish-plan-2026-11-06/scope-and-completion.json',
                 'docs/research/primary-paper-review-2026-11-05/page-grounded-comparison.csv']:
        add(ROOT/name)
    for directory in ['docs/research/reviewer-revision-2026-11-06','docs/research/intent-seeds-001-2026-11-06']:
        for path in (ROOT/directory).iterdir():
            if path.suffix in ('.md','.json','.csv'):add(path)
    for path in (ROOT/'docs/research/reviewer-revision-2026-11-06/reviewer-packet').iterdir():
        if path.is_file():add(path)
    for name in ['intent-v1.1.schema.json','status.json','posthoc-input-example.json','posthoc-input-example.csv']:
        add(ROOT/'docs/research/intent-first-2026-11-06'/name)
    for path in (ROOT/'src/apk_audit').rglob('*'):
        if path.is_file() and path.suffix in ('.py','.json','.apk'):add(path)
    for path in (ROOT/'examples').glob('intent-*-v1.1.json'):add(path)
    for path in (ROOT/'tests').glob('test_intent*.py'):add(path)
    for path in files:
        assert not path.is_relative_to(ROOT/'runs')
        assert path.suffix not in ('.pcap','.pcapng','.jsonl')
    stage.mkdir()
    for path in files:
        target=stage/path.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
    (stage/'README.md').write_text('# レビュー反映版の論文・TeX・データ（2026-11-06）\n\n本文は28ページです。主評価9試行は、同一ホストの別ポート、75秒予定と30秒窓、既知の組立て素材に対する規則の動作確認として記載しました。\n主評価の帰属不明0と、補助群のUDP4単位の事後解析を区別し、端末実行は全て著者本人だったことを明記しました。\n\n- docs/thesis.pdf：修正版草稿。\n- docs/research/reviewer-revision-2026-11-06/READ_FIRST.md：変更と未確認事項、本人の手順。\n- 同フォルダ/review-response.json：レビュー各項目の対応状況。\n- 同フォルダ/REPRODUCE.md：本文から移したMac固有パスと実行方法。\n- 同フォルダ/new-primary-paper-checks.json：Agrigento本文の確認箇所。ReCon・Haystack/Lumenは本文未確認として残す。\n\n独立した第三者確認は未実施です。12件の確認票を用意しただけで、結果や一致率は記入していません。\n第三者には別配布の独立確認用ZIPか、reviewer-packetフォルダだけを渡してください。\nresearcher-system-outputs.jsonはシステムの参照出力で、独立した正解ではありません。記入前には確認者へ渡さないでください。\n確認者が既に草稿の結果を知っていた場合も、その情報を宣言へ記録します。完全な盲検とは呼びません。\n\n## 再生成と点検\n\nXeLaTeX・TikZ・fancyvrb・xurl、Noto CJKとDejaVuのフォントを使い、bash tools/build_thesis.shで生成します。\npython tools/check_manuscript_consistency.py --out /tmp/check.jsonで公開集計と文書参照を検査できます。\n研究者用の原本がある場合だけ --private-original /path/to/review/original を追加できます。\n取得プログラムと原本は変更していません。追加のAndroid実験や過去試行の再実行は不要です。\n\n## 収録範囲\n\nユーザーの原本APK・PCAP・生通信ログ・nonce・第三者の論文PDFは収録していません。\n確認票には自作研究素材の意図と、UID・研究用宛先・時刻・Manifest等の抜粋を含みます。原本そのものではありません。\n同梱の従来ツールには自作参照APKと取得補助APKを含みます。新ランナーの導入を求める資料ではありません。\n著者情報・大学様式・AI利用実態と内容の本人確認は引き続き必要です。\n')
    manifest={str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(stage.rglob('*')) if p.is_file()}
    (stage/'MANIFEST.json').write_text(json.dumps(dict(profile='review-revised-intent-audit-thesis',thesis_pages=28,
        primary_device_trials=9,historical_device_trials=29,new_device_trials=0,required_new_device_trials=0,
        retrospective_component_outputs=27,figures=2,citations=12,author_signoff_pending=True,review_cases_prepared=12,independent_reviews_completed=0,
        raw_capture_or_user_APK_included=False,own_reference_APKs_and_bridge_included=True,files=manifest),ensure_ascii=False,indent=2)+'\n')
    archive=stage.with_suffix('.zip')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in sorted(stage.rglob('*')):
            if path.is_file():z.write(path,path.relative_to(stage.parent))
    pdf=ROOT/'dist/APK_AUDIT_THESIS_REVIEW_REVISED_2026-11-06.pdf'
    if pdf.exists():raise ValueError('Preserve existing PDF artifact')
    shutil.copy2(ROOT/'docs/thesis.pdf',pdf)
    review_zip=ROOT/'dist/APK_AUDIT_INDEPENDENT_REVIEW_12_2026-11-06.zip'
    with zipfile.ZipFile(review_zip,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted((ROOT/'docs/research/reviewer-revision-2026-11-06/reviewer-packet').iterdir()):
            if p.is_file():z.write(p,'independent-review-12/'+p.name)
    for path in [pdf,archive,review_zip]:
        shutil.copy2(path,Path('/workspace/downloads')/path.name)
        print(json.dumps(dict(name=path.name,bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())))


if __name__=='__main__':main()
