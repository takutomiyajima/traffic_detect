#!/usr/bin/env python3
"""Prepare unfilled, output-withheld evidence review forms; never fake a reviewer."""
from pathlib import Path
import csv
import html
import json
import random
import sys
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from apk_audit.core import read_json, read_jsonl, sha256, write_json


def endpoint(uri):
    u=urlsplit(uri);return f'{u.scheme}://{u.hostname}:{u.port}'


def main():
    out=ROOT/'docs/research/reviewer-revision-2026-11-06';packet=out/'reviewer-packet'
    if packet.exists():raise ValueError('Preserve existing review materials')
    packet.mkdir(parents=True)
    study=ROOT/'runs/intent-seeds-001-reviewed-2026-11-06/original';cases=[];keys=[]
    plan=read_json(study/'seed-plan.json')
    for spec in plan['trials']:
        d=study/spec['trial_id'];run=read_json(d/'run.json');meta=read_json(d/'automatic.metadata.json')
        findings=read_json(d/'findings.json')['findings']
        flows=[r for _,r in read_jsonl(d/'flows.jsonl')];ui=[r for _,r in read_jsonl(d/'ui_events.jsonl') if r.get('action')=='open_uri'][0]
        targets=[f for f in flows if f['attribution']=='target']
        selected=[f for f in findings if f['subject'] in ('external_connection','target_observation_coverage')]
        assert len(selected)==1
        c={'question':'通信先の照合について、提示した記録で支持できる判定を選んでください。',
           'topic':'endpoint','policy_timing':'解析前にローカル保存',
           'policy':read_json(d/'intent.json'),'quality':run['dynamic_status'],
           'evidence':{'target_installation_uid':run['target_uid'],'input_endpoint':endpoint(ui['uri']),
                       'input_operation_success':ui['success'],'input_started_utc':ui['started_utc'],'input_ended_utc':ui['ended_utc'],
                       'clock_offset_interval_s':meta['clock_offset_interval_s'],'pre_and_post_controls':{'before':meta['controls_before'],'after':meta['controls_after']},
                       'target_flow_count':len(targets),'other_uid_flow_count':sum(f['attribution']=='other' for f in flows),
                       'unknown_uid_flow_count':sum(f['attribution']=='unknown' for f in flows),
                       'target_flow_records':[{k:f.get(k) for k in ('uid','host','port','transport','application_protocol','observation','started_utc','ended_utc','clock_alignment_half_width_s','source_record')} for f in targets]},
           'source_hashes':{n:sha256(d/n) for n in ['intent.json','ui_events.jsonl','flows.jsonl','raw/installation-identity.json','raw/automatic.pcap']},
           'excerpt_scope':'Parsed excerpts from private originals; request token and path removed. Does not independently authenticate capture or UID assertions.'}
        cases.append(c);keys.append({'original_case':spec['trial_id'],'system_verdict':selected[0]['verdict'],'system_observation':selected[0]['observation'],'timing':'prospective_local_intent'})
    for trial in ('udp-short-001','udp-short-002'):
        d=ROOT/'runs/all13-policy-evaluation-v3-2026-10-31'/trial/'comparisons/captured_allowlist/integrated'
        run=read_json(d/'run.json');f=read_json(d/'findings.json');flows=[r for _,r in read_jsonl(d/'flows.jsonl')]
        selected=next(r for r in flows if r['attribution']=='unknown' and r['port']==8766)
        finding=next(r for r in f['findings'] if selected['evidence_ids'][0] in r['evidence_ids'] and r['subject']=='connection_attribution')
        cases.append({'question':'このUDP記録を対象アプリの許可／禁止通信として照合できるか判断してください。',
                      'topic':'endpoint','policy_timing':'既存記録への事後の意図適用例','policy':f['intent'],'quality':run['dynamic_status'],
                      'evidence':{'target_installation_uid':run.get('target_uid'),'selected_record':{k:selected.get(k) for k in ('uid','package','destination_ip','host','port','transport','application_protocol','observation','source_record','attribution_reason','limitations')}},
                      'source_hashes':{n:sha256(d/n) for n in ['intent.json','flows.jsonl','run.json']},
                      'excerpt_scope':'CSV-derived normalized excerpt. Missing UID stays null; no independent collector-accuracy claim.'})
        keys.append({'original_case':trial,'system_verdict':finding['verdict'],'system_observation':finding['observation'],'timing':'posthoc_policy'})
    d=ROOT/'runs/intent-bundle-static-001';f=read_json(d/'findings.json');static=read_json(d/'static.json');finding=next(r for r in f['findings'] if r['rule_id']=='C04')
    cases.append({'question':'権限宣言が提示した意図と整合するか判断してください。位置情報の実使用は判定対象外です。',
                  'topic':'permission_declaration','policy_timing':'静的解析前に意図を保存した参照素材','policy':f['intent'],
                  'evidence':{'declared_permissions':[r['name'] for r in static['permissions']],
                              'dynamic_observation_performed':False,'source_contract':'Reference source declares a permission without calling location or network APIs.'},
                  'source_hashes':{n:sha256(d/n) for n in ['intent.json','static.json','raw/original.apk']},
                  'excerpt_scope':'Manifest declaration only. Permission use or location transmission is outside scope.'})
    keys.append({'original_case':'static-permission-reference','system_verdict':finding['verdict'],'system_observation':finding['observation'],'timing':'static_reference'})
    assert len(cases)==12
    order=list(range(12));random.Random(20261106).shuffle(order);review_cases=[];reference=[]
    for i,source in enumerate(order,1):
        identifier=f'R{i:02}';review_cases.append({'case_id':identifier,**cases[source]});reference.append({'case_id':identifier,**keys[source]})
    write_json(packet/'cases.json',{'status':'prepared_not_reviewed','selection':'9 primary records, 2 historical unknown-UID records, 1 static permission reference; author-selected after results',
        'independent_accuracy_established':False,'cases':review_cases})
    write_json(out/'researcher-system-outputs.json',{'not_independent_ground_truth':True,'withhold_from_reviewer_until_their_form_is_saved':True,'cases':reference})
    fields=['case_id','reviewer_verdict','evidence_support','reason','reviewer_code','review_date','AI_used']
    with (packet/'reviewer-form.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows({'case_id':c['case_id']} for c in review_cases)
    write_json(packet/'reviewer-declaration.json',{'reviewer_code':'','role':'','involved_in_implementation_or_materials':None,'used_AI_for_judgment':None,'knew_system_outputs_before_review':None,'review_date':'','reviewed_original_raw_records':None,'notes':''})
    instructions='''# 独立した確認を依頼する資料（12件・未実施）

## 依頼する範囲

新しいアプリ実験は行いません。既存記録の抜粋と意図を読み、12件の判定と根拠の対応を確認します。
目安30〜60分です。実装・素材・期待値の作成に関わっていない教員や同期等へ依頼する想定です。
このフォルダだけを渡します。作成側のresearcher-system-outputs.jsonは、記入後まで渡さないでください。

## 手順

1. review.htmlをブラウザで開く（外部通信やJavaScriptは使いません）。
2. reviewer-declaration.jsonに匿名コード、立場、素材・実装への関与、AI利用の有無、確認日を記入します。
3. 各ケースについてreviewer-form.csvの空欄を記入します。
4. 原本が必要な場合は著者へ要求します。提示抜粋だけで判断できなければ根拠不足として残します。
5. 記入したCSVと宣言JSONを著者へ返します。内容を共有する前に個人情報や不要な注記を確認します。

## 判定値

- consistent_with_observed_evidence（整合）：必要な帰属と条件がそろい、明示した条件を満たす。
- mismatch_candidate（不一致候補）：必要な比較ができ、明示した条件に反する。
- needs_review（要確認）：条件が未指定、実行未確認の静的候補等。
- not_evaluable（判定不能）：帰属、観測、方式等の必要な情報が不足する。

evidence_supportにはsupported／insufficient／contradictedを記入し、reasonに判断の根拠を短く書きます。
AI_usedにはyes／noを記入します。AIによる自動点検だけを、第三者本人の独立した確認として集計しません。
システム出力との不一致は修正して隠さず、そのまま残してください。

## 解釈の制約

9件は主評価、2件は事後ポリシーを使う帰属不明の補助例、1件は静的素材です。条件と時点を混ぜて精度を計算しません。
ケースは結果を見た後に作成側が選び、抜粋を整形しています。独立確認ができるのは提示した証拠に対する判定の整合であり、
取得原本の真正性、収集器のUID精度、アプリ一般への精度、漏えい検出を独立に証明する評価ではありません。
同じ参照素材の反復が含まれます。12件を12アプリと数えません。
'''
    (packet/'README.md').write_text(instructions)
    sections=[]
    for c in review_cases:
        excerpt={k:v for k,v in c.items() if k!='case_id'}
        sections.append('<section><h2>'+html.escape(c['case_id'])+'</h2><pre>'+html.escape(json.dumps(excerpt,ensure_ascii=False,indent=2))+'</pre></section>')
    page='<!doctype html><html lang="ja"><meta charset="utf-8"><title>独立確認用12件（未記入）</title><style>body{font:16px/1.65 sans-serif;max-width:1000px;margin:30px auto;padding:0 20px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f4f6f8;padding:18px}section{border-top:2px solid #678;margin-top:40px}@media print{section{break-before:page}}</style><h1>判定と根拠の独立確認用資料</h1><p>実施状況：未実施。判定欄は空欄です。README.mdを先に読み、CSVに記入してください。原本そのものではなく著者が作成した抜粋です。</p>'+''.join(sections)+'</html>'
    (packet/'review.html').write_text(page)
    write_json(packet/'MANIFEST.json',{'files':{p.name:sha256(p) for p in sorted(packet.iterdir()) if p.is_file()},'completed_reviews':0,'new_device_trials':0})
    (out/'REQUEST_REVIEW.md').write_text('''# 教員・同期に渡す依頼文案

以下は手動で内容を確認して送るための文案です。こちらから他の人へ送信していません。

開発意図と静的・動的解析を照合する卒論草稿について、対象範囲とAI利用の開示方法をご確認いただきたいです。
主評価は自作3 APKを各3回実行した規則の動作確認で、一般精度を主張していません。
可能であれば、添付のreviewer-packetにある12件の既存記録について、判定と根拠の対応を独立にご確認いただけますか。
新しい端末実験はなく、30〜60分程度を想定しています。原本が必要な場合や根拠不足の箇所は、その旨を記録いただければ十分です。
判定欄は未記入にしており、記入後までシステム出力は伏せています。ご協力が難しい場合も、独立確認未実施の制約を残して報告します。
''')
    print(json.dumps({'cases':12,'completed_reviews':0,'new_device_trials':0,'reviewer_folder':str(packet)}))


if __name__=='__main__':main()
