#!/usr/bin/env python3
"""Record visible subscription state around the pinned RSS v1 pilot.

No app-data clearing, subscription changes or package modification. The user
opens Subscriptions before starting; one post-capture answer records additional
manual input without pretending it is an objective input-event trace.
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime,timezone
from pathlib import Path

from defusedxml.ElementTree import fromstring

PACKAGE='de.danoeh.antennapod'
APK_SHA='6e79f28f69cef1a8b2e4f5f88c9c3cf3c3d7c51356f01394ac23b0dc5d56a00b'


def now():return datetime.now(timezone.utc).isoformat()
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def write(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def validate(project,assets,rss_tools,apk,name):
    project,assets,rss_tools,apk=map(lambda p:Path(p).resolve(),(project,assets,rss_tools,apk))
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',name):raise ValueError('Select a simple new trial name')
    if not (project/'src/apk_audit/pipeline.py').is_file():raise ValueError('Specify the existing project folder')
    manifest=read(assets/'WRAPPER-MANIFEST.json')
    if digest(assets/'run_preview.py')!=manifest['wrapper_sha256']:raise ValueError('Wrapper hash differs')
    for file,sha in manifest['rss_helper_files'].items():
        if file not in ('run_rss.py','run_public_pilot.py','check_public_pilot.py','PATCH-MANIFEST.json'):raise ValueError('Unsupported helper name')
        if not (rss_tools/file).is_file() or digest(rss_tools/file)!=sha:raise ValueError('Use the unchanged antennapod-rss-preview-v1 folder: '+file)
    patch=read(rss_tools/'PATCH-MANIFEST.json')
    for file,value in patch['modules'].items():
        if file not in ('capture.py','contracts.py','automatic.py','pipeline.py'):raise ValueError('Unsupported patch module')
        if digest(project/'src/apk_audit'/file)!=value['fixed_sha256']:raise ValueError('Apply the previously provided RSS preparation patch first: '+file)
    if not apk.is_file() or digest(apk)!=APK_SHA:raise ValueError('Use the unchanged AntennaPod 3.12.3 APK')
    out=project/'runs'/name;context=project/'handoff'/(name+'-context')
    if any(p.exists() for p in (out,project/'handoff'/name,context,out.with_suffix('.zip'),out.with_suffix('.capture-only.zip'))):
        raise ValueError('Trial name exists; preserve it and choose a new name')
    return out,context


def inspect_subscription_ui(raw):
    text=raw.decode('utf-8',errors='strict');start=text.find('<?xml');end=text.rfind('</hierarchy>')
    if start<0 or end<start:raise ValueError('UI hierarchy unavailable')
    tree=fromstring(text[start:end+len('</hierarchy>')])
    nodes=list(tree.iter('node'))
    selected=any(n.get('resource-id')==PACKAGE+':id/bottom_navigation_subscriptions' and n.get('selected')=='true' for n in nodes)
    if not selected:raise ValueError('Open AntennaPod and select Subscriptions before running; no capture started')
    return {'selected_subscriptions_tab':True,'observation_scope':'visible UI only; not a complete database or subscription count',
            'visible_text':[n.get('text') for n in nodes if n.get('text')],
            'fresh_empty_state_claimed':False,'app_data_changed_by_wrapper':False}


def snapshot(context,serial):
    def adb(*args):
        r=subprocess.run(['adb','-s',serial,*args],capture_output=True,timeout=25)
        if r.returncode:raise ValueError('ADB state recording failed: '+r.stderr.decode(errors='replace')[-500:])
        return r.stdout
    foreground=adb('shell','dumpsys','activity','activities')
    lines=[s for s in foreground.decode(errors='replace').splitlines() if 'mResumedActivity' in s or 'topResumedActivity' in s]
    if not any(PACKAGE+'/' in s for s in lines):raise ValueError('Bring AntennaPod Subscriptions to the foreground first')
    raw=adb('exec-out','uiautomator','dump','/dev/tty');state=inspect_subscription_ui(raw)
    image=adb('exec-out','screencap','-p')
    if not image.startswith(b'\x89PNG') or len(image)>16*1024**2:raise ValueError('Before-capture screenshot unavailable')
    (context/'before-ui.txt').write_bytes(raw);(context/'before-screen.png').write_bytes(image)
    (context/'before-foreground.txt').write_text('\n'.join(lines)+'\n')
    state.update(recorded_utc=now(),serial=serial)
    write(context/'before-state.json',state)


def record_answer(answer):
    values={'0':False,'1':True,'2':None}
    if answer not in values:raise ValueError('Use 0, 1 or 2')
    return {'recorded_utc':now(),'basis':'experimenter_self_report_after_capture',
            'additional_manual_actions_reported':values[answer],
            'no_extra_actions_objectively_proven':False,
            'interpretation':'Consent to PCAPdroid/VPN is allowed. Report app taps, subscription, playback or navigation during the observation window. A no-action answer is self-report, not an input-event trace.'}


def preserve_capture_zip(out):
    current=out.with_suffix('.zip');backup=out.with_suffix('.capture-only.zip')
    if not current.is_file():raise ValueError('Original result ZIP is missing; preserve the result folder for review')
    # Link creation is exclusive. The original bytes survive under the backup
    # name even if creation of the final augmented ZIP subsequently fails.
    original_sha=digest(current);os.link(current,backup);current.unlink()
    return backup,original_sha


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--apk',type=Path,required=True)
    parser.add_argument('--project',type=Path,default=Path.cwd());parser.add_argument('--rss-tools',type=Path)
    parser.add_argument('--out-name',default='antennapod-rss-preview-002');parser.add_argument('--prepare-only',action='store_true');args=parser.parse_args()
    project=args.project.resolve();assets=Path(__file__).resolve().parent
    rss_tools=args.rss_tools.resolve() if args.rss_tools else assets.parent/'antennapod-rss-preview-v1'
    out,context=validate(project,assets,rss_tools,args.apk,args.out_name);context.mkdir(parents=True)
    plan={'prepared_utc':now(),'scope':'state_recorded_exploratory_preview_not_formal_evaluation',
          'initial_state':'preserved; visible Subscriptions snapshot; no clearing, unsubscription or fresh-state claim',
          'apk_sha256':APK_SHA,'trial_id':args.out_name,'wrapper_sha256':digest(assets/'run_preview.py'),
          'intended_observation':'launch 5 seconds, URI preview 60 seconds; no extra target-app input',
          'legacy_rss_release_sha256':read(assets/'WRAPPER-MANIFEST.json')['rss_bundle_sha256']}
    write(context/'wrapper-plan.json',plan);shutil.copyfile(assets/'run_preview.py',context/'wrapper-source.py')
    if args.prepare_only:
        print(json.dumps({'status':'prepared_only_no_android_actions','context':str(context)},ensure_ascii=False));return 0
    try:snapshot(context,'emulator-5554')
    except (OSError,ValueError,subprocess.SubprocessError) as exc:
        write(context/'preparation-error.json',{'error':str(exc),'capture_started_by_wrapper':False})
        print(str(exc));print('記録先: '+str(context));return 4
    write(context/'BEFORE-MANIFEST.json',{'files':{p.name:digest(p) for p in context.iterdir() if p.is_file()},
                                         'recorded_utc':now(),'basis':'local preparation record; not third-party preregistration'})
    sys.path.insert(0,str(rss_tools))
    from run_public_pilot import run_analysis
    print('開始前の購読一覧を保存しました。既存データは保持します。観測中はアプリに追加操作をせず、同意画面だけ確認してください。',flush=True)
    code,interruption=run_analysis([sys.executable,str(rss_tools/'run_rss.py'),'--project',str(project),'--apk',str(args.apk.resolve()),'--out-name',args.out_name],project,{**os.environ,'PYTHONPATH':str(project/'src')})
    if not (out/'run.json').is_file() or not out.with_suffix('.zip').is_file():
        write(context/'child-result.json',{'returncode':code,'interruption':interruption,'final_result_zip_available':False})
        print('解析フォルダ・handoffと表示内容を保存してください。取得状態不明ならPCAPdroidも確認してください。');return code or 4
    answer='2'
    if sys.stdin.isatty() and not interruption:
        try:
            answer=input('観測中のアプリ追加操作：0=なし、1=あり、2=不明。数字を入力してEnter: ').strip()
            if answer not in ('0','1','2'):answer='2'
        except (EOFError,KeyboardInterrupt):answer='2'
    report=record_answer(answer);write(context/'experimenter-report.json',report)
    write(context/'wrapper-result.json',{'returncode':code,'interruption':interruption,'completed_utc':now()})
    shutil.copytree(context,out/'raw/operator-context')
    backup,original_sha=preserve_capture_zip(out)
    write(out/'operator-context-summary.json',{'capture_only_zip':backup.name,'capture_only_zip_sha256':original_sha,
          'scope':'exploratory_preserved_subscription_state','operator_report':report,
          'no_intervention_claim':'self-report only; not objective proof','legacy_capture_acceptance_preserved':True})
    packaged=subprocess.run([sys.executable,str(project/'tools/package_automatic_result.py'),'--run',str(out)],cwd=project)
    if packaged.returncode==0 and out.with_suffix('.zip').is_file():print('返却するZIP: '+str(out.with_suffix('.zip')))
    else:print('最終ZIPの作成に失敗しました。保存した取得ZIPと結果フォルダを保持してください。')
    print('最初の取得ZIPも保存: '+str(backup))
    return 0 if code==0 and packaged.returncode==0 and not interruption else 4


if __name__=='__main__':raise SystemExit(main())
