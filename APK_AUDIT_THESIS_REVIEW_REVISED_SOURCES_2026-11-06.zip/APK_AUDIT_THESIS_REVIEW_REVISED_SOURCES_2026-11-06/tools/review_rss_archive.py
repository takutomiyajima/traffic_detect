#!/usr/bin/env python3
"""Review the first controlled RSS pilot offline; never execute uploaded code.

Uses the authenticated published release, raw UID assertions and saved clock
brackets. This is a case review, not a live device or general accuracy claim.
"""
import argparse
import copy
import hashlib
import json
import re
import shutil
import sys
import zipfile
from collections import Counter
from pathlib import Path
from urllib.parse import urlsplit
from defusedxml.ElementTree import fromstring

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'tools'))
from apk_audit.core import read_json,read_jsonl,sha256,timestamp,write_json
from apk_audit.compare import compare
from apk_audit.differential import build
from apk_audit.pcapdroid import extended_pcap_flows
from review_automatic_archive import inspect_archive,known_code,packet_headers,require
from run_antennapod_rss_pilot import check_rss,PACKAGE,APK_HASH

RSS_BUNDLE_SHA='f66bc23db87db8aa796b52f9d77e390f17eab7098866433e87b1d953d658e964'
STATE_BUNDLE_SHA='ad4eea3d5a8699e96cb064cfac9649f640cbad626754b662e724e76e5364fc1d'
# A separately identified, additive renderer version. These are reviewer-side
# hashes, never substituted for the original capture's recorded code manifest.
DIFFERENCE_EXTENSION_SHA={
    'differential.py':'d0f1b175a5ec2ab79ae7c584f97df5103a5006fd1ba1bfe76576e6e5ef527e18',
    'explanation.py':'e7d2d55f68bd77c5713f9bc7e6cfd6273b4aee5602a66ef5eabfdebab39cbf91',
}

# Separate reviewer version for the explicit 1.1 intent extension. Legacy 1.0
# outputs keep their original schema/rules; capture/parser hashes stay pinned.
INTENT_EXTENSION_SHA = {'contracts.py': 'c5eef56693a8ccf94b321898a96d201456f890e50f0b6fa4c14158c478f5ce09', 'compare.py': 'b9198daf7be3989009734071a0de851b1121bc56eace7c23d3a630da7a7d9092', 'pipeline.py': '66ce1263cbca04213b17d9e14d1b29fec12dc7266da7d2e39be85e31544511b7', 'differential.py': '3919d119df743be4a4f0144f43a07d9caf51fb37592750a9aae64b484b8b0356', 'intent_extensions.py': 'c4d6003ad944ebe7d3f0613f3afe41aa12e60a0c32ff8364053544be75af2030', 'intent_overview.py': '9424e524fea39231eec8312ce8b621d925e56e611f360f857fe2fb8672ee6796'}


def active_review_profile(expected, root=None):
    source=(root or ROOT)/'src/apk_audit'
    def matches(files):
        return all((source/name).is_file() and sha256(source/name)==digest for name,digest in files.items())
    if matches(expected):
        return 'pinned-rss-release'
    versioned={**expected,**DIFFERENCE_EXTENSION_SHA}
    if matches(versioned):
        return 'pinned-rss-release-with-additive-difference-explanation-v1'
    require(INTENT_EXTENSION_SHA and matches({**versioned,**INTENT_EXTENSION_SHA}),
            'Active parser/rules differ from known review versions; use a versioned review')
    return 'pinned-rss-release-with-intent-audit-v1-legacy-policy-path'


def trusted_release():
    expected=known_code()
    path=ROOT/'dist/antennapod-rss-preview-v1.zip'
    require(sha256(path)==RSS_BUNDLE_SHA,'Unexpected local RSS distribution')
    with zipfile.ZipFile(path) as z:
        prefix='antennapod-rss-preview-v1/'
        manifest=json.loads(z.read(prefix+'BUNDLE-MANIFEST.json'))
        for name,digest in manifest['files'].items():
            require(hashlib.sha256(z.read(prefix+name)).hexdigest()==digest,'RSS bundle manifest differs')
        patch=json.loads(z.read(prefix+'PATCH-MANIFEST.json'))
        for name,record in patch['modules'].items():
            require(expected[name]==record['original_sha256'],'RSS patch base differs')
            expected[name]=record['fixed_sha256']
        helper_hashes={name:hashlib.sha256(z.read(prefix+name)).hexdigest()
                       for name in ('run_rss.py','run_public_pilot.py','check_public_pilot.py','PATCH-MANIFEST.json')}
    active_review_profile(expected)
    return expected,helper_hashes


def validate_plan(original,spec,run,helper_hashes):
    prepared=Path(original)/'raw/rss-preparation'
    uri=urlsplit(spec['rss_url']);port=spec['rss_port']
    require(type(port) is int and 1<=port<=65535 and uri.scheme=='http' and uri.hostname=='10.0.2.2'
            and uri.port==port and uri.path==spec['rss_path'] and not uri.query and not uri.fragment
            and uri.username is None and uri.password is None,'RSS endpoint differs from the local pilot')
    require(re.fullmatch(r'/feed/[a-f0-9]{32}\.xml',uri.path),'RSS nonce path invalid')
    nonce=uri.path.removeprefix('/feed/').removesuffix('.xml')
    require(spec['rss_title']=='APK Audit Research Feed '+nonce[:8],'RSS title differs from the frozen nonce')
    require(spec['package']==PACKAGE and spec['apk_sha256']==APK_HASH and spec['serial']=='emulator-5554'
            and spec['pilot_id']=='antennapod-controlled-rss-preview-pilot-v1' and spec['observe_s']==5,'Unsupported RSS pilot identity')
    expected={'schema_version':'1.0','scenario_id':'antennapod-3.12.3-controlled-rss-preview-pilot-v1',
              'execution':'automatic','repetitions':1,'steps':[
                  {'id':'launch','action':'launch','observe_s':5},
                  {'id':'rss-preview','action':'open_uri','uri':spec['rss_url'],
                   'activity':PACKAGE+'/.ui.screen.onlinefeedview.OnlineFeedViewActivity','observe_s':60,
                   'expect_resource_id':PACKAGE+':id/fragmentContainer'}]}
    require(spec['scenario']==read_json(prepared/'scenario.json')==run['analysis_scenario']==expected,'Planned scenario differs')
    require(read_json(prepared/'intent.json')==read_json(Path(original)/'intent.json'),'Research policy changed after preparation')
    require(timestamp(spec['local_prepared_utc'])<=timestamp(run['created_utc']),'Preparation does not predate this run')
    require(sha256(prepared/'feed.xml')==spec['rss_body_sha256'],'Frozen feed body differs')
    require(fromstring((prepared/'feed.xml').read_bytes()).findtext('channel/title')==spec['rss_title'],'Frozen XML title differs')
    names={'scenario.json','intent.json','rss-spec.json','feed.xml','sample.wav',*helper_hashes}
    manifest=read_json(prepared/'PREPARED-MANIFEST.json')['files']
    require(set(manifest)==names,'Unexpected preparation inventory')
    for name,digest in manifest.items():require(sha256(prepared/name)==digest,'Frozen preparation changed: '+name)
    for name,digest in helper_hashes.items():require(sha256(prepared/name)==digest,'Prepared helper differs from the published release')


def clock_interval(meta,samples):
    require(len(samples)==2,'Expected two clock brackets')
    for c in samples:
        require(re.fullmatch(r'\d{10,}\.\d{1,9}',c['device']),'Invalid device clock format')
        device=float(c['device']);quantum=10**-len(c['device'].split('.')[1])
        require(c['host_before']<=c['host_after'] and abs(c['offset_lower_s']-(c['host_before']-device-quantum))<1e-6
                and abs(c['offset_upper_s']-(c['host_after']-device))<1e-6,'Clock calculation differs')
    lower=max(c['offset_lower_s'] for c in samples);upper=min(c['offset_upper_s'] for c in samples)
    require(lower<=upper and meta['clock_offset_interval_s']==[lower,upper] and meta['clock_offset_s']==(lower+upper)/2,'Clock interval differs')
    return lower,upper


def planned_intervals(spec,events):
    if len(events)!=len(spec['scenario']['steps']):return False
    previous=None
    for step,event in zip(spec['scenario']['steps'],events):
        if event.get('event_id')!=step['id'] or event.get('action')!=step['action'] or not event.get('success'):return False
        start,end=timestamp(event['started_utc']),timestamp(event['ended_utc'])
        if end-start<step['observe_s'] or (previous is not None and start<previous):return False
        if step['action']=='open_uri' and event.get('uri')!=step['uri']:return False
        previous=end
    return True


def uid_disagreements(flows,packets,target_uid):
    by_number={p['packet']:p['uid'] for p in packets};differences=[]
    for flow in flows:
        owners={by_number[n] for n in flow['source_record']['packet_numbers']}
        expected_uid=next(iter(owners)) if len(owners)==1 and None not in owners else None
        expected_owner='unknown' if expected_uid is None else 'target' if expected_uid==target_uid else 'other'
        if flow.get('uid')!=expected_uid or flow.get('attribution')!=expected_owner:
            differences.append({'flow_id':flow['flow_id'],'raw_uid_consensus':expected_uid,
                                'recorded_uid':flow.get('uid'),'expected_attribution':expected_owner,
                                'recorded_attribution':flow.get('attribution')})
    return differences


def operator_context(original,run,trial_id):
    context=Path(original)/'raw/operator-context'
    if not context.exists():return None
    bundle=ROOT/'dist/antennapod-preview-state-v1.zip'
    require(sha256(bundle)==STATE_BUNDLE_SHA,'Unexpected state-recording distribution')
    with zipfile.ZipFile(bundle) as z:
        expected=hashlib.sha256(z.read('antennapod-preview-state-v1/run_preview.py')).hexdigest()
    plan=read_json(context/'wrapper-plan.json');state=read_json(context/'before-state.json')
    manifest=read_json(context/'BEFORE-MANIFEST.json');report=read_json(context/'experimenter-report.json')
    require(plan['wrapper_sha256']==expected==sha256(context/'wrapper-source.py'),'State recorder differs from pinned release')
    require(plan['apk_sha256']==run['apk_sha256'] and plan['trial_id']==trial_id,'State-recorded identity differs')
    names={'wrapper-plan.json','wrapper-source.py','before-ui.txt','before-screen.png','before-foreground.txt','before-state.json'}
    require(set(manifest['files'])==names,'Before-state inventory differs')
    for name,digest in manifest['files'].items():require(sha256(context/name)==digest,'Before-state file changed')
    from run_state_recorded_preview import inspect_subscription_ui
    parsed=inspect_subscription_ui((context/'before-ui.txt').read_bytes())
    require(all(state.get(k)==v for k,v in parsed.items()),'Visible subscription state differs from saved XML')
    require(timestamp(plan['prepared_utc'])<=timestamp(state['recorded_utc'])<=timestamp(manifest['recorded_utc'])<=timestamp(run['created_utc']),
            'Before-state recording does not precede the analysis run')
    require(timestamp(report['recorded_utc'])>=timestamp(run['ended_utc']),'Operator report is not after capture')
    extra=report['additional_manual_actions_reported']
    require((extra is None or type(extra) is bool) and report['no_extra_actions_objectively_proven'] is False
            and report['basis']=='experimenter_self_report_after_capture','Unsupported operator report semantics')
    return {'before_state_verified':True,'initial_state':'preserved; visible subscription list only',
            'fresh_empty_state_claimed':False,'additional_manual_actions_reported':extra,
            'operator_action_status':'unknown' if extra is None else 'extra_actions_reported' if extra else 'no_extra_actions_self_reported',
            'no_extra_actions_objectively_proven':False,
            'capture_only_zip_digest_basis':'Recorded by wrapper; sibling capture-only ZIP not independently received',
            'limitations':'Visible UI and post-capture self-report do not prove a complete subscription database or absence of all manual input.'}


def review(archive,out):
    archive,out=Path(archive),Path(out)
    require(not out.exists(),'Review directory exists; preserve the old result')
    prefix,manifest=inspect_archive(archive)
    out.mkdir(parents=True);original=out/'original';original.mkdir()
    with zipfile.ZipFile(archive) as z:
        for name in z.namelist():
            path=original/name.removeprefix(prefix);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(z.read(name))
    checks={'result_manifest_hashes':True};run=read_json(original/'run.json')
    require(run['apk_sha256']==APK_HASH==sha256(original/'raw/original.apk') and run['package']==PACKAGE,'Unexpected original APK')
    checks['unchanged_known_public_apk']=True
    expected,helpers=trusted_release();code=read_json(original/'raw/analysis-code-manifest.json')
    require(sha256(original/'raw/analysis-code-manifest.json')==run['analysis_code_manifest_sha256'] and code['files']==expected,'Recorded code differs from the published RSS release')
    checks['published_code_manifest']=True
    for record in read_json(original/'evidence/index.json').values():
        path=(original/record['path']).resolve()
        require(path.is_relative_to(original.resolve()) and path.is_file() and sha256(path)==record['sha256'],'Source evidence differs')
    checks['source_evidence_hashes']=True
    spec=read_json(original/'raw/rss-preparation/rss-spec.json')
    validate_plan(original,spec,run,helpers);checks['frozen_plan_and_helpers']=True
    events=[e for _,e in read_jsonl(original/'ui_events.jsonl')]
    checks['both_planned_observation_intervals']=planned_intervals(spec,events)
    server=[r for _,r in read_jsonl(original/'raw/rss-server-events.jsonl')]
    acceptance=check_rss(original,spec,server)
    saved=read_json(original/'rss-preview-acceptance.json')
    facts=('acceptance_profile','scope','status','checks','target_flow_count','total_flow_count','unknown_attribution_count',
           'failed_evidence_ids','dynamic_quality','rss_candidate_matches','evidence_references')
    checks['acceptance_facts_recomputed']=all(acceptance.get(k)==saved.get(k) for k in facts)
    details={};capture=original/'raw/automatic.pcap'
    if capture.exists() and (original/'automatic.metadata.json').exists():
        meta=read_json(original/'automatic.metadata.json')
        lower,upper=clock_interval(meta,read_json(original/'raw/clock-samples.json'))
        checks['clock_brackets_recomputed']=True
        checks['capture_copies_identical']=sha256(capture)==sha256(original/'raw/capture-1.pcap')
        headers,packets=packet_headers(capture,meta)
        flows=[f for _,f in read_jsonl(original/'flows.jsonl')]
        differences=uid_disagreements(flows,packets,run['target_uid'])
        checks['flow_uid_matches_raw_packet_consensus']=not differences
        parsed=list(extended_pcap_flows(capture,run,copy.deepcopy(meta)))
        checks['all_parser_flow_fields_reproduced']=len(parsed)==len(flows) and all(
            all(old.get(k)==v for k,v in new.items()) for old,new in zip(flows,parsed))
        trace=read_json(original/'raw/bridge-results.json');controls=[e for _,e in read_jsonl(original/'raw/automatic-controls.jsonl')]
        raw_controls=[]
        for probe in [e for e in trace if e['action']=='probe']:
            hits=[h for h in headers if h['method']=='GET' and h['path']=='/health' and h['uid']==run['bridge_uid']
                  and h['destination_ip']=='10.0.2.2' and h['destination_port']==run['control_port'] and h['run_marker']==probe['request_id']]
            received=[e for e in controls if e.get('event')=='http_request_received' and e.get('run_id')==probe['request_id']]
            if len(hits)==len(received)==1 and timestamp(probe['started_utc'])-(upper-lower)/2<=hits[0]['epoch']<=timestamp(probe['ended_utc'])+(upper-lower)/2:
                raw_controls.append({'request_packet':hits[0]['packet'],'request_id':probe['request_id'],'server_event_id':received[0]['event_id']})
        checks['two_raw_nonce_and_server_controls']=len(raw_controls)==2 and len({r['request_id'] for r in raw_controls})==2
        stopped=[e['result'] for e in trace if e['action']=='stop' and 'result' in e]
        checks['packet_count_matches_stop_stats']=len(stopped)==1 and len(packets)==stopped[0]['pkts_sent']+stopped[0]['pkts_rcvd']
        # Compare against an already verified same-APK static result. This is
        # not falsely described as a new independent static-analysis run.
        expected_static=read_json(ROOT/'runs/antennapod-launch-001-reviewed-final-2026-11-03/original/static.json')
        actual_static=read_json(original/'static.json')
        for d in (expected_static,actual_static):d.pop('analysis_duration_s',None)
        checks['same_apk_static_matches_previous_verified_result']=expected_static==actual_static
        replay=out/'analysis-copy';shutil.copytree(original,replay)
        findings=compare(replay,read_json(original/'intent.json'))
        correspondence=build(replay)
        checks['policy_findings_recomputed']=findings['findings']==read_json(original/'findings.json')['findings']
        checks['correspondence_recomputed']=all(correspondence[k]==read_json(original/'correspondence.json')[k]
                                               for k in ('counts','records','flow_counts','static_candidate_counts'))
        details={'capture_packets':len(packets),'raw_uid_counts':dict(Counter(p['uid'] for p in packets)),
                 'normalized_flows':len(flows),'uid_disagreements':differences,'raw_controls':raw_controls,
                 'clock_interval_s':[lower,upper],'correspondence_counts':correspondence['counts']}
    else:checks['raw_capture_available']=False
    ui=original/'raw/pilot-end-ui.txt';ui_text=ui.read_text(errors='replace') if ui.is_file() else ''
    context_result=operator_context(original,run,prefix.rstrip('/'))
    if context_result:checks['before_state_and_post_capture_operator_report']=True
    checks['received_files_unchanged']=all(sha256(original/name)==digest for name,digest in manifest['files'].items())
    result={'schema_version':'1.0','trial_id':prefix.rstrip('/'),'review_profile':'controlled-rss-offline-case-review-v1',
            'review_execution_profile':active_review_profile(expected),
            'archive_sha256':sha256(archive),'manifest_files':len(manifest['files']),'checks':checks,
            'status':'verified_controlled_rss_fetch' if all(checks.values()) and acceptance['status']=='passed_controlled_rss_fetch' else 'incomplete_or_needs_review',
            'rss_acceptance':acceptance,'raw_review':details,'saved_end_ui_contains_feed_title':spec['rss_title'] in ui_text,
            'operator_context':context_result,
            'analysis_script_sha256':sha256(Path(__file__)),
            'limitations':['No received Python code is executed. Data and code hashes are integrity checks, not cryptographic proof of the experimenter timeline.',
                           'UIDs remain collector assertions tied to recorded installation; no new live ADB identity check is available.',
                           'RSS/server correspondence remains a candidate with the saved nonce, time and NAT limitations.',
                           'Single-segment HTTP headers only; no complete TCP reconstruction or proof the app consumed the body.',
                           'End UI text presence is a supplementary snapshot, not full UI coverage or proof of all app functionality.',
                           'This offline review is not a new Android trial or independent population accuracy evaluation.']}
    write_json(out/'review.json',result)
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--archive',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    result=review(a.archive,a.out)
    print(json.dumps({'status':result['status'],'checks':result['checks'],'raw_review':result['raw_review'],
                      'saved_end_ui_contains_feed_title':result['saved_end_ui_contains_feed_title']},ensure_ascii=False,indent=2))
    return 0 if result['status']=='verified_controlled_rss_fetch' else 4


if __name__=='__main__':raise SystemExit(main())
