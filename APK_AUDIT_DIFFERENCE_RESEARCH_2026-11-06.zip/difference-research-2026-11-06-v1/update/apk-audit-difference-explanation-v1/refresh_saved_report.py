#!/usr/bin/env python3
"""Add the new explanation to a copy; no ADB, recapture or original edits."""
import argparse,hashlib,json,shutil,sys
from pathlib import Path

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fingerprint(folder):return {str(p.relative_to(folder)):sha(p) for p in folder.rglob('*') if p.is_file()}
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--project',type=Path,default=Path.home()/'Documents/apk-audit-unified-v1')
 p.add_argument('--run',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
 a=p.parse_args();project=a.project.expanduser().resolve();source=a.run.expanduser().resolve();dest=a.out.expanduser().resolve()
 if dest.exists() or dest.is_relative_to(source):raise ValueError('Choose a new output folder outside the original trial')
 if not all((source/name).is_file() for name in ['run.json','static.json','flows.jsonl','findings.json','evidence/index.json']):
  raise ValueError('Incomplete saved trial folder')
 sys.path.insert(0,str(project/'src'))
 from apk_audit.core import read_json,write_json
 from apk_audit.differential import build
 from apk_audit.explanation import PROFILE
 before=fingerprint(source)
 shutil.copytree(source,dest,ignore=shutil.ignore_patterns('*MANIFEST*'))
 run=read_json(dest/'run.json');run.update(analysis_mode='replay',explanation_refresh_only=True);write_json(dest/'run.json',run)
 result=build(dest)
 if before!=fingerprint(source):raise ValueError('Source changed during refresh; inspect it before using results')
 write_json(dest/'EXPLANATION-REFRESH-MANIFEST.json',{'profile':PROFILE,'new_device_trials':0,'source':str(source),
             'source_files_unchanged':True,'source_file_sha256':before,'counts':result['counts']})
 print('保存済み取得の説明を追加しました（新しい端末実験ではありません）。')
 print(dest/'summary.html')
if __name__=='__main__':main()
