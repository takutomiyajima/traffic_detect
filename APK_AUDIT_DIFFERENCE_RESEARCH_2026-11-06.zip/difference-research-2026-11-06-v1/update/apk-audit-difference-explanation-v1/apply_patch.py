#!/usr/bin/env python3
"""Install the known additive explanation renderer, preserving a local backup."""
import argparse,hashlib,json,shutil
from datetime import datetime
from pathlib import Path

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--project',type=Path,default=Path.home()/'Documents/apk-audit-unified-v1')
 a=p.parse_args();project=a.project.expanduser().resolve();bundle=Path(__file__).resolve().parent
 if not (project/'pyproject.toml').is_file() or not (project/'src/apk_audit').is_dir():
  raise ValueError('Project not found; specify --project with the existing project folder')
 manifest=json.loads((bundle/'PATCH-MANIFEST.json').read_text());changes=[]
 for name,record in manifest['modules'].items():
  payload=bundle/'payload'/name;target=project/'src/apk_audit'/name
  if sha(payload)!=record['fixed_sha256']:raise ValueError('Changed patch payload: '+name)
  if target.exists() and sha(target)==record['fixed_sha256']:continue
  if (target.exists() and sha(target)!=record['original_sha256']) or (not target.exists() and record['original_sha256']):
   raise ValueError('Different local source; nothing changed. Preserve local edits and report this file: '+str(target))
  changes.append((payload,target))
 if not changes:
  print('更新済みです。追加変更はありません。');return
 backup=project/'backups'/('difference-explanation-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
 backup.mkdir(parents=True)
 for payload,target in changes:
  if target.exists():shutil.copy2(target,backup/target.name)
  shutil.copy2(payload,target)
 (backup/'PATCH-MANIFEST.json').write_bytes((bundle/'PATCH-MANIFEST.json').read_bytes())
 print('差分説明機能を反映しました。元ファイルのバックアップ: '+str(backup))
 print('既存の実験フォルダやエミュレータは変更していません。')
if __name__=='__main__':main()
