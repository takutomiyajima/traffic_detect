# 静的・動的差分の説明機能 v1

2026年11月6日。今ある `apk-audit analyze` に説明欄を追加する更新です。
静的解析・通信取得の方式、ポリシー判定、過去の原本を変更しません。

## 何が増えるか

比較分類ごとに、確認事実、不足、未確認の原因候補、断定しないこと、原本参照を
分けてHTMLに表示します。JSONとCSVも出力します。原因を自動確定する機能では
ありません。URLパスやコードから送信へのデータフローの証明も行いません。

## Mac側へ反映

ZIP内の `apk-audit-difference-explanation-v1` をDocumentsへ置き、既存プロジェクトの
仮想環境を使うターミナルで次を実行します。

```sh
python "$HOME/Documents/apk-audit-difference-explanation-v1/apply_patch.py"
```

元のファイルをバックアップしてから2ファイルだけ反映します。既知の元版か更新済み版
以外は上書きせず停止します。実験結果は移動・削除しません。
別の場所へ設置した場合は `--project /プロジェクトの絶対パス` を付けます。

## まず既存のauto-http-002で確認（新しい端末実験は不要）

既存プロジェクトのフォルダから実行します。更新済みならapply_patchの再実行は不要です。

```sh
python "$HOME/Documents/apk-audit-difference-explanation-v1/refresh_saved_report.py" \
  --run runs/auto-http-002 --out runs/auto-http-002-explained-001
open runs/auto-http-002-explained-001/summary.html
```

元のフォルダをコピーして説明だけを追加します。すでに出力名がある場合は末尾の番号を
変えます。エミュレータ起動・VPN許可・通信取得・追加操作は行いません。

## 次回以降

通常の `apk-audit analyze` の出力にも、新しい説明欄と
`difference-explanation.json`、`difference-explanation.csv` が加わります。
今ある `summary.html` は勝手に更新されません。

## 検証範囲

クラウドで自動テスト250件が成功。既存25試行へ別作業先で適用し、訂正済みの分類件数と
原本を維持しました。Macの端末で新しく取得した結果や、独立した説明正解評価では
ありません。公開起動は訂正済みUID版を使いました。
