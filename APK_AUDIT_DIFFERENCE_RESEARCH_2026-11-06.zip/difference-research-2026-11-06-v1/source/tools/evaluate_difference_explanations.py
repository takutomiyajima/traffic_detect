#!/usr/bin/env python3
"""Apply the additive difference explanation to copies of the existing 25 trials.

No ADB, new device trials, root-cause oracle, or human labels are involved.
"""
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from apk_audit.core import read_json, sha256, write_json
from apk_audit.differential import build


def fingerprint(folder):
    return {str(p.relative_to(folder)): sha256(p) for p in sorted(folder.rglob("*")) if p.is_file()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT / "runs/difference-explanation-v2-2026-11-06")
    parser.add_argument("--tables", type=Path, default=ROOT / "docs/research/difference-study-v2-2026-11-06")
    args = parser.parse_args()
    if args.out.exists() or args.tables.exists():
        raise ValueError("Choose new output folders; previous analyses are preserved")
    design = read_json(ROOT / "docs/research/research-design-existing25-2026-11-05/existing25-synthesis.json")
    args.out.mkdir(parents=True)
    args.tables.mkdir(parents=True)
    rows, sources = [], []
    for trial in design["trials"]:
        trial_id = trial["trial_id"]
        source = ROOT / "runs/ai-all25-recheck-v3-2026-11-05" / trial_id
        if trial_id == "antennapod-launch-001":
            source = ROOT / "runs/antennapod-launch-001-reviewed-final-2026-11-03/replay-corrected"
        before = fingerprint(source)
        dest = args.out / trial_id
        # Old snapshot manifests describe old outputs. Keep them at the source,
        # and identify every copied source file in this analysis's own manifest.
        shutil.copytree(source, dest, ignore=shutil.ignore_patterns("*MANIFEST*"))
        state = read_json(dest / "run.json")
        state.update(analysis_mode="replay", explanation_refresh_only=True)
        write_json(dest / "run.json", state)
        result = build(dest)
        explanation = read_json(dest / "difference-explanation.json")
        assert result["counts"] == trial["correspondence"], trial_id
        assert explanation["status_counts"] == trial["correspondence"]
        assert len(explanation["records"]) == sum(result["counts"].values())
        source_index = read_json(dest / "evidence/index.json")
        for r in explanation["records"]:
            assert all(eid in source_index for eid in r["evidence_ids"])
            assert all("source_file" in f and "fields" in f for f in r["facts"])
            assert "unconfirmed_hypotheses" in r and "not_established" in r
        assert before == fingerprint(source), trial_id
        row = {"trial_id": trial_id, "cohort": trial["cohort"], "quality": trial["quality"],
               "static_endpoint_groups": explanation["units"]["static_endpoint_groups"],
               "target_flow_records": explanation["units"]["target_flow_records"],
               **result["counts"], "explanation_rows": len(explanation["records"]),
               "gap_codes": ", ".join(sorted(explanation["gap_row_counts"])),
               "counts_equal_previous_corrected_analysis": True,
               "source_files_unchanged": True}
        rows.append(row)
        sources.append({"trial_id": trial_id, "source": str(source.relative_to(ROOT)),
                        "files_before_and_after": before,
                        "explanation_sha256": sha256(dest / "difference-explanation.json")})
    with (args.tables / "difference-results-25.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    summary = {"date_jst": "2026-11-06", "kind": "retrospective_additive_explanation_evaluation",
               "device_trials_reused": len(rows), "new_device_trials": 0,
               "correspondence_counts_unchanged_trials": len(rows), "source_files_unchanged": True,
               "explanations_with_source_locators": True, "human_labels": 0,
               "independent_accuracy": None, "causes_independently_verified_by_this_script": False,
               "all_capture_quality": "partial", "public_app_count": 1,
               "trial_counts_by_correspondence_presence": {
                   key: sum(row[key] > 0 for row in rows) for key in ("both", "static_only", "dynamic_only", "indeterminate")},
               "parser_version_note": "Launch uses replay-corrected; known old UID defect is not reintroduced.",
               "limitations": ["Template field completeness is not semantic accuracy or reader understanding.",
                               "Rows from repeated trials are not independent app samples.",
                               "No request-to-code linkage or independently established root causes."]}
    write_json(args.tables / "summary.json", summary)
    write_json(args.out / "ANALYSIS-MANIFEST.json", {
        "new_device_trials": 0, "sources": sources,
        "code_sha256": {p: sha256(ROOT / p) for p in ["src/apk_audit/differential.py", "src/apk_audit/explanation.py", str(Path(__file__).relative_to(ROOT))]},
        "summary": summary})
    lines = [r"\subsection{静的・動的差分を中心とした再解析}",
             "既存25試行を新しい作業先へコピーし，対応表の各行に確認事実，不足情報，未確認の原因候補，"
             "断定しない事項と原本参照を付加した。公開起動は訂正済みUID版を使用した。"
             "25試行すべてで従来の訂正済み対応件数を維持し，参照原本も変更していない。"
             "これは説明形式と出典参照の実装確認であり，原因推定精度や利用者の理解向上の独立評価ではない。",
             r"\begin{longtable}{lrrrr}\caption{主要事例の差分分類。件数は対応表の行数であり，通信回数ではない。}\\",
             r"\toprule 事例 & 対応あり & 静的のみ & 動的のみ & 判断不能 \\\midrule\endfirsthead",
             r"\toprule 事例 & 対応あり & 静的のみ & 動的のみ & 判断不能 \\\midrule\endhead"]
    for row in rows:
        if row["trial_id"] in ("auto-http-002", "antennapod-launch-001", "antennapod-rss-preview-001", "antennapod-rss-preview-002", "antennapod-rss-preview-003", "antennapod-rss-preview-006"):
            label = row["trial_id"].replace("antennapod-rss-preview-", "RSS").replace("antennapod-launch-001", "公開アプリ起動").replace("auto-http-002", "自動HTTP")
            lines.append(label + " & " + " & ".join(str(row[k]) for k in ("both", "static_only", "dynamic_only", "indeterminate")) + r" \\")
    lines += [r"\bottomrule\end{longtable}",
              "自動HTTPでは静的2候補のうち1候補に対象通信が対応し，残る1候補は取得範囲で未対応だった。"
              "公開起動では候補38組がある一方，対象UIDの通信は未観測だった。RSS006は静的38組と対応しない"
              "実測2フローを得たが，2フローは1宛先の記録であり，静的38組との差を算術的に引く対象ではない。"
              "研究用URLが実行時に与えられた事実は保存シナリオで別途確認する。"
              "一般の動的のみ行に対して実行時入力が原因であると自動断定するものではない。"]
    (ROOT / "docs/generated/difference-study-results-2026-11-06.tex").write_text("\n".join(lines) + "\n")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
