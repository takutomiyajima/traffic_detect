"""Explanation must not turn possible causes or missing evidence into facts."""
import json

import pytest

from apk_audit.core import read_json, write_json, write_jsonl
from apk_audit.demo import demo
from apk_audit.differential import build


@pytest.fixture
def observed(tmp_path):
    out = tmp_path / "run"
    demo(out)
    static = read_json(out / "static.json")
    static["urls"] = [{"host": "telemetry.example.org", "port": 443, "scheme": "https",
                       "raw": "https://telemetry.example.org/", "location": {"file": "classes.dex"},
                       "evidence_ids": ["demo"]}]
    write_json(out / "static.json", static)
    return out


def change_flow(out, **values):
    flow = json.loads((out / "flows.jsonl").read_text())
    flow.update(values)
    write_jsonl(out / "flows.jsonl", [flow])


def explained(out):
    before = {p.name: p.read_bytes() for p in [out / "findings.json", out / "flows.jsonl", out / "static.json"]}
    correspondence = build(out)
    for name, data in before.items():
        assert (out / name).read_bytes() == data
    explanation = read_json(out / "difference-explanation.json")
    assert explanation["status_counts"] == correspondence["counts"]
    assert explanation["policy_verdicts_changed"] is False
    assert explanation["causal_inference"] is False
    for row in explanation["records"]:
        assert all(f["source_file"] and f["fields"] for f in row["facts"])
    return explanation


def test_correspondence_explains_endpoint_not_code_path(observed):
    result = explained(observed)
    row = result["records"][0]
    assert row["status"] == "both"
    assert not row["unconfirmed_hypotheses"]
    assert "コード上の送信箇所" in row["not_established"]
    assert row["facts"][1]["source_locations"] == [{"file": "classes.dex"}]
    assert "difference-explanation.json" in (observed / "summary.html").read_text()


def test_runtime_url_cause_remains_hypothesis(observed):
    change_flow(observed, host="runtime.example.org")
    rows = explained(observed)["records"]
    assert [r["status"] for r in rows] == ["static_only", "dynamic_only"]
    dynamic = rows[1]
    assert "実行時入力" in dynamic["unconfirmed_hypotheses"][0]
    assert not any("実行時入力" in f["text"] for f in dynamic["facts"])
    assert "不正通信" in dynamic["not_established"]


@pytest.mark.parametrize("updates,gap", [
    ({"attribution": "unknown", "uid": None}, "attribution_unresolved"),
    ({"host": None}, "hostname_unavailable"),
    ({"transport": "UDP", "host": None}, "transport_outside_matcher"),
])
def test_gaps_are_distinct_without_upgrading_observation(observed, updates, gap):
    change_flow(observed, **updates)
    result = explained(observed)
    rows = [r for r in result["records"] if r["status"] == "indeterminate"]
    assert rows and any(g["code"] == gap for r in rows for g in r["evidence_gaps"])
    assert all(r["not_established"].startswith("対象通信・無通信") for r in rows)


def test_unknown_literal_ip_does_not_require_hostname(observed):
    static = read_json(observed / "static.json")
    static["urls"][0]["host"] = "192.0.2.1"
    write_json(observed / "static.json", static)
    change_flow(observed, host=None, attribution="unknown", uid=None)
    first = explained(observed)["records"][0]
    assert [g["code"] for g in first["evidence_gaps"]] == ["attribution_unresolved"]


def test_failed_capture_is_not_static_only_absence(observed):
    state = read_json(observed / "run.json")
    state.update(dynamic_status="failed", captures=[])
    write_json(observed / "run.json", state)
    write_jsonl(observed / "flows.jsonl", [])
    row = explained(observed)["records"][0]
    assert row["status"] == "indeterminate"
    assert row["evidence_gaps"][0]["code"] == "capture_unavailable"


def test_html_does_not_execute_untrusted_endpoint(observed):
    change_flow(observed, host='<script>alert("x")</script>')
    explained(observed)
    text = (observed / "summary.html").read_text()
    assert "<script>" not in text
    assert "&lt;script&gt;" in text
