"""Evidence-preserving endpoint correspondence, separate from policy verdicts."""
from __future__ import annotations

import csv
import html
from collections import Counter
from pathlib import Path

from .core import AuditError, is_ip, read_json, read_jsonl, sha256, write_json
from .report import csv_safe

LABELS = {"both": "静的候補と動的観測が対応", "static_only": "静的候補のみ（取得範囲内）",
          "dynamic_only": "静的候補にない観測先（解析範囲内）", "indeterminate": "対応を判断できない"}
REFERENCE_URLS = {"http://schemas.android.com/apk/res/android", "http://schemas.android.com/apk/res-auto",
                  "http://schemas.android.com/aapt", "http://schemas.android.com/tools",
                  "http://www.w3.org/2001/XMLSchema", "http://www.w3.org/2001/XMLSchema-instance",
                  "http://www.w3.org/1999/XSL/Transform", "http://www.w3.org/2000/svg"}
VERDICTS = {"consistent_with_observed_evidence": "観測した証拠の範囲で整合", "mismatch_candidate": "ポリシーとの不一致候補",
            "needs_review": "ポリシー未指定・要確認", "not_evaluable": "判定不能"}


def corresponds(candidate, flow):
    if flow.get("observation") == "capture_failed" or flow.get("transport") != "TCP" or candidate["port"] != flow.get("port"):
        return False
    return (candidate["host"] == flow.get("destination_ip") if is_ip(candidate["host"])
            else candidate["host"] == flow.get("host"))


def could_correspond(candidate, flow):
    if candidate["port"] != flow.get("port") or flow.get("transport") != "TCP":
        return False
    if is_ip(candidate["host"]):
        return candidate["host"] == flow.get("destination_ip")
    return flow.get("host") in (None, candidate["host"])


def build(out):
    out = Path(out)
    run = read_json(out / "run.json")
    static = read_json(out / "static.json") if (out / "static.json").exists() else {}
    flows = [v for _, v in read_jsonl(out / "flows.jsonl")]
    groups, hints = {}, []
    for candidate in static.get("urls", []):
        if candidate.get("raw", "").rstrip("/") in REFERENCE_URLS:
            hints.append(candidate)
            continue
        key = (candidate["host"], candidate["port"])
        group = groups.setdefault(key, {"host": key[0], "port": key[1], "evidence_ids": [], "locations": [], "schemes": []})
        group["evidence_ids"] += candidate.get("evidence_ids", [])
        group["locations"].append(candidate.get("location"))
        group["schemes"].append(candidate.get("scheme"))
    target = [f for f in flows if f.get("attribution") == "target" and f.get("observation") != "capture_failed"]
    uncertain = [f for f in flows if f.get("attribution") in ("unknown", "related_candidate") or f.get("observation") == "capture_failed"]
    records, matched = [], set()
    usable = run.get("dynamic_status") in ("completed", "partial") and bool(run.get("captures"))
    for candidate in groups.values():
        hits = [f for f in target if corresponds(candidate, f)]
        possible = [f for f in target + uncertain if could_correspond(candidate, f) and f not in hits]
        if hits:
            status = "both"
            explanation = "APK内の宛先候補と対象UIDの通信先がホストまたは明示IP・ポートで対応しました。URLパス・送信目的・HTTPS成立はこの対応だけでは確認できません。"
        elif not usable or possible:
            status = "indeterminate"
            explanation = "取得が未実施・失敗したか、ホスト名またはアプリ帰属が不足して対応を確定できません。未観測とは区別します。"
        else:
            status = "static_only"
            explanation = "取得できた通信に対応先がありません。未操作の機能、実行条件、取得漏れもあり得るため、不要コードや通信なしとは断定できません。"
        matched.update(f["flow_id"] for f in hits)
        records.append({"status": status, "endpoint": f"{candidate['host']}:{candidate['port']}", "static": candidate,
                        "flows": [f["flow_id"] for f in hits + possible], "explanation": explanation,
                        "evidence_ids": sorted(set(candidate["evidence_ids"] + [e for f in hits + possible for e in f.get("evidence_ids", [])]))})
    for flow in target + uncertain:
        if flow["flow_id"] in matched:
            continue
        known = flow.get("host") or None
        status = "dynamic_only" if flow in target and known and run.get("static_status") == "completed" else "indeterminate"
        explanation = ("対象UIDの通信先を観測しましたが、抽出したURL文字列候補に対応先がありません。実行時生成、設定値、解析対象外のコードなどが候補であり、原因は未確定です。"
                       if status == "dynamic_only" else "UID・ホスト名・静的解析範囲のいずれかが不足しています。IPだけでドメインを推測したり、帰属不明を無通信・違反に置き換えたりしません。")
        records.append({"status": status, "endpoint": f"{known or flow['destination_ip']}:{flow['port']} ({flow['transport']})",
                        "flows": [flow["flow_id"]], "observation": flow["observation"], "attribution": flow["attribution"],
                        "explanation": explanation, "evidence_ids": flow.get("evidence_ids", [])})
    counts = {key: sum(r["status"] == key for r in records) for key in LABELS}
    result = {"schema_version": "1.0", "run_id": run["run_id"], "analysis_mode": run.get("analysis_mode", "existing_run"),
              "counts": counts, "records": records, "reference_hints": hints,
              "static_candidate_counts": {"raw_url_strings": len(static.get("urls", [])), "reference_hints": len(hints), "endpoint_groups": len(groups)},
              "flow_counts": dict(Counter(f.get("attribution", "unknown") for f in flows)),
              "limitations": ["Counts are correspondence rows, not independent apps, packets or network requests.",
                              "Static URL strings are candidates; runtime permission/API/SDK usage is not instrumented.",
                              "No DNS-IP guessing, payload decryption, cross-source merge or proof of absence."]}
    index = read_json(out / "evidence/index.json")
    for row in records:
        for eid in row["evidence_ids"]:
            evidence = index.get(eid)
            if not evidence:
                raise AuditError(f"Missing correspondence evidence: {eid}", 4)
            path = (out / evidence["path"]).resolve()
            if not path.is_relative_to(out.resolve()) or not path.is_file() or sha256(path) != evidence["sha256"]:
                raise AuditError(f"Modified correspondence evidence: {eid}", 4)
    write_json(out / "correspondence.json", result)
    with (out / "correspondence.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["分類", "宛先", "説明", "証拠ID"])
        for row in records:
            writer.writerow([csv_safe(v) for v in (LABELS[row["status"]], row["endpoint"], row["explanation"], row["evidence_ids"])])
    from .explanation import explain
    explanations = explain(out, result)
    _html(out, run, static, result, explanations)
    return result


def _html(out, run, static, result, explanations):
    from .explanation import html_section
    esc = lambda x: html.escape(str(x), quote=True)
    rows = []
    flow_index = {f['flow_id']: f for _, f in read_jsonl(out / 'flows.jsonl')}
    observations = {'connection_attempt': '通信試行', 'transport_established': 'TCP接続成立', 'tls_established': 'TLS成立', 'http_observed': 'HTTP要求を観測', 'capture_failed': '取得失敗'}
    owners = {'target': '対象UID', 'unknown': '帰属不明', 'related_candidate': '関連候補', 'other': '別UID'}
    for record in result["records"]:
        links = " ".join(f'<a href="report.html#e-{esc(e)}">{esc(e)}</a>' for e in record["evidence_ids"])
        facts = ' / '.join(owners.get(flow_index[f].get('attribution'), '帰属不明') + '・' + observations.get(flow_index[f].get('observation'), '観測段階不明') for f in record['flows'])
        rows.append(f'<tr><td>{LABELS[record["status"]]}</td><td>{esc(record["endpoint"])}<br>{esc(facts)}</td><td>{esc(record["explanation"])}</td><td>{links}</td></tr>')
    findings = read_json(out / "findings.json").get("findings", [])
    policy_counts = Counter(VERDICTS.get(f["verdict"], f["verdict"]) for f in findings)
    policy_text = "条件が未指定のため、違反かどうかの判定はしていません。" if run.get("intent_source") == "unspecified_default" else str(dict(policy_counts))
    mode = {"live": "エミュレータで新規取得", "replay": "保存済みログの再解析（新しい端末実験ではありません）", "static": "静的解析のみ"}.get(run.get("analysis_mode"), "既存の解析結果")
    counts = " / ".join(f"{LABELS[k]}: {v}" for k, v in result["counts"].items())
    permissions = ", ".join(p["name"] for p in static.get("permissions", [])) or "抽出なし"
    sdks = ", ".join(s["id"] for s in static.get("sdk_candidates", [])) or "候補なし"
    errors = " / ".join(str(e.get("message")) for e in run.get("errors", [])) or "記録なし"
    scenario = run.get("analysis_scenario", run.get("scenario", "取得時の操作記録を参照"))
    text = f'''<!doctype html><html lang="ja"><meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>APK 静的・動的比較</title>
<style>body{{font:16px/1.8 sans-serif;max-width:1200px;margin:2rem auto;padding:0 1rem;color:#152c3d}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #ccd4dd;padding:.7rem;text-align:left;overflow-wrap:anywhere}}th{{background:#edf3f7}}.note{{background:#fff3dc;padding:1rem}}pre{{white-space:pre-wrap;overflow-wrap:anywhere}}</style>
<h1>APKの静的解析と動的観測の比較</h1><p>{esc(run.get('package'))} / {esc(mode)}</p>
<p>静的解析: {esc(run['static_status'])} ／ 動的取得: {esc(run['dynamic_status'])} ／ 全体: {esc(run['run_status'])}</p>
<p class="note">この結果は実施した操作・取得範囲に限ります。通信が見えないことは通信しない証明ではありません。整合は安全性や送信目的の保証ではありません。</p>
<h2>比較の結果</h2><p>{esc(counts)}</p><p>件数は対応表の行数です。同じ通信が複数の候補の判断材料になるため、通信回数として合算しません。</p>
<table><tr><th>分類</th><th>宛先</th><th>分かったこと・分からないこと</th><th>根拠</th></tr>{''.join(rows)}</table>
<p>別UID・その他のフローも原本に保持します。帰属内訳: {esc(result['flow_counts'])}</p>
{html_section(explanations)}
<h2>宣言・静的候補</h2><p>権限宣言: {esc(permissions)}</p><p>SDK候補: {esc(sdks)}</p><p>抽出URL文字列 {result['static_candidate_counts']['raw_url_strings']} 件 ／ 既知の参照URL {len(result['reference_hints'])} 件 ／ 通信先候補の集約 {result['static_candidate_counts']['endpoint_groups']} 件。</p><p>これらは実行時の使用・送信を証明しません。名前空間等は別枠に保持し、<a href="static.json">静的結果の正本</a>から確認できます。候補が得られない場合も通信しないとは判定しません。</p>
<h2>任意のポリシーとの照合</h2><p>{esc(policy_text)}</p><p>ポリシーを省略した場合は未指定です。システムが開発者の意図を推定することはありません。<a href="report.html">規則別の詳細と証拠索引</a></p>
<h2>実施した操作と取得の状態</h2><pre>{esc(scenario)}</pre><p>エラー: {esc(errors)}</p>
<p>初期データ: {esc(run.get('initial_app_data', '取得時の記録を参照'))}。起動と待機だけではログイン後やボタン操作後の機能を網羅しません。必要な画面を操作するシナリオを追加して再実行してください。</p>
<p><a href="correspondence.json">対応表JSON</a> / <a href="correspondence.csv">対応表CSV</a> / <a href="run.json">条件と取得状態</a> / <a href="ui_events.jsonl">操作記録</a></p>
<p>このレポート一式には原本ログが含まれます。研究者用として扱ってください。</p></html>'''
    (out / "summary.html").write_text(text, encoding="utf-8")
