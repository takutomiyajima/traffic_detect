# 卒論を最初から学ぶ：目的・仕組み・仮説・実験・結論

初めてこの研究を知る人向けの学習資料です。作成日は2026年11月10日です。
実測の参照版は11月6日改訂の卒論で、新しい端末実験は行っていません。

## おすすめの読み方

1. `main.pdf` を読み、基礎→システム→研究設計→実験→結論の順に学びます。
2. `thesis-learning-slides.pdf` で図表と要点を振り返ります。
3. 説明や編集には `thesis-learning-slides.pptx` を使います。全42枚に詳しい発表者ノートがあります。
4. `question-and-answer.md` の問いに自分の言葉で答えます。

`learning-guide.md` は解説全文のテキスト版です。`lessons.json` に同じ42項目の
目標・解説・要点・問題・解答・表等を構造化して保存しています。

## 中身

- 通信、APK、静的解析、動的観測を基礎から説明。
- 意図JSON、シナリオ、UID、時計補正、7規則、差分、証拠追跡。
- 主評価3条件×3反復の9試行と、同じ原本の27再解析出力。
- 既存29試行の制御HTTP/UDP/通信なし/処理不成功/専用信頼HTTPS、自動HTTP、
  AntennaPodの起動・RSS・URI切替の目的・方法・結果。
- 静的文脈29箇所、開発用の静的素材、権限素材、先行研究と結論。
- 学習用の期待出力の説明と、実ランナーの入力依存／非依存仮説を区別。

## データと単位

`primary-nine-trials.csv` は主評価9件、`historical-29-summary.csv` は補助29件の集計です。
9+29=38は端末試行数であり、独立した38アプリや同一の精度標本ではありません。
27は再解析出力数です。対象記録ありと不明候補ありは、同一試行内で重複できます。
独立確認12件は準備のみ、実施済み0として記載しています。

## 編集と再コンパイル

PPTXの本文・図形・表は編集可能です。フォントはNoto Sans CJK JPです。
TeX版は、このフォルダで以下を2回実行します。

```sh
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
```

Noto Serif CJK JP、Noto Sans CJK JP、DejaVu Sans Monoのフォントと、
TikZ・fontspec・tabularx・hyperref等のTeXパッケージが必要です。
PDFは固定表示、PPTXは環境のフォントによって折返しが変わる場合があります。

## 確認範囲

この資料は研究内容の解説で、被験者による理解度の検証や新しい精度実験ではありません。
本文の根拠は `SOURCE-MANIFEST.json`、生成物の確認は `QUALITY-CHECK.json` を参照してください。
通信なし・安全・漏えいなしを自動認証するツールではありません。
AIを用いて学習資料を作成しました。端末実験は著者本人が実行した記録を参照しています。
生PCAP、原APK、実際のnonce/token、個人情報を含む画面は同梱しません。
今回のスライドは独自の白背景レイアウトで作成しています。

## 実験一覧と関連資料

`EXPERIMENT-ATLAS.md` は、主評価・補助群・静的確認・事後比較を
「何を確かめるか／方法／結果と解釈」の一覧で振り返る資料です。

- [卒論草稿（11月6日改訂）](https://github.com/takutomiyajima/traffic_detect/raw/c752fcb9cc440dd56948d8a1c909a9d9d781b7f4/APK_AUDIT_THESIS_REVIEW_REVISED_2026-11-06.pdf)
- [プログラムの仕組み・実装解説（11月9日）](https://github.com/takutomiyajima/traffic_detect/raw/82060b5e273f0e5274aaae139f75310247cc31db/APK_AUDIT_PROGRAM_MECHANISM_2026-11-09.pdf)
