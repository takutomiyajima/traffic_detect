#!/usr/bin/env python3
"""Build final cohort tables and claim boundaries from existing verified data.

This is a secondary analysis of saved reviews, not a new device experiment.
"""
from collections import Counter, defaultdict
from pathlib import Path
import csv
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs/research/review-revision-2026-11-06'


def main():
    sources = {
        'existing25': ROOT / 'docs/research/research-design-existing25-2026-11-05/existing25-synthesis.json',
        'contrast4': ROOT / 'docs/research/diagnostic-ab002-verified-2026-11-06/review-summary.json',
        'context': ROOT / 'runs/diagnostic-ab-002-reviewed-2026-11-06/original/context.json',
    }
    old, new, ctx = [json.loads(sources[key].read_text()) for key in ('existing25', 'contrast4', 'context')]
    assert len(old['trials']) == 25 and len(new['rows']) == 4
    assert len({x['trial_id'] for x in old['trials']}) == 25
    assert new['all_selected_controls_and_requests_verified']
    assert new['all_saved_diagnosis_fields_reproduced']
    assert Counter(r['status'] for r in ctx['records']) == ctx['counts']
    origin_sites = sum(bool(r.get('runtime_origins')) for r in ctx['records'])
    assert origin_sites == 0, 'Reassess the text if runtime provenance is added'
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for r in old['trials']:
        rows.append({'trial_id': r['trial_id'], 'group': 'existing25', 'condition': r['case'],
                     'target_record_present': int(r['target_record_present']),
                     'unknown_candidate_present': int(r['unknown_candidate_present']), 'quality': r['quality']})
    for r in new['rows']:
        rows.append({'trial_id': 'diagnostic-ab-002/' + r['trial_id'], 'group': 'contrast4',
                     'condition': 'uri_contrast', 'target_record_present': int(r['target_flows'] > 0),
                     'unknown_candidate_present': int(r['unknown_flows'] > 0), 'quality': r['quality']})
    assert len(rows) == len({r['trial_id'] for r in rows}) == 29
    with (OUT / 'final29-trials.csv').open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    groups = defaultdict(list)
    for r in rows:
        groups[r['condition']].append(r)
    names = {'http':'HTTP・CSV', 'offline':'通信なし条件・CSV', 'udp':'短時間UDP・CSV',
             'udp_hold':'保持UDP・CSV', 'http_fail':'HTTP処理不成功・CSV', 'https':'専用信頼HTTPS・CSV',
             'http_control':'自動HTTP・PCAP', 'public_launch_only':'公開アプリ起動',
             'rss_subscription_playback_exploratory':'RSS・購読再生等の追加操作',
             'rss_preview':'RSSプレビュー', 'uri_contrast':'URI切替（追加群）'}
    lines = []
    for key, rs in groups.items():
        lines.append(f"{names[key]} & {len(rs)} & {sum(r['target_record_present'] for r in rs)} & "
                     f"{sum(r['unknown_candidate_present'] for r in rs)} \\\\")
    tex = r'''\subsection{最終データ構成}\label{sec:final-ledger}
表\ref{tab:final29}に最終状態をまとめる。対象記録と不明候補は試行内で併存できるため，別列の指標とする。取得原本と解析版の経緯は研究台帳に保存し，本稿の集計はこの表に統一する。
\begin{table}[htbp]\centering\small
\caption{最終29試行の構成。対象・不明は該当記録を含む試行数。}\label{tab:final29}
\begin{tabular}{lrrr}\toprule 条件・取得経路 & 試行数 & 対象あり & 不明候補あり \\\midrule
''' + '\n'.join(lines) + r'''
\midrule 合計 & 29 & 23 & 5 \\\bottomrule
\end{tabular}\end{table}
全試行はAPI35・arm64の単一AVDで取得し，品質をpartialとして保存した。既存25試行の相互排他的な内訳は対象あり19，不明候補4，いずれもなし2である。追加4試行には全て対象記録があり，うち1試行には別に不明フローがある。上表の対象23と不明5は重複を含む列であり，両列を足して無通信試行を推定しない。
'''
    assert sum(r['target_record_present'] for r in rows) == 23
    assert sum(r['unknown_candidate_present'] for r in rows) == 5
    (ROOT / 'docs/generated/final29-cohorts-2026-11-06.tex').write_text(tex)
    claims = {
        'kind': 'secondary_analysis_from_verified_records', 'date': '2026-11-06',
        'sources_sha256': {k: hashlib.sha256(p.read_bytes()).hexdigest() for k,p in sources.items()},
        'device_trials': 29, 'new_cloud_device_trials': 0, 'originals_rewritten': False,
        'context': {'supported_api_sites': 29, 'constant': 2, 'unresolved': 27,
                    'sites_with_runtime_origin_tag': origin_sites,
                    'all_unresolved_are_Intent_RSS_proven': False},
        'contrast': {'order': [r['arm'] for r in new['rows']], 'positive_target_requests': 4,
                     'posthoc_raw_review': True, 'input_ports': [r['port'] for r in new['rows']],
                     'code_to_runtime_path_proven': False, 'selection_superiority_measured': False},
        'independent_accuracy': None, 'novelty_established': False,
        'counts_are_trials_not_independent_apps': True,
    }
    (OUT / 'claim-boundaries.json').write_text(json.dumps(claims, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'device_trials': len(rows), 'conditions': len(groups), 'context_runtime_origin_sites': origin_sites,
                      'outputs': ['final29-trials.csv', 'claim-boundaries.json', 'final29-cohorts.tex']}))


if __name__ == '__main__':
    main()
