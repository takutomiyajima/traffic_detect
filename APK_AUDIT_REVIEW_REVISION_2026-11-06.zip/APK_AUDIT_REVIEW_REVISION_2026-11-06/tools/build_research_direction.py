#!/usr/bin/env python3
"""Build a six-page research direction and reviewer-response document."""
from pathlib import Path
import json
import os
import subprocess

import build_beginner_guide as base

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs/research/review-revision-2026-11-06'


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    protocol = {
        'profile': 'difference-explanation-comparison-draft-v1',
        'status': 'draft_not_preregistered_not_executed', 'date': '2026-11-06',
        'purpose': 'Assess supported difference explanations and execution cost, not generic safety or leak accuracy.',
        'methods': {
            'M0': 'Literal static candidates plus the same baseline capture; no additional trials.',
            'M1': 'M0 plus supported local argument context; no additional trials.',
            'M2': 'M1 plus fixed ABBA URI contrast, four additional trials.',
            'M3': 'M1 plus implemented evidence-conditioned choice: zero trials when local constant candidates cover all dynamic-only records; otherwise eligible ABBA, at most four trials.',
        },
        'maximum_additional_device_trials_per_case': 4,
        'scheduled_seconds_per_additional_trial': {'launch': 5, 'input_observation': 30},
        'budget_policy': 'Same maximum trial/time budget, same pre/post controls and baseline inputs. Report setup and control overhead separately; do not hide it.',
        'candidate_case_families': [
            'Local constant concatenation can supply the missing static endpoint candidate.',
            'The explicitly supplied URI endpoint is followed by a positive target request.',
            'A positive target request stays at a known fixed endpoint while supplied URI endpoints change.',
            'Capture/action failure or insufficient attribution prevents an input-association conclusion.',
        ],
        'initial_scope': 'One separately prepared reference case per family; four development-independent case specifications to freeze before running. No new cases executed here.',
        'required_freeze_before_capture': ['APK/source hashes', 'source-based case oracle and intended action',
            'supported explanation labels and evidence requirements', 'collector and parser code hashes',
            'ordered scenarios and state policy', 'all method budgets and stopping rules'],
        'measures': ['supported explanation count per case family', 'unsupported specific assertions',
                     'withheld/inconclusive outputs', 'additional device trials',
                     'wall-clock time including separately recorded setup/control overhead'],
        'acceptance': {'unsupported_specific_assertions': 0,
                       'missing_capture_must_not_become_no_traffic': True,
                       'inconclusive_must_not_receive_true_negative_credit': True,
                       'equivalent_fixed_and_selected_outputs_report_as_tie': True},
        'practical_stop_rule': 'Stop at the frozen budget and report unresolved cases. Do not add favorable trials after seeing results.',
        'current_implementation_gap': 'Current v1 assessment verifies registered-target positive matches and otherwise retains inconclusive. A separate evidence branch is needed before evaluating positive fixed-endpoint counterexamples.',
        'independence': 'Specifications and source contracts are separate from parser output; same-author reference cases remain a limitation, not independent public-app accuracy.',
        'existing_ab002_use': 'Already observed case and runner validation only; never relabel as a future held-out prospective case.',
        'M3_equals_M2_on_current_case': True,
        'new_device_trials_completed': 0,
    }
    (OUT / 'comparison-protocol-draft.json').write_text(json.dumps(protocol, ensure_ascii=False, indent=2) + '\n')
    source = '''# 研究の今後の方針とレビュー対応

## 01｜研究の中心を一本にする

**目標は、APK内の候補と実測通信の差を、追加の解析・観測で根拠付きに説明することです。**

APKを入力し、静的解析、指定した操作、通信取得、対応表と日本語説明を一続きで行うシステムを基盤にします。差分が残る場合に、局所的な引数追跡と登録済みURIの切替を使って説明を補強します。

:::diagram research_focus

| 項目 | 今回の研究で示す内容 |
| --- | --- |
| 目的 | 静的候補と実測の対応・差分を説明する |
| 方法 | APK解析・通信観測・証拠参照・限定した追加観測 |
| 主結果 | ABBAの4試行すべてで対象要求先が入力先と一致 |
| 結論 | 動的のみの通信を、登録入力への追随として補強できた |

既存25試行は、HTTP、HTTPS、UDP、処理不成功、通常起動、RSS等の補助事例として残します。追加4試行を含む29試行を最終表へ統一し、試行数とフロー数、公開アプリ数を分けます。

:::key 今回の到達点
指定環境での入力追随は確認済みです。次は同じセットアップの確認を繰り返さず、どの説明が正しく増えるかを比較します。
:::

:::source 保存された29試行の台帳、diagnostic-ab-002の原本再解析、実装select_probe・assess。

<!-- page -->
## 02｜レビューを採用する点と、修正する点

| 指摘 | 対応 |
| --- | --- |
| URI切替を主結果へ | 入力・観測ポートを並べ、4試行の一致を先に記載 |
| 仮説と基準が不明 | 第3章に仮説、候補操作、予算、入力生成、成立条件を追加 |
| 古い本文・時系列付録 | 現行取得経路へ更新し、最終29試行の表へ集約 |
| 要旨・結論が防御的 | 目的・方法・肯定的結果・範囲の順へ整理 |
| AI利用の開示 | 実装・テスト・解析補助・執筆支援の範囲を追記 |

**「不明27箇所はRSS URLのIntent入力だから解けない」という説明は、現在の出力からは確定できません。** 27箇所のruntime_originsはすべて空で、ライブラリ等の箇所も含みます。静的追跡の限界と、URI入力への通信の追随は別の証拠です。

説明候補には固定値・組み立て、実行時入力、保存設定・キャッシュ、その他があります。現選択器が実装しているのは、その全原因分類ではなく「入力追随」と「要求先一定」の2つの宣言モデルに対する操作選択です。現診断は登録先の正の要求を確認し、不足時は判断を保留します。

:::key 新規性の位置付け
Agrigento公式資料には、入力情報を変更し通信差を見る先行方式があります。入力切替、静的・動的の併用、VPN取得だけを新規性とはしません。候補は「差分の証拠から追加観測を選び、説明の支持範囲を更新する仕組み」です。これを確定するには比較が必要です。
:::

レビューの成績予想や「2本なら秀」という目安は採点保証になりません。大学・指導教員の評価方針と区別します。

:::source context.jsonの29レコード、固定コミットのAgrigento・AntMonitor公式README。両者の論文本文は今回未取得。

<!-- page -->
## 03｜次に比較するものを固定する

次の評価は「同じ上限予算で、支持できる説明と実行コストがどう変わるか」です。計画JSONは草案として保存しました。素材・正解・コードをそろえた後に取得前固定するため、現時点で事前登録済みとは呼びません。

| 方式 | 与える追加情報・操作 |
| --- | --- |
| M0 | 文字列由来の静的候補と共通の基準通信 |
| M1 | M0に局所的な引数文脈を追加 |
| M2 | M1に固定ABBAの4試行を追加 |
| M3 | 文脈で補える場合は追加0、残れば条件に合うABBAを選択 |

追加予算の上限は各ケース4試行、1試行は起動5秒と入力後30秒です。取得対照、準備、同意待ち、解析時間も記録し、隠れたコストにしません。実行しない方式に予算消費を強制せず、同じ上限下で実コストを比較します。

ケースは、定数結合で補える、入力に追随する、正の要求が一定先に残る、取得不足で保留すべき、の4種類から別の参照素材を準備します。解析器の出力を見て正解を作らず、ソース仕様とサーバー・操作契約を先に固定します。同じ開発者が作る偏りは記録します。

:::key 主指標と停止規則
支持できる説明、根拠のない具体的断定、保留、追加試行数、所要時間を併記します。根拠のない具体的断定は0を成功条件とし、保留を正解陰性に数えません。予算到達で終了し、不利な未解決例も残します。
:::

今回の事例ではM2とM3の順序は同じです。結果が同じなら同等と報告し、文脈により実行を省けた場合は精度と分けてコスト差を評価します。

:::source comparison-protocol-draft.json。新しい比較実験はまだ実施していません。開発用6ケースを独立評価へ転用しません。

<!-- page -->
## 04｜作業順・担当・時間の目安

| 順序 | 作業と担当 | 目安 |
| --- | --- | --- |
| 完了 | AI：本文構成、仮説・判定基準、29試行表、要旨・結論、AI開示を改訂 | 今回実施 |
| 次1 | AI：4種類の参照素材・根拠仕様と比較ハーネスを準備し、版を固定 | 1〜2作業日 |
| 次2 | AI：登録先以外でも正の一定先要求がある場合を検査する分岐と検査を追加 | 0.5〜1作業日 |
| 次3 | Mac：準備した手順を一括実行し、許可画面のみ確認。AIが結果を再解析 | 2〜4時間＋待ち時間 |
| 次4 | AI：方式比較表と考察を更新し、短い発表原稿へまとめる | 1〜2作業日 |

上記は作業量の見積りで、実行済み時間や保証ではありません。Android互換性や素材の修正で延びます。端末はこのクラウドから直接操作できないため、Macでの実行は必要になった時点で、具体的なコマンドと返却物を案内します。

**今回、新たに実行する実験コマンドはありません。** 先に比較器と素材をそろえます。古いrunの削除、アプリデータの一律消去、同じABBAの追加反復は不要です。

キャッシュ等の反例は、入力を無視して既知の一定先に実際の要求を出す参照素材から検査します。単に通信が見えないことをキャッシュの証拠にはしません。公開アプリの反例は機能・状態を調べてから条件を選びます。

:::key 2本目の公開アプリの扱い
候補Feederの公開ソースを固定コミットで確認しました。RSS用の外部入力画面、IntentのURL受け取り、条件付きの検索自動開始があります。リリースAPKの選定・同定と端末確認は未実施です。2本目の実験済み結果には数えず、次の候補として記録しました。
:::

:::source 本文の実装範囲と今後の比較計画。上記の新素材・比較器は計画であり、現行配布プログラムの完成機能ではありません。

<!-- page -->
## 05｜投稿先は主題と原稿形式で選ぶ

第一候補は国内の研究会発表です。今回の主題を「静的候補にない通信を、登録入力への追随として説明するシステム」に絞ります。実装・成立条件・主結果・制約を読める原稿にします。

| 候補 | 適合性と確認事項 |
| --- | --- |
| CSEC／ICSS | Android通信と解析支援に合う。研究会の募集回・分量・発表条件を確認 |
| 情報処理学会 全国大会 | 最初の発表候補。短い指定形式に再構成し、分量・締切・資格を確認 |
| SESやモバイル系のデモ・短報 | ツールとしての説明と再現資料を整えた後の候補 |

公式案内の入口は情報処理学会全国大会（https://www.ipsj.or.jp/event/taikai/）、CSEC（https://www.iwsec.org/csec/）、ICSS（https://www.ieice.org/~icss/）です。最新の募集回、日程、査読の有無、ページ数、会員資格、料金、公開条件を案内ごとに確認します。

**2026年11月6日時点の今回の確認では、公式サイトへの接続が403で拒否され、最新締切・開催日を検証できませんでした。** 日程を確定情報として転載していません。全国大会へ4〜6ページで出せると一律には案内しません。形式は会場ごとに異なります。

:::key 投稿前に研究者が決めること
投稿先と開催回、著者・共著者・謝辞、所属の確認、公開範囲を指導教員と決めます。これは原稿の整備を止める理由ではなく、外部投稿前の確認です。現状で採否や成績を保証することはできません。
:::

国際本会議は、先行研究との差分と評価の独立性を強化した後の段階です。まず国内発表向けに整理し、その比較結果を受けてワークショップ・デモを検討します。

:::source source-checks.jsonにURL、確認可否、公式成果物のコミットとhashを保存。投稿・連絡は実施していません。

<!-- page -->
## 06｜今の結論と、提出前に説明できること

現時点の結論は、**静的候補と実測の差を表示するだけでなく、登録入力を変えた追加観測によって、この事例の説明を補強できた**というものです。4試行はこの主張を支える主結果に置き、残る25試行は取得・帰属・差分の補助結果にします。

| 口頭で説明する項目 | 自分の言葉で押さえる点 |
| --- | --- |
| なぜAとBか | 入力先への追随と要求先一定を区別するため |
| なぜABBAか | 両入力を2回ずつ含む固定順序。ランダム化ではない |
| 何を確認したか | 対象UIDの要求、入力ポート・nonce、サーバー候補対応、前後対照 |
| 何が不明か | コード経路、状態の完全一致、一般精度、選択方式の優越 |
| 静的27不明の意味 | 対応する局所追跡の限界。すべてIntent由来という意味ではない |

実装・テスト・解析補助・文章作成に生成AIを使用した範囲を記録しました。大学と会場の規定を確認して、実際の製品名・利用時期・範囲を提出時に確定してください。「AIが全て確認した」を独立した第三者評価とは扱いません。

:::key 今回の成果物
構成を整理した論文PDFとTeX、最終29試行CSV、主張の境界JSON、比較計画草案、文献・公式サイトの確認記録をまとめました。元の42ページ版と原本は保持し、新しいAndroid試行は加えていません。
:::

次の実装は「正の要求が一定先に残る場合の点検」と「同じ予算で比較するハーネス」です。動作確認を繰り返す段階から、説明品質と費用を測る段階へ進みます。

:::source 改訂論文とレビュー対応記録。提出確定版ではなく、著者情報・大学書式・投稿先の条件は別途確定が必要です。
'''
    (OUT / 'research-direction.md').write_text(source)
    base.DIAGRAMS['research_focus'] = r'''
\begin{center}\begin{tikzpicture}[box/.style={rounded corners=2mm,fill=mint,draw=none,align=center,text width=43mm,minimum height=24mm,font=\small},a/.style={-{Stealth[length=2mm]},thick,draw=teal}]
\node[box] (s) {静的候補と実測\\対応・差分を確認};
\node[box,right=7mm of s,fill=bluewash] (p) {文脈・登録入力\\追加の根拠を取得};
\node[box,right=7mm of p,fill=sand] (x) {説明を更新\\支持できる範囲を提示};
\draw[a](s)--(p);\draw[a](p)--(x);
\end{tikzpicture}\end{center}'''
    tex = base.render(source, expected_pages=6)
    for a,b in {
        'はじめて読む、この研究の全体像':'研究の今後の方針とレビュー対応',
        '研究の目的・仕組み・実験・結果・結論を初心者向けに説明する入門ガイド':'URI切替を主結果とした構成整理と次の比較評価',
        'APKと通信解析を理解する入門ガイド':'研究方針・レビュー対応・投稿候補',
        '2026年11月5日版':'2026年11月6日版',
        '研究の範囲：指定操作下の解析支援と事例評価':'現在の結果と将来の比較計画を区別して記載',
        'RESEARCH GUIDE /':'RESEARCH DIRECTION /',
    }.items():tex=tex.replace(a,b)
    path=ROOT/'docs/research-direction-2026-11-06.tex';path.write_text(tex)
    env={**os.environ,'TEXMFVAR':str(ROOT/'.cache/texmf-var'),'TEXMFCONFIG':str(ROOT/'.cache/texmf-config'),'XDG_CACHE_HOME':str(ROOT/'.cache')}
    for _ in range(3):subprocess.run(['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error',path.name],cwd=path.parent,env=env,check=True)


if __name__ == '__main__':
    main()
