#!/usr/bin/env python3
"""Distribute the restructured thesis and research direction, without raw data."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
STEM = 'APK_AUDIT_REVIEW_REVISION_2026-11-06'


def main():
    stage = ROOT / 'dist' / STEM
    if stage.exists():
        raise SystemExit('Preserve existing package; choose another name.')
    stage.mkdir(parents=True)
    files = set()

    def include(path):
        path = path.resolve()
        if path in files:
            return
        path.relative_to(ROOT)
        if not path.is_file():
            raise FileNotFoundError(path)
        files.add(path)
        if path.suffix == '.tex':
            for kind, name in re.findall(r'\\(input|include|includegraphics)(?:\[[^\]]*\])?\{([^}]+)\}', path.read_text()):
                dep = ROOT / 'docs' / name
                if not dep.suffix and kind != 'includegraphics':
                    dep = dep.with_suffix('.tex')
                include(dep)

    for name in ['docs/thesis.tex', 'docs/thesis.pdf',
                 'docs/research-direction-2026-11-06.tex', 'docs/research-direction-2026-11-06.pdf',
                 'tools/build_thesis.sh', 'tools/build_beginner_guide.py',
                 'tools/build_research_revision.py', 'tools/build_research_direction.py',
                 'tools/package_review_revision.py',
                 'docs/research/research-design-existing25-2026-11-05/existing25-synthesis.json']:
        include(ROOT / name)
    for directory in ['docs/research/review-revision-2026-11-06',
                      'docs/research/diagnostic-ab002-verified-2026-11-06']:
        for path in (ROOT / directory).iterdir():
            if path.suffix in {'.json', '.csv', '.md'}:
                include(path)
    for path in sorted(files):
        assert path.suffix not in {'.apk', '.pcap', '.pcapng', '.jsonl'}
        dest = stage / path.relative_to(ROOT)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dest)
    (stage / 'README.md').write_text('''# 研究レビューを反映した改訂資料（2026-11-06）

docs/thesis.pdf: 27ページの卒業論文草稿。旧42ページ版を整理し、入力切替4試行を主結果にしました。
docs/research-direction-2026-11-06.pdf: 6ページの研究方針・作業順・投稿候補の説明。
docs/research/review-revision-2026-11-06/final29-trials.csv: 最終29試行の台帳。
同じフォルダにレビュー対応、主張の境界、比較仕様草案、文献確認、Feeder候補のソース確認があります。

新しいAndroid試行は0件です。比較仕様は草案であり、事前登録・実施済み評価ではありません。
不明27箇所をIntent由来と同定した結果はありません。URI入力に要求が追随した観測と区別します。
一般的な精度・選択方式の優越・方法上の新規性・成績・採否を確定しません。

このZIPは資料・集計・ソースの配布で、Mac側アプリへ適用するパッチではありません。
APK・PCAP・通信本文ログ・提供された論文PDFは収録していません。

TeX再生成: XeLaTeX、Noto Serif CJK JP、Noto Sans CJK JP、DejaVu Sans Monoと通常のTeXパッケージを用意し、
このフォルダで bash tools/build_thesis.sh を実行します。
研究方針は python tools/build_research_direction.py で生成できます。
build_research_revision.pyの原本照合は、非公開のcontext.json等を含む研究リポジトリを必要とします。
資料ZIPだけでAndroid実験や原本検証が再実行できるとはしません。

著者情報・大学書式・投稿先の条件は提出前に確定してください。公式会場の最新締切・開催日・AI規定は
接続制限により今回確認できず、確定日程としては案内していません。
''')
    entries = [{'path': p.relative_to(stage).as_posix(), 'bytes': p.stat().st_size,
                'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
               for p in sorted(stage.rglob('*')) if p.is_file()]
    manifest = {'date': '2026-11-06', 'kind': 'derived_research_revision',
                'thesis_pages': 27, 'research_direction_pages': 6,
                'visual_review_pages': 33, 'received_device_trials': 29,
                'new_device_trials': 0, 'raw_files_published': False,
                'comparison_protocol_status': 'draft_not_preregistered_not_executed',
                'independent_accuracy_established': False, 'novelty_established': False,
                'files': entries}
    (stage / 'MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    archive_path = stage.with_suffix('.zip')
    if archive_path.exists():
        raise SystemExit('Archive exists')
    with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(stage.rglob('*')):
            if path.is_file():
                z.write(path, path.relative_to(stage.parent))
    pairs = [(ROOT / 'docs/thesis.pdf', ROOT / 'dist/APK_AUDIT_RESTRUCTURED_THESIS_2026-11-06.pdf'),
             (ROOT / 'docs/research-direction-2026-11-06.pdf', ROOT / 'dist/APK_AUDIT_RESEARCH_DIRECTION_2026-11-06.pdf')]
    for source, target in pairs:
        shutil.copy2(source, target)
    for path in [archive_path] + [b for _,b in pairs]:
        shutil.copy2(path, Path('/workspace/downloads') / path.name)
        print(json.dumps({'name': path.name, 'bytes': path.stat().st_size,
                          'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()
