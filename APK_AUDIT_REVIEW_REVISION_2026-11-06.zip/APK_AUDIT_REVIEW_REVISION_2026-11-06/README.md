# 研究レビューを反映した改訂資料（2026-11-06）

docs/thesis.pdf: 27ページの卒業論文草稿。旧42ページ版を整理し、入力切替4試行を主結果にしました。
docs/research-direction-2026-11-06.pdf: 6ページの研究方針・作業順・投稿候補の説明。
docs/research/review-revision-2026-11-06/final29-trials.csv: 最終29試行の台帳。
同じフォルダにレビュー対応、主張の境界、比較仕様草案、文献確認、Feeder候補のソース確認があります。

新しいAndroid試行は0件です。比較仕様は草案であり、事前登録・実施済み評価ではありません。
不明27箇所をIntent由来と同定した結果はありません。URI入力に要求が追随した観測と区別します。
一般的な精度・選択方式の優越・方法上の新規性・成績・採否を確定しません。

このZIPは資料・集計・ソースの配布で、Mac側アプリへ適用するパッチではありません。
APK・PCAP・通信本文ログ・提供された論文PDFは収録していません。

TeX再生成: XeLaTeX、Noto Serif CJK JP、Noto Sans CJK JP、DejaVu Sans Monoと通常のTeXパッケージを用意し、
このフォルダで bash tools/build_thesis.sh を実行します。
研究方針は python tools/build_research_direction.py で生成できます。
build_research_revision.pyの原本照合は、非公開のcontext.json等を含む研究リポジトリを必要とします。
資料ZIPだけでAndroid実験や原本検証が再実行できるとはしません。

著者情報・大学書式・投稿先の条件は提出前に確定してください。公式会場の最新締切・開催日・AI規定は
接続制限により今回確認できず、確定日程としては案内していません。
