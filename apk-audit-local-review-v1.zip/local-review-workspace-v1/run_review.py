#!/usr/bin/env python3
"""Build a local evidence review from four existing runs. No ADB or experiments."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import html
import importlib
import ipaddress
import json
from pathlib import Path
import shutil
import sys
import webbrowser

PUBLIC_SHA = '6e79f28f69cef1a8b2e4f5f88c9c3cf3c3d7c51356f01394ac23b0dc5d56a00b'
CONTROL_SHA = '7c7f24e82c80fb1e51df96923dda326571d3c706d496e03efb6373647df01382'
TRIALS = [('E01', 'auto-http-002', CONTROL_SHA),
          ('E02', 'antennapod-launch-001', PUBLIC_SHA),
          ('E03', 'antennapod-rss-preview-001', PUBLIC_SHA),
          ('E04', 'antennapod-rss-preview-006', PUBLIC_SHA)]
COLUMNS = ['review_unit_id', 'trial_id', 'evidence_directory', 'sampling',
           'reviewer_id', 'reviewer_relation', 'static_facts_from_evidence',
           'dynamic_facts_from_evidence', 'attribution_and_visibility_limits',
           'evidence_refs', 'primary_review_reason',
           'model_statement_support_after_primary_review', 'unresolved_disagreement']


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def preflight(project, roots=None):
    project = Path(project).resolve()
    if not (project/'src/apk_audit/pcapdroid.py').is_file():
        raise ValueError('--projectで既存のapk-audit-unified-v1を指定してください。')
    result = []
    for unit, trial, expected in TRIALS:
        source = Path(roots[trial]) if roots is not None else project/'runs'/trial
        source = source.resolve()
        required = ['run.json', 'static.json', 'findings.json', 'correspondence.json',
                    'automatic.metadata.json', 'raw/automatic.pcap', 'raw/original.apk']
        missing = [name for name in required if not (source/name).is_file()]
        if missing:
            raise ValueError(str(source)+' に必要な保存済みファイルがありません: '+', '.join(missing)
                             +'。再実験せず、この表示をチャットへ返してください。')
        run = read(source/'run.json')
        if run.get('apk_sha256') != expected or digest(source/'raw/original.apk') != expected:
            raise ValueError(trial+': APK識別が以前の結果と異なります。元ファイルを残してください。')
        manifest = source/'RESULT-MANIFEST.json'
        if manifest.is_file():
            for name, expected_sha in read(manifest)['files'].items():
                file = (source/name).resolve()
                if not file.is_relative_to(source) or not file.is_file() or digest(file) != expected_sha:
                    raise ValueError(trial+': 保存manifestと一致しません: '+name
                                     +'。修復せず表示をチャットへ返してください。')
        result.append((unit, trial, source, run))
    return project, result


def prepare(project, destination, roots=None):
    destination = Path(destination).resolve()
    if destination.exists():
        raise ValueError('作成先が既にあります。旧レビュー票を残して新しい--outを指定してください。')
    project, jobs = preflight(project, roots)
    if any(destination.is_relative_to(source) for _, _, source, _ in jobs):
        raise ValueError('作成先を元の実験フォルダ内に置かないでください。')
    sys.path.insert(0, str(project/'src'))
    try:
        dpkt = importlib.import_module('dpkt')
        trailer_uid = importlib.import_module('apk_audit.pcapdroid').trailer_uid
    except ImportError as error:
        raise ValueError('既存プロジェクトの.venv/bin/pythonで実行してください。') from error
    destination.mkdir(parents=True)
    tasks, labels, sources = [], [], []
    for unit, trial, original, run in jobs:
        evidence = destination/'01-evidence'/unit
        model = destination/'02-model-output'/unit
        evidence.mkdir(parents=True); model.mkdir(parents=True)
        def copy(name, directory, target_name=None):
            source = original/name
            if not source.is_file():
                return
            target = directory/(target_name or name)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            sources.append({'unit': unit, 'original': str(source),
                            'copy': str(target.relative_to(destination)), 'sha256': digest(source)})
        for name in ['intent.json', 'ui_events.jsonl', 'automatic.metadata.json',
                     'raw/automatic.pcap', 'raw/installation-identity.json',
                     'raw/clock-samples.json', 'raw/automatic-controls.jsonl',
                     'raw/pilot-end-screen.png', 'raw/pilot-end-ui.txt',
                     'raw/rss-server-events.jsonl', 'raw/rss-preparation/feed.xml',
                     'raw/rss-preparation/rss-spec.json',
                     'raw/operator-context/before-ui.txt',
                     'raw/operator-context/before-screen.png',
                     'raw/operator-context/before-state.json',
                     'raw/operator-context/experimenter-report.json']:
            copy(name, evidence)
        copy('static.json', evidence, 'tool-extracted-static.json')
        for name in ['findings.json', 'correspondence.json', 'correspondence.csv',
                     'report.html', 'summary.html']:
            copy(name, model)
        write(evidence/'recorded-context.json', {
            **{key: run[key] for key in ['package', 'target_uid', 'apk_sha256',
                                         'created_utc', 'ended_utc'] if key in run},
            'original_run_directory': str(original),
            'original_apk_path': str(original/'raw/original.apk'),
            'static_json_status': '解析器の抽出値であり、独立した人手正解ではありません。',
            'uid_status': '収集器と保存されたインストール情報の主張であり、新しいOS測定ではありません。'})
        rows = []
        metadata = read(original/'automatic.metadata.json')
        offset = metadata.get('clock_offset_s')
        with (original/'raw/automatic.pcap').open('rb') as stream:
            reader = dpkt.pcap.Reader(stream)
            if reader.datalink() != dpkt.pcap.DLT_EN10MB:
                raise ValueError(trial+': 想定外のPCAP形式です。作成途中の資料を残してください。')
            for number, (epoch, raw) in enumerate(reader, 1):
                ip = dpkt.ethernet.Ethernet(raw).data
                if not isinstance(ip, (dpkt.ip.IP, dpkt.ip6.IP6)):
                    continue
                transport = ip.data
                payload = bytes(transport.data) if hasattr(transport, 'data') else b''
                rows.append({'packet': number, 'device_epoch': str(epoch),
                             'collector_uid_assertion': trailer_uid(raw),
                             'source_ip': str(ipaddress.ip_address(ip.src)),
                             'destination_ip': str(ipaddress.ip_address(ip.dst)),
                             'source_port': getattr(transport, 'sport', ''),
                             'destination_port': getattr(transport, 'dport', ''),
                             'host_time_midpoint_utc_conditional':
                                 datetime.fromtimestamp(float(epoch)+offset, timezone.utc).isoformat()
                                 if isinstance(offset, (int, float)) else '',
                             'payload_bytes': len(payload),
                             'payload_preview_first_2048_bytes': repr(payload[:2048]),
                             'preview_truncated': len(payload) > 2048})
        with (evidence/'packet-table.tsv').open('w', encoding='utf-8-sig', newline='') as stream:
            if rows:
                writer = csv.DictWriter(stream, fieldnames=list(rows[0]), delimiter='\t')
                writer.writeheader(); writer.writerows(rows)
        write(model/'saved-output-version.json', {
            'basis': 'Macに保存された出力をそのままコピー。新しい実験・解析は行いません。',
            'original_findings_sha256': digest(original/'findings.json'),
            'public_launch_note': 'E02の古い出力には後に訂正したUID保持の不具合があり得ます。'
                                 '原本パケットと出力に不一致があれば、そのまま記入してください。',
            'manual_actions_note': 'E03は実施者が購読・再生等を報告した試行です。'
                                   '操作申告とプログラムの自動イベント記録を区別してください。'})
        labels.append({'review_unit_id': unit, 'trial_id': trial,
                       'evidence_directory': '01-evidence/'+unit,
                       'sampling': 'purposeful retrospective cases; not blinded or population accuracy'})
        tasks.append({'unit': unit, 'trial': trial, 'source_run_sha256': digest(original/'run.json'),
                      'source_model_sha256': digest(original/'findings.json'),
                      'evidence': '01-evidence/'+unit, 'model': '02-model-output/'+unit})
    for name in ['labels-template.csv', 'labels-completed.csv']:
        with (destination/name).open('w', encoding='utf-8-sig', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=COLUMNS)
            writer.writeheader(); writer.writerows(labels)
    guide = Path(__file__).with_name('REVIEW-STEPS.md')
    if not guide.is_file():
        guide = Path(__file__).with_name('local-explanation-review-steps.md')
    shutil.copyfile(guide, destination/'REVIEW-STEPS.md')
    links = ''.join('<li>'+html.escape(task['unit']+' '+task['trial'])
                    +' <a href="'+task['evidence']+'/recorded-context.json">条件</a>'
                    +' / <a href="'+task['evidence']+'/packet-table.tsv">パケット表</a>'
                    +' / <a href="'+task['evidence']+'/raw/automatic.pcap">元PCAP</a></li>'
                    for task in tasks)
    (destination/'start.html').write_text(
        '<!doctype html><html lang="ja"><meta charset="utf-8"><title>証拠レビュー</title>'
        '<style>body{font:18px sans-serif;max-width:950px;margin:40px auto;line-height:1.9}</style>'
        '<h1>4事例の証拠レビュー</h1><p><a href="REVIEW-STEPS.md">手順</a>を読み、'
        '<a href="labels-completed.csv">labels-completed.csv</a>へ記入してください。</p>'
        '<p>先に01-evidenceを読み、その後02-model-outputの保存出力と比べます。'
        'パケット表と静的JSONは機械抽出値であり、独立した正解ではありません。</p><ul>'
        +links+'</ul><p>元の実験ファイルは変更していません。追加実験・ADB操作はしていません。</p>',
        encoding='utf-8')
    write(destination/'tasks.json', {'units': tasks, 'human_annotations_completed': 0,
                                   'new_device_trials': 0, 'blindness_claimed': False})
    write(destination/'SOURCE-MANIFEST.json', {'source_copies': sources})
    write(destination/'REVIEW-MANIFEST.json', {
        'files': {str(path.relative_to(destination)): digest(path)
                  for path in destination.rglob('*') if path.is_file()
                  and path.name != 'labels-completed.csv'},
        'editable_file': 'labels-completed.csv', 'human_annotations_created': 0})
    return destination


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    default_project = Path.cwd() if (Path.cwd()/'src/apk_audit').is_dir() else Path.home()/'Documents/apk-audit-unified-v1'
    parser.add_argument('--project', type=Path, default=default_project)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--check-only', action='store_true')
    parser.add_argument('--no-open', action='store_true')
    args = parser.parse_args()
    try:
        if args.check_only:
            _, jobs = preflight(args.project)
            print('保存済み4試行を確認しました。新しい観測・ファイル変更はしていません。')
            for unit, trial, source, _ in jobs:
                print(unit, trial, source)
            return 0
        destination = args.out or Path.home()/'Documents'/('apk-audit-review-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
        destination = prepare(args.project, destination)
        print('レビュー資料: '+str(destination))
        print('記入して返すCSV: '+str(destination/'labels-completed.csv'))
        print('元の実験結果は変更していません。追加実験は実行していません。')
        if not args.no_open:
            webbrowser.open((destination/'start.html').as_uri())
        return 0
    except (OSError, ValueError, KeyError, ImportError) as error:
        print('作成を停止しました: '+str(error), file=sys.stderr)
        return 4


if __name__ == '__main__':
    raise SystemExit(main())
