# APK Audit プログラムの仕組みと実装解説

研究発表スライドとは別の、日本語の技術解説資料です。
対象は2026年11月9日にクラウド側で確認したPython実装とJava制御補助APKです。

## 読む・編集する

- `main.pdf`：閲覧用PDF。
- `main.tex`：本文。XeLaTeX用です。
- `source-map.tex` / `SOURCE-MAP.csv`：主要44関数・クラスの定義位置。
- `CODE-MANIFEST.json`：説明の対象となった32ソースファイルのSHA-256。
- `examples/`：既存validatorで検証した意図JSON・シナリオJSONの説明例。
- `snippets/`：本文で説明する現行ソースの抜粋。単独実行用プログラムではありません。
- `QUALITY-CHECK.json`：PDF・参照ファイル・JSON例の検査結果。

全体構成、入力契約、ワーカー分離、静的抽出、局所的な引数追跡、ADB、
PCAPdroid制御、前後対照、UID、時計誤差、照合規則、差分説明、証拠索引、
実試行の読取り、配布拡張の仕組み、障害診断を説明しています。

## 再コンパイル

このフォルダで以下を2回実行してください。

```sh
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
```

必要なもの：XeLaTeX、fontspec、TikZ、listings、booktabs、longtable、tabularx、
hyperref、xurl等の一般的なTeXパッケージ、Noto Serif CJK JP / Noto Sans CJK JP /
DejaVu Sans Monoフォント。MacTeX等では、フォントを入れるかmain.tex冒頭の指定を変更します。

## 実装と実測の範囲

- Mac内のプログラムを変更する資料ではありません。ローカルの版は実行manifestで確認します。
- 資料作成に伴う新しいAndroid実験は0件です。
- 主評価9試行は自作参照素材の規則動作確認です。一般精度100%を示しません。
- 既存29試行や27再解析出力を、主評価の独立標本へ合算しません。
- 通信内容、目的、安全性、漏えい不存在を保証しません。
- 生PCAP、元APK、実際のnonce/token、利用者の画面・個人情報をこの配布物に含めません。
- モードや初期状態により出力ファイルは増減します。
- `examples/scenario.json`は構造を説明する例です。そのまま既存の研究素材で
  成功することを保証する実行用シナリオではありません。

コードの説明・文書作成にAIを利用しています。端末実験は著者本人が実行した記録を
参照しており、AIが端末実験や独立した人手評価を代行した扱いにはしていません。
