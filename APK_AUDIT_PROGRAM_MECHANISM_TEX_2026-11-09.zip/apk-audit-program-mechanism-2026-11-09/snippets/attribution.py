def attribution(row, run):
    package, uid = row.get("package"), row.get("uid")
    expected_package, expected_uid = run.get("package"), run.get("target_uid")
    # UID is specific to this installation. Conflicting or incomplete identity stays unknown.
    if not isinstance(expected_uid, int) or not isinstance(uid, int):
        return "unknown", "installation UID or record UID missing"
    if uid == expected_uid:
        if package and package != expected_package:
            return "unknown", "shared/conflicting UID: package differs"
        return "target", "UID matched this run; shared UID attribution remains a limitation"
    if package == expected_package:
        return "unknown", "package matched but installation UID differs"
    if row.get("related_to_target") is True:
        return "related_candidate", "collector annotated possible delegation; not proven"
    return "other", "record UID differs from target installation UID; delegation not excluded"
