epsilon=flow.get("clock_alignment_half_width_s")
if type(epsilon) not in (int,float) or not math.isfinite(epsilon) or epsilon<0:
    return UNKNOWN,"Clock uncertainty for the input interval is unavailable",basis,"clock_unknown"
try:
    start,end=timestamp(flow["started_utc"]),timestamp(flow["ended_utc"])
    active=[r for r in matching if timestamp(r[0]["started_utc"])<=start-epsilon
            and end+epsilon<=timestamp(r[0]["ended_utc"])]
except (KeyError,AuditError):active=[]
if not active:return UNKNOWN,"Endpoint matches an input but interval correspondence is uncertain",basis,"input_interval_uncertain"
