def corresponds(candidate, flow):
    if flow.get("observation") == "capture_failed" or flow.get("transport") != "TCP" or candidate["port"] != flow.get("port"):
        return False
    return (candidate["host"] == flow.get("destination_ip") if is_ip(candidate["host"])
            else candidate["host"] == flow.get("host"))
