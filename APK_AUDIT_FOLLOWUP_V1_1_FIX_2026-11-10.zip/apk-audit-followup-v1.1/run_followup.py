#!/usr/bin/env python3
"""Additive, manifest-checked follow-up runner for the existing Mac project."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys


def main():
    sys.dont_write_bytecode = True; os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--project', type=Path, default=Path.home() / 'Documents/apk-audit-unified-v1')
    commands = p.add_subparsers(dest='command', required=True)
    suite = commands.add_parser('suite'); suite.add_argument('--out', type=Path, required=True)
    suite.add_argument('--serial', default='emulator-5554'); suite.add_argument('--non-interactive', action='store_true')
    starter = commands.add_parser('init'); starter.add_argument('--out', type=Path, required=True)
    starter.add_argument('--network', required=True, choices=['unspecified', 'deny_all', 'allowlist', 'allowlist_or_recorded_inputs'])
    starter.add_argument('--endpoint', action='append', default=[]); starter.add_argument('--package', required=True)
    starter.add_argument('--activity'); starter.add_argument('--uri'); starter.add_argument('--purpose', default='未指定（利用者が確認して編集する）')
    starter.add_argument('--permission', action='append', default=[])
    args = p.parse_args(); bundle = Path(__file__).resolve().parent; project = args.project.expanduser().resolve()
    try:
        manifest = json.loads((bundle / 'BUNDLE-MANIFEST.json').read_text())
        for name, digest in manifest['files'].items():
            path = (bundle / name).resolve()
            if not path.is_relative_to(bundle) or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                raise ValueError('配布ファイルが欠落・変更しています: ' + name)
        for name, digest in manifest['compatible_core'].items():
            path = project / 'src/apk_audit' / name
            if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                raise ValueError('既存プロジェクトの対応版と異なります。上書きせず表示を返してください: ' + name)
        sys.path.insert(0, str(project / 'src'))
        os.environ['PYTHONPATH'] = os.pathsep.join([str(project / 'src'), *filter(None, os.environ.get('PYTHONPATH', '').split(os.pathsep))])
        import apk_audit
        apk_audit.__path__.insert(0, str(bundle / 'payload'))
        from apk_audit.followup import run_suite, create_starter
        if args.command == 'suite':
            print('追加評価は6条件×2回、計12試行で終了します。目安20〜35分（同意待ちで変動）。追加操作はしないでください。', flush=True)
            result, code = run_suite(bundle / 'fixtures', args.out.expanduser(), args.serial, args.non_interactive)
        else:
            result = create_starter(args.out.expanduser(), args.network, args.endpoint, args.package,
                                    args.activity, args.uri, args.purpose, args.permission); code = 0
        print(json.dumps(result, ensure_ascii=False, indent=2)); return code
    except (Exception, KeyboardInterrupt) as exc:
        print(json.dumps({'error': str(exc), 'type': type(exc).__name__}, ensure_ascii=False), file=sys.stderr); return 4


if __name__ == '__main__': raise SystemExit(main())
