package org.example.apkaudit.followup;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import java.net.HttpURLConnection;
import java.net.URL;

/** No database, preferences, accounts, permissions API, SDK or background service. */
public class MainActivity extends Activity {
    // Deliberately present as an unused reference; never requested by this source.
    public static String unusedReference() { return "http://10.0.2.2:18864/not-requested"; }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        TextView text = new TextView(this);
        text.setText("APK intent follow-up\nAutomatic scenario; no extra taps.\nReference app stores no data.");
        text.setPadding(24, 100, 24, 24);
        setContentView(text);
        final Uri input = getIntent().getData();
        if (input == null) return;
        final String leaf = input.getLastPathSegment();
        final String mode = input.getQueryParameter("case");
        if (!"http".equals(input.getScheme()) || !"10.0.2.2".equals(input.getHost()) ||
                input.getPort() != 18862 || leaf == null || !leaf.matches("[a-f0-9]{32}\\.xml") ||
                !("normal".equals(mode) || "outside".equals(mode) || "mixed".equals(mode) || "delayed".equals(mode))) return;
        final String token = leaf.substring(0, 32);
        // Strip only experiment control query parameters; retain the supplied endpoint/path.
        final String allowed = input.buildUpon().clearQuery().build().toString();
        final String outside = "http://10.0.2.2:18861/feed/" + token + ".xml";
        new Thread(new Runnable() { public void run() {
            try {
                if ("delayed".equals(mode)) Thread.sleep(75000);
                if ("mixed".equals(mode)) { request(allowed, token); request(outside, token); }
                else request("normal".equals(mode) ? allowed : outside, token);
            } catch (Exception e) { android.util.Log.i("AuditFollowup", token + " error=" + e.getClass().getSimpleName()); }
        }}).start();
    }

    private void request(String address, String token) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(address).openConnection();
            connection.setConnectTimeout(3000); connection.setReadTimeout(3000);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("X-Apk-Audit-Token", token);
            connection.setRequestProperty("Connection", "close");
            int status = connection.getResponseCode();
            java.io.InputStream stream = connection.getInputStream();
            byte[] data = new byte[1024]; int total = 0, count;
            while ((count = stream.read(data)) != -1) {
                total += count; if (total > 65536) throw new Exception("Response limit");
            }
            stream.close();
            android.util.Log.i("AuditFollowup", token + " status=" + status + " endpoint=" + address);
        } finally { if (connection != null) connection.disconnect(); }
    }
}
