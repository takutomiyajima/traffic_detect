import csv
import html
import json
from collections import Counter
from pathlib import Path

from .core import AuditError, read_json, sha256


def csv_safe(value):
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False)
    text = str(value)
    if text.lstrip().startswith(("=", "+", "-", "@")) or text.startswith(("\t", "\r", "\n")):
        return "'" + text
    return text


def report(out):
    out = Path(out).resolve()
    result = read_json(out / "findings.json")
    run = read_json(out / "run.json")
    index = read_json(out / "evidence/index.json")
    # Evidence must be resolvable and unchanged, not just an ID printed in a report.
    for record in result["findings"]:
        for evidence_id in record["evidence_ids"]:
            if evidence_id not in index:
                raise AuditError(f"Unresolvable evidence ID: {evidence_id}", 4)
            e = index[evidence_id]
            path = (out / e["path"]).resolve()
            if not path.is_relative_to(out) or not path.is_file() or sha256(path) != e["sha256"]:
                raise AuditError(f"Missing/modified evidence: {evidence_id}", 4)
    columns = ["finding_id", "run_id", "rule_id", "subject", "verdict", "observation", "attribution", "content_visibility", "host", "port", "transport", "application_protocol", "message", "evidence_ids", "limitations"]
    with (out / "findings.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        writer.writerows({k: csv_safe(row.get(k)) for k in columns} for row in result["findings"])
    esc = lambda value: html.escape(str(value), quote=True)
    rows = []
    for row in result["findings"]:
        links = " ".join(f'<a href="#e-{esc(e)}">{esc(e)}</a>' for e in row["evidence_ids"])
        rows.append("<tr>" + "".join(f"<td>{esc(row.get(k, ''))}</td>" for k in ("finding_id", "rule_id", "subject", "verdict", "observation", "attribution", "message")) + f"<td>{links}</td></tr>")
    evidence_rows = []
    for key, value in sorted(index.items()):
        # Fixed generated paths only, and HTML navigation to our local evidence files.
        from urllib.parse import quote
        href = quote(value["path"], safe="/")
        evidence_rows.append(f'<li id="e-{esc(key)}"><b>{esc(key)}</b> <a href="{href}">{esc(value["path"])}</a> — {esc(value["locator"])}<br>SHA-256: {esc(value["sha256"])}</li>')
    counts = Counter(f["verdict"] for f in result["findings"])
    from .support import build_support, html_section
    support_html = html_section(build_support(out, result))
    text = f'''<!doctype html><html lang="ja"><meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src 'none'; base-uri 'none'; form-action 'none'">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>APKと開発意図の照合</title>
<style>body{{font:16px/1.7 sans-serif;max-width:1400px;margin:2rem auto;padding:0 1rem;color:#162231}}table{{border-collapse:collapse;width:100%;font-size:13px}}td,th{{border:1px solid #ccd4dd;padding:.5rem;text-align:left;overflow-wrap:anywhere}}th{{background:#e9f0f7}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#f4f6f8;padding:1rem}}.note{{border-left:5px solid #ae6500;padding:1rem;background:#fff4df}}a{{color:#1256a0}}li{{margin-bottom:1rem;overflow-wrap:anywhere}}</style>
<h1>APK通信と開発意図の照合支援</h1>
<p>利用した証拠: {esc(result.get('evidence_mode', 'integrated'))}</p>
<p class="note">許可先への通信も安全性・送信目的を保証しません。未観測は不存在を意味しません。静的候補・通信試行・接続成立・本文可視性を区別してください。原本ログは機密情報を含み得るため、このレポート一式は研究者用です。</p>
<h2>実験条件と取得状態</h2><pre>{esc(json.dumps(run, ensure_ascii=False, indent=2))}</pre>
<h2>開発意図</h2><pre>{esc(json.dumps(result['intent'], ensure_ascii=False, indent=2))}</pre>
{support_html}
<h2>指摘の件数</h2><p>{esc(dict(counts))}（通信回数ではありません）</p>
<table><thead><tr><th>ID</th><th>規則</th><th>対象</th><th>判定</th><th>観測</th><th>帰属</th><th>説明</th><th>根拠</th></tr></thead><tbody>{''.join(rows)}</tbody></table>
<h2>証拠索引</h2><ul>{''.join(evidence_rows)}</ul>
<h2>解釈上の限界</h2><pre>{esc(json.dumps(result['limitations'], ensure_ascii=False, indent=2))}</pre>
<p>操作記録: <a href="ui_events.jsonl">ui_events.jsonl</a> / 通信: <a href="flows.jsonl">flows.jsonl</a> / 正本: <a href="findings.json">findings.json</a></p></html>'''
    (out / "report.html").write_text(text, encoding="utf-8")
    return len(result["findings"])
