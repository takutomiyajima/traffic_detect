"""Bounded 12-trial follow-up: mixed evidence, paired variants, two windows.

Source-defined same-author materials, not an unseen or independent accuracy
benchmark. This module never resets/uninstalls public apps or restores an AVD.
"""
from pathlib import Path
from urllib.parse import urlsplit
import ipaddress
import math
import re
import shutil
import sys
import uuid

from .core import AuditError, read_json, read_jsonl, sha256, timestamp, utc_now, write_json

PACKAGE = 'org.example.apkaudit.followup'
ALLOWED = 18862
OUTSIDE = 18861
UNUSED = 18864
CONDITIONS = ('normal', 'outside', 'mixed', 'permission', 'delay30', 'delay100')


def intention():
    return {'schema_version': '1.1', 'intent_id': 'bounded-followup-fixed-api-v1',
            'app_purpose': 'Only the declared local feed API is allowed; INTERNET only. Source reference, not a real privacy promise.',
            'network': {'mode': 'allowlist', 'allowed_destinations': [
                {'host': '10.0.2.2', 'include_subdomains': False, 'ports': [ALLOWED], 'application_protocols': ['http']}]},
            'permissions': {'mode': 'allowlist', 'allowed': ['android.permission.INTERNET']},
            'sdk': {'mode': 'unspecified'}, 'cleartext_policy': 'allow', 'background_network_policy': 'unspecified'}


def prepare_plan(fixtures):
    from .research_contrast import build_scenario
    fixtures = Path(fixtures)
    materials = read_json(fixtures / 'inventory.json')
    cases = {r['case_id']: r for r in materials['cases']}
    if set(cases) != {'base', 'permission'} or cases['base']['dex_sha256'] != cases['permission']['dex_sha256']:
        raise AuditError('Follow-up requires the two registered, identical-DEX variants')
    for row in cases.values():
        if row['package'] != PACKAGE or sha256(fixtures / row['apk']) != row['apk_sha256']:
            raise AuditError('Follow-up APK identity changed')
    trials = []
    orders = [CONDITIONS, ('outside', 'normal', 'permission', 'mixed', 'delay100', 'delay30')]
    for rep, order in enumerate(orders, 1):
        paired_tokens = {group: uuid.uuid4().hex for group in ('endpoint', 'mixed', 'delay')}
        for condition in order:
            group = 'delay' if condition.startswith('delay') else 'mixed' if condition == 'mixed' else 'endpoint'
            token = paired_tokens[group]
            mode = 'delayed' if condition.startswith('delay') else 'normal' if condition == 'permission' else condition
            observe = 100 if condition == 'delay100' else 30
            variant = 'permission' if condition == 'permission' else 'base'
            url = f'http://10.0.2.2:{ALLOWED}/feed/{token}.xml?case={mode}'
            trials.append({'trial_id': f'{condition}-{rep:03}', 'condition': condition, 'repetition': rep,
                           'variant': variant, 'apk': cases[variant]['apk'], 'apk_sha256': cases[variant]['apk_sha256'],
                           'token': token, 'url': url, 'observe_s': observe,
                           'expected_request_ports': [] if condition == 'delay30' else
                               [ALLOWED, OUTSIDE] if condition == 'mixed' else
                               [OUTSIDE] if condition in ('outside', 'delay100') else [ALLOWED],
                           'expected_permission_mismatch': condition == 'permission',
                           'scenario': build_scenario(PACKAGE, PACKAGE + '/.MainActivity', url, observe)})
    return {'profile': 'intent-followup-12-v1', 'prepared_utc': utc_now(), 'planned_trials': 12,
            'trials': trials, 'intent': intention(), 'materials': materials,
            'oracle_basis': 'source_contract_same_author; materials used in offline development checks; not independent or unseen accuracy',
            'state_policy': 'stateless reference source; force-stop before/after; preserve app data; no pm clear or uninstall; record package state',
            'paired_inputs': 'Same token/path for normal/outside/permission within each repetition and for the two delay windows; server candidates also require per-trial time.',
            'stop_rule': 'Stop on first execution/capture/cleanup failure, retain evidence; no automatic retries or extra cases.',
            'success_rule': 'Report supported/unsupported reference expectations per condition; withhold failures; do not claim general accuracy or usability benefit.',
            'exclusions': ['general HTTPS decryption', 'real SDK accuracy', 'different-host Android generalization', 'human usability evaluation'],
            'new_Android_trials_at_preparation': 0}


def request_evidence(directory, token, servers):
    """Read complete HTTP request headers; retain unknown ownership separately."""
    import dpkt
    from .pcapdroid import trailer_uid
    directory = Path(directory); state = read_json(directory / 'run.json')
    meta = read_json(directory / 'automatic.metadata.json')
    offset = meta.get('clock_offset_s')
    if type(offset) not in (int, float) or not math.isfinite(offset):
        raise AuditError('Finite clock offset is required')
    target = state.get('target_uid')
    if type(target) is not int or target < 0:
        raise AuditError('Nonnegative installation UID is required')
    flows = [r for _, r in read_jsonl(directory / 'flows.jsonl')]
    path = '/feed/' + token + '.xml'; rows = []; seen = set()
    with (directory / 'raw/automatic.pcap').open('rb') as stream:
        for number, (ts, frame) in enumerate(dpkt.pcap.Reader(stream), 1):
            try:
                ip = dpkt.ethernet.Ethernet(frame).data
                if not isinstance(ip, dpkt.ip.IP) or not isinstance(ip.data, dpkt.tcp.TCP) or ip.offset or ip.mf:
                    continue
                tcp = ip.data
                if str(ipaddress.ip_address(ip.dst)) != '10.0.2.2' or tcp.dport not in (ALLOWED, OUTSIDE) or b'\r\n\r\n' not in tcp.data:
                    continue
                request = dpkt.http.Request(tcp.data)
                if request.method != 'GET' or request.uri != path or request.headers.get('x-apk-audit-token') != token:
                    continue
                key = (bytes(ip.src), tcp.sport, tcp.dport, tcp.seq, bytes(tcp.data))
                if key in seen:
                    continue  # retransmitted request bytes are not independent requests
                seen.add(key)
                uid = trailer_uid(frame)
                candidates = [i + 1 for i, s in enumerate(servers) if s.get('token') == token and s.get('path') == path
                              and s.get('port') == tcp.dport and s.get('method') == 'GET' and s.get('status') == 200
                              and s.get('write_completed') is True and abs(timestamp(s['started_utc']) - (float(ts) + offset)) <= 1]
                linked = [r['flow_id'] for r in flows if r.get('attribution') == 'target' and r.get('uid') == target
                          and number in r.get('source_record', {}).get('packet_numbers', []) and r.get('port') == tcp.dport]
                rows.append({'packet': number, 'uid': uid, 'port': tcp.dport, 'host_time': float(ts) + offset,
                             'target_packet_uid': uid == target, 'target_flow_ids': linked,
                             'server_candidates': candidates, 'candidate_match': uid == target and bool(linked) and len(candidates) == 1})
            except (dpkt.UnpackError, AttributeError, ValueError):
                continue
    return rows


def assess_trial(directory, spec, servers):
    from .research_diagnosis import capture_gate, verify_run
    from .compare import compare
    directory = Path(directory); state = verify_run(directory)
    result = read_json(directory / 'findings.json'); static = read_json(directory / 'static.json')
    gate = capture_gate(directory)
    observations = request_evidence(directory, spec['token'], servers)
    good = [r for r in observations if r['candidate_match']]
    actual_ports = sorted(r['port'] for r in good)
    target_findings = [r for r in result['findings'] if r['subject'] == 'external_connection']
    expectations = {'controls_passed': gate['passed'], 'registered_scenario': state.get('analysis_scenario') == spec['scenario'],
                    'research_package': state.get('package') == PACKAGE,
                    'apk_identity': state.get('apk_sha256') == spec['apk_sha256'],
                    'declaration_before_analysis': result.get('intent_declaration_basis') == 'locally_recorded_before_static_analysis',
                    'same_intention': result['intent'] == intention(),
                    'request_ports_with_candidates': actual_ports == sorted(spec['expected_request_ports']),
                    'target_findings_match_witnesses': len(target_findings) == len(good) and
                        sorted(r.get('port') for r in target_findings) == actual_ports,
                    'no_unsupported_token_requests': len(observations) == len(good),
                    'permission_declaration': any(r['subject'] == 'permission_declaration' and r.get('value') == 'android.permission.ACCESS_FINE_LOCATION'
                                                  and r['verdict'] == 'mismatch_candidate' for r in result['findings']) == spec['expected_permission_mismatch'],
                    'unused_candidate_retained': any(r['host'] == '10.0.2.2' and r['port'] == UNUSED for r in static.get('urls', []))}
    correspondence = read_json(directory / 'correspondence.json')
    expectations['static_candidate_without_target_match'] = any(r['status'] == 'static_only' and
        r.get('static', {}).get('host') == '10.0.2.2' and r['static']['port'] == UNUSED for r in correspondence['records'])
    for port in spec['expected_request_ports']:
        expected = 'consistent_with_observed_evidence' if port == ALLOWED else 'mismatch_candidate'
        matching = [f for f in target_findings if f.get('port') == port and f['verdict'] == expected
                    and any(set(f['evidence_ids']) & set(w['target_flow_ids']) for w in good if w['port'] == port)]
        expectations['verdict_port_' + str(port)] = bool(matching)
    if spec['condition'] == 'delay30':
        expectations['withheld_not_absent'] = not target_findings and any(r['subject'] == 'target_observation_coverage'
                    and r['verdict'] == 'not_evaluable' and r['observation'] == 'not_observed' for r in result['findings'])
    if spec['condition'] == 'delay100':
        actions = [r for _, r in read_jsonl(directory / 'ui_events.jsonl') if r.get('event_id') == 'input' and r.get('success')]
        expectations['delayed_request_in_registered_window'] = len(actions) == 1 and all(
            74 <= r['host_time'] - timestamp(actions[0]['started_utc']) <= 100 for r in good) and bool(good)
    return {'trial_id': spec['trial_id'], 'condition': spec['condition'], 'checks': expectations,
            'status': 'supported_reference_expectation' if all(expectations.values()) else 'not_supported_or_incomplete',
            'observations': observations, 'capture_quality': state.get('dynamic_status'),
            'claim_scope': 'source-defined reference condition; no general accuracy, causal root or human benefit established'}


def compare_components(trial, destination):
    from .compare import compare
    from .report import report
    trial, destination = Path(trial), Path(destination)
    if destination.exists(): raise AuditError('Component output exists')
    rows = []
    for mode in ('static-only', 'dynamic-only', 'integrated'):
        out = destination / mode; shutil.copytree(trial, out)
        for pattern in ('summary.html', 'correspondence.*', 'difference-explanation.*'):
            for stale in out.glob(pattern): stale.unlink()
        state = read_json(out / 'run.json')
        state.update(analysis_mode='replay', component_replay_mode=mode, replay_source_analysis_mode=state.get('analysis_mode'))
        write_json(out / 'run.json', state)
        (out / 'REPLAY-README.md').write_text('保存原本の構成要素再解析です。新しい端末試行ではありません。正本はfindings.jsonです。\n')
        result = compare(out, read_json(trial / 'intent.json'), mode); report(out)
        rows.append({'mode': mode, 'permission_mismatches': sum(r['subject'] == 'permission_declaration' and r['verdict'] == 'mismatch_candidate' for r in result['findings']),
                     'static_url_candidates': sum(r['subject'] == 'static_url_candidate' for r in result['findings']),
                     'connection_consistent': sum(r['subject'] == 'external_connection' and r['verdict'] == 'consistent_with_observed_evidence' for r in result['findings']),
                     'connection_mismatch': sum(r['subject'] == 'external_connection' and r['verdict'] == 'mismatch_candidate' for r in result['findings'])})
    return rows


def review_study(study):
    """Verify retained files and recompute completed rows; no Android actions."""
    study = Path(study).resolve()
    inventory = read_json(study / 'EVIDENCE-MANIFEST.json')['files']
    for name, digest in inventory.items():
        path = (study / name).resolve()
        if not path.is_relative_to(study) or not path.is_file() or sha256(path) != digest:
            raise AuditError('Modified follow-up study member: ' + name)
    prepared = read_json(study / 'PREPARED.json')['files']
    for name, digest in prepared.items():
        if name not in inventory or sha256(study / name) != digest: raise AuditError('Prepared condition changed')
    plan = read_json(study / 'plan-before-analysis.json')
    if plan['profile'] != 'intent-followup-12-v1' or plan['planned_trials'] != 12 or plan['intent'] != intention():
        raise AuditError('Unexpected follow-up plan')
    from collections import Counter
    if Counter(t['condition'] for t in plan['trials']) != {c: 2 for c in CONDITIONS}: raise AuditError('Unexpected trial conditions')
    old = read_json(study / 'trial-results.json'); recorded = {r['trial_id'] for r in old}
    if len(recorded) != len(old) or not recorded.issubset({s['trial_id'] for s in plan['trials']}): raise AuditError('Duplicate/unregistered rows')
    rows, ids, captures = [], set(), set()
    for spec in plan['trials']:
        if spec['trial_id'] not in recorded: continue
        if not re.fullmatch(r'(normal|outside|mixed|permission|delay30|delay100)-00[12]', spec['trial_id']):
            raise AuditError('Invalid trial path')
        condition = spec['condition']
        expected_ports = [] if condition == 'delay30' else [ALLOWED, OUTSIDE] if condition == 'mixed' else [OUTSIDE] if condition in ('outside', 'delay100') else [ALLOWED]
        if (spec['expected_request_ports'] != expected_ports or spec['observe_s'] != (100 if condition == 'delay100' else 30)
                or spec['expected_permission_mismatch'] != (condition == 'permission') or not re.fullmatch('[a-f0-9]{32}', spec['token'])):
            raise AuditError('Source-defined expectation changed')
        directory = (study / spec['trial_id']).resolve()
        if not directory.is_relative_to(study): raise AuditError('Trial outside study')
        state = read_json(directory / 'run.json'); digest = sha256(directory / 'raw/automatic.pcap')
        if state['run_id'] in ids or digest in captures: raise AuditError('Repeated run/capture cannot count as a new trial')
        ids.add(state['run_id']); captures.add(digest)
        rows.append(assess_trial(directory, spec, read_json(study / (spec['trial_id'] + '.server.json'))))
    operator = read_json(study / 'operator-report.json')
    return {'profile': 'intent-followup-review-v1', 'completed_trials': len(rows), 'planned_trials': 12,
            'rows': rows, 'new_Android_trials': 0, 'independent_accuracy_established': False,
            'operator_report': operator,
            'all_reference_expectations_supported': len(rows) == 12 and operator.get('additional_actions') == 'none'
                and all(r['status'] == 'supported_reference_expectation' for r in rows)}


def record_state(adb, out, label):
    """Record target-package state, never clear caches/data or global logcat."""
    out = Path(out); out.mkdir(parents=True, exist_ok=True); errors = {}
    for name, args in [('package.txt', ('shell', 'dumpsys', 'package', PACKAGE)),
                       ('proxy.txt', ('shell', 'settings', 'get', 'global', 'http_proxy'))]:
        try: (out / (label + '-' + name)).write_text(adb.call(*args))
        except AuditError as exc: errors[name] = str(exc)
    write_json(out / (label + '-state.json'), {'utc': utc_now(), 'errors': errors,
               'state_restored': False, 'data_cleared': False, 'source_contract': 'reference source stores no app data; package dump is not a database snapshot'})


def run_suite(fixtures, out, serial='emulator-5554', non_interactive=False):
    from .android import Adb
    from .automatic import installed_hash
    from .cli import parser
    from .pipeline import analyze
    from .research_bundle import pack
    from .research_comparison import ReferenceServer
    from .research_contrast import device_preflight
    from .research_diagnosis import capture_gate
    fixtures, out = Path(fixtures).resolve(), Path(out).resolve()
    if out.exists(): raise AuditError('Output exists; preserve it and choose a new name')
    plan = prepare_plan(fixtures); device = device_preflight(serial); adb = Adb(serial)
    # `pm path` returns status 1 with empty stderr for an absent package on
    # Android 15. Query the package list first; absence is a normal first run.
    packages = adb.call('shell', 'pm', 'list', 'packages', '--user', '0', PACKAGE).splitlines()
    present = any(line.strip() == 'package:' + PACKAGE for line in packages)
    if present and installed_hash(adb, PACKAGE) not in {r['apk_sha256'] for r in plan['materials']['cases']}:
        raise AuditError('An unregistered app already uses the research package; no replacement performed')
    servers = []
    try:
        for port in (ALLOWED, OUTSIDE): servers.append(ReferenceServer(port))
    except OSError as exc:
        for server in servers: server.close()
        raise AuditError('Research ports 18861/18862 are busy; no trial started: ' + str(exc)) from exc
    out.mkdir(parents=True); write_json(out / 'plan-before-analysis.json', plan); write_json(out / 'intent-before-analysis.json', plan['intent'])
    write_json(out / 'device-preflight.json', device)
    write_json(out / 'PREPARED.json', {'files': {n: sha256(out / n) for n in ('plan-before-analysis.json', 'intent-before-analysis.json', 'device-preflight.json')},
                                     'module_sha256': {p.name: sha256(p) for p in Path(__file__).parent.glob('*.py')}, 'independent_attestation': False})
    attempts, rows, failure = [], [], None
    try:
        for server in servers: server.start()
        for index, spec in enumerate(plan['trials'], 1):
            print(f"追加評価 {index}/12：{spec['trial_id']}（入力後{spec['observe_s']}秒）。追加操作はせず同意画面のみ確認してください。", flush=True)
            trial = out / spec['trial_id']; scenario = out / (spec['trial_id'] + '.scenario.json'); write_json(scenario, spec['scenario'])
            attempts.append({'trial_id': spec['trial_id'], 'started_utc': utc_now()}); write_json(out / 'attempts.json', attempts)
            record_state(adb, out / 'state' / spec['trial_id'], 'before')
            primary = None
            try:
                args = parser().parse_args(['analyze', '--apk', str(fixtures / spec['apk']), '--intent', str(out / 'intent-before-analysis.json'),
                      '--scenario', str(scenario), '--serial', serial, '--out', str(trial)])
                result, code = analyze(args)
                if code or result.get('error'): raise AuditError(result.get('error') or 'Pipeline failed')
            except (Exception, KeyboardInterrupt) as exc:
                primary = exc; raise
            finally:
                try:
                    adb.call('shell', 'am', 'force-stop', PACKAGE); attempts[-1]['cleanup_confirmed'] = True
                    record_state(adb, out / 'state' / spec['trial_id'], 'after')
                except (Exception, KeyboardInterrupt) as exc:
                    attempts[-1]['cleanup_error'] = str(exc)
                    if primary is None: raise
                finally:
                    attempts[-1]['ended_utc'] = utc_now(); write_json(out / 'attempts.json', attempts)
            if not capture_gate(trial)['passed']: raise AuditError('Capture controls incomplete; later trials stopped')
            events = [r for s in servers for r in s.snapshot() if r.get('token') == spec['token']]
            write_json(out / (spec['trial_id'] + '.server.json'), events)
            row = assess_trial(trial, spec, events)
            row['component_replay'] = compare_components(trial, out / 'component-replay' / spec['trial_id'])
            rows.append(row); write_json(out / 'trial-results.json', rows)
    except (Exception, KeyboardInterrupt) as exc:
        failure = {'type': type(exc).__name__, 'message': str(exc)}; write_json(out / 'failure.json', failure)
    finally:
        for server in servers: server.close()
        operator = 'unknown'
        if sys.stdin.isatty() and not non_interactive and failure is None:
            try: operator = {'0': 'none', '1': 'reported', '2': 'unknown'}.get(input('観測中の追加操作：0=なし、1=あり、2=不明: ').strip(), 'unknown')
            except (EOFError, KeyboardInterrupt): pass
        write_json(out / 'operator-report.json', {'additional_actions': operator, 'basis': 'post_capture_self_report', 'all_input_objectively_monitored': False})
        write_json(out / 'trial-results.json', rows)
        write_json(out / 'server-events.json', [r for s in servers for r in s.snapshot()])
        write_json(out / 'EVIDENCE-MANIFEST.json', {'files': {str(p.relative_to(out)): sha256(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name != 'EVIDENCE-MANIFEST.json'}})
    archive = pack(out)
    return {'profile': plan['profile'], 'planned_trials': 12, 'completed_trials': len(rows), 'error': failure,
            'supported_reference_expectations': sum(r['status'] == 'supported_reference_expectation' for r in rows),
            'operator_additional_actions': operator,
            'archive': str(archive), 'independent_accuracy_established': False}, 4 if failure else 0


def create_starter(out, network, endpoints, package, activity=None, uri=None, purpose='未指定（利用者が確認して編集する）', permissions=()):
    """Explicit choices only; no observed endpoint becomes an intention by default."""
    from .contracts import validate_intent, validate_open_uri
    out = Path(out)
    if out.exists(): raise AuditError('Configuration output exists')
    net = {'mode': network}
    if network == 'allowlist':
        rules = []
        for endpoint in endpoints:
            u = urlsplit(endpoint)
            step = {'uri': endpoint, 'activity': activity or package + '/.MainActivity'}
            validate_open_uri(step, package)
            rules.append({'host': u.hostname, 'ports': [u.port or (443 if u.scheme == 'https' else 80)],
                          'include_subdomains': False, 'application_protocols': [u.scheme]})
        net['allowed_destinations'] = rules
    elif endpoints:
        raise AuditError('Endpoints require allowlist mode')
    if network == 'allowlist_or_recorded_inputs': net.update(allowed_destinations=[], recorded_input_protocols=['http', 'https'])
    policy = {'schema_version': '1.1', 'intent_id': 'user-starter-v1', 'app_purpose': purpose, 'network': net,
              'permissions': {'mode': 'allowlist', 'allowed': list(permissions)} if permissions else {'mode': 'unspecified'},
              'sdk': {'mode': 'unspecified'}, 'cleartext_policy': 'unspecified', 'background_network_policy': 'unspecified'}
    policy = validate_intent(policy)
    if bool(activity) != bool(uri): raise AuditError('Supply both activity and URI, or neither')
    scenario = {'schema_version': '1.0', 'scenario_id': 'user-starter-v1', 'execution': 'automatic', 'repetitions': 1,
                'steps': [{'id': 'launch', 'action': 'launch', 'observe_s': 30}]}
    if uri:
        step = {'id': 'input', 'action': 'open_uri', 'activity': activity, 'uri': uri, 'observe_s': 30}
        validate_open_uri(step, package); scenario['steps'][0]['observe_s'] = 5; scenario['steps'].append(step)
    if not re.fullmatch(r'[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+', package): raise AuditError('Invalid package')
    out.mkdir(parents=True); write_json(out / 'intent.json', policy); write_json(out / 'scenario.json', scenario)
    write_json(out / 'preparation.json', {'generated_utc': utc_now(), 'package': package, 'declaration_confirmed_by_user': False,
                                        'network_choices_explicit': True, 'not_inferred_from_capture': True})
    (out / 'READ_FIRST.md').write_text('生成した条件を解析前に確認してください。未指定を禁止へ変更する必要はありません。\n'
                                     '起動だけでは全機能を実行しません。登録入力先の許可には明示URI操作等が必要です。\n'
                                     'この生成自体は人手負担の削減効果を測った結果ではありません。\n')
    return {'out': str(out.resolve()), 'intent': str(out / 'intent.json'), 'scenario': str(out / 'scenario.json'), 'user_review_required': True}
