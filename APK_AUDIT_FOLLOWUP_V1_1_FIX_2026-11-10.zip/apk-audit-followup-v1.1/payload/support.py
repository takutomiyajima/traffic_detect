"""Explain a finding's recorded basis separately from whole-capture coverage.

This is a presentation layer. It never upgrades a verdict, attributes a flow,
or turns partial capture into evidence that a connection did not occur.
"""
from pathlib import Path
import html

from .core import read_json, read_jsonl, sha256, write_json


def build_support(out, result):
    out = Path(out).resolve()
    run = read_json(out / 'run.json')
    index = read_json(out / 'evidence/index.json')
    flows = {r['flow_id']: r for _, r in read_jsonl(out / 'flows.jsonl') if 'flow_id' in r}
    hashes = {}
    rows = []
    for finding in result['findings']:
        checks = []
        for eid in finding['evidence_ids']:
            item = index.get(eid)
            if not item:
                checks.append(False)
                continue
            path = (out / item['path']).resolve()
            if not path.is_relative_to(out) or not path.is_file():
                checks.append(False)
                continue
            if path not in hashes:
                hashes[path] = sha256(path)
            checks.append(hashes[path] == item['sha256'])
        selected = [flows[eid] for eid in finding['evidence_ids'] if eid in flows]
        evidence = 'verified' if checks and all(checks) else 'missing_or_modified' if checks else 'not_referenced'
        observations = sorted({r.get('observation', 'unknown') for r in selected})
        phase = sorted({r.get('ui_phase_status', 'not_recorded') for r in selected})
        rows.append({'finding_id': finding['finding_id'], 'subject': finding['subject'],
                     'verdict': finding['verdict'], 'evidence_integrity': evidence,
                     'attribution': finding.get('attribution', 'unknown'),
                     'observation': finding.get('observation', 'static_only'),
                     'protocol': finding.get('application_protocol'),
                     'ui_interval_status': phase, 'flow_observations': observations,
                     'intent_declaration_basis': result.get('intent_declaration_basis', 'not_recorded'),
                     'evidence_ids': finding['evidence_ids'],
                     'scope': 'static_declaration_or_candidate' if finding.get('observation') == 'static_only' else 'recorded_observation_or_gap',
                     'absence_supported': False})
    support = {'profile': 'finding-evidence-scope-v1', 'run_id': run['run_id'],
               'evidence_mode': result.get('evidence_mode', 'integrated'),
               'capture_quality': run.get('dynamic_status', 'not_run'),
               'capture_conditions': [{'source_id': c['id'], 'coverage': c.get('metadata', {}).get('coverage_status', 'not_recorded'),
                                       'clock': c.get('metadata', {}).get('clock_alignment_status', 'not_recorded')}
                                      for c in run.get('captures', [])],
               'findings': rows, 'policy_verdicts_changed': False,
               'interpretation': 'Recorded basis and coverage are different axes. Verified hashes do not validate meaning, UID truth, payload or safety. No absence claim.'}
    write_json(out / 'evidence-support.json', support)
    return support


def html_section(support):
    esc = lambda v: html.escape(str(v), quote=True)
    names = {'verified': '参照先とhash一致', 'missing_or_modified': '参照の欠落・変更', 'not_referenced': '原本参照なし'}
    owners = {'target': '対象UID', 'other': '別UID', 'unknown': '帰属不明', 'related_candidate': '関連候補'}
    stages = {'static_only': '宣言・静的候補', 'http_observed': 'HTTP要求を観測', 'connection_attempt': '接続試行',
              'transport_established': 'TCP成立', 'tls_established': 'TLS成立', 'not_observed': '対象未観測', 'capture_failed': '取得不足'}
    phases = {'within_interval_under_clock_assumptions': '時計補正の仮定下で区間内',
              'boundary_uncertain': '時刻の境界で不確か', 'not_linked': '操作区間と未対応', 'not_recorded': '区間情報なし'}
    selected = [r for r in support['findings'] if r['subject'] == 'external_connection' or
                r['verdict'] in ('mismatch_candidate', 'not_evaluable') and r['attribution'] != 'other']
    table = []
    for row in selected[:30]:
        intervals = ', '.join(phases.get(value, value) for value in row['ui_interval_status']) or '対象区間の参照なし'
        table.append('<tr><td>'+esc(row['finding_id'])+'</td><td>'+esc(names[row['evidence_integrity']])+
                     '</td><td>'+esc(owners.get(row['attribution'], row['attribution']))+'</td><td>'+
                     esc(stages.get(row['observation'], row['observation']))+' / '+esc(row['protocol'] or '方式の評価なし・不明')+
                     '</td><td>'+esc(intervals)+'</td></tr>')
    return ('<section id="evidence-scope"><h2>指摘の根拠と、観測できた範囲</h2>'
            '<p>取得全体の品質：<b>'+esc(support['capture_quality'])+'</b>。観測した要求は個別に確認し、未観測から通信の不存在を導きません。</p>'
            '<table><tr><th>指摘</th><th>原本への参照</th><th>帰属</th><th>観測・方式</th><th>操作時刻の対応</th></tr>'+
            ''.join(table)+'</table><p>hash一致はファイルの同一性の確認です。判定の正しさ、UIDの独立した正確性、本文や安全性の保証ではありません。'
            '最大30行の要約です。<a href="evidence-support.json">全指摘の根拠情報JSON</a></p></section>')
