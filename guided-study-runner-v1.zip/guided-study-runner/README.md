# 次の実験：接続失敗・HTTPSの取得手順

2026年10月31日。保存済み13試行の解析はGPT側で実行済みです。この配布物では、新しい端末実験の開始・停止・CSV出力だけを手元で行います。Python標準ライブラリで動作し、pipによる追加導入は不要です。

## 1. 準備

1. `guided-study-runner-v1.zip` を展開し、`guided-study-runner` をDocumentsへ置きます。以前のランナーは上書きしません。
2. VSCodeでこの新しいフォルダを開きます。
3. Android Studioで既存の `Pixel_8_Edited_API_35` を起動します。対象は `emulator-5554`、API35、arm64-v8aです。
4. 以前のPython参照サーバーがまだ起動中なら、そのターミナルでCtrl+Cで停止します。今回のランナーが対照用サーバーを起動します。
5. PCAPdroid 2.0.2を開き、取得対象を「全アプリ」、VPN方式、TLS復号なしにします。UDPだけの取得フィルターを残さないでください。CSVは全接続を保存します。

ターミナルで次を実行します。

```bash
cd "$HOME/Documents/guided-study-runner"
python3 run_guided_trial.py --case http_fail --check
```

`ready: true` は基本環境と配布物hashの確認です。端末での実験成功やポート空きの保証ではありません。本番開始時に、凍結したAVD条件とポート確保も確認します。HTTP proxyは自動変更しません。以前の10.0.2.2:8082を再設定する必要はありません。

## 2. 最初は接続失敗を1件だけ取得する

```bash
python3 run_guided_trial.py --case http_fail --trial-id http-fail-001
```

この条件では、同じHTTP v1.1アプリを10.0.2.2:18765へ接続させます。ホストでは18765をbindだけしてlistenせず、無関係なサーバーが同じポートを使うことを防ぎます。対照用の8765は正常に稼働させます。既存プロセスが18765を使っている場合、勝手に停止せず実験開始前に中断します。

手動操作は、ランナーの表示に合わせて行います。

1. 開始の指示が出たら、PCAPdroidで新しい記録を開始し、Mac側で `start` と入力します。
2. Chromeの前対照、対象アプリの起動とボタン1回押下、30秒待機、後対照は自動です。対象アプリのボタンを追加で押さないでください。
3. Chromeの対照を自動で読めない場合だけ、画面に `ok:true` があることを確認して `ok` と入力します。見えない場合は中止し、成功と申告しません。
4. 停止の指示が出たらPCAPdroidを停止し、Mac側で `stop` と入力します。
5. 途中停止やエラーの有無を実際に応じて `none` / `problem` / `unknown` で回答します。
6. PCAPdroidの接続一覧をCSVへエクスポートし、Downloadへ `capture-http-fail-001.csv` の名前で保存します。
7. 保存先の入力でEnterを押します。別名なら実際のパスを入力し、場所が不明なら `list` を入力します。

この実験で `http_error=ConnectException` または `http_error=SocketTimeoutException` は、予定した通信不成功の結果です。前後対照の成功と分けて確認します。接続試行のCSV行がUnknownまたは欠落していれば、それも研究対象として残します。識別できるようにUIDを編集しません。

出力は次の場所です。

```text
guided-study-runner/handoff/http-fail-001.zip
```

まずこのZIPをチャットに添付してください。001を確認してから同条件を増やすことで、設定不良のまま反復することを避けます。

## 3. 確認後の残りの接続失敗

```bash
python3 run_guided_trial.py --case http_fail --trial-id http-fail-002
python3 run_guided_trial.py --case http_fail --trial-id http-fail-003
```

各回で同じ開始・停止・CSV保存を行い、CSV名のID部分をその試行に合わせます。保存先が既にある場合は上書きせず停止します。失敗した試行も削除せず、新しいIDで追加する場合は理由を残します。

## 4. 次にHTTPS正常通信

```bash
python3 run_guided_trial.py --case https --check
python3 run_guided_trial.py --case https --trial-id https-001
```

手動操作は同じです。CSV名は `capture-https-001.csv`、作成されるZIPは `handoff/https-001.zip` です。001でアプリ200応答とサーバーのHTTPS受信等を確認してから、次を実行します。

```bash
python3 run_guided_trial.py --case https --trial-id https-002
python3 run_guided_trial.py --case https --trial-id https-003
```

HTTPS用の自作アプリv1.2には、この実験用証明書だけを信頼するNetwork Security Configを組み込んでいます。TLSとホスト名の標準検証を使い、検証を無効化しません。OSへのCA導入、root化、プロキシ設定変更、PCAPdroidの復号設定は不要です。

同梱の証明書と鍵は、このループバック研究用サーバーの固定fixtureです。信頼設定はこの自作アプリに限定され、一般アプリの標準設定によるHTTPSを代表する実験とは区別します。証明書期限を過ぎた場合はfixtureとAPKを更新した別条件が必要です。

## 5. 通信なしは保存済み原本を先に確認する

以前の追加試行ZIPがあれば、それを添付すれば十分です。同じ試行の再取得は不要です。原本がない場合だけ、接続失敗とHTTPSの後に次を実施します。

```bash
python3 run_guided_trial.py --case offline --trial-id offline-prospective-001
python3 run_guided_trial.py --case offline --trial-id offline-prospective-002
```

取得前後のChrome通信は対照として残ります。全CSVが空になることを期待せず、対象UIDの記録と対象受信を分けて評価します。

## 6. 自動で保存・確認するもの

APKのインストールと端末hash・UID、取得前ポリシー、取得前の期待値、凍結した研究計画・正解仕様、前後時計、前後対照、UI、画面、アプリログ、サーバーログ、CSV、manifest、ZIPを保存します。

`study/protocol.json`、`gold-spec.json`、`FROZEN-MANIFEST.json` は将来の取得前に用意した設計です。配布物のhashを実行前に確認し、各試行へ計画と正解仕様をコピーします。これは第三者による事前登録や独立した正解確認を意味しません。実測値を期待値へ書き換えません。

自動化しても、PCAPdroidの実際の取得継続は実験者の申告であり、時計差も条件付きです。取得品質partialを維持します。

## 7. 結果が要確認・失敗の場合

`collected_needs_review` は、UID不明、CSV行欠落、時計・対照の不整合等を含む記録です。通信なしや成功へ変更せず、ZIPをそのまま添付してください。

`failed` / `cancelled` でもZIPがあれば保存します。PCAPdroidの停止を確認できなかった旨が表示された場合は、端末で手動停止します。同じIDを上書きせず、どこで止まったかを残します。

この配布物はホスト上の模擬ADB/UIと実際のループバックサーバーで確認しています。新しい接続失敗・HTTPSプロファイルのAndroid実測は、これから取得します。
