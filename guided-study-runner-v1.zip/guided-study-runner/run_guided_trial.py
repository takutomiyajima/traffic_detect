#!/usr/bin/env python3
"""Guided API-35 control trials: PCAPdroid start/stop/export remain manual."""
from __future__ import annotations

import argparse
import contextlib
import csv
import hashlib
import ipaddress
import json
import platform
import re
import shlex
import shutil
import socket
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
if not (HERE / 'apk_audit').is_dir():
    sys.path.insert(0, str(HERE.parent / 'src'))
from apk_audit.control_server import ControlServers
from apk_audit.core import write_json
import measure_android_clock as clock

TLS_CERT = HERE / 'tls/lab-server-cert.pem' if (HERE / 'tls').is_dir() else HERE.parent / 'fixtures/research-tls/lab-server-cert.pem'
TLS_KEY = TLS_CERT.with_name('lab-server-key.pem')
TLS_CERT_SHA256 = '0b7a2a3b03d0e87c7f65231affa1fe06aa385c4fe63bd2004f990bda0199e7a5'

CASES = {
    'offline': {'sha256': '39dd104a69408f8f49a60934388933c2dd2cf855c1abed2faf0f3147d75f6280',
                'expected': 'local_only_completed', 'port': None, 'ipproto': None},
    'http': {'sha256': '7c7f24e82c80fb1e51df96923dda326571d3c706d496e03efb6373647df01382',
             'expected': 'http_response=200', 'port': 8765, 'ipproto': '6'},
    'http_fail': {'sha256': '7c7f24e82c80fb1e51df96923dda326571d3c706d496e03efb6373647df01382',
                  'expected': 'http_error=ConnectException',
                  'expected_results': ['http_error=ConnectException', 'http_error=SocketTimeoutException'],
                  'port': 18765, 'ipproto': '6', 'kind': 'http', 'package_case': 'http',
                  'log_case': 'http', 'intentional_connection_failure': True,
                  'apk_relative': 'runs/control-apks-v3-ui/http.apk'},
    'https': {'sha256': '12cb8e27ab3c3864114e784799d78d450bde49b916edebed11c8a1f755b4311c',
              'expected': 'http_response=200', 'port': 8767, 'ipproto': '6',
              'apk_relative': 'runs/control-apks-v5-https-trust/https.apk'},
    'udp': {'sha256': '360dc7df93299f48b9b158a48de3e1f0d7cf570b57940e1b8d16cf15e12ad359',
            'expected': 'udp_sent', 'port': 8766, 'ipproto': '17'},
    'udp_hold': {'sha256': '1236cb4fe9d3034c6bd5f5726d9402f0ab2f80ca9c30114c27d59fd54d3ec9d7',
                 'expected': 'udp_sent', 'port': 8766, 'ipproto': '17', 'kind': 'udp',
                 'package_case': 'udp', 'log_case': 'udp', 'socket_hold_ms': 2000,
                 'apk_relative': 'runs/control-apks-v4-udp-hold/udp.apk'},
}
PCAP_PACKAGE = 'com.emanuelef.remote_capture'
CHROME = 'com.android.chrome'
HEADER = 'IPProto,SrcIP,SrcPort,DstIp,DstPort,UID,App,PackageName,Proto,Status,Info,BytesSent,BytesRcvd,PktsSent,PktsRcvd,FirstSeen,LastSeen'.split(',')


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


class TrialError(Exception):
    pass


def verify_bundle(root=None):
    root = Path(root or HERE).resolve()
    manifest = root / 'BUNDLE-MANIFEST.json'
    if not manifest.is_file():
        return None
    entries = json.loads(manifest.read_text())['files']
    for entry in entries:
        path = (root / entry['path']).resolve()
        if not path.is_relative_to(root) or not path.is_file() or digest(path) != entry['sha256'] or path.stat().st_size != entry['bytes']:
            raise TrialError('配布物のhashが一致しません。元のZIPを新しいフォルダに展開してください。')
    return digest(manifest)


def installation_uid(text):
    values = re.findall(r'^\s+(?:appId|userId)=(\d+)\b', text, re.M)
    if not values or len(set(values)) != 1 or not re.search(r'^\s+User 0:.*installed=true', text, re.M):
        raise TrialError('User 0のインストールUIDを確認できません。package情報を保存して停止します。')
    return int(values[0])


def button_center(root, resource_id):
    nodes = [n for n in root.iter('node') if n.get('resource-id') == resource_id]
    if len(nodes) != 1 or nodes[0].get('enabled') != 'true' or nodes[0].get('visible-to-user') == 'false':
        raise TrialError('Runボタンを一意に確認できません。再タップせず停止します。')
    m = re.fullmatch(r'\[(\d+),(\d+)\]\[(\d+),(\d+)\]', nodes[0].get('bounds', ''))
    if not m:
        raise TrialError('Runボタンの位置を取得できません。')
    x0, y0, x1, y1 = map(int, m.groups())
    if x1 <= x0 or y1 <= y0 or nodes[0].get('clickable') != 'true':
        raise TrialError('Runボタンの操作可能状態を確認できません。')
    return (x0 + x1) // 2, (y0 + y1) // 2


def policy_for(case, http_port=8765, udp_port=8766, failure_port=18765, https_port=8767):
    failure = CASES[case].get('intentional_connection_failure', False)
    case = CASES[case].get('kind', case)
    network = {'mode': 'deny_all'} if case == 'offline' else {
        'mode': 'allowlist', 'allowed_destinations': [
            {'host': '10.0.2.2', 'include_subdomains': False,
             'ports': [failure_port if failure else http_port if case == 'http' else https_port if case == 'https' else udp_port], 'application_protocols': []}]}
    return {'schema_version': '1.0', 'app_purpose': f'{case}: 自作対照APKの取得前に固定するポリシー。',
            'network': network, 'sdk': {'mode': 'unspecified'},
            'permissions': {'mode': 'deny_all'} if case == 'offline' else {
                'mode': 'allowlist', 'allowed': ['android.permission.INTERNET']},
            'cleartext_policy': 'forbid' if case in ('offline', 'https') else 'allow',
            'background_network_policy': 'unspecified'}


class Adb:
    def __init__(self, serial, log=None):
        self.serial, self.log = serial, log
        self.last_ui_xml = ''

    def run(self, *args, binary=False, allow_error=False, timeout=20):
        argv = ['adb', '-s', self.serial, *map(str, args)]
        try:
            p = subprocess.run(argv, capture_output=True, timeout=timeout)
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise TrialError(f'ADBの実行に失敗: {exc}') from exc
        if self.log:
            self.log('adb_command', argv=argv, returncode=p.returncode,
                     stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),
                     stderr=p.stderr.decode(errors='replace')[-2000:])
        text = p.stdout.decode(errors='replace')
        if not allow_error and (p.returncode or any(s in text for s in ('Error:', 'Failure [', 'KO:'))):
            raise TrialError(f'ADB失敗: {(p.stderr.decode(errors="replace") or text)[-2000:]}')
        return p.stdout if binary else text

    def shell(self, *args, **kwargs):
        return self.run('shell', shlex.join([str(a) for a in args]), **kwargs)

    def ui(self):
        remote = f'/data/local/tmp/apk-audit-guided-{self.serial}.xml'
        try:
            self.shell('uiautomator', 'dump', remote, timeout=12)
            self.last_ui_xml = self.run('exec-out', 'cat', remote)
            return ET.fromstring(self.last_ui_xml)
        except ET.ParseError as exc:
            raise TrialError('UI XMLを解析できません。') from exc
        finally:
            try:
                self.shell('rm', '-f', remote, allow_error=True, timeout=3)
            except TrialError:
                if self.log:
                    self.log('ui_temp_cleanup_failed', remote_path=remote)

    def screenshot(self, path):
        data = self.run('exec-out', 'screencap', '-p', binary=True)
        if not data.startswith(b'\x89PNG\r\n\x1a\n'):
            raise TrialError('スクリーンショットがPNGではありません。')
        Path(path).write_bytes(data)


def check_environment(adb):
    if adb.run('get-state').strip() != 'device':
        raise TrialError('エミュレータがdevice状態ではありません。')
    if adb.shell('am', 'get-current-user').strip() != '0':
        raise TrialError('この版はAndroid User 0のみ対応します。')
    api = adb.shell('getprop', 'ro.build.version.sdk').strip()
    if api != '35':
        raise TrialError(f'この手順の対象はAPI 35です。実際の値: {api}')
    proxy = adb.shell('settings', 'get', 'global', 'http_proxy').strip()
    if proxy not in ('', ':0', 'null'):
        raise TrialError(f'HTTP proxyが設定されています: {proxy}。設定は自動変更しません。')
    pcap = adb.shell('dumpsys', 'package', PCAP_PACKAGE)
    if not re.search(r'^\s+versionName=2\.0\.2\s*$', pcap, re.M):
        raise TrialError('このランナーはPCAPdroid 2.0.2を対象にしています。')
    chrome = adb.shell('dumpsys', 'package', CHROME)
    chrome_uid = installation_uid(chrome)
    avd_raw = adb.run('emu', 'avd', 'name').strip()
    return {
        'serial': adb.serial, 'android_api': int(api),
        'abi': adb.shell('getprop', 'ro.product.cpu.abilist').strip(),
        'fingerprint': adb.shell('getprop', 'ro.build.fingerprint').strip(),
        'avd_name': next((s for s in avd_raw.splitlines() if s and s != 'OK'), ''),
        'avd_name_raw': avd_raw, 'http_proxy': proxy, 'adb_version': adb.run('version').strip(),
        'host': {'os': platform.platform(), 'architecture': platform.machine(), 'python': platform.python_version()},
        'chrome_uid': chrome_uid, 'pcapdroid_package_dump': pcap, 'chrome_package_dump': chrome,
    }


class GuidedTrial:
    def __init__(self, case, trial_id, out, apk, serial='emulator-5554', observe_s=30,
                 http_port=8765, udp_port=8766, adb=None, input_func=input,
                 sleep_func=time.sleep, server_factory=ControlServers, failure_port=18765, https_port=8767):
        self.case, self.spec = case, CASES[case]
        self.kind = self.spec.get('kind', case)
        self.trial_id, self.out, self.apk = trial_id, Path(out), Path(apk)
        self.serial, self.observe_s = serial, observe_s
        self.http_port, self.udp_port = http_port, udp_port
        self.failure_port = failure_port
        self.https_port = https_port
        self.adb = adb or Adb(serial, self.event)
        self.input, self.sleep, self.server_factory = input_func, sleep_func, server_factory
        self.logcat = None
        self.logcat_streams = []
        self.capture_active = False
        self.controls = {}
        self.server_event_lock = None
        self.state = {'schema_version': '1.0', 'trial_id': trial_id, 'case': case,
                      'status': 'running', 'created_utc': utc(), 'execution_method': 'guided_manual_capture',
                      'policy_timing': 'before_capture', 'tap_count': 0,
                      'quality': 'partial', 'coverage_status': 'unknown', 'clock_alignment_status': 'unknown',
                      'udp_socket_hold_ms': self.spec.get('socket_hold_ms', 0),
                      'limitations': ['Operator controls PCAPdroid; the program cannot independently verify capture state',
                                      'A successful collection is not proof of absence, accuracy, privacy or safety',
                                      'Clock endpoint batches do not bound drift during the complete capture',
                                      'This runner supports the pinned self-authored API-35 controls, not arbitrary app workflows']}

    def expected_results(self):
        return self.spec.get('expected_results', [self.spec['expected']])

    @contextlib.contextmanager
    def reference_servers(self):
        with contextlib.ExitStack() as stack:
            if self.spec.get('intentional_connection_failure'):
                if self.failure_port in (self.http_port, self.udp_port):
                    raise TrialError('失敗試験のポートが対照サーバーと重なっています。')
                guard = stack.enter_context(socket.socket(socket.AF_INET, socket.SOCK_STREAM))
                try:
                    guard.bind(('127.0.0.1', self.failure_port))
                except OSError as exc:
                    raise TrialError('失敗試験のポートを確保できません。既存プロセスを停止せず中断します。') from exc
                # Keep the port bound, never listen. Prevent an unrelated server
                # from taking this port while HTTP/UDP controls remain alive.
                self.state['failure_endpoint'] = {'host': '10.0.2.2', 'port': self.failure_port,
                                                  'host_guard': 'bound_without_listen'}
                self.event('failure_port_guard_active', port=self.failure_port)
            options = {'http_port': self.http_port, 'udp_port': self.udp_port}
            if self.kind == 'https':
                if not TLS_CERT.is_file() or digest(TLS_CERT) != TLS_CERT_SHA256 or not TLS_KEY.is_file():
                    raise TrialError('実験用TLS証明書・鍵が見つからないか、証明書hashが違います。')
                options.update(https_port=self.https_port, tls_cert=str(TLS_CERT), tls_key=str(TLS_KEY))
                shutil.copyfile(TLS_CERT, self.out / 'lab-server-cert.pem')
                self.state['tls_trust_profile'] = 'lab_certificate_embedded_in_this_control_APK_only'
                self.state['tls_certificate_sha256'] = TLS_CERT_SHA256
            yield stack.enter_context(self.server_factory(self.out / 'server-events.jsonl', **options))

    def event(self, event, **fields):
        if self.out.is_dir():
            with (self.out / 'runner-events.jsonl').open('a', encoding='utf-8') as stream:
                stream.write(json.dumps({'utc': utc(), 'monotonic_s': time.monotonic(), 'event': event, **fields}, ensure_ascii=False) + '\n')

    def stamp(self, filename):
        (self.out / filename).write_text(utc() + '\n')

    def confirm(self, prompt, token):
        while True:
            answer = self.input(prompt + f'\n完了したら {token} と入力してEnter（中止は q）: ').strip()
            if answer.lower() == 'q':
                raise KeyboardInterrupt()
            if answer == token:
                self.event('operator_confirmation', token=token)
                return
            print(f'続行する場合は {token} を入力してください。', flush=True)

    def measure_clock(self, phase):
        samples = []
        for _ in range(5):
            try:
                samples.append(clock.sample(self.serial))
            except (OSError, ValueError, subprocess.SubprocessError) as exc:
                samples.append({'error': type(exc).__name__, 'detail': str(exc)})
                break
        record = {'schema_version': '1.0', 'serial': self.serial, 'recorded_utc': utc(),
                  'expected_samples': 5, 'samples': samples, 'summary': clock.summarize(samples, 5),
                  'method': 'host brackets around adb shell date +%s.%N',
                  'limitations': ['Batch assumptions only; no capture-wide drift guarantee']}
        write_json(self.out / f'clock-{phase}.json', record)
        return record

    def start_logcat(self):
        for name in ('app-logcat.txt', 'app-logcat-stderr.txt'):
            self.logcat_streams.append((self.out / name).open('wb'))
        self.logcat = subprocess.Popen(
            ['adb', '-s', self.serial, 'logcat', '-v', 'epoch', '-T', '1', 'ApkAuditControl:I', 'AndroidRuntime:E', '*:S'],
            stdout=self.logcat_streams[0], stderr=self.logcat_streams[1], start_new_session=True)

    def stop_logcat(self):
        if self.logcat and self.logcat.poll() is None:
            self.logcat.terminate()
            try:
                self.logcat.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.logcat.kill()
                self.logcat.wait(timeout=5)
                self.state['logcat_forced_kill'] = True
        for stream in self.logcat_streams:
            stream.close()
        self.logcat_streams = []

    def server_events(self):
        with self.server_event_lock or contextlib.nullcontext():
            return [json.loads(line) for line in (self.out / 'server-events.jsonl').read_text().splitlines() if line.strip()]

    def save_ui(self, name, root):
        (self.out / name).write_text(ET.tostring(root, encoding='unicode'), encoding='utf-8')

    def health(self, phase):
        start = utc()
        existing = {e.get('event_id') for e in self.server_events()}
        url = f'http://10.0.2.2:{self.http_port}/health?check={self.trial_id}-{phase}'
        self.adb.shell('am', 'start', '-W', '-a', 'android.intent.action.VIEW', '-d', url, '-p', CHROME)
        until = time.monotonic() + 12
        candidates = []
        while time.monotonic() < until:
            candidates = [e for e in self.server_events() if e.get('event') == 'http_request_received'
                          and e.get('method') == 'GET' and e.get('event_id') not in existing]
            if candidates:
                break
            self.sleep(0.2)
        if not candidates:
            raise TrialError(f'{phase}対照のサーバGETを確認できません。')
        verified_id = None
        try:
            root = self.adb.ui()
            self.save_ui(f'health-{phase}-ui.xml', root)
            text = ' '.join(n.get('text', '') + ' ' + n.get('content-desc', '') for n in root.iter('node'))
            candidates = [e for e in self.server_events() if e.get('event') == 'http_request_received'
                          and e.get('method') == 'GET' and e.get('event_id') not in existing]
            ids = set(re.findall(r'event_id[\s"\x27:]+([a-f0-9]{32})', text))
            if re.search(r'["\x27]?ok["\x27]?\s*:\s*true', text):
                verified_id = next((e['event_id'] for e in candidates if e['event_id'] in ids), None)
        except TrialError as exc:
            self.event('browser_ui_read_failed', phase=phase, detail=str(exc))
        self.adb.screenshot(self.out / f'health-{phase}.png')
        if not verified_id:
            self.confirm(f'Chromeの{phase}対照を自動読取りできませんでした。エミュレータに ok:true が見えることを確認してください。', 'ok')
        self.controls[phase] = {'started_utc': start, 'ended_utc': utc(),
                                'verification': 'ui_and_server_event_id' if verified_id else 'operator_visual_attestation_and_new_server_get',
                                'verified_event_id': verified_id, 'candidate_event_ids': [e['event_id'] for e in candidates]}
        write_json(self.out / 'browser-controls.json', self.controls)

    def run_action(self):
        package = 'org.example.apkaudit.' + self.spec.get('package_case', self.case)
        argv = ['am', 'start', '-S', '-n', package + '/.MainActivity', '--es', 'run_id', self.trial_id]
        if self.kind == 'http':
            port = self.failure_port if self.spec.get('intentional_connection_failure') else self.http_port
            argv += ['--es', 'endpoint', f'http://10.0.2.2:{port}/collect']
        elif self.kind == 'https':
            argv += ['--es', 'endpoint', f'https://10.0.2.2:{self.https_port}/collect']
        elif self.kind == 'udp':
            argv += ['--es', 'endpoint', f'10.0.2.2:{self.udp_port}']
        self.adb.shell(*argv)
        root = self.adb.ui()
        self.save_ui('app-before-ui.xml', root)
        statuses = [n.get('text', '') for n in root.iter('node') if n.get('resource-id') == package + ':id/status']
        if len(statuses) != 1 or not statuses[0].startswith('waiting'):
            raise TrialError('新しいActivityのwaiting状態を確認できません。タップせず停止します。')
        x, y = button_center(root, package + ':id/run_case')
        self.state['action_started_host_utc'] = utc()
        self.state['tap_count'] = 1  # Record attempted action before sending; never retry an uncertain tap.
        self.event('target_tap_attempted', resource_id=package + ':id/run_case', x=x, y=y)
        self.adb.shell('input', 'tap', x, y)
        until = time.monotonic() + 15
        last_status = None
        while time.monotonic() < until:
            root = self.adb.ui()
            statuses = [n.get('text', '') for n in root.iter('node') if n.get('resource-id') == package + ':id/status']
            last_status = statuses[0] if len(statuses) == 1 else None
            if last_status in self.expected_results():
                self.save_ui('app-result-ui.xml', root)
                self.adb.screenshot(self.out / 'app-result.png')
                self.state['app_result'] = last_status
                self.state['action_result_host_utc'] = utc()
                return
            if last_status and '_error=' in last_status:
                break
            self.sleep(0.2)
        self.adb.screenshot(self.out / 'app-failed.png')
        raise TrialError(f'期待したアプリ応答を確認できません: {last_status!r}。再タップしません。')

    def collect_csv(self):
        default = f'/sdcard/Download/capture-{self.trial_id}.csv'
        while True:
            remote = self.input(f'PCAPdroidで全接続CSVをDownloadへ保存してください。\n保存先パス（Enterで {default}、listで一覧、qで中止）: ').strip() or default
            if remote == 'q':
                raise KeyboardInterrupt()
            if remote == 'list':
                print(self.adb.shell('find', '/sdcard/', '-type', 'f', '-iname', '*.csv', allow_error=True), flush=True)
                continue
            if not remote.startswith(('/sdcard/', '/storage/emulated/0/')) or not remote.lower().endswith('.csv') or any(c in remote for c in ('\x00', '\n', '\r')):
                print('共有ストレージ内のCSVの絶対パスを入力してください。', flush=True)
                continue
            try:
                size = int(self.adb.shell('toybox', 'stat', '-c', '%s', remote).strip())
            except (TrialError, ValueError):
                print('そのファイルを確認できません。保存完了を確認するかlistで探してください。', flush=True)
                continue
            if not 0 < size <= 64 * 1024 * 1024:
                raise TrialError('CSVが空、または64 MiBを超えています。')
            self.adb.run('pull', remote, str(self.out / 'capture.csv'), timeout=60)
            write_json(self.out / 'csv-selection.json', {'remote_path': remote, 'bytes': size, 'pulled_utc': utc()})
            return

    def summarize_capture(self):
        with (self.out / 'capture.csv').open(encoding='utf-8-sig', newline='') as stream:
            reader = csv.DictReader(stream)
            if reader.fieldnames not in (HEADER, HEADER + ['Malicious']):
                raise TrialError('CSVヘッダがPCAPdroid 2.0.2契約と一致しません。')
            rows = list(reader)
        for row in rows:
            if None in row or any(v is None for v in row.values()):
                raise TrialError('CSV列数が曖昧です。原本を保持して停止します。')
            if int(row['IPProto']) not in (6, 17):
                raise TrialError('CSVに未対応のIPプロトコルがあります。')
            for key in ('SrcIP', 'DstIp'):
                ipaddress.ip_address(row[key])
            if not 0 <= int(row['SrcPort']) <= 65535 or not 1 <= int(row['DstPort']) <= 65535:
                raise TrialError('CSVのポート番号が不正です。')
            int(row['UID'])
            for key in ('BytesSent', 'BytesRcvd', 'PktsSent', 'PktsRcvd'):
                if int(row[key]) < 0:
                    raise TrialError('CSVの計数値が不正です。')
            for key in ('FirstSeen', 'LastSeen'):
                if datetime.fromisoformat(row[key]).tzinfo is None:
                    raise TrialError('CSV時刻にタイムゾーンがありません。')
            if datetime.fromisoformat(row['LastSeen']) < datetime.fromisoformat(row['FirstSeen']):
                raise TrialError('CSVの開始・終了時刻が逆転しています。')
        target = [r for r in rows if int(r['UID']) == self.state['target_uid'] and r['PackageName'] == self.state['package']]
        chrome = [r for r in rows if int(r['UID']) == self.state['environment']['chrome_uid']
                  and r['PackageName'] == CHROME and r['DstIp'] == '10.0.2.2' and int(r['DstPort']) == self.http_port]
        server = self.server_events()
        requests = [e for e in server if e.get('event') == 'http_request_received' and e.get('method') == 'POST' and e.get('run_id') == self.trial_id]
        datagrams = [e for e in server if e.get('event') == 'udp_datagram_received' and e.get('run_id') == self.trial_id]
        log = (self.out / 'app-logcat.txt').read_text(errors='replace')
        log_case = self.spec.get('log_case', self.case)
        lines = [s for s in log.splitlines() if f'run={self.trial_id} case={log_case} ' in s]
        action_count = sum(s.endswith(' action_started') for s in lines)
        result_count = sum(any(s.endswith(' ' + expected) for expected in self.expected_results()) for s in lines)
        problems = []
        if action_count != 1 or result_count != 1:
            problems.append('app_logcat_action_or_result_not_exactly_once')
        if not chrome:
            problems.append('local_chrome_connection_rows_missing')
        conflicts = [r for r in rows if (int(r['UID']) == self.state['target_uid']) != (r['PackageName'] == self.state['package'])]
        if conflicts:
            problems.append('target_uid_package_conflict_in_csv')
        phase_rows = {}
        outside_rows = []
        bounds = self.state.get('endpoint_compatible_offset_s')
        if bounds:
            capture_start = datetime.fromisoformat((self.out / 'capture-start-earliest.txt').read_text().strip()).timestamp()
            capture_stop = datetime.fromisoformat((self.out / 'capture-stop-latest.txt').read_text().strip()).timestamp()
            def interval(row):
                return (datetime.fromisoformat(row['FirstSeen']).timestamp() + bounds['lower'],
                        datetime.fromisoformat(row['LastSeen']).timestamp() + bounds['upper'])
            for line, row in enumerate(rows, 2):
                first, last = interval(row)
                if last < capture_start or first > capture_stop:
                    outside_rows.append(line)
            if outside_rows:
                problems.append('csv_rows_outside_capture_time_brackets')
            for phase, control in self.controls.items():
                first = datetime.fromisoformat(control['started_utc']).timestamp()
                last = datetime.fromisoformat(control['ended_utc']).timestamp()
                phase_rows[phase] = [n for n, row in enumerate(rows, 2) if row in chrome
                                     and interval(row)[0] <= last and interval(row)[1] >= first]
                if not phase_rows[phase]:
                    problems.append(phase + '_chrome_control_row_not_time_aligned')
        else:
            problems.append('csv_clock_alignment_unknown')
        if self.case == 'offline':
            if target or requests or datagrams:
                problems.append('offline_control_has_target_network_evidence')
        else:
            expected_port = self.failure_port if self.spec.get('intentional_connection_failure') else self.http_port if self.kind == 'http' else self.https_port if self.kind == 'https' else self.udp_port
            if not any(r['DstIp'] == '10.0.2.2' and int(r['DstPort']) == expected_port and r['IPProto'] == self.spec['ipproto'] for r in target):
                problems.append('expected_target_connection_row_missing')
            observed = requests if self.kind in ('http', 'https') else datagrams
            expected_events = 0 if self.spec.get('intentional_connection_failure') else 1
            if len(observed) != expected_events:
                problems.append('server_target_event_not_exactly_once')
            elif observed and observed[0]['body_sha256'] != hashlib.sha256((('audit=' if self.kind in ('http', 'https') else 'audit:') + self.trial_id).encode()).hexdigest():
                problems.append('server_control_body_hash_mismatch')
        self.state['capture_summary'] = {
            'csv_rows': len(rows), 'target_rows': len(target), 'chrome_local_rows': len(chrome),
            'packages': dict(Counter(r['PackageName'] for r in rows)),
            'server_target_posts': len(requests), 'server_target_datagrams': len(datagrams),
            'app_action_count': action_count, 'app_expected_result_count': result_count,
            'chrome_control_row_candidates': phase_rows, 'csv_rows_outside_capture_brackets': outside_rows,
            'checks': 'expectations_met_under_recorded_conditions' if not problems else 'review_required',
            'problems': problems,
            'limitations': ['This is descriptive collection QC, not an accuracy score or full policy analysis',
                            'Counts and protocol labels do not prove absence, TCP/TLS establishment, or payload semantics',
                            'Time-overlapping Chrome rows are candidates; no CSV/server shared connection ID',
                            'Timestamp checks are conditional on the recorded endpoint clock model']}
        if problems:
            self.state['status'] = 'collected_needs_review'

    def collect(self):
        self.state['bundle_manifest_sha256'] = verify_bundle()
        env = check_environment(self.adb)
        frozen = HERE / 'study/protocol.json'
        if frozen.is_file():
            expected_env = json.loads(frozen.read_text())['environment']
            expected = (expected_env['serial'], expected_env['api'], expected_env['abi'], expected_env['avd_name'])
            actual = (env['serial'], env['android_api'], env['abi'].split(',')[0], env['avd_name'])
            if actual != expected:
                raise TrialError('凍結した研究用AVD条件と異なります。APKをインストールせず停止します。')
        (self.out / 'pcapdroid-package.txt').write_text(env.pop('pcapdroid_package_dump'))
        (self.out / 'chrome-package.txt').write_text(env.pop('chrome_package_dump'))
        self.state['environment'] = env
        self.state['package'] = 'org.example.apkaudit.' + self.spec.get('package_case', self.case)
        package = self.state['package']
        if digest(self.apk) != self.spec['sha256']:
            raise TrialError('APKハッシュが固定した自作対照APKと異なります。インストールしません。')
        shutil.copyfile(self.apk, self.out / 'original.apk')
        self.state['apk_sha256'] = digest(self.out / 'original.apk')
        write_json(self.out / 'intent-before-capture.json', policy_for(self.case, self.http_port, self.udp_port, self.failure_port, self.https_port))
        self.state['intent_sha256'] = digest(self.out / 'intent-before-capture.json')
        self.state['policy_saved_utc'] = utc()
        protocol = {'schema_version': '1.0', 'trial_id': self.trial_id, 'case': self.case,
                    'saved_utc': utc(), 'expected_app_results': self.expected_results(),
                    'expected_target_receive_events': 0 if self.case == 'offline' or self.spec.get('intentional_connection_failure') else 1,
                    'positive_controls': ['browser_before', 'browser_after'],
                    'observe_seconds_after_app_result': self.observe_s,
                    'interpretation': 'Transport failure is not collector failure; unknown UID is not no traffic; partial capture cannot prove absence',
                    'design_status': 'Expectations saved before acquisition; not third-party preregistration'}
        write_json(self.out / 'expectations-before-capture.json', protocol)
        self.state['expectations_sha256'] = digest(self.out / 'expectations-before-capture.json')
        self.state['expectations_saved_utc'] = protocol['saved_utc']
        for name in ('protocol.json', 'gold-spec.json'):
            source = HERE / 'study' / name
            if source.is_file():
                shutil.copyfile(source, self.out / ('frozen-' + name))
                self.state['frozen_' + name.removesuffix('.json').replace('-', '_') + '_sha256'] = digest(source)
        if 'Success' not in self.adb.run('install', '-r', str(self.out / 'original.apk'), timeout=90):
            raise TrialError('APKのインストール成功を確認できません。')
        dump = self.adb.shell('dumpsys', 'package', package)
        (self.out / 'app-package.txt').write_text(dump)
        self.state['target_uid'] = installation_uid(dump)
        paths = self.adb.shell('pm', 'path', package)
        (self.out / 'installed-apk-path.txt').write_text(paths)
        bases = [p.removeprefix('package:') for p in paths.splitlines() if p.startswith('package:')]
        if len(bases) != 1 or not bases[0].startswith('/data/app/'):
            raise TrialError('単一のインストールAPKのパスを確認できません。')
        checksum = self.adb.shell('toybox', 'sha256sum', bases[0])
        (self.out / 'installed-apk-sha256.txt').write_text(checksum)
        if not checksum.startswith(self.state['apk_sha256'] + ' '):
            raise TrialError('端末上のAPKと入力APKのハッシュが一致しません。')
        self.state['installed_hash_verified_before_capture_utc'] = utc()
        with self.reference_servers() as servers:
            self.server_event_lock = servers.events.lock
            self.http_port, self.udp_port = servers.addresses['http'][1], servers.addresses['udp'][1]
            if 'https' in servers.addresses:
                self.https_port = servers.addresses['https'][1]
            self.start_logcat()
            before = self.measure_clock('before')
            if before['summary']['status'] != 'measured_under_batch_assumptions':
                raise TrialError('取得前の時計差が不明です。原サンプルを保存して停止します。')
            self.stamp('capture-start-earliest.txt')
            self.state['capture_start_requested'] = True
            self.confirm('PCAPdroidを開き、全アプリ・VPN方式・TLS復号なしを確認して記録を開始してください。', 'start')
            self.capture_active = True
            self.stamp('capture-start-latest.txt')
            self.health('before')
            self.run_action()
            if self.logcat is not None and self.logcat.poll() is not None:
                raise TrialError('logcatが予期せず終了しています。')
            self.state['observation_started_utc'] = utc()
            begin = time.monotonic()
            print(f'{self.observe_s}秒間観測します。この間は追加操作をしないでください。', flush=True)
            self.sleep(self.observe_s)
            self.state['observation_elapsed_monotonic_s'] = time.monotonic() - begin
            self.state['observation_ended_utc'] = utc()
            self.health('after')
            self.stamp('capture-stop-earliest.txt')
            self.confirm('PCAPdroidの記録を停止してください。', 'stop')
            self.capture_active = False
            self.state['capture_stop_confirmed'] = True
            self.stamp('capture-stop-latest.txt')
            after = self.measure_clock('after')
            if after['summary']['status'] == 'measured_under_batch_assumptions':
                low = max(before['summary']['offset_lower_s'], after['summary']['offset_lower_s'])
                high = min(before['summary']['offset_upper_s'], after['summary']['offset_upper_s'])
                if low <= high:
                    self.state['clock_alignment_status'] = 'conditional'
                    self.state['endpoint_compatible_offset_s'] = {'lower': low, 'upper': high}
            coverage = self.input('取得中の停止・一時停止・エラーはありましたか？ none / problem / unknown: ').strip()
            self.state['coverage_status'] = {'none': 'operator_attested', 'problem': 'incomplete'}.get(coverage, 'unknown')
            self.event('operator_coverage_statement', response=coverage)
            self.collect_csv()
            if digest(self.apk) != self.spec['sha256']:
                raise TrialError('実験中に入力APKが変更されました。')
        self.stop_logcat()
        self.state['status'] = 'collected'
        self.summarize_capture()

    def execute(self):
        archive = Path(str(self.out) + '.zip')
        if self.out.exists() or archive.exists():
            raise TrialError('保存先またはZIPが既にあります。新しい実験IDを指定してください。')
        self.out.mkdir(parents=True)
        exit_code = 0
        try:
            self.collect()
            if self.state['status'] != 'collected':
                exit_code = 4
        except (KeyboardInterrupt, EOFError):
            self.state.update(status='cancelled', error='operator_interrupted')
            exit_code = 130
        except Exception as exc:
            self.state.update(status='failed', error=f'{type(exc).__name__}: {exc}')
            print('記録を残して停止します: ' + str(exc), flush=True)
            exit_code = 4
        finally:
            try:
                self.stop_logcat()
            except Exception as exc:
                self.state['logcat_cleanup_error'] = str(exc)
                self.state['status'] = 'failed'
                exit_code = 4
            self.state['manual_capture_stop_required'] = bool(self.state.get('capture_start_requested') and not self.state.get('capture_stop_confirmed'))
            if self.state['manual_capture_stop_required']:
                print('PCAPdroidの停止は確認できていません。エミュレータを確認し、記録中なら停止してください。', flush=True)
            self.state['ended_utc'] = utc()
            write_json(self.out / 'trial.json', self.state)
            entries = [{'path': str(p.relative_to(self.out)), 'sha256': digest(p), 'bytes': p.stat().st_size}
                       for p in sorted(self.out.rglob('*')) if p.is_file()]
            write_json(self.out / 'manifest.json', {'files': entries})
            with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
                for p in sorted(self.out.rglob('*')):
                    if p.is_file():
                        z.write(p, str(Path(self.out.name) / p.relative_to(self.out)))
            print(json.dumps({'saved_zip': str(archive), 'status': self.state['status'],
                              'quality': self.state['quality'], 'exit_code': exit_code}, ensure_ascii=False), flush=True)
        return exit_code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case', choices=CASES, default='offline')
    parser.add_argument('--serial', default='emulator-5554')
    parser.add_argument('--trial-id')
    parser.add_argument('--out-root', type=Path, default=Path('handoff'))
    parser.add_argument('--apk', type=Path)
    parser.add_argument('--observe-seconds', type=int, default=30, metavar='SECONDS')
    parser.add_argument('--check', action='store_true', help='Read-only environment and APK readiness check')
    args = parser.parse_args()
    if not 1 <= args.observe_seconds <= 600:
        parser.error('--observe-secondsは1〜600秒です。')
    if not re.fullmatch(r'emulator-\d+', args.serial):
        parser.error('対象は明示したAndroid Emulatorのみです。')
    trial_id = args.trial_id or f'{args.case}-auto-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    if not re.fullmatch(r'[A-Za-z0-9_.-]{1,80}', trial_id) or trial_id in ('.', '..'):
        parser.error('実験IDは英数字・ドット・ハイフン・アンダースコア、80文字以内です。')
    apk = args.apk or HERE / 'apks' / (args.case + '.apk')
    if not args.apk and not apk.exists():
        apk = HERE.parent / CASES[args.case].get('apk_relative', 'runs/control-apks-v3-ui/' + args.case + '.apk')
    try:
        verify_bundle()
        if not apk.is_file() or digest(apk) != CASES[args.case]['sha256']:
            raise TrialError('対応するAPKがないか、ハッシュが異なります。配布ZIPを展開して使ってください。')
        if args.check:
            env = check_environment(Adb(args.serial))
            env.pop('pcapdroid_package_dump')
            env.pop('chrome_package_dump')
            print(json.dumps({'ready': True, 'case': args.case, 'apk_sha256': digest(apk), 'environment': env}, ensure_ascii=False, indent=2))
            return 0
        if not sys.stdin.isatty():
            raise TrialError('このランナーはPCAPdroid操作を確認する対話ターミナルで実行してください。')
        return GuidedTrial(args.case, trial_id, args.out_root.expanduser().resolve() / trial_id,
                           apk.resolve(), args.serial, args.observe_seconds).execute()
    except (OSError, TrialError) as exc:
        print('実行できません: ' + str(exc), file=sys.stderr)
        return 3


if __name__ == '__main__':
    raise SystemExit(main())
