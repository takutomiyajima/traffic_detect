#!/usr/bin/env python3
"""Additive, policy-first entry point; existing installation is not overwritten."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys


def main():
    sys.dont_write_bytecode=True;os.environ['PYTHONDONTWRITEBYTECODE']='1'
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--project',type=Path,default=Path.home()/'Documents/apk-audit-unified-v1')
    p.add_argument('--apk',type=Path);p.add_argument('--intent',type=Path);p.add_argument('--scenario',type=Path)
    p.add_argument('--out',type=Path);p.add_argument('--serial',default='emulator-5554')
    p.add_argument('--static-only',action='store_true');p.add_argument('--suite',action='store_true')
    p.add_argument('--non-interactive',action='store_true')
    a=p.parse_args();bundle=Path(__file__).resolve().parent;project=a.project.expanduser().resolve()
    try:
        manifest=json.loads((bundle/'BUNDLE-MANIFEST.json').read_text())
        for name,digest in manifest['files'].items():
            q=(bundle/name).resolve()
            if not q.is_relative_to(bundle) or not q.is_file() or hashlib.sha256(q.read_bytes()).hexdigest()!=digest:
                raise ValueError('配布ファイルが変更・欠落しています: '+name)
        for name,digest in manifest['compatible_core'].items():
            q=project/'src/apk_audit'/name
            if not q.is_file() or hashlib.sha256(q.read_bytes()).hexdigest()!=digest:
                raise ValueError('既存プロジェクトの対応版と異なります。上書きせず、この表示を返してください: '+name)
        sys.path.insert(0,str(project/'src'))
        previous=[x for x in os.environ.get('PYTHONPATH','').split(os.pathsep) if x]
        os.environ['PYTHONPATH']=os.pathsep.join([str(project/'src'),*[x for x in previous if x!=str(project/'src')]])
        import apk_audit
        apk_audit.__path__.insert(0,str(bundle/'payload'))
        if a.suite:
            if a.apk or a.intent or a.scenario or a.static_only:raise ValueError('--suiteはAPK等の個別指定と併用しません')
            from apk_audit.intent_seeds import run_suite
            print('許可入力先・意図外固定先・観測時間外の3条件を各3回、計9試行観測します。目安10〜20分です。',flush=True)
            result,code=run_suite(bundle/'fixtures',bundle/'examples/intent-recorded-input-v1.1.json',
                a.out or project/'runs/intent-seeds-001',a.serial,a.non_interactive)
        else:
            if not a.apk or not a.intent:raise ValueError('--apkと、解析前に決めた--intentが必要です')
            from apk_audit.cli import parser
            from apk_audit.pipeline import analyze
            out=a.out or project/'runs/intent-audit-001'
            argv=['analyze','--apk',str(a.apk.expanduser()),'--intent',str(a.intent.expanduser()),'--serial',a.serial,'--out',str(out)]
            if a.scenario:argv+=['--scenario',str(a.scenario.expanduser())]
            if a.static_only:argv+=['--static-only']
            result,code=analyze(parser().parse_args(argv))
            from apk_audit.research_bundle import pack
            result['archive']=str(pack(out))
        print(json.dumps(result,ensure_ascii=False,indent=2));return code
    except (Exception,KeyboardInterrupt) as exc:
        print(json.dumps({'error':str(exc),'type':type(exc).__name__},ensure_ascii=False),file=sys.stderr);return 4


if __name__=='__main__':raise SystemExit(main())
