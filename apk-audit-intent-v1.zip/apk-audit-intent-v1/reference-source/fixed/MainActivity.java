package org.example.apkaudit.compare.fixed;

import android.app.Activity;
import android.os.Bundle;
import android.net.Uri;
import android.widget.TextView;
import java.net.URL;
import java.net.HttpURLConnection;

/** Source-defined reference only: no subscriptions, accounts or stored data. */
public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        TextView text = new TextView(this);
        text.setText("APK comparison reference: fixed\nAutomatic observation; no taps required.");
        text.setPadding(24, 100, 24, 24);
        setContentView(text);
        final String input = getIntent().getDataString();
        if (input == null) return;
        Uri uri = Uri.parse(input);
        final String leaf = uri.getLastPathSegment();
        if (!"http".equals(uri.getScheme()) || !"10.0.2.2".equals(uri.getHost()) ||
            (uri.getPort() != 18762 && uri.getPort() != 18763) ||
            leaf == null || !leaf.matches("[a-f0-9]{32}\\.xml")) return;
        final String token = leaf.substring(0, 32);
        new Thread(new Runnable() {
            public void run() {
                HttpURLConnection c = null;
                try {
                    
                    URL url = endpoint(input);
                    c = (HttpURLConnection) url.openConnection();
                    c.setConnectTimeout(3000);
                    c.setReadTimeout(3000);
                    c.setInstanceFollowRedirects(false);
                    c.setRequestProperty("X-Apk-Audit-Token", token);
                    c.setRequestProperty("Connection", "close");
                    c.setRequestMethod("GET");
                    int status = c.getResponseCode();
                    java.io.InputStream stream = c.getInputStream();
                    byte[] data = new byte[1024];
                    int total = 0, n;
                    while ((n = stream.read(data)) >= 0 && total < 65536) total += n;
                    stream.close();
                    android.util.Log.i("AuditComparison", "case=fixed token=" + token + " status=" + status);
                } catch (Exception e) {
                    android.util.Log.i("AuditComparison", "case=fixed token=" + token + " error=" + e.getClass().getSimpleName());
                } finally {
                    if (c != null) c.disconnect();
                }
            }
        }).start();
    }

    private String savedEndpoint() { return "http://".concat("10.0.").concat("2.2:18761/fixed.xml"); }
private URL endpoint(String input) throws Exception { return new URL(savedEndpoint()); }
}
