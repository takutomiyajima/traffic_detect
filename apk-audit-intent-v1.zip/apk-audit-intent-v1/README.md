# 開発意図と静的・動的解析の照合（intent-v1）

既存のDocuments/apk-audit-unified-v1を使う追加版です。このフォルダをDocumentsへ展開します。
既存ソースや過去の実験結果の上書き・アプリデータの消去は行いません。

## 次の手作業：参照用の意図照合9試行

Android StudioでPixel_8_Edited_API_35（emulator-5554）を起動してください。
Python参照サーバーを18761/18762/18763で動かしている場合だけ停止し、次を実行します。

```sh
"$HOME/Documents/apk-audit-unified-v1/.venv/bin/python" \
  "$HOME/Documents/apk-audit-intent-v1/run_intent.py" \
  --suite \
  --out "$HOME/Documents/apk-audit-unified-v1/runs/intent-seeds-001"
```

目安10〜20分です。アプリの追加操作はせず、PCAPdroid制御・VPNの許可画面だけ確認します。
最後の追加操作の質問には実際の操作状況を答え、表示されたintent-seeds-001.return.zipを返します。
同名フォルダがある場合は削除せず、新しい名前にします。失敗時の自動再試行はしません。
ZIPには取得原本が含まれるため、GitHubへ公開せず研究者用として扱ってください。

9試行は、記録した入力先への通信、宣言外の固定先への通信、観測時間外の要求予定、の各3回です。
今回用の研究参照APK3本をインストールし、各試行の終了後にその参照パッケージだけ停止します。
遅延75秒のスレッドは観測後に停止するため、未観測を通信しない証拠にしません。
4本目permission-only.apkは静的な権限宣言の素材で、上記9試行ではインストールしません。

## 自分のAPKを解析する入口

examplesの意図JSONを別の場所へコピーし、解析結果を見る前に実際の目的に合わせて編集します。
空欄の意味で禁止を選ばず、不明なカテゴリはunspecifiedにします。

```sh
"$HOME/Documents/apk-audit-unified-v1/.venv/bin/python" \
  "$HOME/Documents/apk-audit-intent-v1/run_intent.py" \
  --apk "/path/to/my-app.apk" \
  --intent "/path/to/my-intent.json" \
  --out "$HOME/Documents/apk-audit-unified-v1/runs/my-intent-001"
```

シナリオ未指定は起動と待機のみです。ボタン操作等が必要なら--scenarioを指定します。
利用者入力先の例外は、同一対象UID・明示open_uri操作・固定シナリオ・完全性のある記録・
ホスト／ポート／観測プロトコル・時刻区間が一致する範囲に限ります。
任意の画面での手入力、リダイレクト先、HTTPS本文、コード経路や目的の推論は保証範囲に含めません。
TLSしか分からない場合は、HTTPSのアプリケーション意味を確認済みとせず保留します。

意図JSONは照合条件であり、通信を遮断する設定ではありません。
出力summary.htmlの先頭が意図照合、下部が静的・動的の差分です。整合は観測範囲の判断であり、
プライバシー保護・安全性・全通信の網羅・送信内容の適切性を保証しません。
権限・SDK・URLの静的候補と、実際に観測した対象通信は区別します。

## 実施済みと未実施

参照APKのコンパイル・署名検査、実DEXと静的権限の点検、合成入力とホストHTTPによる自動検査を実施しました。
この新しいintent-v1のAndroid実測は返却後に点検します。過去29試行を事前意図の新評価へ付け替えません。
期待値は解析器出力から作らずソース仕様で決めましたが、同じ開発者の参照素材で独立精度評価ではありません。
FROZEN-PROTOCOL.jsonの意図と条件を今回のsuiteでそのまま使います。実アプリでの自分の意図とは別物です。
